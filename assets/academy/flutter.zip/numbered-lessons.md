# Cross-platform Mobile Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

UI state: The visible interface is a projection of state. User actions update state and trigger a new view.

Apply ui state in Cross-platform Mobile Developer: Use the concept to complete this role exercise: Create a Flutter app and replace the counter label with a task count

Widgets and state transitions: Flutter rebuilds widgets from state. Keep the event that changes state distinct from build(), and use keys when a list item's identity must survive reordering.

### UI state

The visible interface is a projection of state. User actions update state and trigger a new view. In this role, work through: Adding A and B then reordering must preserve each item's completion state. The practical workshop develops this into: Create the Flutter sample, replace the counter with a task form, validate blanks and display keyed rows. Run flutter test with a widget test that taps Add and finds the title.

Mental model: A scoreboard reflects the current score rather than owning the game rules.

Boundary: Rendering frameworks differ; re-rendering does not automatically persist data.

Role application: A blueprint is redrawn when the room changes; drawing it must not move the furniture.

Flutter rebuilds widgets from state. Keep the event that changes state distinct from build(), and use keys when a list item's identity must survive reordering.

Worked example: Adding A and B then reordering must preserve each item's completion state.

Shared foundation example: Adding one task changes count from zero to one.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Flutter and Dart (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Cross-platform Mobile Developer: Adding A and B then reordering must preserve each item's completion state.

Predict the worked case

Read this case without running a tool: Adding A and B then reordering must preserve each item's completion state. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in ui state.

Connect the concept to the role

Apply this rule: The visible interface is a projection of state. User actions update state and trigger a new view. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Rendering frameworks differ; re-rendering does not automatically persist data.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies ui state to this case: Adding A and B then reordering must preserve each item's completion state. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Adding A and B then reordering must preserve each item's completion state. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for UI state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ui state. Use the glossary below, then write your prediction for: Adding A and B then reordering must preserve each item's completion state. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Cross-platform Mobile Developer role interview. Explain ui state using this case: Adding A and B then reordering must preserve each item's completion state. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ui state to a system or workflow you know. Explain ui state using this case: Adding A and B then reordering must preserve each item's completion state. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which state must survive app restart?

Interview: Explain ui state using this case: Adding A and B then reordering must preserve each item's completion state. State the evidence, one alternative and where the mental model stops.

Quiz: After the Widgets and state transitions rehearsal, check this foundation: A screen shows an old count after the underlying list changes. What should you inspect first?

How the view derives from state and receives change notifications.

Whether a screenshot contains the desired count.

Whether an unrelated server restart changes the display.

Reference: How the view derives from state and receives change notifications. — Trace the action, state update and rendered projection before adding a second conflicting source of truth.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

### Widgets and state transitions

Flutter rebuilds widgets from state. Keep the event that changes state distinct from build(), and use keys when a list item's identity must survive reordering. In this role, work through: Adding A and B then reordering must preserve each item's completion state. The practical workshop develops this into: Create the Flutter sample, replace the counter with a task form, validate blanks and display keyed rows. Run flutter test with a widget test that taps Add and finds the title.

Mental model: A blueprint is redrawn when the room changes; drawing it must not move the furniture.

Boundary: Mutating the list inside build can duplicate work; update it only through an action.

Worked example: Adding A and B then reordering must preserve each item's completion state.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Flutter and Dart (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Cross-platform Mobile Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create the Flutter sample, replace the counter with a task form, validate blanks and display keyed rows. Run flutter test with a widget test that taps Add and finds the title.

Start the native template

Run the Flutter scaffold and open lib/main.dart. Start with the generated counter before changing state.

```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter run
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

Adding A and B then reordering must preserve each item's completion state. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create the Flutter sample, replace the counter with a task form, validate blanks and display keyed rows. Run flutter test with a widget test that taps Add and finds the title.

```
flutter test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Exactly one row per valid add and stable state when order changes.

Role workshop · debug and verify

Mutating the list inside build can duplicate work; update it only through an action. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save widget implementation and widget tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Exactly one row per valid add and stable state when order changes.

Expected: Exactly one row per valid add and stable state when order changes.

Troubleshoot: The role exercise differs from the prediction: Mutating the list inside build can duplicate work; update it only through an action.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-beginner-2.md: widget implementation and widget tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with widgets and state transitions. Use the glossary below, then write your prediction for: Adding A and B then reordering must preserve each item's completion state. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Cross-platform Mobile Developer role interview. Explain widgets and state transitions using this case: Adding A and B then reordering must preserve each item's completion state. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate widgets and state transitions to a system or workflow you know. Explain widgets and state transitions using this case: Adding A and B then reordering must preserve each item's completion state. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Mutating the list inside build can duplicate work; update it only through an action.

Interview: Explain widgets and state transitions using this case: Adding A and B then reordering must preserve each item's completion state. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Adding A and B then reordering must preserve each item's completion state.

Exactly one row per valid add and stable state when order changes.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Exactly one row per valid add and stable state when order changes. — Flutter rebuilds widgets from state. Keep the event that changes state distinct from build(), and use keys when a list item's identity must survive reordering. Exactly one row per valid add and stable state when order changes.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Local persistence and offline work: Save data explicitly and show whether it is local, queued or synchronized.

Apply local persistence and offline work in Cross-platform Mobile Developer: Use the concept to complete this role exercise: Persist tasks and test an offline indicator

Offline persistence adapter: Separate the widget tree from the local store so a fake can test loading and failure. Surface an unsaved state instead of claiming persistence before the write completes.

### Local persistence and offline work

Save data explicitly and show whether it is local, queued or synchronized. In this role, work through: A failed save leaves the draft visible and marked unsaved. The practical workshop develops this into: Define a repository interface, add a platform-supported persistence implementation and a failing fake. Test restart on one target and use the fake to verify the error UI.

Mental model: An outbox keeps letters until the courier is available.

Boundary: Local storage can be removed or unavailable; it is not cloud backup.

Role application: The screen is a display connected to a filing service that can fail.

Separate the widget tree from the local store so a fake can test loading and failure. Surface an unsaved state instead of claiming persistence before the write completes.

Worked example: A failed save leaves the draft visible and marked unsaved.

Shared foundation example: Create a task offline, restart and verify it remains marked unsent.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Flutter and Dart (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Cross-platform Mobile Developer: A failed save leaves the draft visible and marked unsaved.

Predict the worked case

Read this case without running a tool: A failed save leaves the draft visible and marked unsaved. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in local persistence and offline work.

Connect the concept to the role

Apply this rule: Save data explicitly and show whether it is local, queued or synchronized. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Local storage can be removed or unavailable; it is not cloud backup.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies local persistence and offline work to this case: A failed save leaves the draft visible and marked unsaved. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A failed save leaves the draft visible and marked unsaved. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Local persistence and offline work; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with local persistence and offline work. Use the glossary below, then write your prediction for: A failed save leaves the draft visible and marked unsaved. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Cross-platform Mobile Developer role interview. Explain local persistence and offline work using this case: A failed save leaves the draft visible and marked unsaved. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate local persistence and offline work to a system or workflow you know. Explain local persistence and offline work using this case: A failed save leaves the draft visible and marked unsaved. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the user see a queued status?

Interview: Explain local persistence and offline work using this case: A failed save leaves the draft visible and marked unsaved. State the evidence, one alternative and where the mental model stops.

Quiz: After the Offline persistence adapter rehearsal, check this foundation: A record is saved locally while offline. Which status is justified before server acknowledgment?

Synchronized because it survives local restart.

Saved locally / pending synchronization.

Rejected because offline work cannot be stored.

Reference: Saved locally / pending synchronization. — Local durability and remote acknowledgment are different states. Communicate them separately.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

### Offline persistence adapter

Separate the widget tree from the local store so a fake can test loading and failure. Surface an unsaved state instead of claiming persistence before the write completes. In this role, work through: A failed save leaves the draft visible and marked unsaved. The practical workshop develops this into: Define a repository interface, add a platform-supported persistence implementation and a failing fake. Test restart on one target and use the fake to verify the error UI.

Mental model: The screen is a display connected to a filing service that can fail.

Boundary: Hot reload is not a restart test; close and reopen the app process.

Worked example: A failed save leaves the draft visible and marked unsaved.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Flutter and Dart (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Cross-platform Mobile Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Define a repository interface, add a platform-supported persistence implementation and a failing fake. Test restart on one target and use the fake to verify the error UI.

Start the native template

Run the Flutter scaffold and open lib/main.dart. Start with the generated counter before changing state.

```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter run
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

A failed save leaves the draft visible and marked unsaved. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Define a repository interface, add a platform-supported persistence implementation and a failing fake. Test restart on one target and use the fake to verify the error UI.

```
flutter test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Saved items survive restart; failed writes never show a saved badge.

Role workshop · debug and verify

Hot reload is not a restart test; close and reopen the app process. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save repository interface, restart log and failure widget test. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Saved items survive restart; failed writes never show a saved badge.

Expected: Saved items survive restart; failed writes never show a saved badge.

Troubleshoot: The role exercise differs from the prediction: Hot reload is not a restart test; close and reopen the app process.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-intermediate-2.md: repository interface, restart log and failure widget test; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with offline persistence adapter. Use the glossary below, then write your prediction for: A failed save leaves the draft visible and marked unsaved. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Cross-platform Mobile Developer role interview. Explain offline persistence adapter using this case: A failed save leaves the draft visible and marked unsaved. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate offline persistence adapter to a system or workflow you know. Explain offline persistence adapter using this case: A failed save leaves the draft visible and marked unsaved. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Hot reload is not a restart test; close and reopen the app process.

Interview: Explain offline persistence adapter using this case: A failed save leaves the draft visible and marked unsaved. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A failed save leaves the draft visible and marked unsaved.

Ignore the failing case and keep only the successful screenshot.

Saved items survive restart; failed writes never show a saved badge.

Treat any successful command as proof that all business and access rules passed.

Reference: Saved items survive restart; failed writes never show a saved badge. — Separate the widget tree from the local store so a fake can test loading and failure. Surface an unsaved state instead of claiming persistence before the write completes. Saved items survive restart; failed writes never show a saved badge.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Lifecycle and synchronization: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.

Apply lifecycle and synchronization in Cross-platform Mobile Developer: Use the concept to complete this role exercise: Test a repeated sync request and accessibility on two platform sizes

Cross-platform release evidence: A shared codebase still encounters different text sizes, navigation and platform APIs. Test the same acceptance contract on each intended platform and name untested targets.

### Lifecycle and synchronization

Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. In this role, work through: Long titles and large system text must not hide the Add action on a small screen. The practical workshop develops this into: Run the task flow on two supported sizes or platforms, interrupt sync and repeat a queued operation. Record screenshots, target SDK versions and failure outcomes before preparing a release checklist.

Mental model: A bookmark preserves your place when a reading session is interrupted.

Boundary: A bookmark cannot decide how to merge two different edits.

Role application: One recipe may need different ovens; the result must still be checked in each.

A shared codebase still encounters different text sizes, navigation and platform APIs. Test the same acceptance contract on each intended platform and name untested targets.

Worked example: Long titles and large system text must not hide the Add action on a small screen.

Shared foundation example: Retry the same task ID after reconnecting and verify one remote record.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Flutter and Dart (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Cross-platform Mobile Developer: Long titles and large system text must not hide the Add action on a small screen.

Predict the worked case

Read this case without running a tool: Long titles and large system text must not hide the Add action on a small screen. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in lifecycle and synchronization.

Connect the concept to the role

Apply this rule: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A bookmark cannot decide how to merge two different edits.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies lifecycle and synchronization to this case: Long titles and large system text must not hide the Add action on a small screen. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Long titles and large system text must not hide the Add action on a small screen. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Lifecycle and synchronization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with lifecycle and synchronization. Use the glossary below, then write your prediction for: Long titles and large system text must not hide the Add action on a small screen. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Cross-platform Mobile Developer role interview. Explain lifecycle and synchronization using this case: Long titles and large system text must not hide the Add action on a small screen. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate lifecycle and synchronization to a system or workflow you know. Explain lifecycle and synchronization using this case: Long titles and large system text must not hide the Add action on a small screen. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens if two devices change the same title offline?

Interview: Explain lifecycle and synchronization using this case: Long titles and large system text must not hide the Add action on a small screen. State the evidence, one alternative and where the mental model stops.

Quiz: After the Cross-platform release evidence rehearsal, check this foundation: An app reconnects after an interrupted upload. Which retry behavior avoids creating a new logical record?

Generate a new record ID on every attempt.

Delete local state before checking the response.

Reuse the stable record ID and apply an explicit conflict policy.

Reference: Reuse the stable record ID and apply an explicit conflict policy. — Stable identity helps replay; concurrent edits still need a deliberate resolution strategy.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

### Cross-platform release evidence

A shared codebase still encounters different text sizes, navigation and platform APIs. Test the same acceptance contract on each intended platform and name untested targets. In this role, work through: Long titles and large system text must not hide the Add action on a small screen. The practical workshop develops this into: Run the task flow on two supported sizes or platforms, interrupt sync and repeat a queued operation. Record screenshots, target SDK versions and failure outcomes before preparing a release checklist.

Mental model: One recipe may need different ovens; the result must still be checked in each.

Boundary: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity.

Worked example: Long titles and large system text must not hide the Add action on a small screen.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Flutter and Dart (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Cross-platform Mobile Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run the task flow on two supported sizes or platforms, interrupt sync and repeat a queued operation. Record screenshots, target SDK versions and failure outcomes before preparing a release checklist.

Start the native template

Run the Flutter scaffold and open lib/main.dart. Start with the generated counter before changing state.

```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter run
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

Long titles and large system text must not hide the Add action on a small screen. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run the task flow on two supported sizes or platforms, interrupt sync and repeat a queued operation. Record screenshots, target SDK versions and failure outcomes before preparing a release checklist.

```
flutter devices
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: No clipped essential controls; duplicate retry creates one effect in the test service.

Role workshop · debug and verify

A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save cross-platform evidence matrix and release checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No clipped essential controls; duplicate retry creates one effect in the test service.

Expected: No clipped essential controls; duplicate retry creates one effect in the test service.

Troubleshoot: The role exercise differs from the prediction: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-advanced-2.md: cross-platform evidence matrix and release checklist; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cross-platform release evidence. Use the glossary below, then write your prediction for: Long titles and large system text must not hide the Add action on a small screen. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Cross-platform Mobile Developer role interview. Explain cross-platform release evidence using this case: Long titles and large system text must not hide the Add action on a small screen. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cross-platform release evidence to a system or workflow you know. Explain cross-platform release evidence using this case: Long titles and large system text must not hide the Add action on a small screen. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity.

Interview: Explain cross-platform release evidence using this case: Long titles and large system text must not hide the Add action on a small screen. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Long titles and large system text must not hide the Add action on a small screen.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

No clipped essential controls; duplicate retry creates one effect in the test service.

Reference: No clipped essential controls; duplicate retry creates one effect in the test service. — A shared codebase still encounters different text sizes, navigation and platform APIs. Test the same acceptance contract on each intended platform and name untested targets. No clipped essential controls; duplicate retry creates one effect in the test service.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
