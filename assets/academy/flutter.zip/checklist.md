# Request tracker — mobile acceptance evidence
Create the project using the official platform tutorial linked in your course.
Do not install unofficial SDK bundles. Use a simulator with synthetic tasks.

## Beginner
[ ] App starts and displays one task title.
[ ] Add button changes visible task count from 0 to 1.
[ ] Empty input shows a readable error.
## Intermediate
[ ] Save task locally; restart app; task remains.
[ ] Label controls for screen readers and test large text.
[ ] Demonstrate offline state without claiming a network save.
## Advanced
[ ] Queue a task offline and retry sync when online.
[ ] Repeating the same identifier does not create a duplicate.
[ ] Record storage, network and UI tests separately.

Evidence table: device/emulator | OS/SDK | input | expected | observed | screenshot.
