# Cross-platform Mobile Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Widgets and state transitions

Flutter rebuilds widgets from state. Keep the event that changes state distinct from build(), and use keys when a list item's identity must survive reordering.
Mental model: A blueprint is redrawn when the room changes; drawing it must not move the furniture.
Case: Adding A and B then reordering must preserve each item's completion state.
Task: Create the Flutter sample, replace the counter with a task form, validate blanks and display keyed rows. Run flutter test with a widget test that taps Add and finds the title.
Acceptance: Exactly one row per valid add and stable state when order changes.
Troubleshooting: Mutating the list inside build can duplicate work; update it only through an action.
Deliverable: widget implementation and widget tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Offline persistence adapter

Separate the widget tree from the local store so a fake can test loading and failure. Surface an unsaved state instead of claiming persistence before the write completes.
Mental model: The screen is a display connected to a filing service that can fail.
Case: A failed save leaves the draft visible and marked unsaved.
Task: Define a repository interface, add a platform-supported persistence implementation and a failing fake. Test restart on one target and use the fake to verify the error UI.
Acceptance: Saved items survive restart; failed writes never show a saved badge.
Troubleshooting: Hot reload is not a restart test; close and reopen the app process.
Deliverable: repository interface, restart log and failure widget test

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Cross-platform release evidence

A shared codebase still encounters different text sizes, navigation and platform APIs. Test the same acceptance contract on each intended platform and name untested targets.
Mental model: One recipe may need different ovens; the result must still be checked in each.
Case: Long titles and large system text must not hide the Add action on a small screen.
Task: Run the task flow on two supported sizes or platforms, interrupt sync and repeat a queued operation. Record screenshots, target SDK versions and failure outcomes before preparing a release checklist.
Acceptance: No clipped essential controls; duplicate retry creates one effect in the test service.
Troubleshooting: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity.
Deliverable: cross-platform evidence matrix and release checklist

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
