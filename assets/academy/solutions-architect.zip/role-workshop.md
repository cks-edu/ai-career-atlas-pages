# Solutions Architect — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Requirements into acceptance criteria

Translate business language into measurable outcomes before selecting products. Include users, peak load, data sensitivity and recovery expectations.
Mental model: A builder needs room sizes and occupancy before choosing materials.
Case: Available all the time is incomplete until availability window and acceptable outage are defined.
Task: Interview a fictional service owner using a requirements worksheet. Convert five vague statements into measurable criteria and mark assumptions needing confirmation.
Acceptance: A signed-off-style brief with clear unknowns, not invented stakeholder answers.
Troubleshooting: Do not assign a demanding SLO without its cost and operational implications.
Deliverable: requirements and assumptions register

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Service selection and responsibility

Compare services against constraints, integration fit and operating responsibility. Similar product names across clouds do not imply equivalent networking, identity or cost behavior.
Mental model: Two rental contracts may offer similar rooms but different maintenance obligations.
Case: A managed database shifts patching work but still needs access and recovery design.
Task: Create a two-option architecture table covering compute, data, identity, observability and failure modes. Link each choice to an acceptance criterion and estimate usage assumptions.
Acceptance: A defensible recommendation with an explicit alternative.
Troubleshooting: A list of logos is not an architecture; draw data and control flows.
Deliverable: solution diagram and weighted trade-off table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Operational readiness review

A solution is ready only when deployment, monitoring, security ownership and recovery have evidence. Distinguish proposed controls from tested controls.
Mental model: A completed building needs an operating manual and evacuation drill.
Case: A backup checkbox cannot substitute for a successful restore rehearsal.
Task: Prepare a deployment sequence, synthetic transaction, incident contacts and restore test. Run local components and mark cloud actions pending if no sandbox exists.
Acceptance: A readiness decision with evidence links and blocking gaps.
Troubleshooting: A green deployment task can conceal an inaccessible application; test the user journey.
Deliverable: operational readiness pack and handover guide

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
