# Solutions Architect

Software Engineering

Start with requirements into acceptance criteria. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward operational readiness pack and handover guide.

## beginner

Interview a fictional service owner using a requirements worksheet. Convert five vague statements into measurable criteria and mark assumptions needing confirmation.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Boundaries and ownership
A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: Drawing more boxes does not make a system more reliable.
Example: The order service owns orders; a notification consumer handles messages.
Recall: Which component owns the truth about whether an order exists?

### Requirements into acceptance criteria
Translate business language into measurable outcomes before selecting products. Include users, peak load, data sensitivity and recovery expectations.
Mental model: A builder needs room sizes and occupancy before choosing materials.
Limit: Do not assign a demanding SLO without its cost and operational implications.
Example: Available all the time is incomplete until availability window and acceptable outage are defined.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not assign a demanding SLO without its cost and operational implications.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Available all the time is incomplete until availability window and acceptable outage are defined. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Interview a fictional service owner using a requirements worksheet. Convert five vague statements into measurable criteria and mark assumptions needing confirmation.
Expected: A signed-off-style brief with clear unknowns, not invented stakeholder answers.

6. Role workshop · debug and verify
Do not assign a demanding SLO without its cost and operational implications. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save requirements and assumptions register. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A signed-off-style brief with clear unknowns, not invented stakeholder answers.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Requirements into acceptance criteria: Do not assign a demanding SLO without its cost and operational implications.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: requirements and assumptions register
A signed-off-style brief with clear unknowns, not invented stakeholder answers.

Interview: Work through this Solutions Architect case: Available all the time is incomplete until availability window and acceptable outage are defined. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Translate business language into measurable outcomes before selecting products. Include users, peak load, data sensitivity and recovery expectations. Expected evidence: A signed-off-style brief with clear unknowns, not invented stakeholder answers. Diagnosis: Do not assign a demanding SLO without its cost and operational implications. State the limits of the mental model: A builder needs room sizes and occupancy before choosing materials.

Resume: Built requirements and assumptions register using Cloud architecture frameworks; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a two-option architecture table covering compute, data, identity, observability and failure modes. Link each choice to an acceptance criterion and estimate usage assumptions.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transactional outbox
Write business data and the event to publish in one local transaction, then deliver the event separately.
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.
Example: The reference stores order-1 and its pending event together.
Recall: Why can publishing first lose consistency if the database write fails?

### Service selection and responsibility
Compare services against constraints, integration fit and operating responsibility. Similar product names across clouds do not imply equivalent networking, identity or cost behavior.
Mental model: Two rental contracts may offer similar rooms but different maintenance obligations.
Limit: A list of logos is not an architecture; draw data and control flows.
Example: A managed database shifts patching work but still needs access and recovery design.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A list of logos is not an architecture; draw data and control flows.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A managed database shifts patching work but still needs access and recovery design. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a two-option architecture table covering compute, data, identity, observability and failure modes. Link each choice to an acceptance criterion and estimate usage assumptions.
Expected: A defensible recommendation with an explicit alternative.

6. Role workshop · debug and verify
A list of logos is not an architecture; draw data and control flows. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save solution diagram and weighted trade-off table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A defensible recommendation with an explicit alternative.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Service selection and responsibility: A list of logos is not an architecture; draw data and control flows.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: solution diagram and weighted trade-off table
A defensible recommendation with an explicit alternative.

Interview: Work through this Solutions Architect case: A managed database shifts patching work but still needs access and recovery design. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Compare services against constraints, integration fit and operating responsibility. Similar product names across clouds do not imply equivalent networking, identity or cost behavior. Expected evidence: A defensible recommendation with an explicit alternative. Diagnosis: A list of logos is not an architecture; draw data and control flows. State the limits of the mental model: Two rental contracts may offer similar rooms but different maintenance obligations.

Resume: Built solution diagram and weighted trade-off table using Cloud architecture frameworks; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Prepare a deployment sequence, synthetic transaction, incident contacts and restore test. Run local components and mark cloud actions pending if no sandbox exists.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Failure semantics
Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.
Recall: How would you recover a permanently failing event without blocking all orders?

### Operational readiness review
A solution is ready only when deployment, monitoring, security ownership and recovery have evidence. Distinguish proposed controls from tested controls.
Mental model: A completed building needs an operating manual and evacuation drill.
Limit: A green deployment task can conceal an inaccessible application; test the user journey.
Example: A backup checkbox cannot substitute for a successful restore rehearsal.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A green deployment task can conceal an inaccessible application; test the user journey.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A backup checkbox cannot substitute for a successful restore rehearsal. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Prepare a deployment sequence, synthetic transaction, incident contacts and restore test. Run local components and mark cloud actions pending if no sandbox exists.
Expected: A readiness decision with evidence links and blocking gaps.

6. Role workshop · debug and verify
A green deployment task can conceal an inaccessible application; test the user journey. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save operational readiness pack and handover guide. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A readiness decision with evidence links and blocking gaps.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Operational readiness review: A green deployment task can conceal an inaccessible application; test the user journey.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: operational readiness pack and handover guide
A readiness decision with evidence links and blocking gaps.

Interview: Work through this Solutions Architect case: A backup checkbox cannot substitute for a successful restore rehearsal. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A solution is ready only when deployment, monitoring, security ownership and recovery have evidence. Distinguish proposed controls from tested controls. Expected evidence: A readiness decision with evidence links and blocking gaps. Diagnosis: A green deployment task can conceal an inaccessible application; test the user journey. State the limits of the mental model: A completed building needs an operating manual and evacuation drill.

Resume: Built operational readiness pack and handover guide using Cloud architecture frameworks; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
