# Solutions Architect — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Boundaries and ownership: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.

Apply boundaries and ownership in Solutions Architect: Use the concept to complete this role exercise: Translate a requirement into observable acceptance criteria

Requirements into acceptance criteria: Translate business language into measurable outcomes before selecting products. Include users, peak load, data sensitivity and recovery expectations.

### Boundaries and ownership

A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. In this role, work through: Available all the time is incomplete until availability window and acceptable outage are defined. The practical workshop develops this into: Interview a fictional service owner using a requirements worksheet. Convert five vague statements into measurable criteria and mark assumptions needing confirmation.

Mental model: Departments own different ledgers and exchange agreed forms.

Boundary: Drawing more boxes does not make a system more reliable.

Role application: A builder needs room sizes and occupancy before choosing materials.

Translate business language into measurable outcomes before selecting products. Include users, peak load, data sensitivity and recovery expectations.

Worked example: Available all the time is incomplete until availability window and acceptable outage are defined.

Shared foundation example: The order service owns orders; a notification consumer handles messages.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Cloud architecture frameworks (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Solutions Architect: Available all the time is incomplete until availability window and acceptable outage are defined.

Predict the worked case

Read this case without running a tool: Available all the time is incomplete until availability window and acceptable outage are defined. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in boundaries and ownership.

Connect the concept to the role

Apply this rule: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Drawing more boxes does not make a system more reliable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies boundaries and ownership to this case: Available all the time is incomplete until availability window and acceptable outage are defined. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Available all the time is incomplete until availability window and acceptable outage are defined. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Boundaries and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with boundaries and ownership. Use the glossary below, then write your prediction for: Available all the time is incomplete until availability window and acceptable outage are defined. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Solutions Architect role interview. Explain boundaries and ownership using this case: Available all the time is incomplete until availability window and acceptable outage are defined. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate boundaries and ownership to a system or workflow you know. Explain boundaries and ownership using this case: Available all the time is incomplete until availability window and acceptable outage are defined. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which component owns the truth about whether an order exists?

Interview: Explain boundaries and ownership using this case: Available all the time is incomplete until availability window and acceptable outage are defined. State the evidence, one alternative and where the mental model stops.

Quiz: After the Requirements into acceptance criteria rehearsal, check this foundation: Two services both write one business record using incompatible rules. What should be clarified first?

The owning service and the contract through which others request changes.

Which service can issue writes faster.

Whether both services can share unrestricted credentials.

Reference: The owning service and the contract through which others request changes. — Ownership defines responsibility for invariants. Sharing write access does not resolve conflicting business rules.

Sources:

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Requirements into acceptance criteria

Translate business language into measurable outcomes before selecting products. Include users, peak load, data sensitivity and recovery expectations. In this role, work through: Available all the time is incomplete until availability window and acceptable outage are defined. The practical workshop develops this into: Interview a fictional service owner using a requirements worksheet. Convert five vague statements into measurable criteria and mark assumptions needing confirmation.

Mental model: A builder needs room sizes and occupancy before choosing materials.

Boundary: Do not assign a demanding SLO without its cost and operational implications.

Worked example: Available all the time is incomplete until availability window and acceptable outage are defined.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Cloud architecture frameworks (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Solutions Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Interview a fictional service owner using a requirements worksheet. Convert five vague statements into measurable criteria and mark assumptions needing confirmation.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Available all the time is incomplete until availability window and acceptable outage are defined. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Interview a fictional service owner using a requirements worksheet. Convert five vague statements into measurable criteria and mark assumptions needing confirmation.

Expected: A signed-off-style brief with clear unknowns, not invented stakeholder answers.

Role workshop · debug and verify

Do not assign a demanding SLO without its cost and operational implications. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save requirements and assumptions register. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A signed-off-style brief with clear unknowns, not invented stakeholder answers.

Expected: A signed-off-style brief with clear unknowns, not invented stakeholder answers.

Troubleshoot: The role exercise differs from the prediction: Do not assign a demanding SLO without its cost and operational implications.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: requirements and assumptions register; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with requirements into acceptance criteria. Use the glossary below, then write your prediction for: Available all the time is incomplete until availability window and acceptable outage are defined. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Solutions Architect role interview. Explain requirements into acceptance criteria using this case: Available all the time is incomplete until availability window and acceptable outage are defined. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate requirements into acceptance criteria to a system or workflow you know. Explain requirements into acceptance criteria using this case: Available all the time is incomplete until availability window and acceptable outage are defined. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not assign a demanding SLO without its cost and operational implications.

Interview: Explain requirements into acceptance criteria using this case: Available all the time is incomplete until availability window and acceptable outage are defined. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Available all the time is incomplete until availability window and acceptable outage are defined.

A signed-off-style brief with clear unknowns, not invented stakeholder answers.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A signed-off-style brief with clear unknowns, not invented stakeholder answers. — Translate business language into measurable outcomes before selecting products. Include users, peak load, data sensitivity and recovery expectations. A signed-off-style brief with clear unknowns, not invented stakeholder answers.

Sources:

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Transactional outbox: Write business data and the event to publish in one local transaction, then deliver the event separately.

Apply transactional outbox in Solutions Architect: Use the concept to complete this role exercise: Map compute, storage, identity and integration boundaries

Service selection and responsibility: Compare services against constraints, integration fit and operating responsibility. Similar product names across clouds do not imply equivalent networking, identity or cost behavior.

### Transactional outbox

Write business data and the event to publish in one local transaction, then deliver the event separately. In this role, work through: A managed database shifts patching work but still needs access and recovery design. The practical workshop develops this into: Create a two-option architecture table covering compute, data, identity, observability and failure modes. Link each choice to an acceptance criterion and estimate usage assumptions.

Mental model: Record a sale and its mailing slip in the same ledger before dispatch.

Boundary: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Role application: Two rental contracts may offer similar rooms but different maintenance obligations.

Compare services against constraints, integration fit and operating responsibility. Similar product names across clouds do not imply equivalent networking, identity or cost behavior.

Worked example: A managed database shifts patching work but still needs access and recovery design.

Shared foundation example: The reference stores order-1 and its pending event together.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Cloud architecture frameworks (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Solutions Architect: A managed database shifts patching work but still needs access and recovery design.

Predict the worked case

Read this case without running a tool: A managed database shifts patching work but still needs access and recovery design. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transactional outbox.

Connect the concept to the role

Apply this rule: Write business data and the event to publish in one local transaction, then deliver the event separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transactional outbox to this case: A managed database shifts patching work but still needs access and recovery design. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A managed database shifts patching work but still needs access and recovery design. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Transactional outbox; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactional outbox. Use the glossary below, then write your prediction for: A managed database shifts patching work but still needs access and recovery design. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Solutions Architect role interview. Explain transactional outbox using this case: A managed database shifts patching work but still needs access and recovery design. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactional outbox to a system or workflow you know. Explain transactional outbox using this case: A managed database shifts patching work but still needs access and recovery design. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why can publishing first lose consistency if the database write fails?

Interview: Explain transactional outbox using this case: A managed database shifts patching work but still needs access and recovery design. State the evidence, one alternative and where the mental model stops.

Quiz: After the Service selection and responsibility rehearsal, check this foundation: Business data commits but publishing its event fails. Which design closes this local write/publish gap?

Publish first, then hope the business write succeeds.

Commit the data and pending outbox entry in one local transaction.

Use a longer broker timeout without recording pending work.

Reference: Commit the data and pending outbox entry in one local transaction. — The outbox preserves a durable publication intent. Delivery can still repeat, so consumers need suitable deduplication.

Sources:

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Service selection and responsibility

Compare services against constraints, integration fit and operating responsibility. Similar product names across clouds do not imply equivalent networking, identity or cost behavior. In this role, work through: A managed database shifts patching work but still needs access and recovery design. The practical workshop develops this into: Create a two-option architecture table covering compute, data, identity, observability and failure modes. Link each choice to an acceptance criterion and estimate usage assumptions.

Mental model: Two rental contracts may offer similar rooms but different maintenance obligations.

Boundary: A list of logos is not an architecture; draw data and control flows.

Worked example: A managed database shifts patching work but still needs access and recovery design.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Cloud architecture frameworks (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Solutions Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a two-option architecture table covering compute, data, identity, observability and failure modes. Link each choice to an acceptance criterion and estimate usage assumptions.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A managed database shifts patching work but still needs access and recovery design. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a two-option architecture table covering compute, data, identity, observability and failure modes. Link each choice to an acceptance criterion and estimate usage assumptions.

Expected: A defensible recommendation with an explicit alternative.

Role workshop · debug and verify

A list of logos is not an architecture; draw data and control flows. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save solution diagram and weighted trade-off table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A defensible recommendation with an explicit alternative.

Expected: A defensible recommendation with an explicit alternative.

Troubleshoot: The role exercise differs from the prediction: A list of logos is not an architecture; draw data and control flows.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: solution diagram and weighted trade-off table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with service selection and responsibility. Use the glossary below, then write your prediction for: A managed database shifts patching work but still needs access and recovery design. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Solutions Architect role interview. Explain service selection and responsibility using this case: A managed database shifts patching work but still needs access and recovery design. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate service selection and responsibility to a system or workflow you know. Explain service selection and responsibility using this case: A managed database shifts patching work but still needs access and recovery design. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A list of logos is not an architecture; draw data and control flows.

Interview: Explain service selection and responsibility using this case: A managed database shifts patching work but still needs access and recovery design. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A managed database shifts patching work but still needs access and recovery design.

Ignore the failing case and keep only the successful screenshot.

A defensible recommendation with an explicit alternative.

Treat any successful command as proof that all business and access rules passed.

Reference: A defensible recommendation with an explicit alternative. — Compare services against constraints, integration fit and operating responsibility. Similar product names across clouds do not imply equivalent networking, identity or cost behavior. A defensible recommendation with an explicit alternative.

Sources:

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Failure semantics: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.

Apply failure semantics in Solutions Architect: Use the concept to complete this role exercise: Present a costed reliability/security design with assumptions and recovery plan

Operational readiness review: A solution is ready only when deployment, monitoring, security ownership and recovery have evidence. Distinguish proposed controls from tested controls.

### Failure semantics

Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. In this role, work through: A backup checkbox cannot substitute for a successful restore rehearsal. The practical workshop develops this into: Prepare a deployment sequence, synthetic transaction, incident contacts and restore test. Run local components and mark cloud actions pending if no sandbox exists.

Mental model: Track a parcel even when the receipt acknowledgment is lost.

Boundary: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Role application: A completed building needs an operating manual and evacuation drill.

A solution is ready only when deployment, monitoring, security ownership and recovery have evidence. Distinguish proposed controls from tested controls.

Worked example: A backup checkbox cannot substitute for a successful restore rehearsal.

Shared foundation example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Cloud architecture frameworks (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Solutions Architect: A backup checkbox cannot substitute for a successful restore rehearsal.

Predict the worked case

Read this case without running a tool: A backup checkbox cannot substitute for a successful restore rehearsal. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure semantics.

Connect the concept to the role

Apply this rule: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure semantics to this case: A backup checkbox cannot substitute for a successful restore rehearsal. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A backup checkbox cannot substitute for a successful restore rehearsal. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Failure semantics; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure semantics. Use the glossary below, then write your prediction for: A backup checkbox cannot substitute for a successful restore rehearsal. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Solutions Architect role interview. Explain failure semantics using this case: A backup checkbox cannot substitute for a successful restore rehearsal. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure semantics to a system or workflow you know. Explain failure semantics using this case: A backup checkbox cannot substitute for a successful restore rehearsal. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you recover a permanently failing event without blocking all orders?

Interview: Explain failure semantics using this case: A backup checkbox cannot substitute for a successful restore rehearsal. State the evidence, one alternative and where the mental model stops.

Quiz: After the Operational readiness review rehearsal, check this foundation: A consumer commits its effect and crashes before acknowledging. What must the design handle?

The broker can infer the effect and guarantee no replay.

The effect must be automatically rolled back by the broker.

The message can be delivered again after the effect already happened.

Reference: The message can be delivered again after the effect already happened. — Acknowledgment and the business effect are separate boundaries. Model the crash window and make replay safe.

Sources:

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Operational readiness review

A solution is ready only when deployment, monitoring, security ownership and recovery have evidence. Distinguish proposed controls from tested controls. In this role, work through: A backup checkbox cannot substitute for a successful restore rehearsal. The practical workshop develops this into: Prepare a deployment sequence, synthetic transaction, incident contacts and restore test. Run local components and mark cloud actions pending if no sandbox exists.

Mental model: A completed building needs an operating manual and evacuation drill.

Boundary: A green deployment task can conceal an inaccessible application; test the user journey.

Worked example: A backup checkbox cannot substitute for a successful restore rehearsal.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Cloud architecture frameworks (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Solutions Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Prepare a deployment sequence, synthetic transaction, incident contacts and restore test. Run local components and mark cloud actions pending if no sandbox exists.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A backup checkbox cannot substitute for a successful restore rehearsal. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Prepare a deployment sequence, synthetic transaction, incident contacts and restore test. Run local components and mark cloud actions pending if no sandbox exists.

Expected: A readiness decision with evidence links and blocking gaps.

Role workshop · debug and verify

A green deployment task can conceal an inaccessible application; test the user journey. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save operational readiness pack and handover guide. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A readiness decision with evidence links and blocking gaps.

Expected: A readiness decision with evidence links and blocking gaps.

Troubleshoot: The role exercise differs from the prediction: A green deployment task can conceal an inaccessible application; test the user journey.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: operational readiness pack and handover guide; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with operational readiness review. Use the glossary below, then write your prediction for: A backup checkbox cannot substitute for a successful restore rehearsal. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Solutions Architect role interview. Explain operational readiness review using this case: A backup checkbox cannot substitute for a successful restore rehearsal. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate operational readiness review to a system or workflow you know. Explain operational readiness review using this case: A backup checkbox cannot substitute for a successful restore rehearsal. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A green deployment task can conceal an inaccessible application; test the user journey.

Interview: Explain operational readiness review using this case: A backup checkbox cannot substitute for a successful restore rehearsal. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A backup checkbox cannot substitute for a successful restore rehearsal.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A readiness decision with evidence links and blocking gaps.

Reference: A readiness decision with evidence links and blocking gaps. — A solution is ready only when deployment, monitoring, security ownership and recovery have evidence. Distinguish proposed controls from tested controls. A readiness decision with evidence links and blocking gaps.

Sources:

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
