# Rust Developer

Software Engineering

Begin with state machines. Create a Cargo project and explain ownership of one String. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Create a Cargo project and explain ownership of one String

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware.

### State machines
A state machine defines allowed states and how events change them.
Mental model: Traffic lights change according to explicit rules.
Limit: Real timing, interrupts and hardware noise require additional engineering.
Example: A fan turns on at 30, stays on at 28 and turns off at 25.
Recall: What state would you use when a sensor reading is unavailable?

### Apply state machines in Rust Developer
Use the concept to complete this role exercise: Create a Cargo project and explain ownership of one String
Mental model: Traffic lights change according to explicit rules.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: A fan turns on at 30, stays on at 28 and turns off at 25. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Start your language-native extension
Install the supported toolchain using the course source. Use a new empty directory for the commands. The shared reference teaches behavior; port the behavior into this native project.
```
cargo new atlas_tickets
cd atlas_tickets
cargo run
```
Expected: Hello, world!

4. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

5. Apply the role exercise
Create a Cargo project and explain ownership of one String
Expected: Save the code, test cases and a distinction between simulated and hardware/device evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: rust-developer-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Create a Cargo project and explain ownership of one String? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A state machine defines allowed states and how events change them. For this role, explicitly address: Create a Cargo project and explain ownership of one String.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Model request outcomes with Result and explicit error handling

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware.

### Memory and ownership
Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.
Mental model: A borrowed library book must not be used after it is returned.
Limit: Languages enforce different parts of this discipline; concurrency adds other hazards.
Example: A fixed array of four readings is traversed with indices zero through three.
Recall: Why is index four invalid in a four-element array?

### Apply memory and ownership in Rust Developer
Use the concept to complete this role exercise: Model request outcomes with Result and explicit error handling
Mental model: A borrowed library book must not be used after it is returned.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: A fixed array of four readings is traversed with indices zero through three. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Start your language-native extension
Install the supported toolchain using the course source. Use a new empty directory for the commands. The shared reference teaches behavior; port the behavior into this native project.
```
cargo new atlas_tickets
cd atlas_tickets
cargo run
```
Expected: Hello, world!

4. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

5. Apply the role exercise
Model request outcomes with Result and explicit error handling
Expected: Save the code, test cases and a distinction between simulated and hardware/device evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: rust-developer-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Model request outcomes with Result and explicit error handling? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. For this role, explicitly address: Model request outcomes with Result and explicit error handling.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Test a bounded work queue and document cancellation and memory limits

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware.

### Determinism and timing
A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: A host simulation does not validate hardware or real-time deadlines.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.
Recall: What measurements would be required on actual hardware?

### Apply determinism and timing in Rust Developer
Use the concept to complete this role exercise: Test a bounded work queue and document cancellation and memory limits
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Start your language-native extension
Install the supported toolchain using the course source. Use a new empty directory for the commands. The shared reference teaches behavior; port the behavior into this native project.
```
cargo new atlas_tickets
cd atlas_tickets
cargo run
```
Expected: Hello, world!

4. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

5. Apply the role exercise
Test a bounded work queue and document cancellation and memory limits
Expected: Save the code, test cases and a distinction between simulated and hardware/device evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: rust-developer-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Test a bounded work queue and document cancellation and memory limits? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. For this role, explicitly address: Test a bounded work queue and document cancellation and memory limits.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
The Rust Programming Language: https://doc.rust-lang.org/book/
Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html
Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
