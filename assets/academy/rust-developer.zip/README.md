# Rust Developer

Software Engineering

Start with ownership and borrowing. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward bounded-channel example and failure lifecycle notes.

## beginner

Create a Cargo binary. Implement normalization without unnecessary cloning of inputs, add unit tests and intentionally attempt use-after-move in a separate scratch file to read the compiler explanation. Restore compiling code afterward.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State machines
A state machine defines allowed states and how events change them.
Mental model: Traffic lights change according to explicit rules.
Limit: Real timing, interrupts and hardware noise require additional engineering.
Example: A fan turns on at 30, stays on at 28 and turns off at 25.
Recall: What state would you use when a sensor reading is unavailable?

### Ownership and borrowing
Rust tracks ownership and lifetimes to prevent invalid references. Borrow a string when only reading it and return an owned value when the result must outlive the input.
Mental model: Borrow a book to read it; obtain your own copy before keeping it after the loan.
Limit: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears.
Example: A normalize function accepts &str and returns an owned trimmed String.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
A normalize function accepts &str and returns an owned trimmed String. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a Cargo binary. Implement normalization without unnecessary cloning of inputs, add unit tests and intentionally attempt use-after-move in a separate scratch file to read the compiler explanation. Restore compiling code afterward.
```
cargo new atlas_tickets
cd atlas_tickets
cargo test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Tests pass and notes explain ownership of input and result; the scratch failure is documented.

6. Role workshop · debug and verify
If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Cargo project and an ownership diagram. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Tests pass and notes explain ownership of input and result; the scratch failure is documented.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Ownership and borrowing: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Cargo project and an ownership diagram
Tests pass and notes explain ownership of input and result; the scratch failure is documented.

Interview: Work through this Rust Developer case: A normalize function accepts &str and returns an owned trimmed String. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Rust tracks ownership and lifetimes to prevent invalid references. Borrow a string when only reading it and return an owned value when the result must outlive the input. Expected evidence: Tests pass and notes explain ownership of input and result; the scratch failure is documented. Diagnosis: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears. State the limits of the mental model: Borrow a book to read it; obtain your own copy before keeping it after the loan.

Resume: Built Cargo project and an ownership diagram using Rust and Cargo; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create parse_amount(&str) returning Result, reject negative values, and match the result in main. Add valid, malformed and negative tests; keep panic out of normal input paths.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Memory and ownership
Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.
Mental model: A borrowed library book must not be used after it is returned.
Limit: Languages enforce different parts of this discipline; concurrency adds other hazards.
Example: A fixed array of four readings is traversed with indices zero through three.
Recall: Why is index four invalid in a four-element array?

### Result and error propagation
Use Result for expected failure and propagate errors with ? when the caller should decide recovery. Panic is unsuitable as ordinary invalid-input handling in a reusable parser.
Mental model: A worker can return either a finished item or a structured reason for rejection.
Limit: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly.
Example: Parsing ten as an amount returns Err; parsing 10 returns Ok(10).
Recall: Explain the expected result before running the exercise, then diagnose this failure: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create parse_amount(&str) returning Result, reject negative values, and match the result in main. Add valid, malformed and negative tests; keep panic out of normal input paths.
```
cargo test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Each invalid input returns a documented error variant without terminating tests.

6. Role workshop · debug and verify
unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save typed-error implementation and tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Each invalid input returns a documented error variant without terminating tests.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Result and error propagation: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: typed-error implementation and tests
Each invalid input returns a documented error variant without terminating tests.

Interview: Work through this Rust Developer case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Use Result for expected failure and propagate errors with ? when the caller should decide recovery. Panic is unsuitable as ordinary invalid-input handling in a reusable parser. Expected evidence: Each invalid input returns a documented error variant without terminating tests. Diagnosis: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly. State the limits of the mental model: A worker can return either a finished item or a structured reason for rejection.

Resume: Built typed-error implementation and tests using Rust and Cargo; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Use std::sync::mpsc::sync_channel in a small worker example. Send numbered jobs, join the worker thread and test order and count. Add a consumer failure and describe how SendError reaches the producer.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Determinism and timing
A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: A host simulation does not validate hardware or real-time deadlines.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.
Recall: What measurements would be required on actual hardware?

### Channels and shutdown ownership
A bounded channel provides backpressure when the consumer is slower. Shutdown must define who drops the sender and how the receiver drains or rejects remaining work.
Mental model: A conveyor with finite slots stops producers when the next station cannot keep up.
Limit: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown.
Example: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use std::sync::mpsc::sync_channel in a small worker example. Send numbered jobs, join the worker thread and test order and count. Add a consumer failure and describe how SendError reaches the producer.
```
cargo test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: No job counted twice; the program terminates without a receiver waiting forever.

6. Role workshop · debug and verify
A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save bounded-channel example and failure lifecycle notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No job counted twice; the program terminates without a receiver waiting forever.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Channels and shutdown ownership: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: bounded-channel example and failure lifecycle notes
No job counted twice; the program terminates without a receiver waiting forever.

Interview: Work through this Rust Developer case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A bounded channel provides backpressure when the consumer is slower. Shutdown must define who drops the sender and how the receiver drains or rejects remaining work. Expected evidence: No job counted twice; the program terminates without a receiver waiting forever. Diagnosis: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown. State the limits of the mental model: A conveyor with finite slots stops producers when the next station cannot keep up.

Resume: Built bounded-channel example and failure lifecycle notes using Rust and Cargo; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
The Rust Programming Language: https://doc.rust-lang.org/book/
Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html
Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
Rust: recoverable errors with Result: https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html
