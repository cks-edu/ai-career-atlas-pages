# Rust Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

State machines: A state machine defines allowed states and how events change them.

Apply state machines in Rust Developer: Use the concept to complete this role exercise: Create a Cargo project and explain ownership of one String

Ownership and borrowing: Rust tracks ownership and lifetimes to prevent invalid references. Borrow a string when only reading it and return an owned value when the result must outlive the input.

### State machines

A state machine defines allowed states and how events change them. In this role, work through: A normalize function accepts &str and returns an owned trimmed String. The practical workshop develops this into: Create a Cargo binary. Implement normalization without unnecessary cloning of inputs, add unit tests and intentionally attempt use-after-move in a separate scratch file to read the compiler explanation. Restore compiling code afterward.

Mental model: Traffic lights change according to explicit rules.

Boundary: Real timing, interrupts and hardware noise require additional engineering.

Role application: Borrow a book to read it; obtain your own copy before keeping it after the loan.

Rust tracks ownership and lifetimes to prevent invalid references. Borrow a string when only reading it and return an owned value when the result must outlive the input.

Worked example: A normalize function accepts &str and returns an owned trimmed String.

Shared foundation example: A fan turns on at 30, stays on at 28 and turns off at 25.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Rust and Cargo (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Rust Developer: A normalize function accepts &str and returns an owned trimmed String.

Predict the worked case

Read this case without running a tool: A normalize function accepts &str and returns an owned trimmed String. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state machines.

Connect the concept to the role

Apply this rule: A state machine defines allowed states and how events change them. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Real timing, interrupts and hardware noise require additional engineering.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state machines to this case: A normalize function accepts &str and returns an owned trimmed String. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A normalize function accepts &str and returns an owned trimmed String. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for State machines; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state machines. Use the glossary below, then write your prediction for: A normalize function accepts &str and returns an owned trimmed String. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Rust Developer role interview. Explain state machines using this case: A normalize function accepts &str and returns an owned trimmed String. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state machines to a system or workflow you know. Explain state machines using this case: A normalize function accepts &str and returns an owned trimmed String. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What state would you use when a sensor reading is unavailable?

Interview: Explain state machines using this case: A normalize function accepts &str and returns an owned trimmed String. State the evidence, one alternative and where the mental model stops.

Quiz: After the Ownership and borrowing rehearsal, check this foundation: An event is valid only in one workflow state. How should it be handled in another state?

Apply the declared transition policy, including rejection or no-op where defined.

Always jump to the final state to complete the flow.

Ignore the current state and repeat the last action.

Reference: Apply the declared transition policy, including rejection or no-op where defined. — A transition depends on the current state and event, not only the event name.

Sources:

Rust: recoverable errors with Result: https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Ownership and borrowing

Rust tracks ownership and lifetimes to prevent invalid references. Borrow a string when only reading it and return an owned value when the result must outlive the input. In this role, work through: A normalize function accepts &str and returns an owned trimmed String. The practical workshop develops this into: Create a Cargo binary. Implement normalization without unnecessary cloning of inputs, add unit tests and intentionally attempt use-after-move in a separate scratch file to read the compiler explanation. Restore compiling code afterward.

Mental model: Borrow a book to read it; obtain your own copy before keeping it after the loan.

Boundary: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears.

Worked example: A normalize function accepts &str and returns an owned trimmed String.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Rust and Cargo (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Rust Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a Cargo binary. Implement normalization without unnecessary cloning of inputs, add unit tests and intentionally attempt use-after-move in a separate scratch file to read the compiler explanation. Restore compiling code afterward.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

A normalize function accepts &str and returns an owned trimmed String. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a Cargo binary. Implement normalization without unnecessary cloning of inputs, add unit tests and intentionally attempt use-after-move in a separate scratch file to read the compiler explanation. Restore compiling code afterward.

```
cargo new atlas_tickets
cd atlas_tickets
cargo test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Tests pass and notes explain ownership of input and result; the scratch failure is documented.

Role workshop · debug and verify

If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Cargo project and an ownership diagram. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Tests pass and notes explain ownership of input and result; the scratch failure is documented.

Expected: Tests pass and notes explain ownership of input and result; the scratch failure is documented.

Troubleshoot: The role exercise differs from the prediction: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: Cargo project and an ownership diagram; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ownership and borrowing. Use the glossary below, then write your prediction for: A normalize function accepts &str and returns an owned trimmed String. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Rust Developer role interview. Explain ownership and borrowing using this case: A normalize function accepts &str and returns an owned trimmed String. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ownership and borrowing to a system or workflow you know. Explain ownership and borrowing using this case: A normalize function accepts &str and returns an owned trimmed String. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears.

Interview: Explain ownership and borrowing using this case: A normalize function accepts &str and returns an owned trimmed String. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A normalize function accepts &str and returns an owned trimmed String.

Tests pass and notes explain ownership of input and result; the scratch failure is documented.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Tests pass and notes explain ownership of input and result; the scratch failure is documented. — Rust tracks ownership and lifetimes to prevent invalid references. Borrow a string when only reading it and return an owned value when the result must outlive the input. Tests pass and notes explain ownership of input and result; the scratch failure is documented.

Sources:

Rust: recoverable errors with Result: https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Memory and ownership: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.

Apply memory and ownership in Rust Developer: Use the concept to complete this role exercise: Model request outcomes with Result and explicit error handling

Result and error propagation: Use Result for expected failure and propagate errors with ? when the caller should decide recovery. Panic is unsuitable as ordinary invalid-input handling in a reusable parser.

### Memory and ownership

Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. In this role, work through: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). The practical workshop develops this into: Create parse_amount(&str) returning Result, reject negative values, and match the result in main. Add valid, malformed and negative tests; keep panic out of normal input paths.

Mental model: A borrowed library book must not be used after it is returned.

Boundary: Languages enforce different parts of this discipline; concurrency adds other hazards.

Role application: A worker can return either a finished item or a structured reason for rejection.

Use Result for expected failure and propagate errors with ? when the caller should decide recovery. Panic is unsuitable as ordinary invalid-input handling in a reusable parser.

Worked example: Parsing ten as an amount returns Err; parsing 10 returns Ok(10).

Shared foundation example: A fixed array of four readings is traversed with indices zero through three.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Rust and Cargo (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Rust Developer: Parsing ten as an amount returns Err; parsing 10 returns Ok(10).

Predict the worked case

Read this case without running a tool: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in memory and ownership.

Connect the concept to the role

Apply this rule: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Languages enforce different parts of this discipline; concurrency adds other hazards.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies memory and ownership to this case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Memory and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with memory and ownership. Use the glossary below, then write your prediction for: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Rust Developer role interview. Explain memory and ownership using this case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate memory and ownership to a system or workflow you know. Explain memory and ownership using this case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is index four invalid in a four-element array?

Interview: Explain memory and ownership using this case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). State the evidence, one alternative and where the mental model stops.

Quiz: After the Result and error propagation rehearsal, check this foundation: A buffer has capacity four and zero-based indices. Which index range is valid?

1 through 4 inclusive.

0 through 3 inclusive.

0 through 4 inclusive.

Reference: 0 through 3 inclusive. — Capacity is the number of elements; the last valid zero-based index is capacity minus one. Lifetime checks are separate.

Sources:

Rust: recoverable errors with Result: https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Result and error propagation

Use Result for expected failure and propagate errors with ? when the caller should decide recovery. Panic is unsuitable as ordinary invalid-input handling in a reusable parser. In this role, work through: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). The practical workshop develops this into: Create parse_amount(&str) returning Result, reject negative values, and match the result in main. Add valid, malformed and negative tests; keep panic out of normal input paths.

Mental model: A worker can return either a finished item or a structured reason for rejection.

Boundary: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly.

Worked example: Parsing ten as an amount returns Err; parsing 10 returns Ok(10).

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Rust and Cargo (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Rust Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create parse_amount(&str) returning Result, reject negative values, and match the result in main. Add valid, malformed and negative tests; keep panic out of normal input paths.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create parse_amount(&str) returning Result, reject negative values, and match the result in main. Add valid, malformed and negative tests; keep panic out of normal input paths.

```
cargo test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Each invalid input returns a documented error variant without terminating tests.

Role workshop · debug and verify

unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save typed-error implementation and tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Each invalid input returns a documented error variant without terminating tests.

Expected: Each invalid input returns a documented error variant without terminating tests.

Troubleshoot: The role exercise differs from the prediction: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: typed-error implementation and tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with result and error propagation. Use the glossary below, then write your prediction for: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Rust Developer role interview. Explain result and error propagation using this case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate result and error propagation to a system or workflow you know. Explain result and error propagation using this case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly.

Interview: Explain result and error propagation using this case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10). State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Parsing ten as an amount returns Err; parsing 10 returns Ok(10).

Ignore the failing case and keep only the successful screenshot.

Each invalid input returns a documented error variant without terminating tests.

Treat any successful command as proof that all business and access rules passed.

Reference: Each invalid input returns a documented error variant without terminating tests. — Use Result for expected failure and propagate errors with ? when the caller should decide recovery. Panic is unsuitable as ordinary invalid-input handling in a reusable parser. Each invalid input returns a documented error variant without terminating tests.

Sources:

Rust: recoverable errors with Result: https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Determinism and timing: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.

Apply determinism and timing in Rust Developer: Use the concept to complete this role exercise: Test a bounded work queue and document cancellation and memory limits

Channels and shutdown ownership: A bounded channel provides backpressure when the consumer is slower. Shutdown must define who drops the sender and how the receiver drains or rejects remaining work.

### Determinism and timing

A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. In this role, work through: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. The practical workshop develops this into: Use std::sync::mpsc::sync_channel in a small worker example. Send numbered jobs, join the worker thread and test order and count. Add a consumer failure and describe how SendError reaches the producer.

Mental model: A rehearsal follows a script; a live performance adds timing constraints.

Boundary: A host simulation does not validate hardware or real-time deadlines.

Role application: A conveyor with finite slots stops producers when the next station cannot keep up.

A bounded channel provides backpressure when the consumer is slower. Shutdown must define who drops the sender and how the receiver drains or rejects remaining work.

Worked example: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop.

Shared foundation example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Rust and Cargo (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Rust Developer: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop.

Predict the worked case

Read this case without running a tool: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in determinism and timing.

Connect the concept to the role

Apply this rule: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A host simulation does not validate hardware or real-time deadlines.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies determinism and timing to this case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Determinism and timing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with determinism and timing. Use the glossary below, then write your prediction for: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Rust Developer role interview. Explain determinism and timing using this case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate determinism and timing to a system or workflow you know. Explain determinism and timing using this case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What measurements would be required on actual hardware?

Interview: Explain determinism and timing using this case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. State the evidence, one alternative and where the mental model stops.

Quiz: After the Channels and shutdown ownership rehearsal, check this foundation: A replay produces the expected output every time. What is still needed for a real-time deadline claim?

No further evidence if results are deterministic.

Only a larger input file.

Measured timing under the intended resource and load conditions.

Reference: Measured timing under the intended resource and load conditions. — Repeatable results do not establish latency or worst-case timing on the target system.

Sources:

Rust: recoverable errors with Result: https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Channels and shutdown ownership

A bounded channel provides backpressure when the consumer is slower. Shutdown must define who drops the sender and how the receiver drains or rejects remaining work. In this role, work through: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. The practical workshop develops this into: Use std::sync::mpsc::sync_channel in a small worker example. Send numbered jobs, join the worker thread and test order and count. Add a consumer failure and describe how SendError reaches the producer.

Mental model: A conveyor with finite slots stops producers when the next station cannot keep up.

Boundary: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown.

Worked example: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Rust and Cargo (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Rust Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use std::sync::mpsc::sync_channel in a small worker example. Send numbered jobs, join the worker thread and test order and count. Add a consumer failure and describe how SendError reaches the producer.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use std::sync::mpsc::sync_channel in a small worker example. Send numbered jobs, join the worker thread and test order and count. Add a consumer failure and describe how SendError reaches the producer.

```
cargo test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: No job counted twice; the program terminates without a receiver waiting forever.

Role workshop · debug and verify

A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save bounded-channel example and failure lifecycle notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No job counted twice; the program terminates without a receiver waiting forever.

Expected: No job counted twice; the program terminates without a receiver waiting forever.

Troubleshoot: The role exercise differs from the prediction: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: bounded-channel example and failure lifecycle notes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with channels and shutdown ownership. Use the glossary below, then write your prediction for: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Rust Developer role interview. Explain channels and shutdown ownership using this case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate channels and shutdown ownership to a system or workflow you know. Explain channels and shutdown ownership using this case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown.

Interview: Explain channels and shutdown ownership using this case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

No job counted twice; the program terminates without a receiver waiting forever.

Reference: No job counted twice; the program terminates without a receiver waiting forever. — A bounded channel provides backpressure when the consumer is slower. Shutdown must define who drops the sender and how the receiver drains or rejects remaining work. No job counted twice; the program terminates without a receiver waiting forever.

Sources:

Rust: recoverable errors with Result: https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
