# Rust Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Ownership and borrowing

Rust tracks ownership and lifetimes to prevent invalid references. Borrow a string when only reading it and return an owned value when the result must outlive the input.
Mental model: Borrow a book to read it; obtain your own copy before keeping it after the loan.
Case: A normalize function accepts &str and returns an owned trimmed String.
Task: Create a Cargo binary. Implement normalization without unnecessary cloning of inputs, add unit tests and intentionally attempt use-after-move in a separate scratch file to read the compiler explanation. Restore compiling code afterward.
Acceptance: Tests pass and notes explain ownership of input and result; the scratch failure is documented.
Troubleshooting: If the borrow checker complains, identify the owner and lifetime instead of adding clones until the error disappears.
Deliverable: Cargo project and an ownership diagram

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Result and error propagation

Use Result for expected failure and propagate errors with ? when the caller should decide recovery. Panic is unsuitable as ordinary invalid-input handling in a reusable parser.
Mental model: A worker can return either a finished item or a structured reason for rejection.
Case: Parsing ten as an amount returns Err; parsing 10 returns Ok(10).
Task: Create parse_amount(&str) returning Result, reject negative values, and match the result in main. Add valid, malformed and negative tests; keep panic out of normal input paths.
Acceptance: Each invalid input returns a documented error variant without terminating tests.
Troubleshooting: unwrap on untrusted input converts an expected error into a panic; locate it and handle Result explicitly.
Deliverable: typed-error implementation and tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Channels and shutdown ownership

A bounded channel provides backpressure when the consumer is slower. Shutdown must define who drops the sender and how the receiver drains or rejects remaining work.
Mental model: A conveyor with finite slots stops producers when the next station cannot keep up.
Case: A capacity-one queue accepts one waiting job; dropping all senders eventually ends the receive loop.
Task: Use std::sync::mpsc::sync_channel in a small worker example. Send numbered jobs, join the worker thread and test order and count. Add a consumer failure and describe how SendError reaches the producer.
Acceptance: No job counted twice; the program terminates without a receiver waiting forever.
Troubleshooting: A hidden cloned sender keeps the channel open; inspect ownership of every sender at shutdown.
Deliverable: bounded-channel example and failure lifecycle notes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
