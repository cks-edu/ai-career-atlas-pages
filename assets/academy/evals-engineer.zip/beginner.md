## beginner — Evaluation contracts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Evaluation contracts
Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.
Mental model: An exam rubric says what earns credit before papers are marked.
Boundary: A benchmark samples behavior and cannot prove correctness for every input.
Worked example: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A grader accepts plausible mistakes
The calibration gate flags more than one false pass in ten deliberately incorrect answers. Two grader configurations accept too many known errors to support the release claim. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording.
Recall: Measure false passes and false failures separately on a new calibration set. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Evaluation contracts: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An evaluation is a repeatable check against defined expectations. A rubric explains what counts as correct and how serious an error is.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use the fictional rule “Library loans last 14 days.” Review three answers: “14 days”, “usually two weeks, but check” and “30 days”.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

3. Try step 2
Write separate criteria for factual correctness, clarity and unsupported claims.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

4. Try step 3
Score the answers using those criteria and explain any borderline judgment.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

5. Explain and check your result
The incorrect 30-day answer fails correctness even if its style is clear; uncertainty and factual errors are not treated as identical. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A small rubric with three scored examples and reasons. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers. Apply this toy-case rule manually: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two grader configurations accept too many known errors to support the release claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI evaluation / evals engineer.
Use the fictional rule “Library loans last 14 days.” Review three answers: “14 days”, “usually two weeks, but check” and “30 days”.
Write separate criteria for factual correctness, clarity and unsupported claims.
Score the answers using those criteria and explain any borderline judgment.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A small rubric with three scored examples and reasons. Include beginner-worksheet.md and your completed Grader calibration report.
Check: The incorrect 30-day answer fails correctness even if its style is clear; uncertainty and factual errors are not treated as identical.

### Interview
Explain your beginner solution for AI evaluation / evals engineer. Use this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers.
Review: Start with the task and permitted scope. Explain evaluation contracts: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. Show the input and observed output, then address Calibrate against independently labeled examples and repair ambiguous rubric wording. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A small rubric with three scored examples and reasons. Include beginner-worksheet.md and your completed Grader calibration report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

