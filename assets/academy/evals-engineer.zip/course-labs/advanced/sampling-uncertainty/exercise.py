import random
values=[1,1,1,0,0];rng=random.Random(17)
means=sorted(sum(rng.choices(values,k=len(values)))/len(values) for _ in range(1000))
low,high=means[24],means[974]
assert 0<=low<=high<=1
print({'sample_mean':sum(values)/len(values),'descriptive_percentile_range':[low,high],'n':len(values)})
