def publishable(report):
    required={'dataset_revision','candidate_versions','rubric','raw_outputs','slice_report','limitations'}
    return required<=report.keys() and report.get('critical_failures')==0 and all(bool(report[k]) for k in required)
report={k:'evidence/'+k for k in ['dataset_revision','candidate_versions','rubric','raw_outputs','slice_report','limitations']}
report['critical_failures']=0;assert publishable(report)
report['critical_failures']=1;assert not publishable(report)
print('PASS: critical failure blocks this report’s release recommendation')
