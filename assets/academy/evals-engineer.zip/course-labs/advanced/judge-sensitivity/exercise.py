def chosen(order,slot): return order[slot]
forward=('candidate-1','candidate-2');reverse=tuple(reversed(forward))
first=chosen(forward,0);swapped=chosen(reverse,0)
assert first!=swapped
print({'forward_choice':first,'reverse_choice':swapped,'order_sensitive':first!=swapped})
