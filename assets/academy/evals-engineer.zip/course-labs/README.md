# AI evaluation / evals engineer — core lessons

Write evaluation cases and scoring contracts before calculating metrics. Practise rubric anchors, slice analysis, abstention coverage and paired comparisons. Finish with sampling uncertainty, judge sensitivity and a reproducible candidate report. Human judgments and automated checks stay distinct.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A versioned evaluation set and candidate comparison with raw outputs, rubrics, per-slice metrics, a failure analysis, uncertainty and a scoped release recommendation.
