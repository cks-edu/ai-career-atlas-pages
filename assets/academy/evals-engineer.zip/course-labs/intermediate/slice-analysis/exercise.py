rows=[('routine',True)]*8+[('ambiguous',False)]*2
scores={}
for group,correct in rows: scores.setdefault(group,[]).append(correct)
report={group:{'n':len(values),'accuracy':sum(values)/len(values)} for group,values in scores.items()}
assert sum(v for _,v in rows)/len(rows)==0.8
assert report['ambiguous']=={'n':2,'accuracy':0.0}
print(report)
