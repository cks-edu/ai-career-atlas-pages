expected=['a','b','c','d'];predicted=['a',None,'wrong',None]
answered=[(truth,pred) for truth,pred in zip(expected,predicted) if pred is not None]
coverage=len(answered)/len(expected)
accuracy=sum(truth==pred for truth,pred in answered)/len(answered)
assert coverage==0.5 and accuracy==0.5
print({'coverage':coverage,'answered_accuracy':accuracy,'abstained':2})
