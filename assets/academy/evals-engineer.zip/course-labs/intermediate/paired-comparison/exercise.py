a={'c1':1,'c2':1,'c3':0};b={'c1':1,'c2':0,'c3':1}
assert a.keys()==b.keys()
wins=[k for k in a if b[k]>a[k]];losses=[k for k in a if b[k]<a[k]]
assert wins==['c3'] and losses==['c2']
print({'improved':wins,'regressed':losses,'ties':len(a)-len(wins)-len(losses)})
