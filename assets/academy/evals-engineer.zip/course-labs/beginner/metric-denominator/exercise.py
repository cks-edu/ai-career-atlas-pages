def ratio(a,b): return None if b==0 else a/b
tp,fp,fn=3,1,2
precision=ratio(tp,tp+fp);recall=ratio(tp,tp+fn)
assert precision==0.75 and recall==0.6
assert ratio(0,0) is None
print({'precision':precision,'recall':recall,'counts':{'tp':tp,'fp':fp,'fn':fn}})
