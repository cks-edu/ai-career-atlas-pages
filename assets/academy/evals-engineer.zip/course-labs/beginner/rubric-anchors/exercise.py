reviewer_a={'c1':2,'c2':1,'c3':0}
reviewer_b={'c1':2,'c2':0,'c3':0}
assert reviewer_a.keys()==reviewer_b.keys()
disagreements=[case for case in reviewer_a if reviewer_a[case]!=reviewer_b[case]]
assert disagreements==['c2']
print({'needs_adjudication':disagreements})
