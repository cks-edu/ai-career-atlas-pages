cases=[{'id':'c1','input':'A parcel has not arrived','expected':'delivery','slice':'routine'},
       {'id':'c2','input':'I cannot sign in','expected':'access','slice':'routine'}]
assert len({c['id'] for c in cases})==len(cases)
assert all(c['input'] and c['expected'] and c['slice'] for c in cases)
print('PASS:',len(cases),'identified cases with declared expectations')
