# AI evaluation / evals engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Evaluation contracts. An evaluation is a repeatable check against defined expectations. A rubric explains what counts as correct and how serious an error is. Then try Write an answer-review rubric. The three levels build toward Auditable model evaluation harness. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Evaluation contracts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Evaluation contracts
Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.
Mental model: An exam rubric says what earns credit before papers are marked.
Boundary: A benchmark samples behavior and cannot prove correctness for every input.
Worked example: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A grader accepts plausible mistakes
The calibration gate flags more than one false pass in ten deliberately incorrect answers. Two grader configurations accept too many known errors to support the release claim. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording.
Recall: Measure false passes and false failures separately on a new calibration set. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Evaluation contracts: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An evaluation is a repeatable check against defined expectations. A rubric explains what counts as correct and how serious an error is.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use the fictional rule “Library loans last 14 days.” Review three answers: “14 days”, “usually two weeks, but check” and “30 days”.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

3. Try step 2
Write separate criteria for factual correctness, clarity and unsupported claims.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

4. Try step 3
Score the answers using those criteria and explain any borderline judgment.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

5. Explain and check your result
The incorrect 30-day answer fails correctness even if its style is clear; uncertainty and factual errors are not treated as identical. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A small rubric with three scored examples and reasons. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers. Apply this toy-case rule manually: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two grader configurations accept too many known errors to support the release claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI evaluation / evals engineer.
Use the fictional rule “Library loans last 14 days.” Review three answers: “14 days”, “usually two weeks, but check” and “30 days”.
Write separate criteria for factual correctness, clarity and unsupported claims.
Score the answers using those criteria and explain any borderline judgment.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A small rubric with three scored examples and reasons. Include beginner-worksheet.md and your completed Grader calibration report.
Check: The incorrect 30-day answer fails correctness even if its style is clear; uncertainty and factual errors are not treated as identical.

### Interview
Explain your beginner solution for AI evaluation / evals engineer. Use this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers.
Review: Start with the task and permitted scope. Explain evaluation contracts: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. Show the input and observed output, then address Calibrate against independently labeled examples and repair ambiguous rubric wording. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A small rubric with three scored examples and reasons. Include beginner-worksheet.md and your completed Grader calibration report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Grader calibration

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Test design, Python or TypeScript, statistics and careful labeling.

### Grader calibration
Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.
Mental model: Calibrate a scale against known weights before weighing new objects.
Boundary: Human agreement is useful evidence, not an infallible truth source.
Worked example: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Auditable model evaluation harness
Build an evaluation harness with traceable judgments and defensible release decisions. Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Recall: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Identify one observation that would contradict your claim.

### Terms
Grader calibration: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an evaluation harness with traceable judgments and defensible release decisions. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The calibration gate flags more than one false pass in ten deliberately incorrect answers. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Build an evaluation harness with traceable judgments and defensible release decisions.
Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.
Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.
Deliverables: Evaluation code and versioned test set; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI evaluation / evals engineer. Use this scenario: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.
Review: Start with the task and permitted scope. Explain grader calibration: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. Show the input and observed output, then address Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Evaluation code and versioned test set; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Regression and slice analysis

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Regression and slice analysis
Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases.
Mental model: A class average can hide one group consistently being left behind.
Boundary: Very small slices need uncertainty and cautious interpretation.
Worked example: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Auditable model evaluation harness
Build an evaluation harness with traceable judgments and defensible release decisions. Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.
Recall: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Identify one observation that would contradict your claim.

### Terms
Regression and slice analysis: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an evaluation harness with traceable judgments and defensible release decisions. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Build an evaluation harness with traceable judgments and defensible release decisions.
Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.
Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average.
Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.
Add bootstrap intervals and test whether candidate rankings remain stable under reasonable rubric changes.
Deliverables: Evaluation code and versioned test set; Rubric/adjudication records; Release recommendation with failure analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A reviewer must reproduce one result and identify which capabilities you implemented. Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

### Interview
Explain your advanced solution for AI evaluation / evals engineer. Use this scenario: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.
Review: Start with the task and permitted scope. Explain regression and slice analysis: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. Show the input and observed output, then address Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Evaluation code and versioned test set; Rubric/adjudication records; Release recommendation with failure analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Python — Open source · local
Isolated environments and reproducible scripts.
Alternative: A spreadsheet for manual evidence exercises, or another supported programming language for implementation; reproduce the same acceptance checks.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Label Studio — Open source Community · commercial editions optional
Configure annotation tasks and export reviewer judgments.
Alternative: A reviewed CSV workbook for small batches, or a commercial annotation platform; access, adjudication and export matter more than brand.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Python: https://docs.python.org/3/library/venv.html
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
Label Studio: https://labelstud.io/guide/quick_start
MLflow: https://mlflow.org/docs/latest/
scikit-learn: https://scikit-learn.org/stable/user_guide.html
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
