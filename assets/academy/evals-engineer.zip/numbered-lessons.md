# AI evaluation / evals engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Evaluation contracts: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Evaluation contracts

Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. In this role, work through: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An exam rubric says what earns credit before papers are marked.

Boundary: A benchmark samples behavior and cannot prove correctness for every input.

Worked example: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI evaluation / evals engineer: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Predict the worked case

Read this case without running a tool: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in evaluation contracts.

Connect the concept to the role

Apply this rule: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A benchmark samples behavior and cannot prove correctness for every input.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies evaluation contracts to this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Evaluation contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with evaluation contracts. Use the glossary below, then write your prediction for: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain evaluation contracts using this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate evaluation contracts to a system or workflow you know. Explain evaluation contracts using this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain evaluation contracts using this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. — Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. A benchmark samples behavior and cannot prove correctness for every input.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: A grader accepts plausible mistakes

The calibration gate flags more than one false pass in ten deliberately incorrect answers. Two grader configurations accept too many known errors to support the release claim. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: An exam rubric says what earns credit before papers are marked.

A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Worked example: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The calibration gate flags more than one false pass in ten deliberately incorrect answers. Two grader configurations accept too many known errors to support the release claim. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers. Apply this toy-case rule manually: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An evaluation is a repeatable check against defined expectations. A rubric explains what counts as correct and how serious an error is.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use the fictional rule “Library loans last 14 days.” Review three answers: “14 days”, “usually two weeks, but check” and “30 days”.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

Preparation · Try step 2

Write separate criteria for factual correctness, clarity and unsupported claims.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

Preparation · Try step 3

Score the answers using those criteria and explain any borderline judgment.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

Preparation · Explain and check your result

The incorrect 30-day answer fails correctness even if its style is clear; uncertainty and factual errors are not treated as identical. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A small rubric with three scored examples and reasons. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers. Apply this toy-case rule manually: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two grader configurations accept too many known errors to support the release claim. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two grader configurations accept too many known errors to support the release claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a grader accepts plausible mistakes. Use the glossary below, then write your prediction for: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain diagnose: a grader accepts plausible mistakes using this case: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a grader accepts plausible mistakes to a system or workflow you know. Explain diagnose: a grader accepts plausible mistakes using this case: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure false passes and false failures separately on a new calibration set. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a grader accepts plausible mistakes using this case: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. State the evidence, one alternative and where the mental model stops.

Quiz: A grader accepts plausible mistakes: The calibration gate flags more than one false pass in ten deliberately incorrect answers.

Change the acceptance rule after seeing an inconvenient result.

Calibrate against independently labeled examples and repair ambiguous rubric wording.

Omit failed cases and report only the successful demonstrations.

Reference: Calibrate against independently labeled examples and repair ambiguous rubric wording. — Calibrate against independently labeled examples and repair ambiguous rubric wording. Measure false passes and false failures separately on a new calibration set.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Test design, Python or TypeScript, statistics and careful labeling.

Terms:

Grader calibration: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Grader calibration

Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. In this role, work through: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Calibrate a scale against known weights before weighing new objects.

Boundary: Human agreement is useful evidence, not an infallible truth source.

Worked example: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Test design, Python or TypeScript, statistics and careful labeling.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI evaluation / evals engineer: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Predict the worked case

Read this case without running a tool: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in grader calibration.

Connect the concept to the role

Apply this rule: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Human agreement is useful evidence, not an infallible truth source.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies grader calibration to this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Grader calibration; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with grader calibration. Use the glossary below, then write your prediction for: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain grader calibration using this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate grader calibration to a system or workflow you know. Explain grader calibration using this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain grader calibration using this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Treat a passing starter as proof of the whole role workflow.

Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.

Ignore the failure because the tool produced an output.

Reference: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. — Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. Human agreement is useful evidence, not an infallible truth source.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Auditable model evaluation harness

Build an evaluation harness with traceable judgments and defensible release decisions. Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication. In this role, work through: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: Calibrate a scale against known weights before weighing new objects.

Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Worked example: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Build an evaluation harness with traceable judgments and defensible release decisions. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Build an evaluation harness with traceable judgments and defensible release decisions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The calibration gate flags more than one false pass in ten deliberately incorrect answers. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-intermediate-2.md: Evaluation code and versioned test set; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: auditable model evaluation harness. Use the glossary below, then write your prediction for: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain integrate: auditable model evaluation harness using this case: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: auditable model evaluation harness to a system or workflow you know. Explain integrate: auditable model evaluation harness using this case: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Identify one observation that would contradict your claim.

Interview: Explain integrate: auditable model evaluation harness using this case: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Auditable model evaluation harness at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Reference: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. — Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Regression and slice analysis: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Regression and slice analysis

Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. In this role, work through: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A class average can hide one group consistently being left behind.

Boundary: Very small slices need uncertainty and cautious interpretation.

Worked example: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI evaluation / evals engineer: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Predict the worked case

Read this case without running a tool: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in regression and slice analysis.

Connect the concept to the role

Apply this rule: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Very small slices need uncertainty and cautious interpretation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies regression and slice analysis to this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Regression and slice analysis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with regression and slice analysis. Use the glossary below, then write your prediction for: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain regression and slice analysis using this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate regression and slice analysis to a system or workflow you know. Explain regression and slice analysis using this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain regression and slice analysis using this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases.

Reference: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. — Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. Very small slices need uncertainty and cautious interpretation.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Auditable model evaluation harness

Build an evaluation harness with traceable judgments and defensible release decisions. Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average. In this role, work through: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: A class average can hide one group consistently being left behind.

Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Worked example: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Build an evaluation harness with traceable judgments and defensible release decisions. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Build an evaluation harness with traceable judgments and defensible release decisions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A reviewer must reproduce one result and identify which capabilities you implemented. Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-advanced-2.md: Evaluation code and versioned test set; Rubric/adjudication records; Release recommendation with failure analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: auditable model evaluation harness. Use the glossary below, then write your prediction for: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain defend: auditable model evaluation harness using this case: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: auditable model evaluation harness to a system or workflow you know. Explain defend: auditable model evaluation harness using this case: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Identify one observation that would contradict your claim.

Interview: Explain defend: auditable model evaluation harness using this case: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Auditable model evaluation harness at this level?

Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. — Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
