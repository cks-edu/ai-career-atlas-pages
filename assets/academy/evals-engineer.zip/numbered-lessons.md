# AI evaluation / evals engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Evaluation contracts: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Write the task contract before the score

Evaluation asks whether a system meets a defined task. Start with cases: input, expected behavior, evidence and a reason the case matters. A test case should distinguish a useful answer from a plausible-looking one.

How it works
The fixture stores a stable case ID, expected label and task category. Missing expectations are rejected. A real evaluation dataset also needs provenance, consent where applicable and a separation between development and final evaluation.

Where the model stops
A tiny case set cannot represent every user or failure mode. Do not write expected answers after seeing the candidate output.

Make one change
Write ten synthetic support cases before running a candidate. Include ambiguous, no-answer and adversarial inputs. State when a case should be reviewed by a person instead of forcing one correct label.

Mental model: A driving test specifies a maneuver and observation; it does not score how impressive the car looks.

Boundary: A tiny case set cannot represent every user or failure mode. Do not write expected answers after seeing the candidate output.

Worked example: cases=[{'id':'c1','input':'A parcel has not arrived','expected':'delivery','slice':'routine'},
       {'id':'c2','input':'I cannot sign in','expected':'access','slice':'routine'}]
assert len({c['id'] for c in cases})==len(cases)
assert all(c['input'] and c['expected'] and c['slice'] for c in cases)
print('PASS:',len(cases),'identified cases with declared expectations')


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/evaluation-cases. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Write ten synthetic support cases before running a candidate. Include ambiguous, no-answer and adversarial inputs. State when a case should be reviewed by a person instead of forcing one correct label.

Terminal folder: course-labs/beginner/evaluation-cases

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture stores a stable case ID, expected label and task category. Missing expectations are rejected. A real evaluation dataset also needs provenance, consent where applicable and a separation between development and final evaluation.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/evaluation-cases. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The two reference cases have unique IDs and explicit expectations. Your case sheet records uncertainty rather than inventing an answer for every input.

Build your change

Write ten synthetic support cases before running a candidate. Include ambiguous, no-answer and adversarial inputs. State when a case should be reviewed by a person instead of forcing one correct label.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The two reference cases have unique IDs and explicit expectations. Your case sheet records uncertainty rather than inventing an answer for every input.

Break, repair and explain

Deliberately violate this boundary: A tiny case set cannot represent every user or failure mode. Do not write expected answers after seeing the candidate output. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The two reference cases have unique IDs and explicit expectations. Your case sheet records uncertainty rather than inventing an answer for every input.

Troubleshoot: My result does not match Write the task contract before the score: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture stores a stable case ID, expected label and task category. Missing expectations are rejected. A real evaluation dataset also needs provenance, consent where applicable and a separation between development and final evaluation. Then inspect this limit: A tiny case set cannot represent every user or failure mode. Do not write expected answers after seeing the candidate output. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/evaluation-cases/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Write the task contract before the score line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A driving test specifies a maneuver and observation; it does not score how impressive the car looks.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: When should the expected behavior be decided? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A tiny case set cannot represent every user or failure mode. Do not write expected answers after seeing the candidate output. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: When should the expected behavior be decided?

Interview: When should the expected behavior be decided? Defend your answer using your actual lab result and this boundary: A tiny case set cannot represent every user or failure mode. Do not write expected answers after seeing the candidate output.

Quiz: When should the expected behavior be decided?

Before inspecting the candidate outputs used for the final comparison.

After selecting the favorite candidate.

Only for passing cases.

Reference: Before inspecting the candidate outputs used for the final comparison. — Predeclared criteria reduce cherry-picking. Ambiguous cases need an explicit policy and review route.

Sources:

Python: JSON documents and parsing: https://docs.python.org/3/library/json.html

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

### Count errors with the right denominator

Accuracy counts correct predictions divided by evaluated predictions. Precision and recall answer different questions about a chosen positive class. Name the metric, population and denominator instead of reporting an unexplained percentage.

How it works
For the fixture’s positive class, precision is TP/(TP+FP) and recall is TP/(TP+FN). A zero denominator returns unknown, not a perfect score. Real tasks may need costs or continuous outcomes instead.

Where the model stops
A metric can be calculated correctly and still be unsuitable for the task. Small samples and class imbalance change how to interpret it.

Make one change
Create six labeled cases and predictions. Calculate counts by hand, then verify them in Python. Add a candidate that never predicts the positive class and explain its precision/recall without hiding undefined values.

Mental model: A score of eight means little until you know whether it was eight out of ten or eight out of a thousand.

Boundary: A metric can be calculated correctly and still be unsuitable for the task. Small samples and class imbalance change how to interpret it.

Worked example: def ratio(a,b): return None if b==0 else a/b
tp,fp,fn=3,1,2
precision=ratio(tp,tp+fp);recall=ratio(tp,tp+fn)
assert precision==0.75 and recall==0.6
assert ratio(0,0) is None
print({'precision':precision,'recall':recall,'counts':{'tp':tp,'fp':fp,'fn':fn}})


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/metric-denominator. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create six labeled cases and predictions. Calculate counts by hand, then verify them in Python. Add a candidate that never predicts the positive class and explain its precision/recall without hiding undefined values.

Terminal folder: course-labs/beginner/metric-denominator

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. For the fixture’s positive class, precision is TP/(TP+FP) and recall is TP/(TP+FN). A zero denominator returns unknown, not a perfect score. Real tasks may need costs or continuous outcomes instead.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/metric-denominator. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Precision is 0.75 and recall 0.6 for the declared counts. Your report keeps raw counts and explains the zero-denominator case.

Build your change

Create six labeled cases and predictions. Calculate counts by hand, then verify them in Python. Add a candidate that never predicts the positive class and explain its precision/recall without hiding undefined values.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Precision is 0.75 and recall 0.6 for the declared counts. Your report keeps raw counts and explains the zero-denominator case.

Break, repair and explain

Deliberately violate this boundary: A metric can be calculated correctly and still be unsuitable for the task. Small samples and class imbalance change how to interpret it. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Precision is 0.75 and recall 0.6 for the declared counts. Your report keeps raw counts and explains the zero-denominator case.

Troubleshoot: My result does not match Count errors with the right denominator: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: For the fixture’s positive class, precision is TP/(TP+FP) and recall is TP/(TP+FN). A zero denominator returns unknown, not a perfect score. Real tasks may need costs or continuous outcomes instead. Then inspect this limit: A metric can be calculated correctly and still be unsuitable for the task. Small samples and class imbalance change how to interpret it. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/metric-denominator/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Count errors with the right denominator line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A score of eight means little until you know whether it was eight out of ten or eight out of a thousand.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: There are no positive predictions. Is precision automatically 100%? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A metric can be calculated correctly and still be unsuitable for the task. Small samples and class imbalance change how to interpret it. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: There are no positive predictions. Is precision automatically 100%?

Interview: There are no positive predictions. Is precision automatically 100%? Defend your answer using your actual lab result and this boundary: A metric can be calculated correctly and still be unsuitable for the task. Small samples and class imbalance change how to interpret it.

Quiz: There are no positive predictions. Is precision automatically 100%?

Yes.

No; its denominator is zero and the reporting policy must be explicit.

Only if accuracy is high.

Reference: No; its denominator is zero and the reporting policy must be explicit. — No positive predictions provide no evidence for precision. Report the undefined case or the chosen library policy explicitly.

Sources:

Python: statistics functions: https://docs.python.org/3/library/statistics.html

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

### Use examples to make a rubric understandable

Some outputs need human judgment. A rubric describes observable criteria and concrete examples for each score. Reviewers should be able to explain why an answer met an anchor rather than relying on whether it sounded polished.

How it works
The fixture records two independent scores on the same case IDs and identifies disagreements. Agreement is a diagnostic for rubric clarity; reviewers can agree and still be wrong.

Where the model stops
Averaging conflicting scores can hide a different interpretation of the task. Preserve original judgments before adjudicating.

Make one change
Write a 0/1/2 rubric for source-supported answers: unsupported, partially supported and fully supported under a declared evidence scope. Score three answers independently with a second reviewer or two separated passes; retain disagreements and the revised anchor.

Mental model: A marking guide shows what earns each point; it is not just a row of empty stars.

Boundary: Averaging conflicting scores can hide a different interpretation of the task. Preserve original judgments before adjudicating.

Worked example: reviewer_a={'c1':2,'c2':1,'c3':0}
reviewer_b={'c1':2,'c2':0,'c3':0}
assert reviewer_a.keys()==reviewer_b.keys()
disagreements=[case for case in reviewer_a if reviewer_a[case]!=reviewer_b[case]]
assert disagreements==['c2']
print({'needs_adjudication':disagreements})


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/rubric-anchors. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Write a 0/1/2 rubric for source-supported answers: unsupported, partially supported and fully supported under a declared evidence scope. Score three answers independently with a second reviewer or two separated passes; retain disagreements and the revised anchor.

Terminal folder: course-labs/beginner/rubric-anchors

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture records two independent scores on the same case IDs and identifies disagreements. Agreement is a diagnostic for rubric clarity; reviewers can agree and still be wrong.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/rubric-anchors. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: c2 is flagged for adjudication. Your rubric includes examples and reasons; a revised score does not erase the first judgment.

Build your change

Write a 0/1/2 rubric for source-supported answers: unsupported, partially supported and fully supported under a declared evidence scope. Score three answers independently with a second reviewer or two separated passes; retain disagreements and the revised anchor.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. c2 is flagged for adjudication. Your rubric includes examples and reasons; a revised score does not erase the first judgment.

Break, repair and explain

Deliberately violate this boundary: Averaging conflicting scores can hide a different interpretation of the task. Preserve original judgments before adjudicating. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: c2 is flagged for adjudication. Your rubric includes examples and reasons; a revised score does not erase the first judgment.

Troubleshoot: My result does not match Use examples to make a rubric understandable: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture records two independent scores on the same case IDs and identifies disagreements. Agreement is a diagnostic for rubric clarity; reviewers can agree and still be wrong. Then inspect this limit: Averaging conflicting scores can hide a different interpretation of the task. Preserve original judgments before adjudicating. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/rubric-anchors/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Use examples to make a rubric understandable line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A marking guide shows what earns each point; it is not just a row of empty stars.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: Two reviewers disagree. What is a useful next step? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Averaging conflicting scores can hide a different interpretation of the task. Preserve original judgments before adjudicating. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Two reviewers disagree. What is a useful next step?

Interview: Two reviewers disagree. What is a useful next step? Defend your answer using your actual lab result and this boundary: Averaging conflicting scores can hide a different interpretation of the task. Preserve original judgments before adjudicating.

Quiz: Two reviewers disagree. What is a useful next step?

Delete the lower score.

Hide the case.

Inspect the anchor and preserve both judgments before adjudication.

Reference: Inspect the anchor and preserve both judgments before adjudication. — Disagreement can expose vague instructions or ambiguous evidence. It is useful data, not noise to discard.

Sources:

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

Python: JSON documents and parsing: https://docs.python.org/3/library/json.html

### Evaluation contracts

Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. In this role, work through: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An exam rubric says what earns credit before papers are marked.

Boundary: A benchmark samples behavior and cannot prove correctness for every input.

Worked example: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI evaluation / evals engineer: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Predict the worked case

Read this case without running a tool: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in evaluation contracts.

Connect the concept to the role

Apply this rule: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A benchmark samples behavior and cannot prove correctness for every input.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies evaluation contracts to this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Evaluation contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with evaluation contracts. Use the glossary below, then write your prediction for: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain evaluation contracts using this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate evaluation contracts to a system or workflow you know. Explain evaluation contracts using this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain evaluation contracts using this case: A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. — Define the intended behavior, representative inputs and scoring rule before judging outputs. Keep format, factual support and task success as distinct measurements. A benchmark samples behavior and cannot prove correctness for every input.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: A grader accepts plausible mistakes

The calibration gate flags more than one false pass in ten deliberately incorrect answers. Two grader configurations accept too many known errors to support the release claim. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: An exam rubric says what earns credit before papers are marked.

A policy answer gets separate scores for correct policy, supporting citation and readable format; valid JSON cannot compensate for wrong policy.

Worked example: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The calibration gate flags more than one false pass in ten deliberately incorrect answers. Two grader configurations accept too many known errors to support the release claim. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers. Apply this toy-case rule manually: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An evaluation is a repeatable check against defined expectations. A rubric explains what counts as correct and how serious an error is.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use the fictional rule “Library loans last 14 days.” Review three answers: “14 days”, “usually two weeks, but check” and “30 days”.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

Preparation · Try step 2

Write separate criteria for factual correctness, clarity and unsupported claims.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

Preparation · Try step 3

Score the answers using those criteria and explain any borderline judgment.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A small rubric with three scored examples and reasons.

Preparation · Explain and check your result

The incorrect 30-day answer fails correctness even if its style is clear; uncertainty and factual errors are not treated as identical. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A small rubric with three scored examples and reasons. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The calibration gate flags more than one false pass in ten deliberately incorrect answers. Apply this toy-case rule manually: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two grader configurations accept too many known errors to support the release claim. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two grader configurations accept too many known errors to support the release claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a grader accepts plausible mistakes. Use the glossary below, then write your prediction for: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain diagnose: a grader accepts plausible mistakes using this case: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a grader accepts plausible mistakes to a system or workflow you know. Explain diagnose: a grader accepts plausible mistakes using this case: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure false passes and false failures separately on a new calibration set. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a grader accepts plausible mistakes using this case: Review when false_passes >= 2 (out of ten incorrect answers). This is a declared toy-case contract, not an industry standard. Calibrate against independently labeled examples and repair ambiguous rubric wording. State the evidence, one alternative and where the mental model stops.

Quiz: A grader accepts plausible mistakes: The calibration gate flags more than one false pass in ten deliberately incorrect answers.

Change the acceptance rule after seeing an inconvenient result.

Calibrate against independently labeled examples and repair ambiguous rubric wording.

Omit failed cases and report only the successful demonstrations.

Reference: Calibrate against independently labeled examples and repair ambiguous rubric wording. — Calibrate against independently labeled examples and repair ambiguous rubric wording. Measure false passes and false failures separately on a new calibration set.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Test design, Python or TypeScript, statistics and careful labeling.

Terms:

Grader calibration: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Look beyond the overall average

A strong overall score can hide weak performance for a language, task type or input condition. Choose meaningful evaluation slices before comparing candidates and report the sample size for each.

How it works
Aggregate correct flags separately for each declared slice. This fixture exposes a low score in a small slice. It is a descriptive classroom calculation, not a statistical fairness certification.

Where the model stops
Tiny slices are noisy and categories can overlap. Avoid publishing private attributes or drawing causal conclusions from these rates alone.

Make one change
Add two candidates and compare their per-slice counts, not just the average. Include a slice with one case and explain why you need more evidence before making a broad claim about that group.

Mental model: A class average can look healthy while one group has no access to the right teaching materials.

Boundary: Tiny slices are noisy and categories can overlap. Avoid publishing private attributes or drawing causal conclusions from these rates alone.

Worked example: rows=[('routine',True)]*8+[('ambiguous',False)]*2
scores={}
for group,correct in rows: scores.setdefault(group,[]).append(correct)
report={group:{'n':len(values),'accuracy':sum(values)/len(values)} for group,values in scores.items()}
assert sum(v for _,v in rows)/len(rows)==0.8
assert report['ambiguous']=={'n':2,'accuracy':0.0}
print(report)


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/slice-analysis. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add two candidates and compare their per-slice counts, not just the average. Include a slice with one case and explain why you need more evidence before making a broad claim about that group.

Terminal folder: course-labs/intermediate/slice-analysis

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Aggregate correct flags separately for each declared slice. This fixture exposes a low score in a small slice. It is a descriptive classroom calculation, not a statistical fairness certification.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/slice-analysis. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Overall accuracy is 0.8 while the ambiguous slice scores 0/2. Your comparison names the uncertainty around small slices.

Build your change

Add two candidates and compare their per-slice counts, not just the average. Include a slice with one case and explain why you need more evidence before making a broad claim about that group.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Overall accuracy is 0.8 while the ambiguous slice scores 0/2. Your comparison names the uncertainty around small slices.

Break, repair and explain

Deliberately violate this boundary: Tiny slices are noisy and categories can overlap. Avoid publishing private attributes or drawing causal conclusions from these rates alone. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Overall accuracy is 0.8 while the ambiguous slice scores 0/2. Your comparison names the uncertainty around small slices.

Troubleshoot: My result does not match Look beyond the overall average: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Aggregate correct flags separately for each declared slice. This fixture exposes a low score in a small slice. It is a descriptive classroom calculation, not a statistical fairness certification. Then inspect this limit: Tiny slices are noisy and categories can overlap. Avoid publishing private attributes or drawing causal conclusions from these rates alone. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/slice-analysis/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Look beyond the overall average line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A class average can look healthy while one group has no access to the right teaching materials.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: Can 80% overall accuracy establish that every slice performs adequately? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Tiny slices are noisy and categories can overlap. Avoid publishing private attributes or drawing causal conclusions from these rates alone. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Can 80% overall accuracy establish that every slice performs adequately?

Interview: Can 80% overall accuracy establish that every slice performs adequately? Defend your answer using your actual lab result and this boundary: Tiny slices are noisy and categories can overlap. Avoid publishing private attributes or drawing causal conclusions from these rates alone.

Quiz: Can 80% overall accuracy establish that every slice performs adequately?

No; inspect meaningful slices and sample sizes.

Yes.

Only for a large model.

Reference: No; inspect meaningful slices and sample sizes. — An aggregate mixes different cases. Report disaggregated evidence and its limitations before making a release decision.

Sources:

Python: statistics functions: https://docs.python.org/3/library/statistics.html

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

### Measure both correctness and unanswered cases

A system may abstain when evidence is missing. Report how often it answers and how often those answered cases are correct. Otherwise a system can look accurate by refusing nearly everything.

How it works
Coverage divides answered cases by all eligible cases. Conditional accuracy uses only answered cases. The fixture reports both and keeps abstentions in the population count.

Where the model stops
Abstention can be appropriate or harmful depending on task costs. Define which cases should receive a safe refusal and review them separately.

Make one change
Compare a candidate that answers everything with one that abstains on uncertain cases. Report coverage, answered-case accuracy, correct abstentions and inappropriate refusals under your prewritten rubric.

Mental model: A goalkeeper who only attempts easy saves needs an attempt rate beside the save percentage.

Boundary: Abstention can be appropriate or harmful depending on task costs. Define which cases should receive a safe refusal and review them separately.

Worked example: expected=['a','b','c','d'];predicted=['a',None,'wrong',None]
answered=[(truth,pred) for truth,pred in zip(expected,predicted) if pred is not None]
coverage=len(answered)/len(expected)
accuracy=sum(truth==pred for truth,pred in answered)/len(answered)
assert coverage==0.5 and accuracy==0.5
print({'coverage':coverage,'answered_accuracy':accuracy,'abstained':2})


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/abstention-coverage. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Compare a candidate that answers everything with one that abstains on uncertain cases. Report coverage, answered-case accuracy, correct abstentions and inappropriate refusals under your prewritten rubric.

Terminal folder: course-labs/intermediate/abstention-coverage

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Coverage divides answered cases by all eligible cases. Conditional accuracy uses only answered cases. The fixture reports both and keeps abstentions in the population count.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/abstention-coverage. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Coverage and conditional accuracy both equal 0.5. Your report retains the two unanswered cases instead of dropping them silently.

Build your change

Compare a candidate that answers everything with one that abstains on uncertain cases. Report coverage, answered-case accuracy, correct abstentions and inappropriate refusals under your prewritten rubric.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Coverage and conditional accuracy both equal 0.5. Your report retains the two unanswered cases instead of dropping them silently.

Break, repair and explain

Deliberately violate this boundary: Abstention can be appropriate or harmful depending on task costs. Define which cases should receive a safe refusal and review them separately. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Coverage and conditional accuracy both equal 0.5. Your report retains the two unanswered cases instead of dropping them silently.

Troubleshoot: My result does not match Measure both correctness and unanswered cases: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Coverage divides answered cases by all eligible cases. Conditional accuracy uses only answered cases. The fixture reports both and keeps abstentions in the population count. Then inspect this limit: Abstention can be appropriate or harmful depending on task costs. Define which cases should receive a safe refusal and review them separately. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/abstention-coverage/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Measure both correctness and unanswered cases line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A goalkeeper who only attempts easy saves needs an attempt rate beside the save percentage.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: A candidate answers one easy case correctly and refuses 99. Is 100% answered-case accuracy sufficient? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Abstention can be appropriate or harmful depending on task costs. Define which cases should receive a safe refusal and review them separately. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A candidate answers one easy case correctly and refuses 99. Is 100% answered-case accuracy sufficient?

Interview: A candidate answers one easy case correctly and refuses 99. Is 100% answered-case accuracy sufficient? Defend your answer using your actual lab result and this boundary: Abstention can be appropriate or harmful depending on task costs. Define which cases should receive a safe refusal and review them separately.

Quiz: A candidate answers one easy case correctly and refuses 99. Is 100% answered-case accuracy sufficient?

Yes.

No; report 1% coverage and evaluate the refusals.

Only if it responds quickly.

Reference: No; report 1% coverage and evaluate the refusals. — Conditional accuracy alone hides the amount of work completed. Coverage and refusal quality are part of the task contract.

Sources:

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

Python: statistics functions: https://docs.python.org/3/library/statistics.html

### Compare candidates on the same case IDs

A paired comparison evaluates both candidates on the same inputs. Track wins, losses and ties per case so a better average does not hide newly broken behavior.

How it works
The fixture requires identical case sets, then records each changed outcome. Case c2 regresses even though c3 improves. Retain both changes and their importance instead of reporting only the net total.

Where the model stops
Equal case sets do not remove judge bias or stochastic variation. Keep candidate versions and repeated-run policies explicit.

Make one change
Compare two candidates on your ten-case set. Produce a case-level diff with raw outputs and rubric reasons. Mark critical failures before running the comparison and keep a separate decision for them.

Mental model: Two runners compete on the same course before their times are compared.

Boundary: Equal case sets do not remove judge bias or stochastic variation. Keep candidate versions and repeated-run policies explicit.

Worked example: a={'c1':1,'c2':1,'c3':0};b={'c1':1,'c2':0,'c3':1}
assert a.keys()==b.keys()
wins=[k for k in a if b[k]>a[k]];losses=[k for k in a if b[k]<a[k]]
assert wins==['c3'] and losses==['c2']
print({'improved':wins,'regressed':losses,'ties':len(a)-len(wins)-len(losses)})


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/paired-comparison. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Compare two candidates on your ten-case set. Produce a case-level diff with raw outputs and rubric reasons. Mark critical failures before running the comparison and keep a separate decision for them.

Terminal folder: course-labs/intermediate/paired-comparison

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture requires identical case sets, then records each changed outcome. Case c2 regresses even though c3 improves. Retain both changes and their importance instead of reporting only the net total.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/paired-comparison. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The report exposes one improvement and one regression. Your release recommendation discusses the changed cases, not just a tied average.

Build your change

Compare two candidates on your ten-case set. Produce a case-level diff with raw outputs and rubric reasons. Mark critical failures before running the comparison and keep a separate decision for them.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The report exposes one improvement and one regression. Your release recommendation discusses the changed cases, not just a tied average.

Break, repair and explain

Deliberately violate this boundary: Equal case sets do not remove judge bias or stochastic variation. Keep candidate versions and repeated-run policies explicit. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The report exposes one improvement and one regression. Your release recommendation discusses the changed cases, not just a tied average.

Troubleshoot: My result does not match Compare candidates on the same case IDs: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture requires identical case sets, then records each changed outcome. Case c2 regresses even though c3 improves. Retain both changes and their importance instead of reporting only the net total. Then inspect this limit: Equal case sets do not remove judge bias or stochastic variation. Keep candidate versions and repeated-run policies explicit. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/paired-comparison/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Compare candidates on the same case IDs line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Two runners compete on the same course before their times are compared.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: Two averages are identical. What should you inspect next? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Equal case sets do not remove judge bias or stochastic variation. Keep candidate versions and repeated-run policies explicit. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Two averages are identical. What should you inspect next?

Interview: Two averages are identical. What should you inspect next? Defend your answer using your actual lab result and this boundary: Equal case sets do not remove judge bias or stochastic variation. Keep candidate versions and repeated-run policies explicit.

Quiz: Two averages are identical. What should you inspect next?

Only the prettier output.

Only the model size.

Per-case wins, regressions and critical failures.

Reference: Per-case wins, regressions and critical failures. — An unchanged aggregate can contain important changed behavior. Preserve the paired evidence for review.

Sources:

Python: JSON documents and parsing: https://docs.python.org/3/library/json.html

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

### Grader calibration

Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. In this role, work through: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Calibrate a scale against known weights before weighing new objects.

Boundary: Human agreement is useful evidence, not an infallible truth source.

Worked example: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Test design, Python or TypeScript, statistics and careful labeling.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI evaluation / evals engineer: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Predict the worked case

Read this case without running a tool: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in grader calibration.

Connect the concept to the role

Apply this rule: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Human agreement is useful evidence, not an infallible truth source.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies grader calibration to this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Grader calibration; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with grader calibration. Use the glossary below, then write your prediction for: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain grader calibration using this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate grader calibration to a system or workflow you know. Explain grader calibration using this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain grader calibration using this case: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Treat a passing starter as proof of the whole role workflow.

Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.

Ignore the failure because the tool produced an output.

Reference: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. — Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. Human agreement is useful evidence, not an infallible truth source.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Auditable model evaluation harness

Build an evaluation harness with traceable judgments and defensible release decisions. Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication. In this role, work through: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: Calibrate a scale against known weights before weighing new objects.

Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.

Worked example: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Build an evaluation harness with traceable judgments and defensible release decisions. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Build an evaluation harness with traceable judgments and defensible release decisions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The calibration gate flags more than one false pass in ten deliberately incorrect answers. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-intermediate-2.md: Evaluation code and versioned test set; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: auditable model evaluation harness. Use the glossary below, then write your prediction for: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain integrate: auditable model evaluation harness using this case: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: auditable model evaluation harness to a system or workflow you know. Explain integrate: auditable model evaluation harness using this case: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Identify one observation that would contradict your claim.

Interview: Explain integrate: auditable model evaluation harness using this case: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Auditable model evaluation harness at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Reference: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. — Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Regression and slice analysis: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Show uncertainty around a small sample

A sample score is an estimate under assumptions about the sampled population. Repeated resampling can illustrate how much a metric changes with the observed cases. It cannot discover failure modes absent from the dataset.

How it works
The bootstrap fixture resamples five independent binary observations with a fixed local generator. It reports a descriptive percentile range, not a guarantee for arbitrary future users. Correlated cases need a suitable resampling unit.

Where the model stops
A bootstrap range can be misleading with tiny, biased or correlated samples. Describe assumptions and obtain broader evidence before high-impact decisions.

Make one change
Repeat with five and fifty synthetic independent observations, then with duplicated correlated cases. Explain why duplication does not create fifty independent users. Record the resampling unit and the missing population coverage.

Mental model: Measuring a few stones from a bag tells you about that sample; it cannot reveal a second bag you never opened.

Boundary: A bootstrap range can be misleading with tiny, biased or correlated samples. Describe assumptions and obtain broader evidence before high-impact decisions.

Worked example: import random
values=[1,1,1,0,0];rng=random.Random(17)
means=sorted(sum(rng.choices(values,k=len(values)))/len(values) for _ in range(1000))
low,high=means[24],means[974]
assert 0<=low<=high<=1
print({'sample_mean':sum(values)/len(values),'descriptive_percentile_range':[low,high],'n':len(values)})


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/sampling-uncertainty. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Repeat with five and fifty synthetic independent observations, then with duplicated correlated cases. Explain why duplication does not create fifty independent users. Record the resampling unit and the missing population coverage.

Terminal folder: course-labs/advanced/sampling-uncertainty

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The bootstrap fixture resamples five independent binary observations with a fixed local generator. It reports a descriptive percentile range, not a guarantee for arbitrary future users. Correlated cases need a suitable resampling unit.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/sampling-uncertainty. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The script prints a sample mean of 0.6 and a bounded resampling range. Your conclusion states the small-sample and independence limits.

Build your change

Repeat with five and fifty synthetic independent observations, then with duplicated correlated cases. Explain why duplication does not create fifty independent users. Record the resampling unit and the missing population coverage.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The script prints a sample mean of 0.6 and a bounded resampling range. Your conclusion states the small-sample and independence limits.

Break, repair and explain

Deliberately violate this boundary: A bootstrap range can be misleading with tiny, biased or correlated samples. Describe assumptions and obtain broader evidence before high-impact decisions. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The script prints a sample mean of 0.6 and a bounded resampling range. Your conclusion states the small-sample and independence limits.

Troubleshoot: My result does not match Show uncertainty around a small sample: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The bootstrap fixture resamples five independent binary observations with a fixed local generator. It reports a descriptive percentile range, not a guarantee for arbitrary future users. Correlated cases need a suitable resampling unit. Then inspect this limit: A bootstrap range can be misleading with tiny, biased or correlated samples. Describe assumptions and obtain broader evidence before high-impact decisions. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/sampling-uncertainty/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Show uncertainty around a small sample line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Measuring a few stones from a bag tells you about that sample; it cannot reveal a second bag you never opened.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: What can resampling the same dataset fail to reveal? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A bootstrap range can be misleading with tiny, biased or correlated samples. Describe assumptions and obtain broader evidence before high-impact decisions. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What can resampling the same dataset fail to reveal?

Interview: What can resampling the same dataset fail to reveal? Defend your answer using your actual lab result and this boundary: A bootstrap range can be misleading with tiny, biased or correlated samples. Describe assumptions and obtain broader evidence before high-impact decisions.

Quiz: What can resampling the same dataset fail to reveal?

The original sample mean.

Entire failure modes missing from the collected cases.

Any arithmetic result.

Reference: Entire failure modes missing from the collected cases. — Resampling varies the observed evidence; it does not create representative cases from an unseen population.

Sources:

Python: reproducible pseudorandom generators: https://docs.python.org/3/library/random.html

Python: statistics functions: https://docs.python.org/3/library/statistics.html

### Test whether the judge changes the result

An automated judge is another system to evaluate. Candidate order, verbosity and answer style can affect its preference. Compare with a reviewed human overlap set and retain disagreements.

How it works
The fixture maps swapped A/B positions back to stable candidate identities. A positional judge chooses the first slot twice and therefore changes its preferred candidate. This detects one bias pattern; it does not measure every judge limitation.

Where the model stops
An LLM judge score is not ground truth. Keep its model, prompt, version and sampling settings with the evaluation artifact.

Make one change
Blind candidate names and randomize answer order for an overlap set. Compare judge decisions before/after swaps and with human rubric judgments. Categorize disagreements and document when human review overrides automation.

Mental model: A referee also needs calibration; changing shirt colors should not change which rule was broken.

Boundary: An LLM judge score is not ground truth. Keep its model, prompt, version and sampling settings with the evaluation artifact.

Worked example: def chosen(order,slot): return order[slot]
forward=('candidate-1','candidate-2');reverse=tuple(reversed(forward))
first=chosen(forward,0);swapped=chosen(reverse,0)
assert first!=swapped
print({'forward_choice':first,'reverse_choice':swapped,'order_sensitive':first!=swapped})


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/judge-sensitivity. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Blind candidate names and randomize answer order for an overlap set. Compare judge decisions before/after swaps and with human rubric judgments. Categorize disagreements and document when human review overrides automation.

Terminal folder: course-labs/advanced/judge-sensitivity

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture maps swapped A/B positions back to stable candidate identities. A positional judge chooses the first slot twice and therefore changes its preferred candidate. This detects one bias pattern; it does not measure every judge limitation.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/judge-sensitivity. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The fixture detects an order-sensitive first-position preference. Your report separates agreement rates from evidence of factual correctness.

Build your change

Blind candidate names and randomize answer order for an overlap set. Compare judge decisions before/after swaps and with human rubric judgments. Categorize disagreements and document when human review overrides automation.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The fixture detects an order-sensitive first-position preference. Your report separates agreement rates from evidence of factual correctness.

Break, repair and explain

Deliberately violate this boundary: An LLM judge score is not ground truth. Keep its model, prompt, version and sampling settings with the evaluation artifact. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The fixture detects an order-sensitive first-position preference. Your report separates agreement rates from evidence of factual correctness.

Troubleshoot: My result does not match Test whether the judge changes the result: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture maps swapped A/B positions back to stable candidate identities. A positional judge chooses the first slot twice and therefore changes its preferred candidate. This detects one bias pattern; it does not measure every judge limitation. Then inspect this limit: An LLM judge score is not ground truth. Keep its model, prompt, version and sampling settings with the evaluation artifact. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/judge-sensitivity/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Test whether the judge changes the result line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A referee also needs calibration; changing shirt colors should not change which rule was broken.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: A judge always prefers whichever answer is shown first. What does swapping reveal? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An LLM judge score is not ground truth. Keep its model, prompt, version and sampling settings with the evaluation artifact. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A judge always prefers whichever answer is shown first. What does swapping reveal?

Interview: A judge always prefers whichever answer is shown first. What does swapping reveal? Defend your answer using your actual lab result and this boundary: An LLM judge score is not ground truth. Keep its model, prompt, version and sampling settings with the evaluation artifact.

Quiz: A judge always prefers whichever answer is shown first. What does swapping reveal?

Order sensitivity; map results back to stable candidate IDs.

That both candidates are perfect.

That human review is unnecessary.

Reference: Order sensitivity; map results back to stable candidate IDs. — Position labels must not be confused with candidate identity. A consistent positional preference is a calibration warning.

Sources:

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

Python: JSON documents and parsing: https://docs.python.org/3/library/json.html

### Capstone: an evidence-backed evaluation report

Deliver a small but reproducible candidate comparison: predeclared cases, stable IDs, explicit rubrics, raw outputs, slice metrics, uncertainty, critical failures and a clear recommendation. Use the original course project to run the evaluation harness.

How it works
The fixture blocks publication when a critical failure is present or required evidence is absent. Passing means the dossier meets this classroom schema; the underlying observations still need review.

Where the model stops
A release report is bounded by its cases, task and environment. It is not a universal safety certificate or a promise of job readiness.

Make one change
Run at least 20 cases through two candidates or two explicitly labeled deterministic baselines. Include no-answer and difficult slices. Publish the case-level diff, rubric, raw predictions, limitations and a five-minute interview explanation. Claim real model execution only if you actually ran and recorded it.

Mental model: An inspection report shows measurements, exceptions and the decision rule, not just a green stamp.

Boundary: A release report is bounded by its cases, task and environment. It is not a universal safety certificate or a promise of job readiness.

Worked example: def publishable(report):
    required={'dataset_revision','candidate_versions','rubric','raw_outputs','slice_report','limitations'}
    return required<=report.keys() and report.get('critical_failures')==0 and all(bool(report[k]) for k in required)
report={k:'evidence/'+k for k in ['dataset_revision','candidate_versions','rubric','raw_outputs','slice_report','limitations']}
report['critical_failures']=0;assert publishable(report)
report['critical_failures']=1;assert not publishable(report)
print('PASS: critical failure blocks this report’s release recommendation')


Setup: Download and extract evals-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/evaluation-capstone. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Run at least 20 cases through two candidates or two explicitly labeled deterministic baselines. Include no-answer and difficult slices. Publish the case-level diff, rubric, raw predictions, limitations and a five-minute interview explanation. Claim real model execution only if you actually ran and recorded it.

Terminal folder: course-labs/advanced/evaluation-capstone

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture blocks publication when a critical failure is present or required evidence is absent. Passing means the dossier meets this classroom schema; the underlying observations still need review.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/evaluation-capstone. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The report rejects a critical failure. Your portfolio contains reproducible comparisons and an honest recommendation, including what remains unknown.

Build your change

Run at least 20 cases through two candidates or two explicitly labeled deterministic baselines. Include no-answer and difficult slices. Publish the case-level diff, rubric, raw predictions, limitations and a five-minute interview explanation. Claim real model execution only if you actually ran and recorded it.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The report rejects a critical failure. Your portfolio contains reproducible comparisons and an honest recommendation, including what remains unknown.

Break, repair and explain

Deliberately violate this boundary: A release report is bounded by its cases, task and environment. It is not a universal safety certificate or a promise of job readiness. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The report rejects a critical failure. Your portfolio contains reproducible comparisons and an honest recommendation, including what remains unknown.

Troubleshoot: My result does not match Capstone: an evidence-backed evaluation report: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture blocks publication when a critical failure is present or required evidence is absent. Passing means the dossier meets this classroom schema; the underlying observations still need review. Then inspect this limit: A release report is bounded by its cases, task and environment. It is not a universal safety certificate or a promise of job readiness. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/evaluation-capstone/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Capstone: an evidence-backed evaluation report line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An inspection report shows measurements, exceptions and the decision rule, not just a green stamp.

seeker: Prepare a coursework example for AI evaluation / evals engineer. Answer this interview question before revealing the rubric: Which conclusion fits a successful bounded evaluation? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A release report is bounded by its cases, task and environment. It is not a universal safety certificate or a promise of job readiness. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which conclusion fits a successful bounded evaluation?

Interview: Which conclusion fits a successful bounded evaluation? Defend your answer using your actual lab result and this boundary: A release report is bounded by its cases, task and environment. It is not a universal safety certificate or a promise of job readiness.

Quiz: Which conclusion fits a successful bounded evaluation?

This system is safe for every possible user.

The candidate met the declared checks on the tested cases; other conditions remain unverified.

No monitoring is needed.

Reference: The candidate met the declared checks on the tested cases; other conditions remain unverified. — Evaluation provides scoped evidence. Preserve its task, sample and environment boundaries when communicating the result.

Sources:

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

Python: JSON documents and parsing: https://docs.python.org/3/library/json.html

Python: unittest assertions and fixtures: https://docs.python.org/3/library/unittest.html

### Regression and slice analysis

Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. In this role, work through: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A class average can hide one group consistently being left behind.

Boundary: Very small slices need uncertainty and cautious interpretation.

Worked example: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI evaluation / evals engineer: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Predict the worked case

Read this case without running a tool: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in regression and slice analysis.

Connect the concept to the role

Apply this rule: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Very small slices need uncertainty and cautious interpretation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies regression and slice analysis to this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Regression and slice analysis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with regression and slice analysis. Use the glossary below, then write your prediction for: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain regression and slice analysis using this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate regression and slice analysis to a system or workflow you know. Explain regression and slice analysis using this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain regression and slice analysis using this case: Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases.

Reference: Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. — Track performance by relevant input groups as well as overall averages. Re-run a frozen suite after changes and investigate newly failing cases. Very small slices need uncertainty and cautious interpretation.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Auditable model evaluation harness

Build an evaluation harness with traceable judgments and defensible release decisions. Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average. In this role, work through: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: A class average can hide one group consistently being left behind.

Overall accuracy rises while multilingual cases regress; show both counts and hold the release if the declared critical slice fails.

Worked example: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); MLflow (Open source · hosted offerings optional); Label Studio (Open source Community · commercial editions optional)

Build an evaluation harness with traceable judgments and defensible release decisions. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Build an evaluation harness with traceable judgments and defensible release decisions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A reviewer must reproduce one result and identify which capabilities you implemented. Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-advanced-2.md: Evaluation code and versioned test set; Rubric/adjudication records; Release recommendation with failure analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: auditable model evaluation harness. Use the glossary below, then write your prediction for: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI evaluation / evals engineer role interview. Explain defend: auditable model evaluation harness using this case: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: auditable model evaluation harness to a system or workflow you know. Explain defend: auditable model evaluation harness using this case: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Identify one observation that would contradict your claim.

Interview: Explain defend: auditable model evaluation harness using this case: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Auditable model evaluation harness at this level?

Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. — Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions. Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Sources:

Python: https://docs.python.org/3/library/venv.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Label Studio: https://labelstud.io/guide/quick_start

MLflow: https://mlflow.org/docs/latest/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
