# SAMPLE — Grader calibration report
Role: AI evaluation / evals engineer
Case: A grader accepts plausible mistakes
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The calibration gate flags more than one false pass in ten deliberately incorrect answers.

## Evidence table
| Record | false_passes (out of ten incorrect answers) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | within_demo_bound |
| case-3 | 2 | review |
| case-4 | 5 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two grader configurations accept too many known errors to support the release claim.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Calibrate against independently labeled examples and repair ambiguous rubric wording.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai evaluation / evals engineer.
Before release: Measure false passes and false failures separately on a new calibration set.

## Design choice and trade-off
Keep grader evaluation separate from model evaluation; preserve rubric versions and human adjudication.
A stricter grader can reject useful answers; calibrate both sides rather than maximizing agreement with itself.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Answer-quality harness: Report grader error alongside model quality.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
