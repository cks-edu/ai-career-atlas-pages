## intermediate — Grader calibration

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Test design, Python or TypeScript, statistics and careful labeling.

### Grader calibration
Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.
Mental model: Calibrate a scale against known weights before weighing new objects.
Boundary: Human agreement is useful evidence, not an infallible truth source.
Worked example: Two reviewers disagree on an ambiguous refusal. Resolve the rubric and record the reason before training or trusting an automatic grader.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Auditable model evaluation harness
Build an evaluation harness with traceable judgments and defensible release decisions. Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Recall: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. Identify one observation that would contradict your claim.

### Terms
Grader calibration: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an evaluation harness with traceable judgments and defensible release decisions. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The calibration gate flags more than one false pass in ten deliberately incorrect answers. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Build an evaluation harness with traceable judgments and defensible release decisions.
Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.
Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.
Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.
Deliverables: Evaluation code and versioned test set; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI evaluation / evals engineer. Use this scenario: Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.
Review: Start with the task and permitted scope. Explain grader calibration: Compare automated grading with independently reviewed examples and inspect disagreements. Version rubrics and preserve uncertain cases instead of forcing false precision. Show the input and observed output, then address Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Evaluation code and versioned test set; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

