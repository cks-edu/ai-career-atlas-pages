# Auditable model evaluation harness

Career: AI evaluation / evals engineer
Reviewed: 2026-10-22

Build an evaluation harness with traceable judgments and defensible release decisions.

## Prerequisites
Test design, Python or TypeScript, statistics and careful labeling.

## Included starter versus your implementation
A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; the scoring skeleton needs only the standard library.

```sh
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create 40 task records with input, expected facts, rubric and slice labels. Freeze test cases before evaluating two candidate outputs.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the supplied evaluate.py on seeded outputs. Replace the toy exact-match metric with task-specific checks while retaining raw predictions and error records.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Blind candidate identity for human scoring in Label Studio or Calc. Write rubric anchors and independently score an overlap sample before adjudication.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Evaluation code and versioned test set — artifact-1.md
2. Rubric/adjudication records — artifact-2.md
3. Release recommendation with failure analysis — artifact-3.md

## Troubleshooting
- Missing predictions: keep them in the denominator.
- Metric disagrees with humans: inspect rubric validity before optimizing the model.
- Scores change: compare candidate, dataset and evaluator versions separately.

## Extension
Add bootstrap intervals and test whether candidate rankings remain stable under reasonable rubric changes.

## Primary learning resources
- Python: https://docs.python.org/3/library/venv.html — Open source · local; Isolated environments and reproducible scripts.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.
- Label Studio: https://labelstud.io/guide/quick_start — Open source Community · commercial editions optional; Configure annotation tasks and export reviewer judgments.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
