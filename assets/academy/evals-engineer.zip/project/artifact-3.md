# Release recommendation with failure analysis

Project: Auditable model evaluation harness
Status: blank work product — not completed evidence

## Purpose and audience
Build an evaluation harness with traceable judgments and defensible release decisions.

## Required content
Log dataset, evaluator and candidate versions in MLflow. Add a regression report that highlights newly failing cases rather than hiding them in an average.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report metric validity, reviewer agreement, slice performance and uncertainty. Preserve disagreements and distinguish judge-model outputs from verified labels.

## Failure evidence
Add a fluent answer containing an incorrect critical fact and a candidate that copies evaluator instructions. The rubric and harness must catch both without treating output text as grading instructions.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
