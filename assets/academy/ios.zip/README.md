# iOS Developer

Software Engineering

Start with swiftui state ownership. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward interruption test matrix and sync recovery note.

## beginner

Create a SwiftUI App, bind a TextField to input state and use a Button to validate and append. Test spaces, a normal title and large text in the simulator.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### UI state
The visible interface is a projection of state. User actions update state and trigger a new view.
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: Rendering frameworks differ; re-rendering does not automatically persist data.
Example: Adding one task changes count from zero to one.
Recall: Which state must survive app restart?

### SwiftUI state ownership
SwiftUI views describe state. Place editable state at a clear owner and pass bindings only where edits are intended; view reconstruction is not a reliable persistence event.
Mental model: A view is a window onto a ledger, not the ledger itself.
Limit: Unexpected resets suggest state stored at a short-lived view boundary; trace ownership before adding global state.
Example: An Add action appends one title; redrawing the view must append none.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Unexpected resets suggest state stored at a short-lived view boundary; trace ownership before adding global state.

1. Start the native template
In Xcode choose File → New → Project → iOS App. Select SwiftUI, choose a simulator and Run. Locate ContentView.swift.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
An Add action appends one title; redrawing the view must append none. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a SwiftUI App, bind a TextField to input state and use a Button to validate and append. Test spaces, a normal title and large text in the simulator.
Expected: One task per valid tap and an understandable error for blank input.

6. Role workshop · debug and verify
Unexpected resets suggest state stored at a short-lived view boundary; trace ownership before adding global state. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save ContentView.swift and a state-flow sketch. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One task per valid tap and an understandable error for blank input.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
SwiftUI state ownership: Unexpected resets suggest state stored at a short-lived view boundary; trace ownership before adding global state.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: ContentView.swift and a state-flow sketch
One task per valid tap and an understandable error for blank input.

Interview: Work through this iOS Developer case: An Add action appends one title; redrawing the view must append none. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: SwiftUI views describe state. Place editable state at a clear owner and pass bindings only where edits are intended; view reconstruction is not a reliable persistence event. Expected evidence: One task per valid tap and an understandable error for blank input. Diagnosis: Unexpected resets suggest state stored at a short-lived view boundary; trace ownership before adding global state. State the limits of the mental model: A view is a window onto a ledger, not the ledger itself.

Resume: Built ContentView.swift and a state-flow sketch using Xcode and SwiftUI; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Use the Apple persistence tutorial appropriate to your deployment target. Save two tasks, relaunch, then walk the list using VoiceOver. Record OS, deployment target and label text.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Local persistence and offline work
Save data explicitly and show whether it is local, queued or synchronized.
Mental model: An outbox keeps letters until the courier is available.
Limit: Local storage can be removed or unavailable; it is not cloud backup.
Example: Create a task offline, restart and verify it remains marked unsent.
Recall: Why must the user see a queued status?

### Local storage and VoiceOver
Persistence and accessibility are independent requirements. Save a stable task identity and ensure assistive technology announces the title and action without relying on visual position.
Mental model: The notebook stores the record; a spoken index helps someone find it.
Limit: If persistence works only in preview, run the actual simulator app and inspect the store location/lifecycle.
Example: After relaunch, Task A remains and VoiceOver can identify its completion action.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If persistence works only in preview, run the actual simulator app and inspect the store location/lifecycle.

1. Start the native template
In Xcode choose File → New → Project → iOS App. Select SwiftUI, choose a simulator and Run. Locate ContentView.swift.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
After relaunch, Task A remains and VoiceOver can identify its completion action. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use the Apple persistence tutorial appropriate to your deployment target. Save two tasks, relaunch, then walk the list using VoiceOver. Record OS, deployment target and label text.
Expected: Two restored tasks with distinct IDs and meaningful spoken controls.

6. Role workshop · debug and verify
If persistence works only in preview, run the actual simulator app and inspect the store location/lifecycle. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save persistence sample and accessibility walkthrough. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Two restored tasks with distinct IDs and meaningful spoken controls.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Local storage and VoiceOver: If persistence works only in preview, run the actual simulator app and inspect the store location/lifecycle.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: persistence sample and accessibility walkthrough
Two restored tasks with distinct IDs and meaningful spoken controls.

Interview: Work through this iOS Developer case: After relaunch, Task A remains and VoiceOver can identify its completion action. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Persistence and accessibility are independent requirements. Save a stable task identity and ensure assistive technology announces the title and action without relying on visual position. Expected evidence: Two restored tasks with distinct IDs and meaningful spoken controls. Diagnosis: If persistence works only in preview, run the actual simulator app and inspect the store location/lifecycle. State the limits of the mental model: The notebook stores the record; a spoken index helps someone find it.

Resume: Built persistence sample and accessibility walkthrough using Xcode and SwiftUI; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Build a fake sync service with an injected acknowledgment failure. Save the pending operation ID, relaunch and replay it. Test background/resume separately from full process termination.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Lifecycle and synchronization
Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: A bookmark cannot decide how to merge two different edits.
Example: Retry the same task ID after reconnecting and verify one remote record.
Recall: What happens if two devices change the same title offline?

### Lifecycle interruption
An app may stop between saving intent and receiving a response. Persist pending work before starting it and make resumed work safe to retry.
Mental model: A bookmark and an outbox let the reader resume without sending the same letter twice.
Limit: Background callbacks are not guaranteed unlimited execution; never depend on a final callback to save essential state.
Example: Simulated acceptance followed by lost acknowledgment should not duplicate task t1 after relaunch.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Background callbacks are not guaranteed unlimited execution; never depend on a final callback to save essential state.

1. Start the native template
In Xcode choose File → New → Project → iOS App. Select SwiftUI, choose a simulator and Run. Locate ContentView.swift.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Simulated acceptance followed by lost acknowledgment should not duplicate task t1 after relaunch. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Build a fake sync service with an injected acknowledgment failure. Save the pending operation ID, relaunch and replay it. Test background/resume separately from full process termination.
Expected: One effect and an explicit pending or synchronized status after recovery.

6. Role workshop · debug and verify
Background callbacks are not guaranteed unlimited execution; never depend on a final callback to save essential state. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save interruption test matrix and sync recovery note. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One effect and an explicit pending or synchronized status after recovery.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Lifecycle interruption: Background callbacks are not guaranteed unlimited execution; never depend on a final callback to save essential state.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: interruption test matrix and sync recovery note
One effect and an explicit pending or synchronized status after recovery.

Interview: Work through this iOS Developer case: Simulated acceptance followed by lost acknowledgment should not duplicate task t1 after relaunch. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An app may stop between saving intent and receiving a response. Persist pending work before starting it and make resumed work safe to retry. Expected evidence: One effect and an explicit pending or synchronized status after recovery. Diagnosis: Background callbacks are not guaranteed unlimited execution; never depend on a final callback to save essential state. State the limits of the mental model: A bookmark and an outbox let the reader resume without sending the same letter twice.

Resume: Built interruption test matrix and sync recovery note using Xcode and SwiftUI; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course
Flutter learning pathway: https://docs.flutter.dev/learn
