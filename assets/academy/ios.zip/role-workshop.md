# iOS Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
SwiftUI state ownership

SwiftUI views describe state. Place editable state at a clear owner and pass bindings only where edits are intended; view reconstruction is not a reliable persistence event.
Mental model: A view is a window onto a ledger, not the ledger itself.
Case: An Add action appends one title; redrawing the view must append none.
Task: Create a SwiftUI App, bind a TextField to input state and use a Button to validate and append. Test spaces, a normal title and large text in the simulator.
Acceptance: One task per valid tap and an understandable error for blank input.
Troubleshooting: Unexpected resets suggest state stored at a short-lived view boundary; trace ownership before adding global state.
Deliverable: ContentView.swift and a state-flow sketch

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Local storage and VoiceOver

Persistence and accessibility are independent requirements. Save a stable task identity and ensure assistive technology announces the title and action without relying on visual position.
Mental model: The notebook stores the record; a spoken index helps someone find it.
Case: After relaunch, Task A remains and VoiceOver can identify its completion action.
Task: Use the Apple persistence tutorial appropriate to your deployment target. Save two tasks, relaunch, then walk the list using VoiceOver. Record OS, deployment target and label text.
Acceptance: Two restored tasks with distinct IDs and meaningful spoken controls.
Troubleshooting: If persistence works only in preview, run the actual simulator app and inspect the store location/lifecycle.
Deliverable: persistence sample and accessibility walkthrough

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Lifecycle interruption

An app may stop between saving intent and receiving a response. Persist pending work before starting it and make resumed work safe to retry.
Mental model: A bookmark and an outbox let the reader resume without sending the same letter twice.
Case: Simulated acceptance followed by lost acknowledgment should not duplicate task t1 after relaunch.
Task: Build a fake sync service with an injected acknowledgment failure. Save the pending operation ID, relaunch and replay it. Test background/resume separately from full process termination.
Acceptance: One effect and an explicit pending or synchronized status after recovery.
Troubleshooting: Background callbacks are not guaranteed unlimited execution; never depend on a final callback to save essential state.
Deliverable: interruption test matrix and sync recovery note

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
