## advanced — Workload-aware benchmarking

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Workload-aware benchmarking
Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result.
Mental model: A road's capacity must be tested with the traffic that will actually use it.
Boundary: A synthetic load test cannot guarantee performance for another workload.
Worked example: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Inference capacity and latency benchmark
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. Add a streaming client for time-to-first-token and inter-token latency. Scrape /metrics into Prometheus and correlate queue depth, KV cache pressure and throughput.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.
Worked example: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.
Recall: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. Identify one observation that would contradict your claim.

### Terms
Workload-aware benchmarking: Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
KV cache: Stored attention keys and values reused while generating a sequence; active sequences consume serving memory.
quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Lab
Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks. Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install vllm
# Set MODEL_ID to your chosen compatible model before continuing.
test -n "$MODEL_ID"
vllm serve "$MODEL_ID" --host 127.0.0.1 --port 8001
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks.

2. Prepare the project inputs
Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add a streaming client for time-to-first-token and inter-token latency. Scrape /metrics into Prometheus and correlate queue depth, KV cache pressure and throughput.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the serving process with Ctrl+C and release any rented compute. Keep raw benchmark output and model/version metadata.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# In another activated terminal with the same MODEL_ID:
curl -s http://127.0.0.1:8001/health
curl -s http://127.0.0.1:8001/v1/models
CONCURRENCY=1 python load.py
CONCURRENCY=4 python load.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Server does not start: check model access, architecture and available memory.
404 on completions: verify endpoint and served model name.
High p95: inspect queueing, prompt lengths and failed requests rather than only average throughput.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the serving process with Ctrl+C and release any rented compute. Keep raw benchmark output and model/version metadata.

### Portfolio
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint.
Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.
Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.
Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.
Add a streaming client for time-to-first-token and inter-token latency. Scrape /metrics into Prometheus and correlate queue depth, KV cache pressure and throughput.
Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.
Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.
Compare two quantization settings on both task quality and serving performance before recommending one.
Deliverables: Benchmark client and raw measurements; Capacity curves with hardware/model manifest; Overload and capacity-planning runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. A reviewer must reproduce one result and identify which capabilities you implemented. Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

### Interview
Explain your advanced solution for Inference / model-serving engineer. Use this scenario: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.
Review: Start with the task and permitted scope. Explain workload-aware benchmarking: Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result. Show the input and observed output, then address Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Benchmark client and raw measurements; Capacity curves with hardware/model manifest; Overload and capacity-planning runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

