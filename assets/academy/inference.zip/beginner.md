## beginner — Serving latency components

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Serving latency components
Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently.
Mental model: A restaurant has waiting time, time to the first dish and time to finish the meal.
Boundary: Tokens per second alone does not describe user-perceived latency.
Worked example: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A longer prompt overloads serving
The workload contract flags time to first token above 1,000 ms for interactive requests. Two long-context requests miss the interactive latency bound. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries.
Recall: Replay the same prompt-length and concurrency distribution and verify tail latency. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Serving latency components: Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Inference is using a trained model to produce an output. Waiting in a queue and executing the model contribute different delays.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use fictional times: request arrives at 0 ms, execution starts at 80 ms, first output at 230 ms, final output at 630 ms.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A timing table with four named durations.

3. Try step 2
Calculate queue delay, execution-to-first-output delay, time to first output and total request time.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A timing table with four named durations.

4. Try step 3
Explain why a longer queue could make users wait even if model execution is unchanged.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A timing table with four named durations.

5. Explain and check your result
The durations are 80, 150, 230 and 630 ms respectively; total request time includes queueing. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A timing table with four named durations. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The workload contract flags time to first token above 1,000 ms for interactive requests. Apply this toy-case rule manually: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two long-context requests miss the interactive latency bound. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Inference / model-serving engineer.
Use fictional times: request arrives at 0 ms, execution starts at 80 ms, first output at 230 ms, final output at 630 ms.
Calculate queue delay, execution-to-first-output delay, time to first output and total request time.
Explain why a longer queue could make users wait even if model execution is unchanged.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A timing table with four named durations. Include beginner-worksheet.md and your completed Serving benchmark and overload policy.
Check: The durations are 80, 150, 230 and 630 ms respectively; total request time includes queueing.

### Interview
Explain your beginner solution for Inference / model-serving engineer. Use this scenario: The workload contract flags time to first token above 1,000 ms for interactive requests.
Review: Start with the task and permitted scope. Explain serving latency components: Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently. Show the input and observed output, then address Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A timing table with four named durations. Include beginner-worksheet.md and your completed Serving benchmark and overload policy.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

