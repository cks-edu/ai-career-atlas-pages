# Inference capacity and latency benchmark

Career: Inference / model-serving engineer
Reviewed: 2026-10-22

Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint.

## Prerequisites
Learn Python, Linux, networking, containers, profiling and basic transformer execution. Real accelerator experience matters for performance claims. Begin with a CPU mock for orchestration, then use compatible hardware for measured serving results.

## Included starter versus your implementation
A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks.

Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install vllm
# Set MODEL_ID to your chosen compatible model before continuing.
test -n "$MODEL_ID"
vllm serve "$MODEL_ID" --host 127.0.0.1 --port 8001
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Add a streaming client for time-to-first-token and inter-token latency. Scrape /metrics into Prometheus and correlate queue depth, KV cache pressure and throughput.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the serving process with Ctrl+C and release any rented compute. Keep raw benchmark output and model/version metadata.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# In another activated terminal with the same MODEL_ID:
curl -s http://127.0.0.1:8001/health
curl -s http://127.0.0.1:8001/v1/models
CONCURRENCY=1 python load.py
CONCURRENCY=4 python load.py
```

## Portfolio deliverables
1. Benchmark client and raw measurements — artifact-1.md
2. Capacity curves with hardware/model manifest — artifact-2.md
3. Overload and capacity-planning runbook — artifact-3.md

## Troubleshooting
- Server does not start: check model access, architecture and available memory.
- 404 on completions: verify endpoint and served model name.
- High p95: inspect queueing, prompt lengths and failed requests rather than only average throughput.

## Extension
Compare two quantization settings on both task quality and serving performance before recommending one.

## Primary learning resources
- vLLM: https://docs.vllm.ai/en/stable/getting_started/quickstart/ — Open source · compatible accelerator usually needed; Model serving and metrics; hardware/model compatibility matters.
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.
- Prometheus: https://prometheus.io/docs/introduction/overview/ — Open source; Metrics collection and alert evidence.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
