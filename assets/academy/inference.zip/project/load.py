"""Whole-response latency probe for a local vLLM completions endpoint, not TTFT."""
import concurrent.futures,json,os,time,urllib.request,urllib.error,math
from pathlib import Path
model=os.environ.get('MODEL_ID')
if not model: raise SystemExit('Set MODEL_ID to the model served locally.')
concurrency=int(os.environ.get('CONCURRENCY','1'))
if not 1<=concurrency<=8: raise SystemExit('Use concurrency 1..8 for this bounded probe.')
def request(i):
    start=time.perf_counter();status='ok';tokens=0;error=None
    body=json.dumps({'model':model,'prompt':'Explain why reproducible tests matter.','max_tokens':32,'temperature':0}).encode()
    try:
        req=urllib.request.Request('http://127.0.0.1:8001/v1/completions',data=body,headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=60) as response: result=json.load(response)
        tokens=result.get('usage',{}).get('completion_tokens',0)
    except (urllib.error.URLError,TimeoutError,ValueError) as exc: status='error';error=str(exc)
    return {'id':i,'seconds':time.perf_counter()-start,'status':status,'completion_tokens':tokens,'error':error}
if __name__=='__main__':
    warmup=request(-1)
    if warmup['status']!='ok': raise SystemExit('Warmup failed: '+str(warmup['error']))
    start=time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool: rows=list(pool.map(request,range(20)))
    elapsed=time.perf_counter()-start;ok=[r for r in rows if r['status']=='ok'];latencies=sorted(r['seconds'] for r in ok)
    result={'model':model,'concurrency':concurrency,'warmup':warmup,'requests':20,'errors':20-len(ok),'elapsed_seconds':elapsed,'successful_output_tokens_per_second':sum(r['completion_tokens'] for r in ok)/elapsed,'p95_success_seconds':latencies[math.ceil(.95*len(latencies))-1] if latencies else None,'rows':rows}
    Path('output').mkdir(exist_ok=True);Path(f'output/load-{concurrency}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
