# Capacity curves with hardware/model manifest

Project: Inference capacity and latency benchmark
Status: blank work product — not completed evidence

## Purpose and audience
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint.

## Required content
Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.

## Failure evidence
Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
