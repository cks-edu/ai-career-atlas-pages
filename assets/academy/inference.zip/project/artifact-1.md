# Benchmark client and raw measurements

Project: Inference capacity and latency benchmark
Status: blank work product — not completed evidence

## Purpose and audience
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint.

## Required content
Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.

## Failure evidence
Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
