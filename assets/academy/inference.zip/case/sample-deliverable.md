# SAMPLE — Serving benchmark and overload policy
Role: Inference / model-serving engineer
Case: A longer prompt overloads serving
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The workload contract flags time to first token above 1,000 ms for interactive requests.

## Evidence table
| Record | ttft (milliseconds) | Decision |
|---|---:|---|
| case-1 | 300 | within_demo_bound |
| case-2 | 900 | within_demo_bound |
| case-3 | 1001 | review |
| case-4 | 2400 | review |
| case-5 | 750 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two long-context requests miss the interactive latency bound.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in inference / model-serving engineer.
Before release: Replay the same prompt-length and concurrency distribution and verify tail latency.

## Design choice and trade-off
Separate admission, queue and generation timing; benchmark realistic prompt/output shapes.
Larger batches improve throughput but can harm interactive tail latency; define which objective governs.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Measure a bounded inference queue: Retain raw records for baseline, concurrency change and failure drill. Separate successful throughput from attempted request rate. Label every mock result and explain which real serving metrics remain unmeasured.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
