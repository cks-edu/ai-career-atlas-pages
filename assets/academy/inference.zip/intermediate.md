## intermediate — KV cache and batching

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn Python, Linux, networking, containers, profiling and basic transformer execution. Real accelerator experience matters for performance claims. Begin with a CPU mock for orchestration, then use compatible hardware for measured serving results.

### KV cache and batching
Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling.
Mental model: Each active conversation keeps a notebook on a shared desk.
Boundary: Exact cache representation and memory behavior depend on engine, model and settings.
Worked example: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Inference capacity and latency benchmark
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.
Worked example: Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.
Recall: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. Identify one observation that would contradict your claim.

### Terms
KV cache and batching: Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
KV cache: Stored attention keys and values reused while generating a sequence; active sequences consume serving memory.
quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Lab
Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks. Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install vllm
# Set MODEL_ID to your chosen compatible model before continuing.
test -n "$MODEL_ID"
vllm serve "$MODEL_ID" --host 127.0.0.1 --port 8001
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks.

2. Prepare the project inputs
Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The workload contract flags time to first token above 1,000 ms for interactive requests. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# In another activated terminal with the same MODEL_ID:
curl -s http://127.0.0.1:8001/health
curl -s http://127.0.0.1:8001/v1/models
CONCURRENCY=1 python load.py
CONCURRENCY=4 python load.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Server does not start: check model access, architecture and available memory.
404 on completions: verify endpoint and served model name.
High p95: inspect queueing, prompt lengths and failed requests rather than only average throughput.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the serving process with Ctrl+C and release any rented compute. Keep raw benchmark output and model/version metadata.

### Portfolio
Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint.
Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.
Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.
Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.
Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.
Deliverables: Benchmark client and raw measurements; Capacity curves with hardware/model manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Inference / model-serving engineer. Use this scenario: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.
Review: Start with the task and permitted scope. Explain kv cache and batching: Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling. Show the input and observed output, then address Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Benchmark client and raw measurements; Capacity curves with hardware/model manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

