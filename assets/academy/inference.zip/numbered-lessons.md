# Inference / model-serving engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Serving latency components: Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Serving latency components

Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently. In this role, work through: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A restaurant has waiting time, time to the first dish and time to finish the meal.

Boundary: Tokens per second alone does not describe user-perceived latency.

Worked example: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: vLLM (Open source · compatible accelerator usually needed); PyTorch (Open source · hardware dependent); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Inference / model-serving engineer: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs.

Predict the worked case

Read this case without running a tool: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in serving latency components.

Connect the concept to the role

Apply this rule: Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Tokens per second alone does not describe user-perceived latency.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies serving latency components to this case: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Serving latency components; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with serving latency components. Use the glossary below, then write your prediction for: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Inference / model-serving engineer role interview. Explain serving latency components using this case: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate serving latency components to a system or workflow you know. Explain serving latency components using this case: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain serving latency components using this case: Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs.

Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently. — Distinguish time waiting in a queue, time to first token and time to finish. Request length and concurrent demand can change these differently. Tokens per second alone does not describe user-perceived latency.

Sources:

vLLM: https://docs.vllm.ai/en/stable/getting_started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

vLLM: https://docs.vllm.ai/en/stable/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Diagnose: A longer prompt overloads serving

The workload contract flags time to first token above 1,000 ms for interactive requests. Two long-context requests miss the interactive latency bound. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A restaurant has waiting time, time to the first dish and time to finish the meal.

Two servers finish in eight seconds, but one starts at one second and the other at seven. Interactive experience differs.

Worked example: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: vLLM (Open source · compatible accelerator usually needed); PyTorch (Open source · hardware dependent); Prometheus (Open source)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The workload contract flags time to first token above 1,000 ms for interactive requests. Two long-context requests miss the interactive latency bound. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The workload contract flags time to first token above 1,000 ms for interactive requests. Apply this toy-case rule manually: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Inference is using a trained model to produce an output. Waiting in a queue and executing the model contribute different delays.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use fictional times: request arrives at 0 ms, execution starts at 80 ms, first output at 230 ms, final output at 630 ms.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A timing table with four named durations.

Preparation · Try step 2

Calculate queue delay, execution-to-first-output delay, time to first output and total request time.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A timing table with four named durations.

Preparation · Try step 3

Explain why a longer queue could make users wait even if model execution is unchanged.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A timing table with four named durations.

Preparation · Explain and check your result

The durations are 80, 150, 230 and 630 ms respectively; total request time includes queueing. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A timing table with four named durations. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The workload contract flags time to first token above 1,000 ms for interactive requests. Apply this toy-case rule manually: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two long-context requests miss the interactive latency bound. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two long-context requests miss the interactive latency bound. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a longer prompt overloads serving. Use the glossary below, then write your prediction for: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Inference / model-serving engineer role interview. Explain diagnose: a longer prompt overloads serving using this case: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a longer prompt overloads serving to a system or workflow you know. Explain diagnose: a longer prompt overloads serving using this case: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Replay the same prompt-length and concurrency distribution and verify tail latency. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a longer prompt overloads serving using this case: Review when ttft > 1000 (milliseconds). This is a declared toy-case contract, not an industry standard. Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. State the evidence, one alternative and where the mental model stops.

Quiz: A longer prompt overloads serving: The workload contract flags time to first token above 1,000 ms for interactive requests.

Change the acceptance rule after seeing an inconvenient result.

Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries.

Omit failed cases and report only the successful demonstrations.

Reference: Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. — Inspect queue delay and KV-cache pressure; bound admission before adding indiscriminate retries. Replay the same prompt-length and concurrency distribution and verify tail latency.

Sources:

vLLM: https://docs.vllm.ai/en/stable/getting_started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

vLLM: https://docs.vllm.ai/en/stable/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

Prometheus: https://prometheus.io/docs/introduction/overview/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn Python, Linux, networking, containers, profiling and basic transformer execution. Real accelerator experience matters for performance claims. Begin with a CPU mock for orchestration, then use compatible hardware for measured serving results.

Terms:

KV cache and batching: Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

KV cache: Stored attention keys and values reused while generating a sequence; active sequences consume serving memory.

quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### KV cache and batching

Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling. In this role, work through: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Each active conversation keeps a notebook on a shared desk.

Boundary: Exact cache representation and memory behavior depend on engine, model and settings.

Worked example: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn Python, Linux, networking, containers, profiling and basic transformer execution. Real accelerator experience matters for performance claims. Begin with a CPU mock for orchestration, then use compatible hardware for measured serving results.

Tools for this exercise: Document or text editor

Course tool and framework map: vLLM (Open source · compatible accelerator usually needed); PyTorch (Open source · hardware dependent); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Inference / model-serving engineer: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone.

Predict the worked case

Read this case without running a tool: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in kv cache and batching.

Connect the concept to the role

Apply this rule: Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exact cache representation and memory behavior depend on engine, model and settings.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies kv cache and batching to this case: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for KV cache and batching; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with kv cache and batching. Use the glossary below, then write your prediction for: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Inference / model-serving engineer role interview. Explain kv cache and batching using this case: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate kv cache and batching to a system or workflow you know. Explain kv cache and batching using this case: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain kv cache and batching using this case: More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone.

Treat a passing starter as proof of the whole role workflow.

Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling.

Ignore the failure because the tool produced an output.

Reference: Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling. — Autoregressive serving retains attention state for active sequences. Batch size, context length and concurrent requests compete for memory and affect scheduling. Exact cache representation and memory behavior depend on engine, model and settings.

Sources:

vLLM: https://docs.vllm.ai/en/stable/getting_started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

vLLM: https://docs.vllm.ai/en/stable/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Integrate: Inference capacity and latency benchmark

Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error. In this role, work through: Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.

Role application: Each active conversation keeps a notebook on a shared desk.

More long conversations fill the desk even when model weights are unchanged. Reduce measured concurrency or context limits before blaming weight size alone.

Worked example: Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.

Setup: Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: vLLM (Open source · compatible accelerator usually needed); PyTorch (Open source · hardware dependent); Prometheus (Open source)

Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks. Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.

Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install vllm
# Set MODEL_ID to your chosen compatible model before continuing.
test -n "$MODEL_ID"
vllm serve "$MODEL_ID" --host 127.0.0.1 --port 8001
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks.

Prepare the project inputs

Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The workload contract flags time to first token above 1,000 ms for interactive requests. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# In another activated terminal with the same MODEL_ID:
curl -s http://127.0.0.1:8001/health
curl -s http://127.0.0.1:8001/v1/models
CONCURRENCY=1 python load.py
CONCURRENCY=4 python load.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the serving process with Ctrl+C and release any rented compute. Keep raw benchmark output and model/version metadata.

Deliverable: lesson-intermediate-2.md: Benchmark client and raw measurements; Capacity curves with hardware/model manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: inference capacity and latency benchmark. Use the glossary below, then write your prediction for: Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Inference / model-serving engineer role interview. Explain integrate: inference capacity and latency benchmark using this case: Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: inference capacity and latency benchmark to a system or workflow you know. Explain integrate: inference capacity and latency benchmark using this case: Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. Identify one observation that would contradict your claim.

Interview: Explain integrate: inference capacity and latency benchmark using this case: Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Inference capacity and latency benchmark at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.

Reference: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. — Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.

Sources:

vLLM: https://docs.vllm.ai/en/stable/getting_started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

vLLM: https://docs.vllm.ai/en/stable/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

Prometheus: https://prometheus.io/docs/introduction/overview/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Workload-aware benchmarking: Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

KV cache: Stored attention keys and values reused while generating a sequence; active sequences consume serving memory.

quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Workload-aware benchmarking

Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result. In this role, work through: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A road's capacity must be tested with the traffic that will actually use it.

Boundary: A synthetic load test cannot guarantee performance for another workload.

Worked example: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: vLLM (Open source · compatible accelerator usually needed); PyTorch (Open source · hardware dependent); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Inference / model-serving engineer: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response.

Predict the worked case

Read this case without running a tool: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in workload-aware benchmarking.

Connect the concept to the role

Apply this rule: Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A synthetic load test cannot guarantee performance for another workload.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies workload-aware benchmarking to this case: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Workload-aware benchmarking; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with workload-aware benchmarking. Use the glossary below, then write your prediction for: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Inference / model-serving engineer role interview. Explain workload-aware benchmarking using this case: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate workload-aware benchmarking to a system or workflow you know. Explain workload-aware benchmarking using this case: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain workload-aware benchmarking using this case: Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result.

Reference: Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result. — Benchmark a declared mix of input lengths, output lengths and arrivals. Include errors and timeouts, warmup policy and hardware details in the result. A synthetic load test cannot guarantee performance for another workload.

Sources:

vLLM: https://docs.vllm.ai/en/stable/getting_started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

vLLM: https://docs.vllm.ai/en/stable/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Defend: Inference capacity and latency benchmark

Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. Add a streaming client for time-to-first-token and inter-token latency. Scrape /metrics into Prometheus and correlate queue depth, KV cache pressure and throughput. In this role, work through: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.

Role application: A road's capacity must be tested with the traffic that will actually use it.

Report p95 end-to-end latency for 32 concurrent requests alongside failures, rather than publishing only the fastest single response.

Worked example: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

Setup: Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: vLLM (Open source · compatible accelerator usually needed); PyTorch (Open source · hardware dependent); Prometheus (Open source)

Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint. A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks. Accelerator/model requirements vary; no GPU allocation or live inference has been performed by this website. Set a compute budget before renting hardware.

Build a repeatable serving benchmark that identifies the usable operating range of a model endpoint.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a dedicated compatible Linux environment. Follow the vLLM hardware-specific install guide, then set MODEL_ID to an accessible model that fits your accelerator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install vllm
# Set MODEL_ID to your chosen compatible model before continuing.
test -n "$MODEL_ID"
vllm serve "$MODEL_ID" --host 127.0.0.1 --port 8001
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded HTTP benchmark client is included. You supply the model and serving environment; streaming timing and monitoring are implementation tasks.

Prepare the project inputs

Use a compatible Linux accelerator environment for vLLM. Select an accessible model that fits the actual VRAM; log GPU, driver, model revision and quantization. No GPU is provisioned by this guide.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Follow the vLLM installation page for your hardware, start a loopback-bound endpoint using the supplied command recipe and verify /health and /v1/models.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run the supplied HTTP load client against completions with fixed prompt/output limits. Sweep concurrency 1, 2, 4 and 8; keep warmup results separate and record every error.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add a streaming client for time-to-first-token and inter-token latency. Scrape /metrics into Prometheus and correlate queue depth, KV cache pressure and throughput.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the serving process with Ctrl+C and release any rented compute. Keep raw benchmark output and model/version metadata.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# In another activated terminal with the same MODEL_ID:
curl -s http://127.0.0.1:8001/health
curl -s http://127.0.0.1:8001/v1/models
CONCURRENCY=1 python load.py
CONCURRENCY=4 python load.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. A reviewer must reproduce one result and identify which capabilities you implemented. Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the serving process with Ctrl+C and release any rented compute. Keep raw benchmark output and model/version metadata.

Deliverable: lesson-advanced-2.md: Benchmark client and raw measurements; Capacity curves with hardware/model manifest; Overload and capacity-planning runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: inference capacity and latency benchmark. Use the glossary below, then write your prediction for: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Inference / model-serving engineer role interview. Explain defend: inference capacity and latency benchmark using this case: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: inference capacity and latency benchmark to a system or workflow you know. Explain defend: inference capacity and latency benchmark using this case: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately. Identify one observation that would contradict your claim.

Interview: Explain defend: inference capacity and latency benchmark using this case: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Inference capacity and latency benchmark at this level?

Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host. — Increase context length or concurrency until admission fails or latency rises. Add a bounded request queue and compare overload behavior without exhausting the host. Publish throughput versus p95 latency and error rate by concurrency. The starter measures whole-response latency only; streaming metrics must be implemented and labeled separately.

Sources:

vLLM: https://docs.vllm.ai/en/stable/getting_started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

vLLM: https://docs.vllm.ai/en/stable/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

Prometheus: https://prometheus.io/docs/introduction/overview/
