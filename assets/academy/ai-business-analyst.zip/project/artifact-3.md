# Business case with sensitivity analysis

Project: AI process redesign and requirements pack
Status: blank work product — not completed evidence

## Purpose and audience
Translate an operational problem into testable requirements and a realistic automation proposal.

## Required content
Prototype the workflow in Power Automate if available, or execute a labeled tabletop simulation in Calc. Write UAT scripts for normal, duplicate, missing-data and rejection cases.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

## Failure evidence
A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
