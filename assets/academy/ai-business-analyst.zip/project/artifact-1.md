# As-is/to-be process maps

Project: AI process redesign and requirements pack
Status: blank work product — not completed evidence

## Purpose and audience
Translate an operational problem into testable requirements and a realistic automation proposal.

## Required content
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

## Failure evidence
A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
