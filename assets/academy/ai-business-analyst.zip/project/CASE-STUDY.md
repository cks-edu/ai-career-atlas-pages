# AI process redesign and requirements pack

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Translate an operational problem into testable requirements and a realistic automation proposal.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

## Limitations and next iteration
Validate the proposed process with a consenting domain practitioner and record rejected assumptions.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
