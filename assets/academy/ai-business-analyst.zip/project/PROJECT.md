# AI process redesign and requirements pack

Career: AI business / process analyst
Reviewed: 2026-10-22

Translate an operational problem into testable requirements and a realistic automation proposal.

## Prerequisites
Spreadsheet fluency, process mapping and stakeholder interviewing; SQL is useful for deeper analysis.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Prototype the workflow in Power Automate if available, or execute a labeled tabletop simulation in Calc. Write UAT scripts for normal, duplicate, missing-data and rejection cases.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. As-is/to-be process maps — artifact-1.md
2. Requirements and UAT traceability workbook — artifact-2.md
3. Business case with sensitivity analysis — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Validate the proposed process with a consenting domain practitioner and record rejected assumptions.

## Primary learning resources
- diagrams.net: https://www.drawio.com/docs/getting-started/ — Open source editor · browser/desktop; Architecture diagrams, process maps and trust boundaries.
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.
- Power Automate: https://learn.microsoft.com/en-us/power-automate/ — Commercial · account and connector licensing; Test approval workflows; use a labeled manual simulation if access is unavailable.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
