## intermediate — Testable requirements

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Spreadsheet fluency, process mapping and stakeholder interviewing; SQL is useful for deeper analysis.

### Testable requirements
Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path.
Mental model: A shopping list says what must arrive and how it will be checked.
Boundary: Precise criteria can still solve the wrong problem if discovery was weak.
Worked example: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI process redesign and requirements pack
Translate an operational problem into testable requirements and a realistic automation proposal. Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Recall: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. Identify one observation that would contradict your claim.

### Terms
Testable requirements: Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Translate an operational problem into testable requirements and a realistic automation proposal. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The process pilot flags more than two reworked cases in each ten-case batch. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Translate an operational problem into testable requirements and a realistic automation proposal.
Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.
Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.
Deliverables: As-is/to-be process maps; Requirements and UAT traceability workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI business / process analyst. Use this scenario: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.
Review: Start with the task and permitted scope. Explain testable requirements: Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path. Show the input and observed output, then address Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [As-is/to-be process maps; Requirements and UAT traceability workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

