# SAMPLE — Process map and benefit-assumption worksheet
Role: AI business / process analyst
Case: Automation moves work into exceptions
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The process pilot flags more than two reworked cases in each ten-case batch.

## Evidence table
| Record | rework_cases (out of ten cases) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 5 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two batches exceed the exception allowance; claimed time savings omitted rework.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Map the failed handoffs and include exception handling in the process and benefit calculation.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai business / process analyst.
Before release: Recalculate total staff time, including review, corrections and escalations.

## Design choice and trade-off
Document normal and exception flows; distinguish required capability from a chosen vendor feature.
Automating a frequent step may not improve the whole process if downstream exceptions become expensive.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Automation opportunity assessment: Ranking exposes assumptions and data gaps.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
