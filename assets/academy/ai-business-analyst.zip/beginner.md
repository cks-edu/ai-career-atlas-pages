## beginner — Current-state workflow

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Current-state workflow
Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation.
Mental model: Trace a letter through every desk it crosses before redesigning the office.
Boundary: An interview describes a perception; observations and records may show a different workflow.
Worked example: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Automation moves work into exceptions
The process pilot flags more than two reworked cases in each ten-case batch. Two batches exceed the exception allowance; claimed time savings omitted rework. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation.
Recall: Recalculate total staff time, including review, corrections and escalations. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Current-state workflow: Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A workflow has inputs, decisions, handoffs and exceptions. Measure the existing process before suggesting automation.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create five study-room requests: two complete, one missing a date, one duplicate and one requesting a full room.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

3. Try step 2
Make a table with the next action, responsible person and information needed for each.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

4. Try step 3
Count how many requests can proceed directly and list the reasons the others need attention.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

5. Explain and check your result
Only two proceed directly under these assumptions; missing, duplicate and unavailable requests have different next actions. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A five-row process table and an exception summary. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The process pilot flags more than two reworked cases in each ten-case batch. Apply this toy-case rule manually: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two batches exceed the exception allowance; claimed time savings omitted rework. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI business / process analyst.
Create five study-room requests: two complete, one missing a date, one duplicate and one requesting a full room.
Make a table with the next action, responsible person and information needed for each.
Count how many requests can proceed directly and list the reasons the others need attention.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A five-row process table and an exception summary. Include beginner-worksheet.md and your completed Process map and benefit-assumption worksheet.
Check: Only two proceed directly under these assumptions; missing, duplicate and unavailable requests have different next actions.

### Interview
Explain your beginner solution for AI business / process analyst. Use this scenario: The process pilot flags more than two reworked cases in each ten-case batch.
Review: Start with the task and permitted scope. Explain current-state workflow: Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation. Show the input and observed output, then address Map the failed handoffs and include exception handling in the process and benefit calculation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A five-row process table and an exception summary. Include beginner-worksheet.md and your completed Process map and benefit-assumption worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

