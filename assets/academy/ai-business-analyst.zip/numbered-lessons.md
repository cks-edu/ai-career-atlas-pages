# AI business / process analyst — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Current-state workflow: Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Current-state workflow

Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation. In this role, work through: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Trace a letter through every desk it crosses before redesigning the office.

Boundary: An interview describes a perception; observations and records may show a different workflow.

Worked example: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI business / process analyst: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data.

Predict the worked case

Read this case without running a tool: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in current-state workflow.

Connect the concept to the role

Apply this rule: Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An interview describes a perception; observations and records may show a different workflow.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies current-state workflow to this case: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Current-state workflow; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with current-state workflow. Use the glossary below, then write your prediction for: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI business / process analyst role interview. Explain current-state workflow using this case: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate current-state workflow to a system or workflow you know. Explain current-state workflow using this case: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain current-state workflow using this case: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Invoice review waits for missing supplier details; faster text generation does not resolve that missing data.

Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation. — Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation. An interview describes a perception; observations and records may show a different workflow.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

### Diagnose: Automation moves work into exceptions

The process pilot flags more than two reworked cases in each ten-case batch. Two batches exceed the exception allowance; claimed time savings omitted rework. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Trace a letter through every desk it crosses before redesigning the office.

Invoice review waits for missing supplier details; faster text generation does not resolve that missing data.

Worked example: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The process pilot flags more than two reworked cases in each ten-case batch. Two batches exceed the exception allowance; claimed time savings omitted rework. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The process pilot flags more than two reworked cases in each ten-case batch. Apply this toy-case rule manually: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A workflow has inputs, decisions, handoffs and exceptions. Measure the existing process before suggesting automation.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Create five study-room requests: two complete, one missing a date, one duplicate and one requesting a full room.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

Preparation · Try step 2

Make a table with the next action, responsible person and information needed for each.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

Preparation · Try step 3

Count how many requests can proceed directly and list the reasons the others need attention.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

Preparation · Explain and check your result

Only two proceed directly under these assumptions; missing, duplicate and unavailable requests have different next actions. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A five-row process table and an exception summary. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The process pilot flags more than two reworked cases in each ten-case batch. Apply this toy-case rule manually: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two batches exceed the exception allowance; claimed time savings omitted rework. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two batches exceed the exception allowance; claimed time savings omitted rework. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: automation moves work into exceptions. Use the glossary below, then write your prediction for: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI business / process analyst role interview. Explain diagnose: automation moves work into exceptions using this case: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: automation moves work into exceptions to a system or workflow you know. Explain diagnose: automation moves work into exceptions using this case: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Recalculate total staff time, including review, corrections and escalations. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: automation moves work into exceptions using this case: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation. State the evidence, one alternative and where the mental model stops.

Quiz: Automation moves work into exceptions: The process pilot flags more than two reworked cases in each ten-case batch.

Change the acceptance rule after seeing an inconvenient result.

Map the failed handoffs and include exception handling in the process and benefit calculation.

Omit failed cases and report only the successful demonstrations.

Reference: Map the failed handoffs and include exception handling in the process and benefit calculation. — Map the failed handoffs and include exception handling in the process and benefit calculation. Recalculate total staff time, including review, corrections and escalations.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Spreadsheet fluency, process mapping and stakeholder interviewing; SQL is useful for deeper analysis.

Terms:

Testable requirements: Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Testable requirements

Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path. In this role, work through: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A shopping list says what must arrive and how it will be checked.

Boundary: Precise criteria can still solve the wrong problem if discovery was weak.

Worked example: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Spreadsheet fluency, process mapping and stakeholder interviewing; SQL is useful for deeper analysis.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI business / process analyst: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction.

Predict the worked case

Read this case without running a tool: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in testable requirements.

Connect the concept to the role

Apply this rule: Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Precise criteria can still solve the wrong problem if discovery was weak.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies testable requirements to this case: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Testable requirements; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with testable requirements. Use the glossary below, then write your prediction for: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI business / process analyst role interview. Explain testable requirements using this case: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate testable requirements to a system or workflow you know. Explain testable requirements using this case: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain testable requirements using this case: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Given an unreadable invoice, the system creates a review item with the original file and no payment instruction.

Treat a passing starter as proof of the whole role workflow.

Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path.

Ignore the failure because the tool produced an output.

Reference: Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path. — Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path. Precise criteria can still solve the wrong problem if discovery was weak.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

### Integrate: AI process redesign and requirements pack

Translate an operational problem into testable requirements and a realistic automation proposal. Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners. In this role, work through: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A shopping list says what must arrive and how it will be checked.

Given an unreadable invoice, the system creates a review item with the original file and no payment instruction.

Worked example: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing)

Translate an operational problem into testable requirements and a realistic automation proposal. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Translate an operational problem into testable requirements and a realistic automation proposal.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The process pilot flags more than two reworked cases in each ten-case batch. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: As-is/to-be process maps; Requirements and UAT traceability workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: ai process redesign and requirements pack. Use the glossary below, then write your prediction for: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI business / process analyst role interview. Explain integrate: ai process redesign and requirements pack using this case: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: ai process redesign and requirements pack to a system or workflow you know. Explain integrate: ai process redesign and requirements pack using this case: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. Identify one observation that would contradict your claim.

Interview: Explain integrate: ai process redesign and requirements pack using this case: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI process redesign and requirements pack at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

Reference: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. — Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Feasibility and change impact: Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Feasibility and change impact

Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow. In this role, work through: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A new road changes intersections and traffic rules around it.

Boundary: Estimated benefits must be labeled assumptions until measured.

Worked example: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI business / process analyst: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case.

Predict the worked case

Read this case without running a tool: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in feasibility and change impact.

Connect the concept to the role

Apply this rule: Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Estimated benefits must be labeled assumptions until measured.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies feasibility and change impact to this case: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Feasibility and change impact; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with feasibility and change impact. Use the glossary below, then write your prediction for: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI business / process analyst role interview. Explain feasibility and change impact using this case: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate feasibility and change impact to a system or workflow you know. Explain feasibility and change impact using this case: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain feasibility and change impact using this case: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow.

Reference: Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow. — Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow. Estimated benefits must be labeled assumptions until measured.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

### Defend: AI process redesign and requirements pack

Translate an operational problem into testable requirements and a realistic automation proposal. Prototype the workflow in Power Automate if available, or execute a labeled tabletop simulation in Calc. Write UAT scripts for normal, duplicate, missing-data and rejection cases. In this role, work through: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A new road changes intersections and traffic rules around it.

A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case.

Worked example: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing)

Translate an operational problem into testable requirements and a realistic automation proposal. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Translate an operational problem into testable requirements and a realistic automation proposal.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Prototype the workflow in Power Automate if available, or execute a labeled tabletop simulation in Calc. Write UAT scripts for normal, duplicate, missing-data and rejection cases.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A reviewer must reproduce one result and identify which capabilities you implemented. A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: As-is/to-be process maps; Requirements and UAT traceability workbook; Business case with sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: ai process redesign and requirements pack. Use the glossary below, then write your prediction for: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI business / process analyst role interview. Explain defend: ai process redesign and requirements pack using this case: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: ai process redesign and requirements pack to a system or workflow you know. Explain defend: ai process redesign and requirements pack using this case: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. Identify one observation that would contradict your claim.

Interview: Explain defend: ai process redesign and requirements pack using this case: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI process redesign and requirements pack at this level?

A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action. — A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action. Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
