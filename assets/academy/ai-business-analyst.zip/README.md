# AI business / process analyst

AI Engineering · Beginner → Intermediate → Advanced

Start with Current-state workflow. A workflow has inputs, decisions, handoffs and exceptions. Measure the existing process before suggesting automation. Then try Map a fictional request queue. The three levels build toward AI process redesign and requirements pack. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Current-state workflow

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Current-state workflow
Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation.
Mental model: Trace a letter through every desk it crosses before redesigning the office.
Boundary: An interview describes a perception; observations and records may show a different workflow.
Worked example: Invoice review waits for missing supplier details; faster text generation does not resolve that missing data.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Automation moves work into exceptions
The process pilot flags more than two reworked cases in each ten-case batch. Two batches exceed the exception allowance; claimed time savings omitted rework. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Map the failed handoffs and include exception handling in the process and benefit calculation.
Recall: Recalculate total staff time, including review, corrections and escalations. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Current-state workflow: Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A workflow has inputs, decisions, handoffs and exceptions. Measure the existing process before suggesting automation.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create five study-room requests: two complete, one missing a date, one duplicate and one requesting a full room.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

3. Try step 2
Make a table with the next action, responsible person and information needed for each.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

4. Try step 3
Count how many requests can proceed directly and list the reasons the others need attention.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row process table and an exception summary.

5. Explain and check your result
Only two proceed directly under these assumptions; missing, duplicate and unavailable requests have different next actions. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A five-row process table and an exception summary. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The process pilot flags more than two reworked cases in each ten-case batch. Apply this toy-case rule manually: Review when rework_cases >= 3 (out of ten cases). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two batches exceed the exception allowance; claimed time savings omitted rework. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI business / process analyst.
Create five study-room requests: two complete, one missing a date, one duplicate and one requesting a full room.
Make a table with the next action, responsible person and information needed for each.
Count how many requests can proceed directly and list the reasons the others need attention.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A five-row process table and an exception summary. Include beginner-worksheet.md and your completed Process map and benefit-assumption worksheet.
Check: Only two proceed directly under these assumptions; missing, duplicate and unavailable requests have different next actions.

### Interview
Explain your beginner solution for AI business / process analyst. Use this scenario: The process pilot flags more than two reworked cases in each ten-case batch.
Review: Start with the task and permitted scope. Explain current-state workflow: Map actors, inputs, decisions and exceptions in the existing process. Confirm where delays and rework happen before proposing automation. Show the input and observed output, then address Map the failed handoffs and include exception handling in the process and benefit calculation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A five-row process table and an exception summary. Include beginner-worksheet.md and your completed Process map and benefit-assumption worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Testable requirements

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Spreadsheet fluency, process mapping and stakeholder interviewing; SQL is useful for deeper analysis.

### Testable requirements
Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path.
Mental model: A shopping list says what must arrive and how it will be checked.
Boundary: Precise criteria can still solve the wrong problem if discovery was weak.
Worked example: Given an unreadable invoice, the system creates a review item with the original file and no payment instruction.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI process redesign and requirements pack
Translate an operational problem into testable requirements and a realistic automation proposal. Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Recall: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. Identify one observation that would contradict your claim.

### Terms
Testable requirements: Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Translate an operational problem into testable requirements and a realistic automation proposal. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The process pilot flags more than two reworked cases in each ten-case batch. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Translate an operational problem into testable requirements and a realistic automation proposal.
Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.
Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.
Deliverables: As-is/to-be process maps; Requirements and UAT traceability workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI business / process analyst. Use this scenario: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.
Review: Start with the task and permitted scope. Explain testable requirements: Turn a stakeholder request into observable acceptance criteria and trace it to evidence. Include exception handling and responsibility, not only the happy path. Show the input and observed output, then address Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [As-is/to-be process maps; Requirements and UAT traceability workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Feasibility and change impact

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Feasibility and change impact
Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow.
Mental model: A new road changes intersections and traffic rules around it.
Boundary: Estimated benefits must be labeled assumptions until measured.
Worked example: A triage tool saves classification time but adds a manual exception queue; include that queue's staffing in the business case.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI process redesign and requirements pack
Translate an operational problem into testable requirements and a realistic automation proposal. Prototype the workflow in Power Automate if available, or execute a labeled tabletop simulation in Calc. Write UAT scripts for normal, duplicate, missing-data and rejection cases.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.
Recall: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. Identify one observation that would contradict your claim.

### Terms
Feasibility and change impact: Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Translate an operational problem into testable requirements and a realistic automation proposal. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Prototype the workflow in Power Automate if available, or execute a labeled tabletop simulation in Calc. Write UAT scripts for normal, duplicate, missing-data and rejection cases.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Translate an operational problem into testable requirements and a realistic automation proposal.
Model a fictional service request process with 30 cases, handoffs, wait time and rework. Define units and mark estimated versus observed times.
Draw an as-is process with swimlanes and exception paths. Identify bottlenecks from case-level evidence rather than assuming every step should use AI.
Create a to-be process and a requirements traceability matrix linking business goals, data fields, rules, acceptance tests and owners.
Prototype the workflow in Power Automate if available, or execute a labeled tabletop simulation in Calc. Write UAT scripts for normal, duplicate, missing-data and rejection cases.
A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.
Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings.
Validate the proposed process with a consenting domain practitioner and record rejected assumptions.
Deliverables: As-is/to-be process maps; Requirements and UAT traceability workbook; Business case with sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A reviewer must reproduce one result and identify which capabilities you implemented. A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.

### Interview
Explain your advanced solution for AI business / process analyst. Use this scenario: A requester bypasses a mandatory review and an upstream field changes. Show how requirements and process controls detect both before a downstream action.
Review: Start with the task and permitted scope. Explain feasibility and change impact: Compare the proposed process with a non-AI alternative and account for integrations, skills, operating costs and control changes. Identify who must adopt the new workflow. Show the input and observed output, then address Compare cycle time, rework and manual touches with explicit assumptions. Separate a business case estimate from realized operational savings. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [As-is/to-be process maps; Requirements and UAT traceability workbook; Business case with sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Power Automate — Commercial · account and connector licensing
Test approval workflows; use a labeled manual simulation if access is unavailable.
Alternative: Node-RED (open source) or a manually executed checklist; connector availability and operating responsibility differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
diagrams.net: https://www.drawio.com/docs/getting-started/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Power Automate: https://learn.microsoft.com/en-us/power-automate/
Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
