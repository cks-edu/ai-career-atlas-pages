# SAMPLE — Evidence-linked extraction worksheet
Role: Multimodal application engineer
Case: Receipt totals without evidence
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference.

## Evidence table
| Record | unlinked_fields (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | review |
| case-3 | 1 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three receipts contain accepted fields with no traceable page evidence.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Retain page and region references through extraction and route unlinked fields to review.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in multimodal application engineer.
Before release: Validate referenced regions, arithmetic and rotated-page cases, not just nonempty citations.

## Design choice and trade-off
Bind extracted fields to source regions; separate visual extraction from arithmetic validation.
Evidence links help review but do not prove the OCR text is right; retain the original page.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Receipt review workbench: Scanned and rotated receipts are evaluated separately.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
