# Multimodal application engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Modality-specific evidence. Multimodal systems use more than one kind of input, such as an image and text. Layout and image quality can change which information is available. Then try Compare two versions of a form. The three levels build toward Evidence-grounded document intake. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Modality-specific evidence

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Modality-specific evidence
Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene.
Mental model: Several witnesses see different parts of the same event.
Boundary: Models and OCR may miss small print, layout or visual context.
Worked example: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Receipt totals without evidence
The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Three receipts contain accepted fields with no traceable page evidence. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Retain page and region references through extraction and route unlinked fields to review.
Recall: Validate referenced regions, arithmetic and rotated-page cases, not just nonempty citations. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Modality-specific evidence: Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Multimodal systems use more than one kind of input, such as an image and text. Layout and image quality can change which information is available.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create a fictional form with Name: Alex and Total: 42. Put “42” near a second label, Tax, in a deliberately confusing version.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two form sketches and a table of expected values and possible reading errors.

3. Try step 2
Ask a peer, or review it yourself, to copy the total from each version without extra context.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two form sketches and a table of expected values and possible reading errors.

4. Try step 3
Record which version is ambiguous and rewrite the form so each value has one clear label.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two form sketches and a table of expected values and possible reading errors.

5. Explain and check your result
You distinguish missing or ambiguous input from a wrong interpretation; this is an input-design exercise, not a model accuracy test. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Two form sketches and a table of expected values and possible reading errors. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Apply this toy-case rule manually: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three receipts contain accepted fields with no traceable page evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Multimodal application engineer.
Create a fictional form with Name: Alex and Total: 42. Put “42” near a second label, Tax, in a deliberately confusing version.
Ask a peer, or review it yourself, to copy the total from each version without extra context.
Record which version is ambiguous and rewrite the form so each value has one clear label.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Two form sketches and a table of expected values and possible reading errors. Include beginner-worksheet.md and your completed Evidence-linked extraction worksheet.
Check: You distinguish missing or ambiguous input from a wrong interpretation; this is an input-design exercise, not a model accuracy test.

### Interview
Explain your beginner solution for Multimodal application engineer. Use this scenario: The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference.
Review: Start with the task and permitted scope. Explain modality-specific evidence: Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene. Show the input and observed output, then address Retain page and region references through extraction and route unlinked fields to review. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Two form sketches and a table of expected values and possible reading errors. Include beginner-worksheet.md and your completed Evidence-linked extraction worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Input normalization

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Image/audio formats, API integration and task-specific ground truth.

### Input normalization
Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input.
Mental model: A map resized without updating its scale gives wrong distances.
Boundary: A valid file header does not prove a file is harmless or semantically correct.
Worked example: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Evidence-grounded document intake
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.
Recall: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. Identify one observation that would contradict your claim.

### Terms
Input normalization: Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.
coordinate: A position described relative to a named frame or coordinate reference system.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use Pillow to create or resize test images, and Tesseract to extract text plus bounding boxes. Keep the original image hash and per-page OCR output.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source.
Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.
Use Pillow to create or resize test images, and Tesseract to extract text plus bounding boxes. Keep the original image hash and per-page OCR output.
Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.
Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.
Deliverables: Annotated image fixtures and extraction API; Reviewer interface with source highlighting. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Multimodal application engineer. Use this scenario: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.
Review: Start with the task and permitted scope. Explain input normalization: Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input. Show the input and observed output, then address Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Annotated image fixtures and extraction API; Reviewer interface with source highlighting. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Cross-modal evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Cross-modal evaluation
Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples.
Mental model: Test each sensor before trusting the combined instrument panel.
Boundary: Agreement between two model outputs can reflect a shared error.
Worked example: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Evidence-grounded document intake
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. Build a review screen that highlights each source region and allows correction. Compare OCR rules with a vision-capable model only after checking model support and data-use terms.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.
Recall: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. Identify one observation that would contradict your claim.

### Terms
Cross-modal evaluation: Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use Pillow to create or resize test images, and Tesseract to extract text plus bounding boxes. Keep the original image hash and per-page OCR output.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Build a review screen that highlights each source region and allows correction. Compare OCR rules with a vision-capable model only after checking model support and data-use terms.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source.
Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.
Use Pillow to create or resize test images, and Tesseract to extract text plus bounding boxes. Keep the original image hash and per-page OCR output.
Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.
Build a review screen that highlights each source region and allows correction. Compare OCR rules with a vision-capable model only after checking model support and data-use terms.
Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.
Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.
Add multi-page evidence linking and demonstrate how conflicting totals are escalated.
Deliverables: Annotated image fixtures and extraction API; Reviewer interface with source highlighting; Field-level evaluation and error taxonomy. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. A reviewer must reproduce one result and identify which capabilities you implemented. Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

### Interview
Explain your advanced solution for Multimodal application engineer. Use this scenario: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.
Review: Start with the task and permitted scope. Explain cross-modal evaluation: Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples. Show the input and observed output, then address Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Annotated image fixtures and extraction API; Reviewer interface with source highlighting; Field-level evaluation and error taxonomy. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Tesseract — Open source
OCR text and positional evidence extraction.
Alternative: PaddleOCR (open source) or commercial document extraction; evaluate layout, language and permissions on the same samples.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Pillow — Open source
Image validation, generation and controlled transformations.
Alternative: OpenCV (open source) for broader vision operations; image color order and transforms need explicit checks.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
FastAPI: https://fastapi.tiangolo.com/tutorial/
Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html
Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html
Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome
Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
