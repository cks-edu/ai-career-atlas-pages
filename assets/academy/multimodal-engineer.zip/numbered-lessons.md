# Multimodal application engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Modality-specific evidence: Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

### Modality-specific evidence

Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene. In this role, work through: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Several witnesses see different parts of the same event.

Boundary: Models and OCR may miss small print, layout or visual context.

Worked example: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Tesseract (Open source); Pillow (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Multimodal application engineer: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars.

Predict the worked case

Read this case without running a tool: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in modality-specific evidence.

Connect the concept to the role

Apply this rule: Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Models and OCR may miss small print, layout or visual context.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies modality-specific evidence to this case: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Modality-specific evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with modality-specific evidence. Use the glossary below, then write your prediction for: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multimodal application engineer role interview. Explain modality-specific evidence using this case: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate modality-specific evidence to a system or workflow you know. Explain modality-specific evidence using this case: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain modality-specific evidence using this case: OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars.

Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene. — Text, images and audio have different ambiguities. Preserve which input supports each claim and avoid treating extracted text as a complete account of a document or scene. Models and OCR may miss small print, layout or visual context.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: Receipt totals without evidence

The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Three receipts contain accepted fields with no traceable page evidence. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Retain page and region references through extraction and route unlinked fields to review. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Several witnesses see different parts of the same event.

OCR finds Total 80 but misses the currency symbol. Record the amount and mark currency unknown instead of assuming dollars.

Worked example: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Retain page and region references through extraction and route unlinked fields to review.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: FastAPI (Open source · local); Tesseract (Open source); Pillow (Open source)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Three receipts contain accepted fields with no traceable page evidence. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Apply this toy-case rule manually: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Multimodal systems use more than one kind of input, such as an image and text. Layout and image quality can change which information is available.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Create a fictional form with Name: Alex and Total: 42. Put “42” near a second label, Tax, in a deliberately confusing version.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Two form sketches and a table of expected values and possible reading errors.

Preparation · Try step 2

Ask a peer, or review it yourself, to copy the total from each version without extra context.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Two form sketches and a table of expected values and possible reading errors.

Preparation · Try step 3

Record which version is ambiguous and rewrite the form so each value has one clear label.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Two form sketches and a table of expected values and possible reading errors.

Preparation · Explain and check your result

You distinguish missing or ambiguous input from a wrong interpretation; this is an input-design exercise, not a model accuracy test. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: Two form sketches and a table of expected values and possible reading errors. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Apply this toy-case rule manually: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three receipts contain accepted fields with no traceable page evidence. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three receipts contain accepted fields with no traceable page evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: receipt totals without evidence. Use the glossary below, then write your prediction for: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Retain page and region references through extraction and route unlinked fields to review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multimodal application engineer role interview. Explain diagnose: receipt totals without evidence using this case: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Retain page and region references through extraction and route unlinked fields to review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: receipt totals without evidence to a system or workflow you know. Explain diagnose: receipt totals without evidence using this case: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Retain page and region references through extraction and route unlinked fields to review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Validate referenced regions, arithmetic and rotated-page cases, not just nonempty citations. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: receipt totals without evidence using this case: Review when unlinked_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Retain page and region references through extraction and route unlinked fields to review. State the evidence, one alternative and where the mental model stops.

Quiz: Receipt totals without evidence: The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference.

Change the acceptance rule after seeing an inconvenient result.

Retain page and region references through extraction and route unlinked fields to review.

Omit failed cases and report only the successful demonstrations.

Reference: Retain page and region references through extraction and route unlinked fields to review. — Retain page and region references through extraction and route unlinked fields to review. Validate referenced regions, arithmetic and rotated-page cases, not just nonempty citations.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Image/audio formats, API integration and task-specific ground truth.

Terms:

Input normalization: Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

coordinate: A position described relative to a named frame or coordinate reference system.

### Input normalization

Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input. In this role, work through: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A map resized without updating its scale gives wrong distances.

Boundary: A valid file header does not prove a file is harmless or semantically correct.

Worked example: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Image/audio formats, API integration and task-specific ground truth.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Tesseract (Open source); Pillow (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Multimodal application engineer: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original.

Predict the worked case

Read this case without running a tool: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in input normalization.

Connect the concept to the role

Apply this rule: Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A valid file header does not prove a file is harmless or semantically correct.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies input normalization to this case: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Input normalization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with input normalization. Use the glossary below, then write your prediction for: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multimodal application engineer role interview. Explain input normalization using this case: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate input normalization to a system or workflow you know. Explain input normalization using this case: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain input normalization using this case: Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original.

Treat a passing starter as proof of the whole role workflow.

Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input.

Ignore the failure because the tool produced an output.

Reference: Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input. — Validate file type and size, retain original dimensions and track every transformation. Coordinate or timestamp changes must be reversible if an output points back to the input. A valid file header does not prove a file is harmless or semantically correct.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Evidence-grounded document intake

Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence. In this role, work through: Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A map resized without updating its scale gives wrong distances.

Resize an image to half width; a box at x=50 in the resized image corresponds to x=100 in the original.

Worked example: Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Tesseract (Open source); Pillow (Open source)

Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use Pillow to create or resize test images, and Tesseract to extract text plus bounding boxes. Keep the original image hash and per-page OCR output.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The receipt reviewer requires every accepted extracted total to have a resolvable page-evidence reference. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: Annotated image fixtures and extraction API; Reviewer interface with source highlighting. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: evidence-grounded document intake. Use the glossary below, then write your prediction for: Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multimodal application engineer role interview. Explain integrate: evidence-grounded document intake using this case: Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: evidence-grounded document intake to a system or workflow you know. Explain integrate: evidence-grounded document intake using this case: Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. Identify one observation that would contradict your claim.

Interview: Explain integrate: evidence-grounded document intake using this case: Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Evidence-grounded document intake at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.

Reference: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. — Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Cross-modal evaluation: Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

### Cross-modal evaluation

Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples. In this role, work through: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Test each sensor before trusting the combined instrument panel.

Boundary: Agreement between two model outputs can reflect a shared error.

Worked example: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Tesseract (Open source); Pillow (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Multimodal application engineer: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence.

Predict the worked case

Read this case without running a tool: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in cross-modal evaluation.

Connect the concept to the role

Apply this rule: Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Agreement between two model outputs can reflect a shared error.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies cross-modal evaluation to this case: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Cross-modal evaluation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cross-modal evaluation. Use the glossary below, then write your prediction for: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multimodal application engineer role interview. Explain cross-modal evaluation using this case: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cross-modal evaluation to a system or workflow you know. Explain cross-modal evaluation using this case: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain cross-modal evaluation using this case: Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples.

Reference: Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples. — Test each modality alone and together to find where an error originates. Include missing, contradictory and degraded inputs rather than evaluating only clean paired examples. Agreement between two model outputs can reflect a shared error.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Evidence-grounded document intake

Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. Build a review screen that highlights each source region and allows correction. Compare OCR rules with a vision-capable model only after checking model support and data-use terms. In this role, work through: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: Test each sensor before trusting the combined instrument panel.

Supply an invoice image and conflicting typed amount. The application flags the conflict and links both pieces of evidence.

Worked example: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Tesseract (Open source); Pillow (Open source)

Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use Pillow to create or resize test images, and Tesseract to extract text plus bounding boxes. Keep the original image hash and per-page OCR output.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Build a review screen that highlights each source region and allows correction. Compare OCR rules with a vision-capable model only after checking model support and data-use terms.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. A reviewer must reproduce one result and identify which capabilities you implemented. Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: Annotated image fixtures and extraction API; Reviewer interface with source highlighting; Field-level evaluation and error taxonomy. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: evidence-grounded document intake. Use the glossary below, then write your prediction for: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multimodal application engineer role interview. Explain defend: evidence-grounded document intake using this case: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: evidence-grounded document intake to a system or workflow you know. Explain defend: evidence-grounded document intake using this case: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields. Identify one observation that would contradict your claim.

Interview: Explain defend: evidence-grounded document intake using this case: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Evidence-grounded document intake at this level?

Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files. — Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files. Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
