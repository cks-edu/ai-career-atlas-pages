import unittest
from fastapi.testclient import TestClient
from app import app
class ServiceTests(unittest.TestCase):
    def setUp(self): self.client=TestClient(app)
    def test_health(self): self.assertEqual(self.client.get('/health').status_code,200)
    def test_proposal(self):
        result=self.client.post('/propose',json={'text':'Review this fictional request.'}).json()
        self.assertTrue(result['requires_review'])
        self.assertEqual(result['mode'],'deterministic-baseline')
    def test_missing_text(self): self.assertEqual(self.client.post('/propose',json={}).status_code,422)
    def test_length(self): self.assertEqual(self.client.post('/propose',json={'text':'x'*4001}).status_code,422)
if __name__=='__main__': unittest.main()
