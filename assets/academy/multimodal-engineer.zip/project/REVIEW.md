# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Annotated image fixtures and extraction API.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
