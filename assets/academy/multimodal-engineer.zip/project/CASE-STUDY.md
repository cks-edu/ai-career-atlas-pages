# Evidence-grounded document intake

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

## Limitations and next iteration
Add multi-page evidence linking and demonstrate how conflicting totals are escalated.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
