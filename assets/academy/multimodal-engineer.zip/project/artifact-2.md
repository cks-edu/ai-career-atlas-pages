# Reviewer interface with source highlighting

Project: Evidence-grounded document intake
Status: blank work product — not completed evidence

## Purpose and audience
Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source.

## Required content
Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.

## Failure evidence
Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
