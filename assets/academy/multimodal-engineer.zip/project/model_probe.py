"""Real local Ollama call; requires a separately installed server and model."""
import json, os, urllib.request
model=os.environ.get('OLLAMA_MODEL')
if not model:
    raise SystemExit('Set OLLAMA_MODEL to a model you have already pulled with Ollama.')
payload={'model':model,'prompt':'Summarize this fictional ticket in one sentence: I cannot reset my password.','stream':False}
request=urllib.request.Request('http://127.0.0.1:11434/api/generate',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=120) as response:
    result=json.load(response)
print(json.dumps({'model':model,'response':result.get('response'),'total_duration_ns':result.get('total_duration'),'eval_count':result.get('eval_count')},indent=2))
