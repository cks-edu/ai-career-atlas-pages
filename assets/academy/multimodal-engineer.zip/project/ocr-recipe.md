# OCR setup and evidence

Install Tesseract with the English language data from the official distribution. Supply a fictional document image named `receipt.png`.

```sh
tesseract receipt.png output -l eng tsv
```

Inspect `output.tsv`: preserve page, bounding box, text and confidence fields. Confidence is an OCR signal, not proof that a field is correct. Add the image hash and a separate human correction ledger. Install Pillow with `python -m pip install pillow` before building image validation.
