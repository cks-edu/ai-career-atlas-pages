"""Deterministic API baseline. This does not call a model or perform actions."""
import uuid
from fastapi import FastAPI
from pydantic import BaseModel, Field
app = FastAPI(title='Portfolio review service')
class Request(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
class Result(BaseModel):
    request_id: str
    proposal: str
    requires_review: bool = True
    mode: str = 'deterministic-baseline'
@app.get('/health')
def health():
    return {'status': 'ok'}
@app.post('/propose', response_model=Result)
def propose(request: Request):
    return Result(request_id=str(uuid.uuid4()), proposal=request.text.strip()[:200])
