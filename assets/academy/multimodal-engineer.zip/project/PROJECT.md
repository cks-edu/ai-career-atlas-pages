# Evidence-grounded document intake

Career: Multimodal application engineer
Reviewed: 2026-10-22

Build an intake tool that extracts fields from document images and lets a reviewer trace every field to its source.

## Prerequisites
Image/audio formats, API integration and task-specific ground truth.

## Included starter versus your implementation
FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create 20 fictional receipts with varied layouts, rotated scans, missing totals and two-page examples. Record the true fields and page coordinates before adding image noise.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Use Pillow to create or resize test images, and Tesseract to extract text plus bounding boxes. Keep the original image hash and per-page OCR output.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Extend the API starter with an upload route using a size limit and an image decoder check. Store extracted fields with page and bounding-box references; do not treat model text as verified evidence.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Build a review screen that highlights each source region and allows correction. Compare OCR rules with a vision-capable model only after checking model support and data-use terms.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Upload an image with a plausible but wrong total and another with no total. Flag inconsistency and absence instead of silently inventing a value; reject oversized or non-image files.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report field exact match, evidence-link accuracy, manual correction rate and latency by layout. Keep missing fields distinct from incorrect fields.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

## Portfolio deliverables
1. Annotated image fixtures and extraction API — artifact-1.md
2. Reviewer interface with source highlighting — artifact-2.md
3. Field-level evaluation and error taxonomy — artifact-3.md

## Troubleshooting
- Port occupied: select an unused local port and update client URLs.
- 422 response: inspect the request JSON and schema.
- Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.

## Extension
Add multi-page evidence linking and demonstrate how conflicting totals are escalated.

## Primary learning resources
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.
- Tesseract: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html — Open source; OCR text and positional evidence extraction.
- Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html — Open source; Image validation, generation and controlled transformations.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
