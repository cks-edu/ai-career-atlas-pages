# Python Developer

Software Engineering

Start with typed csv ingestion. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward installable CLI project, rollback test and supported-Python notes.

## beginner

Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Typed CSV ingestion
CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input.
Mental model: An intake clerk checks the label, the format and then whether the requested amount is allowed.
Limit: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.
Example: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.
```
python3 pipeline.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Accepted total 30 and two distinct rejection reasons for c and d.

6. Role workshop · debug and verify
If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save validate_rows.py and a rejection CSV. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Accepted total 30 and two distinct rejection reasons for c and d.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Typed CSV ingestion: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: validate_rows.py and a rejection CSV
Accepted total 30 and two distinct rejection reasons for c and d.

Interview: Work through this Python Developer case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input. Expected evidence: Accepted total 30 and two distinct rejection reasons for c and d. Diagnosis: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file. State the limits of the mental model: An intake clerk checks the label, the format and then whether the requested amount is allowed.

Resume: Built validate_rows.py and a rejection CSV using Python and sqlite3; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### CLI interfaces and tests
A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process.
Mental model: The command line is a public form for other programs as well as humans.
Limit: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.
Example: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
--input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.
```
python3 -m unittest discover
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

6. Role workshop · debug and verify
If importing the module runs the load, place CLI execution under if __name__ == '__main__'. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save CLI source, unittest suite and captured exit codes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
CLI interfaces and tests: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: CLI source, unittest suite and captured exit codes
Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Interview: Work through this Python Developer case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process. Expected evidence: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass. Diagnosis: If importing the module runs the load, place CLI execution under if __name__ == '__main__'. State the limits of the mental model: The command line is a public form for other programs as well as humans.

Resume: Built CLI source, unittest suite and captured exit codes using Python and sqlite3; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Transactions and packaging
Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work.
Mental model: A sealed batch is either accepted as a whole or split into explicitly recorded parcels.
Limit: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.
Example: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.
```
python3 -m unittest discover
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

6. Role workshop · debug and verify
An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save installable CLI project, rollback test and supported-Python notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Transactions and packaging: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: installable CLI project, rollback test and supported-Python notes
Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Interview: Work through this Python Developer case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work. Expected evidence: Failed batch commits zero records; retry commits two; clean-environment setup is documented. Diagnosis: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic. State the limits of the mental model: A sealed batch is either accepted as a whole or split into explicitly recorded parcels.

Resume: Built installable CLI project, rollback test and supported-Python notes using Python and sqlite3; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
Python: argparse reference: https://docs.python.org/3/library/argparse.html
