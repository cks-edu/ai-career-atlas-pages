import asyncio
async def main():
 cleaned=[]
 async def worker():
  try:
   await asyncio.Event().wait()
  finally:
   cleaned.append('closed')
 try:
  await asyncio.wait_for(worker(),timeout=0.01)
 except asyncio.TimeoutError:
  pass
 assert cleaned==['closed']
 print('PASS: timeout triggers cooperative cleanup')
asyncio.run(main())
