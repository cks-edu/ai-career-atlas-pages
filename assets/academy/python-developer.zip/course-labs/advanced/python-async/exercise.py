import asyncio
async def fetch_name(name):
 await asyncio.sleep(0)
 return name.upper()
async def main():
 result=await asyncio.gather(fetch_name('read'),fetch_name('build'))
 assert result==['READ','BUILD']
 print('PASS: scheduled coroutines return ordered results')
asyncio.run(main())
