cache={}
def put(tenant,task,value,now): cache[(tenant,task)]=(value,now+60)
def get(tenant,task,now):
 entry=cache.get((tenant,task))
 return entry[0] if entry and now<entry[1] else None
put('a',1,'Private',0)
assert get('a',1,59)=='Private'
assert get('a',1,60) is None
assert get('b',1,1) is None
print('PASS: key isolation and exact expiry')
