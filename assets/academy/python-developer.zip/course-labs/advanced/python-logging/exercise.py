import json
def event(request):
 return {'event':'task.read','request_id':request['request_id'],'status':request['status']}
source={'request_id':'req-7','status':200,'password':'never-log','token':'secret'}
encoded=json.dumps(event(source),sort_keys=True)
assert 'never-log' not in encoded and 'secret' not in encoded
assert json.loads(encoded)['request_id']=='req-7'
print(encoded)
