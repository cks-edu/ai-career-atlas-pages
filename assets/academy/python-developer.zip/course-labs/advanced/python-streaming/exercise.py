def nonblank(lines):
 for line in lines:
  value=line.strip()
  if value:
   yield value
source=iter([' Read\n',' \n','Build\n'])
values=nonblank(source)
assert next(values)=='Read'
assert list(values)==['Build']
assert list(values)==[]
print('PASS: incremental consumption and exhaustion')
