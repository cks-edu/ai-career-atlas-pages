import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.execute('create table tasks(id integer primary key,title text not null)')
 with con:
  con.execute('insert into tasks values(?,?)',(1,"Read SQL's guide"))
 row=con.execute('select title from tasks where id=?',(1,)).fetchone()
 assert row==("Read SQL's guide",)
 assert con.execute('select title from tasks where id=?',(99,)).fetchone() is None
 print('PASS: quoted value and absent row')
finally:
 con.close()
