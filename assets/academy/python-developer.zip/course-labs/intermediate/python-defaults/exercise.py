def append_title(title,titles=None):
 result=[] if titles is None else list(titles)
 result.append(title)
 return result
assert append_title('Read')==['Read']
assert append_title('Build')==['Build']
source=['Plan']
assert append_title('Read',source)==['Plan','Read']
assert source==['Plan']
print('PASS: independent calls and preserved caller list')
