import json
def parse_tasks(text):
 try:
  value=json.loads(text)
 except json.JSONDecodeError as error:
  return {'ok':False,'error':'Invalid JSON','line':error.lineno}
 if not isinstance(value,list):
  return {'ok':False,'error':'Expected task array'}
 return {'ok':True,'tasks':value}
assert parse_tasks('[]')=={'ok':True,'tasks':[]}
assert not parse_tasks('{')['ok']
assert parse_tasks('{}')['error']=='Expected task array'
print('PASS: empty, syntax error and schema error stay distinct')
