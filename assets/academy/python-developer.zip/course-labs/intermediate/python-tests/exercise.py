import unittest
def normalise(title):
 if not isinstance(title,str) or not title.strip():
  raise ValueError('Title required')
 return title.strip()
class TitlesTest(unittest.TestCase):
 def test_trim(self): self.assertEqual(normalise(' Read '),'Read')
 def test_blank(self):
  with self.assertRaises(ValueError): normalise(' ')
result=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(TitlesTest))
if not result.wasSuccessful(): raise SystemExit(1)
