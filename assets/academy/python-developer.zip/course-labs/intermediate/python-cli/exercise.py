import argparse
parser=argparse.ArgumentParser(description='Plan one study session')
parser.add_argument('--minutes',type=int,default=25)
def parse(args):
 result=parser.parse_args(args)
 if not 1<=result.minutes<=180:
  raise ValueError('Minutes must be 1 to 180')
 return result
assert parse([]).minutes==25
assert parse(['--minutes','50']).minutes==50
try:
 parse(['--minutes','0'])
except ValueError:
 print('PASS: default, option and domain range')
else:
 raise AssertionError('Expected invalid range')
