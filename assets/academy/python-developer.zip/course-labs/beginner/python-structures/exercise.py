rows=[{'id':1,'title':'Read'},{'id':2,'title':'Build'}]
by_id={row['id']:row for row in rows}
assert by_id[2]['title']=='Build'
assert by_id.get(99) is None
assert len(by_id)==len(rows)
print(sorted(by_id))
