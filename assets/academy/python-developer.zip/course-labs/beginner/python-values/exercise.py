count=2
label='2'
assert count+1==3
assert label+'1'=='21'
assert int(label)+1==3
try:
 int('two')
except ValueError:
 print('PASS: invalid conversion rejected')
else:
 raise AssertionError('Expected ValueError')
