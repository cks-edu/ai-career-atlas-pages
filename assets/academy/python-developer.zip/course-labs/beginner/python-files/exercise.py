import json
from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory(prefix='skillbadi-') as folder:
 path=Path(folder)/'tasks.json'
 original=[{'id':1,'title':'చదువు'}]
 path.write_text(json.dumps(original,ensure_ascii=False),encoding='utf-8')
 restored=json.loads(path.read_text(encoding='utf-8'))
 assert restored==original
 print('PASS: UTF-8 JSON round trip')
