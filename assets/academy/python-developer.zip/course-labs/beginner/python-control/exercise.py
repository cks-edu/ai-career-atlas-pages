values=[' Read ',' ',None,'Build']
clean=[]
for value in values:
 if isinstance(value,str) and value.strip():
  clean.append(value.strip())
assert clean==['Read','Build']
assert values[0]==' Read '
print(clean)
