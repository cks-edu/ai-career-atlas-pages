def seconds(minutes):
 if type(minutes) is not int or minutes<0:
  raise ValueError('Use nonnegative integer minutes')
 return minutes*60
assert seconds(25)==1500
assert seconds(0)==0
try:
 seconds(True)
except ValueError:
 print('PASS: bool is deliberately rejected despite being an int subclass')
else:
 raise AssertionError('Expected rejection')
