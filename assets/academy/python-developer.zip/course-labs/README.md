# Python Developer — core lessons

Start with values, conditions, functions, collections and UTF-8 files. Continue to mutable-state pitfalls, CLI design, tests and SQLite, then async cancellation, streaming and safe operational logs.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A Python task tool with validated input, reproducible file/database behaviour, error tests and an operational evidence report.
