# Python Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Typed CSV ingestion

CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input.
Mental model: An intake clerk checks the label, the format and then whether the requested amount is allowed.
Case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.
Task: Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.
Acceptance: Accepted total 30 and two distinct rejection reasons for c and d.
Troubleshooting: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.
Deliverable: validate_rows.py and a rejection CSV

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
CLI interfaces and tests

A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process.
Mental model: The command line is a public form for other programs as well as humans.
Case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.
Task: Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.
Acceptance: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.
Troubleshooting: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.
Deliverable: CLI source, unittest suite and captured exit codes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Transactions and packaging

Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work.
Mental model: A sealed batch is either accepted as a whole or split into explicitly recorded parcels.
Case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.
Task: Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.
Acceptance: Failed batch commits zero records; retry commits two; clean-environment setup is documented.
Troubleshooting: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.
Deliverable: installable CLI project, rollback test and supported-Python notes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
