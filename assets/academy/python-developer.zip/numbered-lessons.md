# Python Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Python Developer: Use the concept to complete this role exercise: Read a CSV and validate typed fields

Typed CSV ingestion: CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input.

### Values, names and basic types

Python names refer to values. Strings represent text, integers represent whole numbers and booleans represent true or false. Print a small expression and explain its type before combining operations.

How it works
The + operator adds numbers but joins strings. Converting text with int can fail when the text is not an integer. Keep conversion at an explicit input boundary.

Where the model stops
Python dynamic typing does not remove contracts. A type hint alone does not reject wrong runtime input.

Make one change
Create a minutes-to-seconds function. Test integer 25, numeric text and invalid text, and decide which types the function accepts.

Mental model: A name is a label attached to a value, not a box permanently restricted to one type.

Boundary: Python dynamic typing does not remove contracts. A type hint alone does not reject wrong runtime input.

Worked example: count=2
label='2'
assert count+1==3
assert label+'1'=='21'
assert int(label)+1==3
try:
 int('two')
except ValueError:
 print('PASS: invalid conversion rejected')
else:
 raise AssertionError('Expected ValueError')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/python-values. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create a minutes-to-seconds function. Test integer 25, numeric text and invalid text, and decide which types the function accepts.

Terminal folder: course-labs/beginner/python-values

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The + operator adds numbers but joins strings. Converting text with int can fail when the text is not an integer. Keep conversion at an explicit input boundary.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/python-values. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Numeric addition and string joining differ; invalid integer text is rejected. Your conversion contract is documented and tested.

Build your change

Create a minutes-to-seconds function. Test integer 25, numeric text and invalid text, and decide which types the function accepts.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Numeric addition and string joining differ; invalid integer text is rejected. Your conversion contract is documented and tested.

Break, repair and explain

Deliberately violate this boundary: Python dynamic typing does not remove contracts. A type hint alone does not reject wrong runtime input. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Numeric addition and string joining differ; invalid integer text is rejected. Your conversion contract is documented and tested.

Troubleshoot: My result does not match Values, names and basic types: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The + operator adds numbers but joins strings. Converting text with int can fail when the text is not an integer. Keep conversion at an explicit input boundary. Then inspect this limit: Python dynamic typing does not remove contracts. A type hint alone does not reject wrong runtime input. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/python-values/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Values, names and basic types line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A name is a label attached to a value, not a box permanently restricted to one type.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: What is the value of "2" + "1"? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Python dynamic typing does not remove contracts. A type hint alone does not reject wrong runtime input. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What is the value of "2" + "1"?

Interview: What is the value of "2" + "1"? Defend your answer using your actual lab result and this boundary: Python dynamic typing does not remove contracts. A type hint alone does not reject wrong runtime input.

Quiz: What is the value of "2" + "1"?

3

21 as text

An integer 21

Reference: 21 as text — Both operands are strings, so + concatenates them. Convert explicitly when numeric input is intended.

Sources:

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Conditions and iteration

An if statement selects a path. A for loop visits elements of an iterable. Indentation groups the statements belonging to a branch or loop, so it is part of Python syntax.

How it works
Test a value before applying an operation that assumes its type. The loop below keeps nonblank strings, strips their surrounding whitespace and leaves the original sequence unchanged.

Where the model stops
Filtering invalid records silently can hide data quality problems. Production imports may need an explicit rejection report.

Make one change
Return both accepted values and rejected positions. Test empty input and a numeric entry so skipped data is visible in an import report.

Mental model: Indented steps belong to the same instruction card.

Boundary: Filtering invalid records silently can hide data quality problems. Production imports may need an explicit rejection report.

Worked example: values=[' Read ',' ',None,'Build']
clean=[]
for value in values:
 if isinstance(value,str) and value.strip():
  clean.append(value.strip())
assert clean==['Read','Build']
assert values[0]==' Read '
print(clean)


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/python-control. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Return both accepted values and rejected positions. Test empty input and a numeric entry so skipped data is visible in an import report.

Terminal folder: course-labs/beginner/python-control

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Test a value before applying an operation that assumes its type. The loop below keeps nonblank strings, strips their surrounding whitespace and leaves the original sequence unchanged.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/python-control. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The reference prints Read and Build. Your report identifies the blank, null and numeric positions without changing the original input.

Build your change

Return both accepted values and rejected positions. Test empty input and a numeric entry so skipped data is visible in an import report.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The reference prints Read and Build. Your report identifies the blank, null and numeric positions without changing the original input.

Break, repair and explain

Deliberately violate this boundary: Filtering invalid records silently can hide data quality problems. Production imports may need an explicit rejection report. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The reference prints Read and Build. Your report identifies the blank, null and numeric positions without changing the original input.

Troubleshoot: My result does not match Conditions and iteration: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Test a value before applying an operation that assumes its type. The loop below keeps nonblank strings, strips their surrounding whitespace and leaves the original sequence unchanged. Then inspect this limit: Filtering invalid records silently can hide data quality problems. Production imports may need an explicit rejection report. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/python-control/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Conditions and iteration line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Indented steps belong to the same instruction card.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Why is indentation important in Python? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Filtering invalid records silently can hide data quality problems. Production imports may need an explicit rejection report. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why is indentation important in Python?

Interview: Why is indentation important in Python? Defend your answer using your actual lab result and this boundary: Filtering invalid records silently can hide data quality problems. Production imports may need an explicit rejection report.

Quiz: Why is indentation important in Python?

It defines which statements belong to a block.

It changes text colour.

It automatically validates data.

Reference: It defines which statements belong to a block. — Python uses indentation to express block structure. Consistent spaces and a visible editor indentation guide help avoid mistakes.

Sources:

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Functions and explicit return values

A function gives a repeatable rule a name. Parameters receive values; return sends a result to the caller. Printing a result and returning it are different operations.

How it works
Validate the type and range, then return the computed value. A function without an executed return statement returns None, even if it printed the right-looking text.

Where the model stops
A pure example does not validate external files or concurrent execution. Keep side effects separate from this calculation.

Make one change
Add a maximum session of 180 minutes and test 180, 181 and a negative input. Explain why this example deliberately rejects bool.

Mental model: A function hands a result back to its caller; a print statement only puts a message on the noticeboard.

Boundary: A pure example does not validate external files or concurrent execution. Keep side effects separate from this calculation.

Worked example: def seconds(minutes):
 if type(minutes) is not int or minutes<0:
  raise ValueError('Use nonnegative integer minutes')
 return minutes*60
assert seconds(25)==1500
assert seconds(0)==0
try:
 seconds(True)
except ValueError:
 print('PASS: bool is deliberately rejected despite being an int subclass')
else:
 raise AssertionError('Expected rejection')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/python-functions. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a maximum session of 180 minutes and test 180, 181 and a negative input. Explain why this example deliberately rejects bool.

Terminal folder: course-labs/beginner/python-functions

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Validate the type and range, then return the computed value. A function without an executed return statement returns None, even if it printed the right-looking text.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/python-functions. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The reference returns 1500 and 0, and rejects True. Your maximum boundary has separate valid and invalid cases.

Build your change

Add a maximum session of 180 minutes and test 180, 181 and a negative input. Explain why this example deliberately rejects bool.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The reference returns 1500 and 0, and rejects True. Your maximum boundary has separate valid and invalid cases.

Break, repair and explain

Deliberately violate this boundary: A pure example does not validate external files or concurrent execution. Keep side effects separate from this calculation. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The reference returns 1500 and 0, and rejects True. Your maximum boundary has separate valid and invalid cases.

Troubleshoot: My result does not match Functions and explicit return values: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Validate the type and range, then return the computed value. A function without an executed return statement returns None, even if it printed the right-looking text. Then inspect this limit: A pure example does not validate external files or concurrent execution. Keep side effects separate from this calculation. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/python-functions/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Functions and explicit return values line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A function hands a result back to its caller; a print statement only puts a message on the noticeboard.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Does printing 1500 make a function return 1500? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A pure example does not validate external files or concurrent execution. Keep side effects separate from this calculation. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does printing 1500 make a function return 1500?

Interview: Does printing 1500 make a function return 1500? Defend your answer using your actual lab result and this boundary: A pure example does not validate external files or concurrent execution. Keep side effects separate from this calculation.

Quiz: Does printing 1500 make a function return 1500?

Always.

Only in an IDE.

No; it needs an appropriate return statement.

Reference: No; it needs an appropriate return statement. — Printing is an output side effect. The caller receives the return value, or None if no return value is produced.

Sources:

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Lists and dictionaries: order and identity

A list holds an ordered sequence. A dictionary associates keys with values. A list index is a position, while a record id is an identity that should survive reordering.

How it works
Build a dictionary keyed by task id for lookup. Duplicate keys replace earlier values, so check for duplicates when importing data instead of silently losing a row.

Where the model stops
A copied dictionary still shares nested mutable values unless you copy them intentionally.

Make one change
Add a duplicate id and make the import reject it explicitly. Reverse the source list and verify that identity lookup still returns the same task.

Mental model: A seating position can change; a person identity does not change when they move seats.

Boundary: A copied dictionary still shares nested mutable values unless you copy them intentionally.

Worked example: rows=[{'id':1,'title':'Read'},{'id':2,'title':'Build'}]
by_id={row['id']:row for row in rows}
assert by_id[2]['title']=='Build'
assert by_id.get(99) is None
assert len(by_id)==len(rows)
print(sorted(by_id))


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/python-structures. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a duplicate id and make the import reject it explicitly. Reverse the source list and verify that identity lookup still returns the same task.

Terminal folder: course-labs/beginner/python-structures

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Build a dictionary keyed by task id for lookup. Duplicate keys replace earlier values, so check for duplicates when importing data instead of silently losing a row.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/python-structures. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The keys are 1 and 2. Your duplicate input is reported and reordering does not change the id-to-task relationship.

Build your change

Add a duplicate id and make the import reject it explicitly. Reverse the source list and verify that identity lookup still returns the same task.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The keys are 1 and 2. Your duplicate input is reported and reordering does not change the id-to-task relationship.

Break, repair and explain

Deliberately violate this boundary: A copied dictionary still shares nested mutable values unless you copy them intentionally. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The keys are 1 and 2. Your duplicate input is reported and reordering does not change the id-to-task relationship.

Troubleshoot: My result does not match Lists and dictionaries: order and identity: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Build a dictionary keyed by task id for lookup. Duplicate keys replace earlier values, so check for duplicates when importing data instead of silently losing a row. Then inspect this limit: A copied dictionary still shares nested mutable values unless you copy them intentionally. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/python-structures/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Lists and dictionaries: order and identity line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A seating position can change; a person identity does not change when they move seats.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: What does a list index represent? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A copied dictionary still shares nested mutable values unless you copy them intentionally. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does a list index represent?

Interview: What does a list index represent? Defend your answer using your actual lab result and this boundary: A copied dictionary still shares nested mutable values unless you copy them intentionally.

Quiz: What does a list index represent?

A durable database identity.

A position in that sequence.

A unique user permission.

Reference: A position in that sequence. — An index follows sequence order. Use stable identifiers when referring to records across changes.

Sources:

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Files and JSON: save and restore a small result

A saved file preserves data after the program stops. pathlib helps work with paths and json encodes simple data. Use a temporary directory while learning so the exercise cannot overwrite personal files.

How it works
Write UTF-8 text, read it with the same encoding and compare the decoded values. The temporary-directory context removes its own fixture on exit.

Where the model stops
A direct file write is not an atomic multi-writer database transaction. Corrupt or missing data needs an explicit recovery policy.

Make one change
Add malformed JSON and a missing-path case. Preserve the malformed text as evidence instead of silently replacing it with an empty file.

Mental model: A saved notebook must be opened and decoded before its pages become program values again.

Boundary: A direct file write is not an atomic multi-writer database transaction. Corrupt or missing data needs an explicit recovery policy.

Worked example: import json
from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory(prefix='skillbadi-') as folder:
 path=Path(folder)/'tasks.json'
 original=[{'id':1,'title':'చదువు'}]
 path.write_text(json.dumps(original,ensure_ascii=False),encoding='utf-8')
 restored=json.loads(path.read_text(encoding='utf-8'))
 assert restored==original
 print('PASS: UTF-8 JSON round trip')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/python-files. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add malformed JSON and a missing-path case. Preserve the malformed text as evidence instead of silently replacing it with an empty file.

Terminal folder: course-labs/beginner/python-files

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Write UTF-8 text, read it with the same encoding and compare the decoded values. The temporary-directory context removes its own fixture on exit.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/python-files. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The Telugu title survives the UTF-8 round trip. Your error cases distinguish decode failure from a missing file.

Build your change

Add malformed JSON and a missing-path case. Preserve the malformed text as evidence instead of silently replacing it with an empty file.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The Telugu title survives the UTF-8 round trip. Your error cases distinguish decode failure from a missing file.

Break, repair and explain

Deliberately violate this boundary: A direct file write is not an atomic multi-writer database transaction. Corrupt or missing data needs an explicit recovery policy. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The Telugu title survives the UTF-8 round trip. Your error cases distinguish decode failure from a missing file.

Troubleshoot: My result does not match Files and JSON: save and restore a small result: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Write UTF-8 text, read it with the same encoding and compare the decoded values. The temporary-directory context removes its own fixture on exit. Then inspect this limit: A direct file write is not an atomic multi-writer database transaction. Corrupt or missing data needs an explicit recovery policy. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/python-files/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Files and JSON: save and restore a small result line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A saved notebook must be opened and decoded before its pages become program values again.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Does valid JSON guarantee the task schema is correct? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A direct file write is not an atomic multi-writer database transaction. Corrupt or missing data needs an explicit recovery policy. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does valid JSON guarantee the task schema is correct?

Interview: Does valid JSON guarantee the task schema is correct? Defend your answer using your actual lab result and this boundary: A direct file write is not an atomic multi-writer database transaction. Corrupt or missing data needs an explicit recovery policy.

Quiz: Does valid JSON guarantee the task schema is correct?

No; validate the decoded structure too.

Yes.

Only when written by Python.

Reference: No; validate the decoded structure too. — JSON syntax and application schema are separate contracts. A valid JSON value may still have the wrong fields.

Sources:

Python: JSON encoding and decoding: https://docs.python.org/3/library/json.html

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. The practical workshop develops this into: Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: An intake clerk checks the label, the format and then whether the requested amount is allowed.

CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input.

Worked example: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Python Developer: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Predict the worked case

Read this case without running a tool: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain keys and constraints using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops.

Quiz: After the Typed CSV ingestion rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Typed CSV ingestion

CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input. In this role, work through: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. The practical workshop develops this into: Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

Mental model: An intake clerk checks the label, the format and then whether the requested amount is allowed.

Boundary: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.

Worked example: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Python Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

```
python3 pipeline.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Accepted total 30 and two distinct rejection reasons for c and d.

Role workshop · debug and verify

If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save validate_rows.py and a rejection CSV. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Accepted total 30 and two distinct rejection reasons for c and d.

Expected: Accepted total 30 and two distinct rejection reasons for c and d.

Troubleshoot: The role exercise differs from the prediction: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: validate_rows.py and a rejection CSV; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with typed csv ingestion. Use the glossary below, then write your prediction for: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain typed csv ingestion using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate typed csv ingestion to a system or workflow you know. Explain typed csv ingestion using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.

Interview: Explain typed csv ingestion using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Accepted total 30 and two distinct rejection reasons for c and d.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Accepted total 30 and two distinct rejection reasons for c and d. — CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input. Accepted total 30 and two distinct rejection reasons for c and d.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Python Developer: Use the concept to complete this role exercise: Refactor loading into functions with explicit error cases

CLI interfaces and tests: A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process.

### Mutable defaults and shared state

Default argument values are evaluated when a function is defined. A mutable default can accidentally retain changes between calls, causing unrelated users to share a list.

How it works
Use None to mean no list was supplied, then allocate inside the call. If callers supply a list, decide whether the function mutates that list or returns a copy; document the choice.

Where the model stops
A fresh outer list does not deeply copy nested objects. Be explicit about ownership at every mutable layer.

Make one change
Create the deliberately broken mutable-default version and demonstrate cross-call leakage. Restore the safe version and add an explicit-list test.

Mental model: A default notebook left on the desk gets reused by the next visitor.

Boundary: A fresh outer list does not deeply copy nested objects. Be explicit about ownership at every mutable layer.

Worked example: def append_title(title,titles=None):
 result=[] if titles is None else list(titles)
 result.append(title)
 return result
assert append_title('Read')==['Read']
assert append_title('Build')==['Build']
source=['Plan']
assert append_title('Read',source)==['Plan','Read']
assert source==['Plan']
print('PASS: independent calls and preserved caller list')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/python-defaults. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create the deliberately broken mutable-default version and demonstrate cross-call leakage. Restore the safe version and add an explicit-list test.

Terminal folder: course-labs/intermediate/python-defaults

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Use None to mean no list was supplied, then allocate inside the call. If callers supply a list, decide whether the function mutates that list or returns a copy; document the choice.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/python-defaults. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Separate calls do not share titles and the caller list is unchanged. Your failure evidence shows the broken version retaining state.

Build your change

Create the deliberately broken mutable-default version and demonstrate cross-call leakage. Restore the safe version and add an explicit-list test.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Separate calls do not share titles and the caller list is unchanged. Your failure evidence shows the broken version retaining state.

Break, repair and explain

Deliberately violate this boundary: A fresh outer list does not deeply copy nested objects. Be explicit about ownership at every mutable layer. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Separate calls do not share titles and the caller list is unchanged. Your failure evidence shows the broken version retaining state.

Troubleshoot: My result does not match Mutable defaults and shared state: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use None to mean no list was supplied, then allocate inside the call. If callers supply a list, decide whether the function mutates that list or returns a copy; document the choice. Then inspect this limit: A fresh outer list does not deeply copy nested objects. Be explicit about ownership at every mutable layer. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/python-defaults/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Mutable defaults and shared state line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A default notebook left on the desk gets reused by the next visitor.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: When is a function default list created? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A fresh outer list does not deeply copy nested objects. Be explicit about ownership at every mutable layer. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: When is a function default list created?

Interview: When is a function default list created? Defend your answer using your actual lab result and this boundary: A fresh outer list does not deeply copy nested objects. Be explicit about ownership at every mutable layer.

Quiz: When is a function default list created?

On every call.

Only when printed.

When the function definition is evaluated.

Reference: When the function definition is evaluated. — The same default object can be reused across calls. Allocate mutable per-call state inside the function.

Sources:

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Exceptions: recover without hiding defects

Catch the errors you expect and can interpret. A blanket exception handler can turn a programming defect into misleading empty data. Keep parsing failures distinct from valid empty results.

How it works
Catch JSONDecodeError for invalid JSON, then validate the decoded shape. Other I/O failures belong at the boundary that owns the file and can present a useful message.

Where the model stops
The example has no filesystem. A file adapter must separately handle access denied, missing paths and decoding errors.

Make one change
Validate each list entry as an object containing an integer id and a nonblank title. Report the failing index without exposing private record contents.

Mental model: A missing document and a blank document are different events at the records desk.

Boundary: The example has no filesystem. A file adapter must separately handle access denied, missing paths and decoding errors.

Worked example: import json
def parse_tasks(text):
 try:
  value=json.loads(text)
 except json.JSONDecodeError as error:
  return {'ok':False,'error':'Invalid JSON','line':error.lineno}
 if not isinstance(value,list):
  return {'ok':False,'error':'Expected task array'}
 return {'ok':True,'tasks':value}
assert parse_tasks('[]')=={'ok':True,'tasks':[]}
assert not parse_tasks('{')['ok']
assert parse_tasks('{}')['error']=='Expected task array'
print('PASS: empty, syntax error and schema error stay distinct')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/python-errors. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Validate each list entry as an object containing an integer id and a nonblank title. Report the failing index without exposing private record contents.

Terminal folder: course-labs/intermediate/python-errors

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Catch JSONDecodeError for invalid JSON, then validate the decoded shape. Other I/O failures belong at the boundary that owns the file and can present a useful message.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/python-errors. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: An empty array is valid, malformed syntax is an error and an object has the wrong shape. Your entry-level checks identify the failing position.

Build your change

Validate each list entry as an object containing an integer id and a nonblank title. Report the failing index without exposing private record contents.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. An empty array is valid, malformed syntax is an error and an object has the wrong shape. Your entry-level checks identify the failing position.

Break, repair and explain

Deliberately violate this boundary: The example has no filesystem. A file adapter must separately handle access denied, missing paths and decoding errors. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: An empty array is valid, malformed syntax is an error and an object has the wrong shape. Your entry-level checks identify the failing position.

Troubleshoot: My result does not match Exceptions: recover without hiding defects: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Catch JSONDecodeError for invalid JSON, then validate the decoded shape. Other I/O failures belong at the boundary that owns the file and can present a useful message. Then inspect this limit: The example has no filesystem. A file adapter must separately handle access denied, missing paths and decoding errors. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/python-errors/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Exceptions: recover without hiding defects line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A missing document and a blank document are different events at the records desk.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Why avoid returning [] for every exception? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The example has no filesystem. A file adapter must separately handle access denied, missing paths and decoding errors. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why avoid returning [] for every exception?

Interview: Why avoid returning [] for every exception? Defend your answer using your actual lab result and this boundary: The example has no filesystem. A file adapter must separately handle access denied, missing paths and decoding errors.

Quiz: Why avoid returning [] for every exception?

It can disguise a failed read as valid empty data.

It makes JSON larger.

It is illegal syntax.

Reference: It can disguise a failed read as valid empty data. — Recovery should not erase the distinction between no records and unavailable or corrupted records.

Sources:

Python: JSON encoding and decoding: https://docs.python.org/3/library/json.html

### Command-line tools: define a usable interface

A command-line tool is an interface for people and automation. argparse provides help text, named options and validation. A predictable exit outcome matters as much as a readable success message.

How it works
Define the option type, parse a supplied argument list in tests and validate business limits after parsing. argparse handles syntax and conversion, not every domain rule.

Where the model stops
Parsing arguments does not run the requested work or verify file permissions. Never log secret command-line values.

Make one change
Add an --output path option and a dry-run mode that prints the planned write without writing. Test that dry-run leaves a temporary directory unchanged.

Mental model: Command options are a labelled control panel rather than an unexplained positional puzzle.

Boundary: Parsing arguments does not run the requested work or verify file permissions. Never log secret command-line values.

Worked example: import argparse
parser=argparse.ArgumentParser(description='Plan one study session')
parser.add_argument('--minutes',type=int,default=25)
def parse(args):
 result=parser.parse_args(args)
 if not 1<=result.minutes<=180:
  raise ValueError('Minutes must be 1 to 180')
 return result
assert parse([]).minutes==25
assert parse(['--minutes','50']).minutes==50
try:
 parse(['--minutes','0'])
except ValueError:
 print('PASS: default, option and domain range')
else:
 raise AssertionError('Expected invalid range')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/python-cli. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add an --output path option and a dry-run mode that prints the planned write without writing. Test that dry-run leaves a temporary directory unchanged.

Terminal folder: course-labs/intermediate/python-cli

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Define the option type, parse a supplied argument list in tests and validate business limits after parsing. argparse handles syntax and conversion, not every domain rule.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/python-cli. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The default is 25, an explicit 50 is accepted and 0 is rejected. Your dry-run has a test proving no file was created.

Build your change

Add an --output path option and a dry-run mode that prints the planned write without writing. Test that dry-run leaves a temporary directory unchanged.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The default is 25, an explicit 50 is accepted and 0 is rejected. Your dry-run has a test proving no file was created.

Break, repair and explain

Deliberately violate this boundary: Parsing arguments does not run the requested work or verify file permissions. Never log secret command-line values. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The default is 25, an explicit 50 is accepted and 0 is rejected. Your dry-run has a test proving no file was created.

Troubleshoot: My result does not match Command-line tools: define a usable interface: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Define the option type, parse a supplied argument list in tests and validate business limits after parsing. argparse handles syntax and conversion, not every domain rule. Then inspect this limit: Parsing arguments does not run the requested work or verify file permissions. Never log secret command-line values. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/python-cli/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Command-line tools: define a usable interface line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Command options are a labelled control panel rather than an unexplained positional puzzle.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: What does type=int in argparse establish? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Parsing arguments does not run the requested work or verify file permissions. Never log secret command-line values. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does type=int in argparse establish?

Interview: What does type=int in argparse establish? Defend your answer using your actual lab result and this boundary: Parsing arguments does not run the requested work or verify file permissions. Never log secret command-line values.

Quiz: What does type=int in argparse establish?

All business limits are valid.

The argument can be converted to an integer.

The output file is writable.

Reference: The argument can be converted to an integer. — Conversion and business validation are different checks. Range and resource access need their own rules.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

### Unit tests: verify an error path

A regression test preserves a behaviour that previously failed. Use the standard unittest module to express independent cases and helpful failures. Check a rejected input as well as a successful result.

How it works
Test methods start with test and use assertion helpers. assertRaises verifies the intended exception. Calling the runner with exit=False lets this standalone lesson report its own result clearly.

Where the model stops
A unit test of one function does not prove file, network or deployment behaviour.

Make one change
Add tests for None and an already-clean string. Deliberately remove blank validation and record the failing error-path test before restoring the code.

Mental model: A test is a repeatable experiment with a stated expected observation.

Boundary: A unit test of one function does not prove file, network or deployment behaviour.

Worked example: import unittest
def normalise(title):
 if not isinstance(title,str) or not title.strip():
  raise ValueError('Title required')
 return title.strip()
class TitlesTest(unittest.TestCase):
 def test_trim(self): self.assertEqual(normalise(' Read '),'Read')
 def test_blank(self):
  with self.assertRaises(ValueError): normalise(' ')
result=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(TitlesTest))
if not result.wasSuccessful(): raise SystemExit(1)


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/python-tests. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add tests for None and an already-clean string. Deliberately remove blank validation and record the failing error-path test before restoring the code.

Terminal folder: course-labs/intermediate/python-tests

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Test methods start with test and use assertion helpers. assertRaises verifies the intended exception. Calling the runner with exit=False lets this standalone lesson report its own result clearly.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/python-tests. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Two reference tests pass and the script exits unsuccessfully if any test fails. Your deliberate mutation is caught.

Build your change

Add tests for None and an already-clean string. Deliberately remove blank validation and record the failing error-path test before restoring the code.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Two reference tests pass and the script exits unsuccessfully if any test fails. Your deliberate mutation is caught.

Break, repair and explain

Deliberately violate this boundary: A unit test of one function does not prove file, network or deployment behaviour. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Two reference tests pass and the script exits unsuccessfully if any test fails. Your deliberate mutation is caught.

Troubleshoot: My result does not match Unit tests: verify an error path: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Test methods start with test and use assertion helpers. assertRaises verifies the intended exception. Calling the runner with exit=False lets this standalone lesson report its own result clearly. Then inspect this limit: A unit test of one function does not prove file, network or deployment behaviour. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/python-tests/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Unit tests: verify an error path line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A test is a repeatable experiment with a stated expected observation.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: What does assertRaises check? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A unit test of one function does not prove file, network or deployment behaviour. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does assertRaises check?

Interview: What does assertRaises check? Defend your answer using your actual lab result and this boundary: A unit test of one function does not prove file, network or deployment behaviour.

Quiz: What does assertRaises check?

That any output was printed.

That the file has a .py extension.

That the specified operation raises the expected exception.

Reference: That the specified operation raises the expected exception. — An error-path assertion checks behaviour rather than just the absence of a crash.

Sources:

Python: unittest: https://docs.python.org/3/library/unittest.html

### SQLite: parameterised reads and writes

A relational database stores structured rows and enforces declared constraints. Python sqlite3 is included with normal Python installations and is useful for a small local lab without a paid service.

How it works
Use a primary key for task identity and a bound value for lookup. Commit when a later connection must see a write. Close the connection you opened.

Where the model stops
An in-memory database disappears when closed. SQLite concurrency and deployment constraints differ from a managed server database.

Make one change
Add a UNIQUE title rule, insert a duplicate and inspect IntegrityError. Document whether the API should return a conflict or treat a replay as the same operation.

Mental model: SQL describes which records are needed; parameters carry the values separately.

Boundary: An in-memory database disappears when closed. SQLite concurrency and deployment constraints differ from a managed server database.

Worked example: import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.execute('create table tasks(id integer primary key,title text not null)')
 with con:
  con.execute('insert into tasks values(?,?)',(1,"Read SQL's guide"))
 row=con.execute('select title from tasks where id=?',(1,)).fetchone()
 assert row==("Read SQL's guide",)
 assert con.execute('select title from tasks where id=?',(99,)).fetchone() is None
 print('PASS: quoted value and absent row')
finally:
 con.close()


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/python-sql. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a UNIQUE title rule, insert a duplicate and inspect IntegrityError. Document whether the API should return a conflict or treat a replay as the same operation.

Terminal folder: course-labs/intermediate/python-sql

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Use a primary key for task identity and a bound value for lookup. Commit when a later connection must see a write. Close the connection you opened.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/python-sql. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The apostrophe round trips correctly and a missing id yields None. Your duplicate is handled deliberately.

Build your change

Add a UNIQUE title rule, insert a duplicate and inspect IntegrityError. Document whether the API should return a conflict or treat a replay as the same operation.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The apostrophe round trips correctly and a missing id yields None. Your duplicate is handled deliberately.

Break, repair and explain

Deliberately violate this boundary: An in-memory database disappears when closed. SQLite concurrency and deployment constraints differ from a managed server database. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The apostrophe round trips correctly and a missing id yields None. Your duplicate is handled deliberately.

Troubleshoot: My result does not match SQLite: parameterised reads and writes: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use a primary key for task identity and a bound value for lookup. Commit when a later connection must see a write. Close the connection you opened. Then inspect this limit: An in-memory database disappears when closed. SQLite concurrency and deployment constraints differ from a managed server database. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/python-sql/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace SQLite: parameterised reads and writes line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: SQL describes which records are needed; parameters carry the values separately.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Why pass the id separately from the SQL string? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An in-memory database disappears when closed. SQLite concurrency and deployment constraints differ from a managed server database. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why pass the id separately from the SQL string?

Interview: Why pass the id separately from the SQL string? Defend your answer using your actual lab result and this boundary: An in-memory database disappears when closed. SQLite concurrency and deployment constraints differ from a managed server database.

Quiz: Why pass the id separately from the SQL string?

To bind it as a value rather than query syntax.

To force a network call.

To remove all permissions.

Reference: To bind it as a value rather than query syntax. — Parameters keep values distinct from SQL instructions. Permissions and schema constraints remain necessary.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. The practical workshop develops this into: Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: The command line is a public form for other programs as well as humans.

A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process.

Worked example: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Python Developer: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Predict the worked case

Read this case without running a tool: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain idempotent processing using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops.

Quiz: After the CLI interfaces and tests rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### CLI interfaces and tests

A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process. In this role, work through: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. The practical workshop develops this into: Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

Mental model: The command line is a public form for other programs as well as humans.

Boundary: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.

Worked example: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Python Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

--input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

```
python3 -m unittest discover
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Role workshop · debug and verify

If importing the module runs the load, place CLI execution under if __name__ == '__main__'. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save CLI source, unittest suite and captured exit codes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Troubleshoot: The role exercise differs from the prediction: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: CLI source, unittest suite and captured exit codes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cli interfaces and tests. Use the glossary below, then write your prediction for: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain cli interfaces and tests using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cli interfaces and tests to a system or workflow you know. Explain cli interfaces and tests using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.

Interview: Explain cli interfaces and tests using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Ignore the failing case and keep only the successful screenshot.

Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Treat any successful command as proof that all business and access rules passed.

Reference: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass. — A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process. Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Python Developer: Use the concept to complete this role exercise: Package the command-line tool and document transaction recovery

Transactions and packaging: Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work.

### Async I/O: concurrency is not automatic parallelism

async def creates a coroutine function. Calling it produces a coroutine object; awaiting it or scheduling a task performs the work. Async I/O allows other work to progress during cooperative waits.

How it works
gather waits for multiple awaitables and returns results in input order. asyncio.sleep yields control. A blocking CPU loop or synchronous I/O inside the event loop still blocks other tasks.

Where the model stops
This local timing-free check establishes results and scheduling semantics, not throughput or latency performance.

Make one change
Add one failing coroutine and inspect gather behaviour without claiming it automatically cancels every sibling. Design a bounded concurrency policy for 100 requests.

Mental model: One cook can prepare another dish while the first simmers; that is not two cooks doing CPU work simultaneously.

Boundary: This local timing-free check establishes results and scheduling semantics, not throughput or latency performance.

Worked example: import asyncio
async def fetch_name(name):
 await asyncio.sleep(0)
 return name.upper()
async def main():
 result=await asyncio.gather(fetch_name('read'),fetch_name('build'))
 assert result==['READ','BUILD']
 print('PASS: scheduled coroutines return ordered results')
asyncio.run(main())


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/python-async. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add one failing coroutine and inspect gather behaviour without claiming it automatically cancels every sibling. Design a bounded concurrency policy for 100 requests.

Terminal folder: course-labs/advanced/python-async

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. gather waits for multiple awaitables and returns results in input order. asyncio.sleep yields control. A blocking CPU loop or synchronous I/O inside the event loop still blocks other tasks.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/python-async. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Both awaitables produce the ordered result. Your failure experiment documents sibling lifecycle and how outstanding tasks are cleaned up.

Build your change

Add one failing coroutine and inspect gather behaviour without claiming it automatically cancels every sibling. Design a bounded concurrency policy for 100 requests.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Both awaitables produce the ordered result. Your failure experiment documents sibling lifecycle and how outstanding tasks are cleaned up.

Break, repair and explain

Deliberately violate this boundary: This local timing-free check establishes results and scheduling semantics, not throughput or latency performance. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Both awaitables produce the ordered result. Your failure experiment documents sibling lifecycle and how outstanding tasks are cleaned up.

Troubleshoot: My result does not match Async I/O: concurrency is not automatic parallelism: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: gather waits for multiple awaitables and returns results in input order. asyncio.sleep yields control. A blocking CPU loop or synchronous I/O inside the event loop still blocks other tasks. Then inspect this limit: This local timing-free check establishes results and scheduling semantics, not throughput or latency performance. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/python-async/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Async I/O: concurrency is not automatic parallelism line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: One cook can prepare another dish while the first simmers; that is not two cooks doing CPU work simultaneously.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Does async automatically make a CPU-heavy Python loop nonblocking? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This local timing-free check establishes results and scheduling semantics, not throughput or latency performance. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does async automatically make a CPU-heavy Python loop nonblocking?

Interview: Does async automatically make a CPU-heavy Python loop nonblocking? Defend your answer using your actual lab result and this boundary: This local timing-free check establishes results and scheduling semantics, not throughput or latency performance.

Quiz: Does async automatically make a CPU-heavy Python loop nonblocking?

Yes.

No, it must yield or be moved to a suitable execution boundary.

Only when the function name contains fetch.

Reference: No, it must yield or be moved to a suitable execution boundary. — Async execution is cooperative. CPU work can block the event loop unless deliberately isolated.

Sources:

Python: asyncio tasks, cancellation and timeouts: https://docs.python.org/3/library/asyncio-task.html

### Timeouts and cleanup in async tasks

A deadline limits how long a caller waits. asyncio.wait_for cancels its awaited task on timeout and waits for that cancellation to finish. Cleanup belongs in finally so it runs on cancellation too.

How it works
The test uses a never-completing Event and records cleanup in finally. TimeoutError is the caller signal; the cleanup record is separate evidence of the worker lifecycle.

Where the model stops
Code can delay or suppress cancellation. A timeout is not proof that an external write was reversed.

Make one change
Add a completed-before-deadline case and preserve cleanup in both paths. Explain how a remote write would be reconciled after an unknown timeout outcome.

Mental model: A stop request needs a cleanup checklist before the work is considered stopped.

Boundary: Code can delay or suppress cancellation. A timeout is not proof that an external write was reversed.

Worked example: import asyncio
async def main():
 cleaned=[]
 async def worker():
  try:
   await asyncio.Event().wait()
  finally:
   cleaned.append('closed')
 try:
  await asyncio.wait_for(worker(),timeout=0.01)
 except asyncio.TimeoutError:
  pass
 assert cleaned==['closed']
 print('PASS: timeout triggers cooperative cleanup')
asyncio.run(main())


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/python-timeout. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a completed-before-deadline case and preserve cleanup in both paths. Explain how a remote write would be reconciled after an unknown timeout outcome.

Terminal folder: course-labs/advanced/python-timeout

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The test uses a never-completing Event and records cleanup in finally. TimeoutError is the caller signal; the cleanup record is separate evidence of the worker lifecycle.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/python-timeout. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The timeout path records cleanup exactly once. Your normal path also releases its resource.

Build your change

Add a completed-before-deadline case and preserve cleanup in both paths. Explain how a remote write would be reconciled after an unknown timeout outcome.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The timeout path records cleanup exactly once. Your normal path also releases its resource.

Break, repair and explain

Deliberately violate this boundary: Code can delay or suppress cancellation. A timeout is not proof that an external write was reversed. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The timeout path records cleanup exactly once. Your normal path also releases its resource.

Troubleshoot: My result does not match Timeouts and cleanup in async tasks: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The test uses a never-completing Event and records cleanup in finally. TimeoutError is the caller signal; the cleanup record is separate evidence of the worker lifecycle. Then inspect this limit: Code can delay or suppress cancellation. A timeout is not proof that an external write was reversed. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/python-timeout/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Timeouts and cleanup in async tasks line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A stop request needs a cleanup checklist before the work is considered stopped.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Should a coroutine swallow cancellation and keep doing indefinite work? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Code can delay or suppress cancellation. A timeout is not proof that an external write was reversed. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Should a coroutine swallow cancellation and keep doing indefinite work?

Interview: Should a coroutine swallow cancellation and keep doing indefinite work? Defend your answer using your actual lab result and this boundary: Code can delay or suppress cancellation. A timeout is not proof that an external write was reversed.

Quiz: Should a coroutine swallow cancellation and keep doing indefinite work?

Yes, to appear reliable.

Only if it prints a warning.

No, cancellation must be handled deliberately and normally propagated.

Reference: No, cancellation must be handled deliberately and normally propagated. — Cleanup should run, then cancellation should retain its meaning unless the API has a carefully documented alternative.

Sources:

Python: asyncio tasks, cancellation and timeouts: https://docs.python.org/3/library/asyncio-task.html

### Generators: process data with bounded memory

A generator produces values on demand. It can process a large input incrementally instead of building a second complete list. The caller controls how far the generator is consumed.

How it works
yield pauses the function while preserving its local state. The source must also be streamed to achieve bounded memory; wrapping an already-loaded huge list does not undo its cost.

Where the model stops
A generator is generally single-use and may hold an open resource until closed or exhausted. Define resource ownership.

Make one change
Read a temporary text file line by line and stop after the first accepted item. Ensure the file context closes even when consumption stops early.

Mental model: A tap provides one cup at a time instead of filling the whole room with water.

Boundary: A generator is generally single-use and may hold an open resource until closed or exhausted. Define resource ownership.

Worked example: def nonblank(lines):
 for line in lines:
  value=line.strip()
  if value:
   yield value
source=iter([' Read\n',' \n','Build\n'])
values=nonblank(source)
assert next(values)=='Read'
assert list(values)==['Build']
assert list(values)==[]
print('PASS: incremental consumption and exhaustion')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/python-streaming. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Read a temporary text file line by line and stop after the first accepted item. Ensure the file context closes even when consumption stops early.

Terminal folder: course-labs/advanced/python-streaming

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. yield pauses the function while preserving its local state. The source must also be streamed to achieve bounded memory; wrapping an already-loaded huge list does not undo its cost.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/python-streaming. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The first call consumes Read, the remaining iteration consumes Build and the exhausted generator returns no values.

Build your change

Read a temporary text file line by line and stop after the first accepted item. Ensure the file context closes even when consumption stops early.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The first call consumes Read, the remaining iteration consumes Build and the exhausted generator returns no values.

Break, repair and explain

Deliberately violate this boundary: A generator is generally single-use and may hold an open resource until closed or exhausted. Define resource ownership. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The first call consumes Read, the remaining iteration consumes Build and the exhausted generator returns no values.

Troubleshoot: My result does not match Generators: process data with bounded memory: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: yield pauses the function while preserving its local state. The source must also be streamed to achieve bounded memory; wrapping an already-loaded huge list does not undo its cost. Then inspect this limit: A generator is generally single-use and may hold an open resource until closed or exhausted. Define resource ownership. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/python-streaming/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Generators: process data with bounded memory line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A tap provides one cup at a time instead of filling the whole room with water.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Does a generator automatically make an already-loaded list disappear from memory? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A generator is generally single-use and may hold an open resource until closed or exhausted. Define resource ownership. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does a generator automatically make an already-loaded list disappear from memory?

Interview: Does a generator automatically make an already-loaded list disappear from memory? Defend your answer using your actual lab result and this boundary: A generator is generally single-use and may hold an open resource until closed or exhausted. Define resource ownership.

Quiz: Does a generator automatically make an already-loaded list disappear from memory?

No.

Yes.

Only if named stream.

Reference: No. — Memory use depends on the entire data path. Stream the source and avoid retaining all outputs if bounded memory is the goal.

Sources:

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Caching: choose immutable keys and expiry

A cache trades freshness for less repeated work. Its key must capture the inputs that affect the result. Its expiry rule must be tested at the exact boundary.

How it works
The tuple key includes tenant and task id. An injected clock makes expiry reproducible. An entry is valid only strictly before its expires value.

Where the model stops
This dictionary has no memory bound or cross-process coordination. A production cache needs eviction, invalidation and access-control design.

Make one change
Add a maximum size and an intentional eviction policy. Test invalidation after a write and explain why two worker processes would not share this dictionary.

Mental model: A dated lookup card is only valid for the same question until its expiry time.

Boundary: This dictionary has no memory bound or cross-process coordination. A production cache needs eviction, invalidation and access-control design.

Worked example: cache={}
def put(tenant,task,value,now): cache[(tenant,task)]=(value,now+60)
def get(tenant,task,now):
 entry=cache.get((tenant,task))
 return entry[0] if entry and now<entry[1] else None
put('a',1,'Private',0)
assert get('a',1,59)=='Private'
assert get('a',1,60) is None
assert get('b',1,1) is None
print('PASS: key isolation and exact expiry')


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/python-cache. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a maximum size and an intentional eviction policy. Test invalidation after a write and explain why two worker processes would not share this dictionary.

Terminal folder: course-labs/advanced/python-cache

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The tuple key includes tenant and task id. An injected clock makes expiry reproducible. An entry is valid only strictly before its expires value.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/python-cache. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Expiry and tenant isolation checks pass. Your design distinguishes local cache limits from durable storage guarantees.

Build your change

Add a maximum size and an intentional eviction policy. Test invalidation after a write and explain why two worker processes would not share this dictionary.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Expiry and tenant isolation checks pass. Your design distinguishes local cache limits from durable storage guarantees.

Break, repair and explain

Deliberately violate this boundary: This dictionary has no memory bound or cross-process coordination. A production cache needs eviction, invalidation and access-control design. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Expiry and tenant isolation checks pass. Your design distinguishes local cache limits from durable storage guarantees.

Troubleshoot: My result does not match Caching: choose immutable keys and expiry: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The tuple key includes tenant and task id. An injected clock makes expiry reproducible. An entry is valid only strictly before its expires value. Then inspect this limit: This dictionary has no memory bound or cross-process coordination. A production cache needs eviction, invalidation and access-control design. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/python-cache/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Caching: choose immutable keys and expiry line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A dated lookup card is only valid for the same question until its expiry time.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Which key detail prevents tenant b reading tenant a cached task? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This dictionary has no memory bound or cross-process coordination. A production cache needs eviction, invalidation and access-control design. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which key detail prevents tenant b reading tenant a cached task?

Interview: Which key detail prevents tenant b reading tenant a cached task? Defend your answer using your actual lab result and this boundary: This dictionary has no memory bound or cross-process coordination. A production cache needs eviction, invalidation and access-control design.

Quiz: Which key detail prevents tenant b reading tenant a cached task?

The timestamp alone.

The tenant component of the key.

The spelling of cache.

Reference: The tenant component of the key. — The cache identity must include the data isolation boundary; permission checks remain required as well.

Sources:

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Structured logs: record useful, safe evidence

A structured log has named fields that can be searched and correlated. Choose an allowlist rather than copying an entire request, because request objects may contain secrets and private data.

How it works
Build a small public operational event from trusted fields. Use request id for correlation and an event category for analysis. Test that the serialised output omits known sensitive inputs.

Where the model stops
An allowlist reduces accidental disclosure but cannot guarantee every selected value is safe. Apply retention and access rules to the log store.

Make one change
Add a duration measurement and define its unit. Test that no title, email or bearer token is included, then write an incident note using only the request id and safe outcome fields.

Mental model: An incident receipt records the reference number and outcome, not the customer password.

Boundary: An allowlist reduces accidental disclosure but cannot guarantee every selected value is safe. Apply retention and access rules to the log store.

Worked example: import json
def event(request):
 return {'event':'task.read','request_id':request['request_id'],'status':request['status']}
source={'request_id':'req-7','status':200,'password':'never-log','token':'secret'}
encoded=json.dumps(event(source),sort_keys=True)
assert 'never-log' not in encoded and 'secret' not in encoded
assert json.loads(encoded)['request_id']=='req-7'
print(encoded)


Setup: Download and extract python-developer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/python-logging. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3.9+ standard library and a text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a duration measurement and define its unit. Test that no title, email or bearer token is included, then write an incident note using only the request id and safe outcome fields.

Terminal folder: course-labs/advanced/python-logging

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Build a small public operational event from trusted fields. Use request id for correlation and an event category for analysis. Test that the serialised output omits known sensitive inputs.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/python-logging. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The JSON event has event, request_id and status without password or token. Your expanded event keeps the same explicit privacy boundary.

Build your change

Add a duration measurement and define its unit. Test that no title, email or bearer token is included, then write an incident note using only the request id and safe outcome fields.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The JSON event has event, request_id and status without password or token. Your expanded event keeps the same explicit privacy boundary.

Break, repair and explain

Deliberately violate this boundary: An allowlist reduces accidental disclosure but cannot guarantee every selected value is safe. Apply retention and access rules to the log store. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The JSON event has event, request_id and status without password or token. Your expanded event keeps the same explicit privacy boundary.

Troubleshoot: My result does not match Structured logs: record useful, safe evidence: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Build a small public operational event from trusted fields. Use request id for correlation and an event category for analysis. Test that the serialised output omits known sensitive inputs. Then inspect this limit: An allowlist reduces accidental disclosure but cannot guarantee every selected value is safe. Apply retention and access rules to the log store. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/python-logging/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Structured logs: record useful, safe evidence line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An incident receipt records the reference number and outcome, not the customer password.

seeker: Prepare a coursework example for Python Developer. Answer this interview question before revealing the rubric: Which logging approach is safer by default? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An allowlist reduces accidental disclosure but cannot guarantee every selected value is safe. Apply retention and access rules to the log store. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which logging approach is safer by default?

Interview: Which logging approach is safer by default? Defend your answer using your actual lab result and this boundary: An allowlist reduces accidental disclosure but cannot guarantee every selected value is safe. Apply retention and access rules to the log store.

Quiz: Which logging approach is safer by default?

Serialise the whole request.

Log all headers for convenience.

Construct a small allowlisted event.

Reference: Construct a small allowlisted event. — Minimising fields reduces disclosure risk and improves the usefulness of the record. Review the values as well as field names.

Sources:

OWASP: logging guidance: https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. The practical workshop develops this into: Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: A sealed batch is either accepted as a whole or split into explicitly recorded parcels.

Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work.

Worked example: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Python Developer: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Predict the worked case

Read this case without running a tool: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain transaction and recovery using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops.

Quiz: After the Transactions and packaging rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Transactions and packaging

Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work. In this role, work through: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. The practical workshop develops this into: Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

Mental model: A sealed batch is either accepted as a whole or split into explicitly recorded parcels.

Boundary: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.

Worked example: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Python Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

```
python3 -m unittest discover
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Role workshop · debug and verify

An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save installable CLI project, rollback test and supported-Python notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Troubleshoot: The role exercise differs from the prediction: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: installable CLI project, rollback test and supported-Python notes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactions and packaging. Use the glossary below, then write your prediction for: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain transactions and packaging using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactions and packaging to a system or workflow you know. Explain transactions and packaging using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.

Interview: Explain transactions and packaging using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Reference: Failed batch commits zero records; retry commits two; clean-environment setup is documented. — Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work. Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
