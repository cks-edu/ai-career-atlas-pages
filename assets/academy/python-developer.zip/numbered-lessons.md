# Python Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Python Developer: Use the concept to complete this role exercise: Read a CSV and validate typed fields

Typed CSV ingestion: CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. The practical workshop develops this into: Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: An intake clerk checks the label, the format and then whether the requested amount is allowed.

CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input.

Worked example: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Python Developer: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Predict the worked case

Read this case without running a tool: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain keys and constraints using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops.

Quiz: After the Typed CSV ingestion rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Typed CSV ingestion

CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input. In this role, work through: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. The practical workshop develops this into: Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

Mental model: An intake clerk checks the label, the format and then whether the requested amount is allowed.

Boundary: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.

Worked example: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Python Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Copy pipeline.py and move row validation into a function returning either a normalized record or a structured error. Add d,ten without letting ValueError terminate the batch.

```
python3 pipeline.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Accepted total 30 and two distinct rejection reasons for c and d.

Role workshop · debug and verify

If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save validate_rows.py and a rejection CSV. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Accepted total 30 and two distinct rejection reasons for c and d.

Expected: Accepted total 30 and two distinct rejection reasons for c and d.

Troubleshoot: The role exercise differs from the prediction: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: validate_rows.py and a rejection CSV; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with typed csv ingestion. Use the glossary below, then write your prediction for: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain typed csv ingestion using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate typed csv ingestion to a system or workflow you know. Explain typed csv ingestion using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the batch stops on d, catch conversion errors at the row boundary rather than ignoring the whole file.

Interview: Explain typed csv ingestion using this case: Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Rows a,10 and b,20 pass; c,-5 fails the amount rule; d,ten fails conversion.

Accepted total 30 and two distinct rejection reasons for c and d.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Accepted total 30 and two distinct rejection reasons for c and d. — CSV supplies strings, not trusted numbers. Parse fields deliberately and separate missing IDs, bad numeric syntax and business-rule failures so callers can repair the input. Accepted total 30 and two distinct rejection reasons for c and d.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Python Developer: Use the concept to complete this role exercise: Refactor loading into functions with explicit error cases

CLI interfaces and tests: A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. The practical workshop develops this into: Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: The command line is a public form for other programs as well as humans.

A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process.

Worked example: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Python Developer: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Predict the worked case

Read this case without running a tool: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain idempotent processing using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops.

Quiz: After the CLI interfaces and tests rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### CLI interfaces and tests

A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process. In this role, work through: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. The practical workshop develops this into: Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

Mental model: The command line is a public form for other programs as well as humans.

Boundary: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.

Worked example: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Python Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

--input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add argparse input/output arguments to your loader. Use pathlib for files, unittest for valid/invalid rows and a temporary directory for output. Run --help before the success and failure cases.

```
python3 -m unittest discover
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Role workshop · debug and verify

If importing the module runs the load, place CLI execution under if __name__ == '__main__'. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save CLI source, unittest suite and captured exit codes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Expected: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Troubleshoot: The role exercise differs from the prediction: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: CLI source, unittest suite and captured exit codes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cli interfaces and tests. Use the glossary below, then write your prediction for: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain cli interfaces and tests using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cli interfaces and tests to a system or workflow you know. Explain cli interfaces and tests using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If importing the module runs the load, place CLI execution under if __name__ == '__main__'.

Interview: Explain cli interfaces and tests using this case: --input missing.csv should report a readable error and nonzero exit; a valid file should write a result. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? --input missing.csv should report a readable error and nonzero exit; a valid file should write a result.

Ignore the failing case and keep only the successful screenshot.

Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Treat any successful command as proof that all business and access rules passed.

Reference: Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass. — A command-line program needs predictable arguments, exit status and output destinations. Keep parsing separate from transformation so tests can call the core without starting another process. Help describes arguments; missing input fails without a traceback dump of unrelated state; valid tests pass.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Python Developer: Use the concept to complete this role exercise: Package the command-line tool and document transaction recovery

Transactions and packaging: Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. The practical workshop develops this into: Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: A sealed batch is either accepted as a whole or split into explicitly recorded parcels.

Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work.

Worked example: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Python Developer: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Predict the worked case

Read this case without running a tool: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain transaction and recovery using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops.

Quiz: After the Transactions and packaging rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Transactions and packaging

Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work. In this role, work through: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. The practical workshop develops this into: Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

Mental model: A sealed batch is either accepted as a whole or split into explicitly recorded parcels.

Boundary: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.

Worked example: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python and sqlite3 (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Python Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Move your loader into a package, add a pyproject.toml, and use a temporary SQLite database in tests. Inject an exception inside a transaction, verify rollback, then rerun the original file successfully.

```
python3 -m unittest discover
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Role workshop · debug and verify

An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save installable CLI project, rollback test and supported-Python notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Expected: Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Troubleshoot: The role exercise differs from the prediction: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: installable CLI project, rollback test and supported-Python notes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactions and packaging. Use the glossary below, then write your prediction for: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Python Developer role interview. Explain transactions and packaging using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactions and packaging to a system or workflow you know. Explain transactions and packaging using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: An early commit inside the row loop defeats batch rollback. Inspect transaction ownership before adding retry logic.

Interview: Explain transactions and packaging using this case: Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Inject failure after inserting a but before b; an all-or-nothing batch leaves zero rows.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Reference: Failed batch commits zero records; retry commits two; clean-environment setup is documented. — Package reusable code with an explicit entry point and dependency declaration. A failure halfway through a batch must follow the chosen transaction policy rather than accidentally committing partial work. Failed batch commits zero records; retry commits two; clean-environment setup is documented.

Sources:

Python: argparse reference: https://docs.python.org/3/library/argparse.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
