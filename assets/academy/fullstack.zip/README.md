# Full-stack Developer

Software Engineering

Start with trace a vertical slice. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward compatibility-matrix.md and a versioned deployment rehearsal.

## beginner

Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Request and response
A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.
Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.
Recall: Draw the request and response for adding one task.

### Trace a vertical slice
A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation.
Mental model: Follow one parcel through every desk until its receipt matches the original order.
Limit: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.
Example: Create Task A in the browser and match its returned ID to GET /api/tasks.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Create Task A in the browser and match its returned ID to GET /api/tasks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.
```
node app.mjs
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One ID and one title match across all five boundaries.

6. Role workshop · debug and verify
A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save vertical-slice.md with a sequence diagram and redacted HTTP examples. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One ID and one title match across all five boundaries.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Trace a vertical slice: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: vertical-slice.md with a sequence diagram and redacted HTTP examples
One ID and one title match across all five boundaries.

Interview: Work through this Full-stack Developer case: Create Task A in the browser and match its returned ID to GET /api/tasks. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation. Expected evidence: One ID and one title match across all five boundaries. Diagnosis: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance. State the limits of the mental model: Follow one parcel through every desk until its receipt matches the original order.

Resume: Built vertical-slice.md with a sequence diagram and redacted HTTP examples using Node.js; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Validation at a boundary
Check input before storing or using it. Client checks help people; the server must also enforce the rule.
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.
Example: A blank title receives 400 and does not change task count.
Recall: Why must the server reject invalid input even if the form already checks it?

### Storage adapter contract
Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details.
Mental model: Replace a filing cabinet while keeping the front desk request form unchanged.
Limit: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.
Example: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.
```
node app.mjs test intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

6. Role workshop · debug and verify
If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save storage-adapter code, restart transcript and adapter contract tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Storage adapter contract: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: storage-adapter code, restart transcript and adapter contract tests
Task A survives restart; invalid titles never reach storage; tests isolate their files.

Interview: Work through this Full-stack Developer case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details. Expected evidence: Task A survives restart; invalid titles never reach storage; tests isolate their files. Diagnosis: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one. State the limits of the mental model: Replace a filing cabinet while keeping the front desk request form unchanged.

Resume: Built storage-adapter code, restart transcript and adapter contract tests using Node.js; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State and recovery
State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.
Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database.
Recall: Name two things required before calling this service production ready.

### Compatible feature rollout
Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning.
Mental model: Two editions of a form must be accepted while offices replace their stationery.
Limit: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.
Example: Add optional priority with a default while an older browser still sends only title.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Add optional priority with a default while an older browser still sends only title. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.
```
node app.mjs test advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

6. Role workshop · debug and verify
A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save compatibility-matrix.md and a versioned deployment rehearsal. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Compatible feature rollout: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: compatibility-matrix.md and a versioned deployment rehearsal
Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Interview: Work through this Full-stack Developer case: Add optional priority with a default while an older browser still sends only title. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning. Expected evidence: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand. Diagnosis: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout. State the limits of the mental model: Two editions of a form must be accepted while offices replace their stationery.

Resume: Built compatibility-matrix.md and a versioned deployment rehearsal using Node.js; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
