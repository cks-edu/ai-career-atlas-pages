import assert from 'node:assert/strict';
const required=['create','invalid-input','owner-denial','conflict','recovery'];
const gate = report => required.every(name=>report[name] === true);
const report=Object.fromEntries(required.map(name=>[name,true]));
assert.equal(gate(report),true);
assert.equal(gate({...report,recovery:false}),false);
assert.equal(gate({create:true}),false);
console.log('PASS: complete, failing and incomplete report');
