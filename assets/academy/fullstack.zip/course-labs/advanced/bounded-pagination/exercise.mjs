import assert from 'node:assert/strict';
const tasks=[1,2,3,4,5].map(id=>({id}));
function page(after=0,limit=2) {
  const size = Math.min(3,Math.max(1,Number.isInteger(limit)?limit:2));
  return tasks.filter(t=>t.id>after).sort((a,b)=>a.id-b.id).slice(0,size);
}
assert.deepEqual(page(2,2).map(t=>t.id),[3,4]);
assert.equal(page(0,1000).length,3);
console.log('PASS: cursor order and capped response');
