import assert from 'node:assert/strict';
let record = {id:1,title:'Draft',version:1};
function update(expected, title) {
  if (record.version !== expected) return {status:409};
  record = {...record,title,version:record.version+1}; return {status:200};
}
assert.equal(update(1,'First edit').status,200);
assert.equal(update(1,'Stale edit').status,409);
assert.equal(record.title,'First edit');
console.log('PASS: stale write rejected');
