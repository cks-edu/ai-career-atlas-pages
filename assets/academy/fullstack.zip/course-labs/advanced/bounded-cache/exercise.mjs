import assert from 'node:assert/strict';
const cache = new Map();
const key = (tenant,id) => JSON.stringify([tenant,id]);
function put(tenant,id,value,now) { cache.set(key(tenant,id),{value,expires:now+1000}); }
function get(tenant,id,now) { const e=cache.get(key(tenant,id)); return e && now<e.expires ? e.value : undefined; }
put('a',1,'Private A',0);
assert.equal(get('a',1,999),'Private A');
assert.equal(get('a',1,1000),undefined);
assert.equal(get('b',1,1),undefined);
console.log('PASS: expiry and tenant isolation');
