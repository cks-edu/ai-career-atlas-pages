import assert from 'node:assert/strict';
let generation = 0, shown = '';
function begin() { const mine = ++generation; return value => { if (mine === generation) shown = value; }; }
const old = begin(); const recent = begin();
recent('new search'); old('old search');
assert.equal(shown,'new search');
console.log('PASS: out-of-order completion keeps newest result');
