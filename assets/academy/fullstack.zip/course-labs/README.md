# Full-stack Developer — core lessons

Build a small web application from semantic HTML and JavaScript state through HTTP contracts, data relationships and production failure decisions. Begin with the five new core lessons, then revisit the original workshops. The course is a bounded learning route, not a claim to cover every framework.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A task application: labelled input, validated API contract, task ownership, conflicting edits and a release report.
