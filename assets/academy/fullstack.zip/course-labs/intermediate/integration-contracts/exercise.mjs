import assert from 'node:assert/strict';
function parseTask(x) {
  if (!x || !Number.isInteger(x.id) || typeof x.title !== 'string' || !x.title.trim()) throw new Error('Invalid task');
  return {id:x.id,title:x.title};
}
assert.deepEqual(parseTask({id:4,title:'Read'}),{id:4,title:'Read'});
assert.throws(() => parseTask({id:'4',title:'Read'}),/Invalid/);
assert.throws(() => parseTask({id:4,title:' '}),/Invalid/);
console.log('PASS: contract and two invalid bodies');
