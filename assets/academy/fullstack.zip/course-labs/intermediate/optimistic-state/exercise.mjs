import assert from 'node:assert/strict';
const pending = [{id:1,title:'Existing'},{id:'pending-2',title:'Draft',pending:true}];
const confirmed = {id:42,title:'Draft',pending:false};
const success = pending.map(t => t.id === 'pending-2' ? confirmed : t);
const failure = pending.filter(t => t.id !== 'pending-2');
assert.equal(success[1].id,42);
assert.deepEqual(failure,[{id:1,title:'Existing'}]);
console.log('PASS: targeted confirmation and rollback');
