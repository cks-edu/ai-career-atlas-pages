import assert from 'node:assert/strict';
async function load(request) {
  try {
    const r = await request();
    if (!r.ok) return {state:'error', message:'HTTP ' + r.status};
    const data = await r.json();
    if (!Array.isArray(data)) throw new Error('Invalid task list');
    return {state:'ready', data};
  } catch { return {state:'error', message:'Could not load tasks'}; }
}
assert.equal((await load(async () => ({ok:false,status:503}))).state, 'error');
assert.equal((await load(async () => ({ok:true,json:async () => []}))).state, 'ready');
assert.equal((await load(async () => {throw new Error('offline')})).state, 'error');
console.log('PASS: success, HTTP error, transport error');
