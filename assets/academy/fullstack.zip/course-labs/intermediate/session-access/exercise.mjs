import assert from 'node:assert/strict';
function canEdit(session, task) { return !!session && session.userId === task.ownerId; }
const task = {id:1,ownerId:7};
assert.equal(canEdit({userId:7},task),true);
assert.equal(canEdit({userId:8},task),false);
assert.equal(canEdit(null,task),false);
console.log('PASS: owner, other user, anonymous');
