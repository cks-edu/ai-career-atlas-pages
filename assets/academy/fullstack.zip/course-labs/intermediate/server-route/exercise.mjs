import http from 'node:http';
import assert from 'node:assert/strict';
const server = http.createServer((req,res) => {
  res.setHeader('Content-Type','application/json');
  res.writeHead(req.url === '/tasks' ? 200 : 404);
  res.end(JSON.stringify(req.url === '/tasks' ? [{id:1,title:'Read'}] : {error:'Not found'}));
});
await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
try {
  const base = 'http://127.0.0.1:' + server.address().port;
  assert.equal((await fetch(base + '/tasks')).status,200);
  assert.equal((await fetch(base + '/missing')).status,404);
  console.log('PASS: two real loopback HTTP requests');
} finally { await new Promise(resolve => server.close(resolve)); }
