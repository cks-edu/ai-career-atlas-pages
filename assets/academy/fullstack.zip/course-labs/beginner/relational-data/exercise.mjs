import assert from 'node:assert/strict';
const users = [{id:7, name:'Mira'}];
const tasks = [{id:1, ownerId:7, title:'Read SQL'}];
const rows = tasks.map(t => ({title:t.title, owner:users.find(u => u.id === t.ownerId)?.name ?? 'Missing owner'}));
assert.deepEqual(rows, [{title:'Read SQL', owner:'Mira'}]);
console.log(JSON.stringify(rows));
