import assert from 'node:assert/strict';
function addTask(tasks, title) {
  const clean = title.trim();
  if (!clean) throw new Error('Title required');
  const id = Math.max(0, ...tasks.map(t => t.id)) + 1;
  return [...tasks, {id, title: clean, done: false}];
}
const before = [];
const after = addTask(before, ' Read HTML ');
assert.equal(before.length, 0);
assert.equal(after[0].title, 'Read HTML');
assert.throws(() => addTask(after, ' '), /required/);
console.log(JSON.stringify(after));
