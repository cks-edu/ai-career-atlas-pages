import assert from 'node:assert/strict';
function handle(method, path, body) {
  if (method !== 'POST' || path !== '/tasks') return {status: 404};
  if (typeof body?.title !== 'string' || !body.title.trim()) return {status: 422};
  return {status: 201, body: {id: 1, title: body.title.trim()}};
}
assert.equal(handle('POST', '/tasks', {title:'Read'}).status, 201);
assert.equal(handle('POST', '/tasks', {title:' '}).status, 422);
assert.equal(handle('GET', '/missing').status, 404);
console.log('PASS: create, invalid input, missing route');
