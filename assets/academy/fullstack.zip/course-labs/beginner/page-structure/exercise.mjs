import assert from 'node:assert/strict';
const html = '<form><label for="title">Task title</label><input id="title" name="title" required><button type="submit">Add task</button></form>';
assert.match(html, /for="title"/);
assert.match(html, /id="title" name="title"/);
console.log(html);
