import assert from 'node:assert/strict';
const contentBox = (width, padding, border) => width + padding * 2 + border * 2;
assert.equal(contentBox(300, 16, 1), 334);
const css = '* { box-sizing: border-box; } main { width: 100%; max-width: 48rem; margin-inline: auto; padding: 1rem; }';
console.log(css);
