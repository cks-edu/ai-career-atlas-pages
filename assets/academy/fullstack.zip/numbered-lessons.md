# Full-stack Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in Full-stack Developer: Use the concept to complete this role exercise: Trace one task from form through HTTP to the server list

Trace a vertical slice: A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation.

### HTML: give a page meaning

HTML describes the meaning and structure of a page. A heading names a section, a label names an input and a button performs an action. Start with a useful document before adding visual polish.

How it works
The label for attribute matches the input id. A button with type submit submits its enclosing form. A name attribute identifies a field when form data is collected; id and name serve different jobs.

Where the model stops
A placeholder is not a replacement for a visible label. This small form has no server or persistence yet.

Make one change
Copy the printed HTML into index.html and open it in a browser. Focus the input with Tab, type a title and submit an empty form as a second case. Add a main element and a descriptive h1.

Mental model: A page is a labelled form: the browser needs the labels and relationships, not just the appearance.

Boundary: A placeholder is not a replacement for a visible label. This small form has no server or persistence yet.

Worked example: import assert from 'node:assert/strict';
const html = '<form><label for="title">Task title</label><input id="title" name="title" required><button type="submit">Add task</button></form>';
assert.match(html, /for="title"/);
assert.match(html, /id="title" name="title"/);
console.log(html);


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/page-structure. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Browser, HTML and Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Copy the printed HTML into index.html and open it in a browser. Focus the input with Tab, type a title and submit an empty form as a second case. Add a main element and a descriptive h1.

Terminal folder: course-labs/beginner/page-structure

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. The label for attribute matches the input id. A button with type submit submits its enclosing form. A name attribute identifies a field when form data is collected; id and name serve different jobs.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/page-structure. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The label focuses the input when clicked, Tab reaches the controls, and required prevents the empty submission. The Node checks inspect markup only; record the actual browser behaviour separately.

Build your change

Copy the printed HTML into index.html and open it in a browser. Focus the input with Tab, type a title and submit an empty form as a second case. Add a main element and a descriptive h1.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The label focuses the input when clicked, Tab reaches the controls, and required prevents the empty submission. The Node checks inspect markup only; record the actual browser behaviour separately.

Break, repair and explain

Deliberately violate this boundary: A placeholder is not a replacement for a visible label. This small form has no server or persistence yet. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The label focuses the input when clicked, Tab reaches the controls, and required prevents the empty submission. The Node checks inspect markup only; record the actual browser behaviour separately.

Troubleshoot: My result does not match HTML: give a page meaning: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The label for attribute matches the input id. A button with type submit submits its enclosing form. A name attribute identifies a field when form data is collected; id and name serve different jobs. Then inspect this limit: A placeholder is not a replacement for a visible label. This small form has no server or persistence yet. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/page-structure/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace HTML: give a page meaning line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A page is a labelled form: the browser needs the labels and relationships, not just the appearance.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Why does this input need both id and name? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A placeholder is not a replacement for a visible label. This small form has no server or persistence yet. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why does this input need both id and name?

Interview: Why does this input need both id and name? Defend your answer using your actual lab result and this boundary: A placeholder is not a replacement for a visible label. This small form has no server or persistence yet.

Quiz: Why does this input need both id and name?

Both make the text bold.

id connects its label; name identifies submitted data.

They save the task.

Reference: id connects its label; name identifies submitted data. — The label uses id; form encoding uses name. Neither attribute creates a backend or durable storage.

Sources:

MDN: basic HTML syntax: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

### CSS: build a layout that fits

CSS controls presentation. The box model includes content, padding, border and margin. A layout should still work with a long title, narrow screen and enlarged text.

How it works
With border-box, a declared width includes padding and border. max-width prevents a reading column from stretching indefinitely. Flexible widths allow the same content to fit different viewports.

Where the model stops
A fixed height can clip real content. This calculation explains one box; it is not a browser layout or accessibility test.

Make one change
Add the printed CSS to your previous HTML page. Test at 360px wide and at 200% zoom. Add an unbroken long title and repair any overflow with an intentional wrapping rule.

Mental model: A card is a parcel: the contents, wrapping and outer spacing all contribute to its footprint.

Boundary: A fixed height can clip real content. This calculation explains one box; it is not a browser layout or accessibility test.

Worked example: import assert from 'node:assert/strict';
const contentBox = (width, padding, border) => width + padding * 2 + border * 2;
assert.equal(contentBox(300, 16, 1), 334);
const css = '* { box-sizing: border-box; } main { width: 100%; max-width: 48rem; margin-inline: auto; padding: 1rem; }';
console.log(css);


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/css-layout. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Browser DevTools and CSS

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add the printed CSS to your previous HTML page. Test at 360px wide and at 200% zoom. Add an unbroken long title and repair any overflow with an intentional wrapping rule.

Terminal folder: course-labs/beginner/css-layout

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. With border-box, a declared width includes padding and border. max-width prevents a reading column from stretching indefinitely. Flexible widths allow the same content to fit different viewports.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/css-layout. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The calculation prints CSS after its assertion passes. In the browser, the form remains readable without a fixed content height. Capture the two tested sizes.

Build your change

Add the printed CSS to your previous HTML page. Test at 360px wide and at 200% zoom. Add an unbroken long title and repair any overflow with an intentional wrapping rule.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The calculation prints CSS after its assertion passes. In the browser, the form remains readable without a fixed content height. Capture the two tested sizes.

Break, repair and explain

Deliberately violate this boundary: A fixed height can clip real content. This calculation explains one box; it is not a browser layout or accessibility test. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The calculation prints CSS after its assertion passes. In the browser, the form remains readable without a fixed content height. Capture the two tested sizes.

Troubleshoot: My result does not match CSS: build a layout that fits: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: With border-box, a declared width includes padding and border. max-width prevents a reading column from stretching indefinitely. Flexible widths allow the same content to fit different viewports. Then inspect this limit: A fixed height can clip real content. This calculation explains one box; it is not a browser layout or accessibility test. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/css-layout/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace CSS: build a layout that fits line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A card is a parcel: the contents, wrapping and outer spacing all contribute to its footprint.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: A 300px content-box has 16px padding and 1px border on each side. Its outer width before margin is? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A fixed height can clip real content. This calculation explains one box; it is not a browser layout or accessibility test. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A 300px content-box has 16px padding and 1px border on each side. Its outer width before margin is?

Interview: A 300px content-box has 16px padding and 1px border on each side. Its outer width before margin is? Defend your answer using your actual lab result and this boundary: A fixed height can clip real content. This calculation explains one box; it is not a browser layout or accessibility test.

Quiz: A 300px content-box has 16px padding and 1px border on each side. Its outer width before margin is?

300px

317px

334px

Reference: 334px — 300 + 32 + 2 = 334. border-box changes how the declared width is interpreted, not the existence of padding.

Sources:

MDN: CSS box model: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

### JavaScript: keep data and display in sync

JavaScript values represent your application data. An array holds a sequence of tasks; an object gives one task named properties. Keep that data separate from the code that displays it.

How it works
A function takes input and returns a result. This add function validates a title, allocates an identifier and returns a new array. Copying the array makes the change explicit without changing the previous snapshot.

Where the model stops
A local array disappears on refresh. Returning a new array does not make nested objects immutable.

Make one change
Add a toggleTask function that returns a changed copy for one known id. Test a known id, a missing id and that the previous snapshot has not changed.

Mental model: The task array is a notebook; the page is a view of the notebook. Editing one does not automatically update the other.

Boundary: A local array disappears on refresh. Returning a new array does not make nested objects immutable.

Worked example: import assert from 'node:assert/strict';
function addTask(tasks, title) {
  const clean = title.trim();
  if (!clean) throw new Error('Title required');
  const id = Math.max(0, ...tasks.map(t => t.id)) + 1;
  return [...tasks, {id, title: clean, done: false}];
}
const before = [];
const after = addTask(before, ' Read HTML ');
assert.equal(before.length, 0);
assert.equal(after[0].title, 'Read HTML');
assert.throws(() => addTask(after, ' '), /required/);
console.log(JSON.stringify(after));


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/javascript-state. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a toggleTask function that returns a changed copy for one known id. Test a known id, a missing id and that the previous snapshot has not changed.

Terminal folder: course-labs/beginner/javascript-state

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. A function takes input and returns a result. This add function validates a title, allocates an identifier and returns a new array. Copying the array makes the change explicit without changing the previous snapshot.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/javascript-state. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The reference prints one trimmed task. Your tests show whether a missing id is rejected or ignored, and document that policy.

Build your change

Add a toggleTask function that returns a changed copy for one known id. Test a known id, a missing id and that the previous snapshot has not changed.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The reference prints one trimmed task. Your tests show whether a missing id is rejected or ignored, and document that policy.

Break, repair and explain

Deliberately violate this boundary: A local array disappears on refresh. Returning a new array does not make nested objects immutable. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The reference prints one trimmed task. Your tests show whether a missing id is rejected or ignored, and document that policy.

Troubleshoot: My result does not match JavaScript: keep data and display in sync: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: A function takes input and returns a result. This add function validates a title, allocates an identifier and returns a new array. Copying the array makes the change explicit without changing the previous snapshot. Then inspect this limit: A local array disappears on refresh. Returning a new array does not make nested objects immutable. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/javascript-state/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace JavaScript: keep data and display in sync line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The task array is a notebook; the page is a view of the notebook. Editing one does not automatically update the other.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Why render after updating the task array? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A local array disappears on refresh. Returning a new array does not make nested objects immutable. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why render after updating the task array?

Interview: Why render after updating the task array? Defend your answer using your actual lab result and this boundary: A local array disappears on refresh. Returning a new array does not make nested objects immutable.

Quiz: Why render after updating the task array?

The DOM does not automatically observe an ordinary array.

Arrays automatically save to a database.

Rendering validates all server requests.

Reference: The DOM does not automatically observe an ordinary array. — Plain JavaScript arrays have no built-in DOM synchronisation. The application must update the view, and the server still needs its own validation.

Sources:

MDN: JavaScript guide: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

### HTTP: agree on a request and response

The browser and service communicate through a contract. A method states the kind of operation, a path identifies the resource, and the response includes a status and body. JSON is a data format, not a transport or validation rule.

How it works
The example models a POST /tasks handler as a pure function so you can test its decisions before opening a network port. It distinguishes an unknown route from invalid input and a successful creation.

Where the model stops
A pure handler does not test socket behaviour, JSON parsing, authentication or persistence. Client checks do not replace server checks.

Make one change
Add a maximum title length of 80 characters. Check lengths 0, 80 and 81, then describe what the browser should display for each response.

Mental model: A service counter accepts a particular order form and returns a receipt with a result code.

Boundary: A pure handler does not test socket behaviour, JSON parsing, authentication or persistence. Client checks do not replace server checks.

Worked example: import assert from 'node:assert/strict';
function handle(method, path, body) {
  if (method !== 'POST' || path !== '/tasks') return {status: 404};
  if (typeof body?.title !== 'string' || !body.title.trim()) return {status: 422};
  return {status: 201, body: {id: 1, title: body.title.trim()}};
}
assert.equal(handle('POST', '/tasks', {title:'Read'}).status, 201);
assert.equal(handle('POST', '/tasks', {title:' '}).status, 422);
assert.equal(handle('GET', '/missing').status, 404);
console.log('PASS: create, invalid input, missing route');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/request-contract. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a maximum title length of 80 characters. Check lengths 0, 80 and 81, then describe what the browser should display for each response.

Terminal folder: course-labs/beginner/request-contract

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. The example models a POST /tasks handler as a pure function so you can test its decisions before opening a network port. It distinguishes an unknown route from invalid input and a successful creation.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/request-contract. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Three reference cases pass. Your boundary tests distinguish 80 from 81 characters and show a useful validation message.

Build your change

Add a maximum title length of 80 characters. Check lengths 0, 80 and 81, then describe what the browser should display for each response.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Three reference cases pass. Your boundary tests distinguish 80 from 81 characters and show a useful validation message.

Break, repair and explain

Deliberately violate this boundary: A pure handler does not test socket behaviour, JSON parsing, authentication or persistence. Client checks do not replace server checks. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Three reference cases pass. Your boundary tests distinguish 80 from 81 characters and show a useful validation message.

Troubleshoot: My result does not match HTTP: agree on a request and response: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The example models a POST /tasks handler as a pure function so you can test its decisions before opening a network port. It distinguishes an unknown route from invalid input and a successful creation. Then inspect this limit: A pure handler does not test socket behaviour, JSON parsing, authentication or persistence. Client checks do not replace server checks. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/request-contract/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace HTTP: agree on a request and response line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A service counter accepts a particular order form and returns a receipt with a result code.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: The browser already rejects blank titles. What must the service do? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A pure handler does not test socket behaviour, JSON parsing, authentication or persistence. Client checks do not replace server checks. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: The browser already rejects blank titles. What must the service do?

Interview: The browser already rejects blank titles. What must the service do? Defend your answer using your actual lab result and this boundary: A pure handler does not test socket behaviour, JSON parsing, authentication or persistence. Client checks do not replace server checks.

Quiz: The browser already rejects blank titles. What must the service do?

Trust the browser.

Validate its own request boundary.

Change every error to status 200.

Reference: Validate its own request boundary. — Clients can be bypassed or outdated. The receiving service validates its own contract and returns an appropriate response.

Sources:

MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### Data: connect tasks to their owners

A relation is a table of rows sharing named columns. A primary key identifies one row; a foreign key relates a row to another table. Learn the relationship before choosing a database product.

How it works
Joining matches the owner identifier to the person identifier. The in-memory example performs the same matching idea with arrays; a database can also enforce a foreign-key constraint when configured.

Where the model stops
An array lookup is not a SQL database and does not enforce referential integrity by itself. Do not use a displayed owner name as an authorisation check.

Make one change
Add a task referencing a nonexistent owner. Show the missing-owner result, then write down whether a real application should reject that insert or preserve an explicit unassigned state.

Mental model: Tasks carry an owner number that points to the matching person in an address book.

Boundary: An array lookup is not a SQL database and does not enforce referential integrity by itself. Do not use a displayed owner name as an authorisation check.

Worked example: import assert from 'node:assert/strict';
const users = [{id:7, name:'Mira'}];
const tasks = [{id:1, ownerId:7, title:'Read SQL'}];
const rows = tasks.map(t => ({title:t.title, owner:users.find(u => u.id === t.ownerId)?.name ?? 'Missing owner'}));
assert.deepEqual(rows, [{title:'Read SQL', owner:'Mira'}]);
console.log(JSON.stringify(rows));


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/relational-data. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a task referencing a nonexistent owner. Show the missing-owner result, then write down whether a real application should reject that insert or preserve an explicit unassigned state.

Terminal folder: course-labs/beginner/relational-data

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Joining matches the owner identifier to the person identifier. The in-memory example performs the same matching idea with arrays; a database can also enforce a foreign-key constraint when configured.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/relational-data. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: One task is joined to Mira. Your second case exposes the broken relationship instead of inventing a person.

Build your change

Add a task referencing a nonexistent owner. Show the missing-owner result, then write down whether a real application should reject that insert or preserve an explicit unassigned state.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. One task is joined to Mira. Your second case exposes the broken relationship instead of inventing a person.

Break, repair and explain

Deliberately violate this boundary: An array lookup is not a SQL database and does not enforce referential integrity by itself. Do not use a displayed owner name as an authorisation check. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: One task is joined to Mira. Your second case exposes the broken relationship instead of inventing a person.

Troubleshoot: My result does not match Data: connect tasks to their owners: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Joining matches the owner identifier to the person identifier. The in-memory example performs the same matching idea with arrays; a database can also enforce a foreign-key constraint when configured. Then inspect this limit: An array lookup is not a SQL database and does not enforce referential integrity by itself. Do not use a displayed owner name as an authorisation check. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/relational-data/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Data: connect tasks to their owners line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Tasks carry an owner number that points to the matching person in an address book.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Which field relates a task to a user? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An array lookup is not a SQL database and does not enforce referential integrity by itself. Do not use a displayed owner name as an authorisation check. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which field relates a task to a user?

Interview: Which field relates a task to a user? Defend your answer using your actual lab result and this boundary: An array lookup is not a SQL database and does not enforce referential integrity by itself. Do not use a displayed owner name as an authorisation check.

Quiz: Which field relates a task to a user?

The user display name.

The position of the row on screen.

ownerId referencing the user primary key.

Reference: ownerId referencing the user primary key. — Identifiers express the relationship. Names can change and array or display order is not stable identity.

Sources:

PostgreSQL: relational database tutorial: https://www.postgresql.org/docs/current/tutorial.html

### Request and response

A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. In this role, work through: Create Task A in the browser and match its returned ID to GET /api/tasks. The practical workshop develops this into: Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Role application: Follow one parcel through every desk until its receipt matches the original order.

A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation.

Worked example: Create Task A in the browser and match its returned ID to GET /api/tasks.

Shared foundation example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Full-stack Developer: Create Task A in the browser and match its returned ID to GET /api/tasks.

Predict the worked case

Read this case without running a tool: Create Task A in the browser and match its returned ID to GET /api/tasks. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in request and response.

Connect the concept to the role

Apply this rule: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Networks can time out; sending an order does not prove it was fulfilled.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies request and response to this case: Create Task A in the browser and match its returned ID to GET /api/tasks. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Create Task A in the browser and match its returned ID to GET /api/tasks. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Request and response; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request and response. Use the glossary below, then write your prediction for: Create Task A in the browser and match its returned ID to GET /api/tasks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain request and response using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request and response to a system or workflow you know. Explain request and response using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Draw the request and response for adding one task.

Interview: Explain request and response using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops.

Quiz: After the Trace a vertical slice rehearsal, check this foundation: A request returns HTTP 404. Which boundary has evidence of working?

An HTTP server returned a response; inspect the route next.

The request never reached any HTTP server.

The server has confirmed that the resource exists.

Reference: An HTTP server returned a response; inspect the route next. — 404 is an HTTP response, not a transport timeout. It does not prove which component generated it or that the business operation succeeded.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Trace a vertical slice

A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation. In this role, work through: Create Task A in the browser and match its returned ID to GET /api/tasks. The practical workshop develops this into: Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

Mental model: Follow one parcel through every desk until its receipt matches the original order.

Boundary: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.

Worked example: Create Task A in the browser and match its returned ID to GET /api/tasks.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Full-stack Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Create Task A in the browser and match its returned ID to GET /api/tasks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

```
node app.mjs
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One ID and one title match across all five boundaries.

Role workshop · debug and verify

A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save vertical-slice.md with a sequence diagram and redacted HTTP examples. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One ID and one title match across all five boundaries.

Expected: One ID and one title match across all five boundaries.

Troubleshoot: The role exercise differs from the prediction: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: vertical-slice.md with a sequence diagram and redacted HTTP examples; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with trace a vertical slice. Use the glossary below, then write your prediction for: Create Task A in the browser and match its returned ID to GET /api/tasks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain trace a vertical slice using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate trace a vertical slice to a system or workflow you know. Explain trace a vertical slice using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.

Interview: Explain trace a vertical slice using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Create Task A in the browser and match its returned ID to GET /api/tasks.

One ID and one title match across all five boundaries.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: One ID and one title match across all five boundaries. — A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation. One ID and one title match across all five boundaries.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in Full-stack Developer: Use the concept to complete this role exercise: Add a storage adapter and test the same request through UI and API

Storage adapter contract: Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details.

### Async requests: handle success and failure

A Promise represents a result that may arrive later. await pauses the current async function until that result settles; it does not freeze the whole application. Treat transport failure and an HTTP error response as different outcomes.

How it works
fetch resolves for HTTP responses such as 404. Check response.ok before reading a successful data contract. A rejected Promise needs a catch path as well. The injected request below lets you reproduce both paths without a public service.

Where the model stops
A successful HTTP status still does not prove the body matches the expected schema.

Make one change
Test a 200 response containing an object instead of an array. Add explicit loading and empty states to your UI design and keep retry separate from a duplicate write.

Mental model: Waiting for a delivery is different from receiving a parcel containing a rejection notice.

Boundary: A successful HTTP status still does not prove the body matches the expected schema.

Worked example: import assert from 'node:assert/strict';
async function load(request) {
  try {
    const r = await request();
    if (!r.ok) return {state:'error', message:'HTTP ' + r.status};
    const data = await r.json();
    if (!Array.isArray(data)) throw new Error('Invalid task list');
    return {state:'ready', data};
  } catch { return {state:'error', message:'Could not load tasks'}; }
}
assert.equal((await load(async () => ({ok:false,status:503}))).state, 'error');
assert.equal((await load(async () => ({ok:true,json:async () => []}))).state, 'ready');
assert.equal((await load(async () => {throw new Error('offline')})).state, 'error');
console.log('PASS: success, HTTP error, transport error');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/async-boundaries. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Test a 200 response containing an object instead of an array. Add explicit loading and empty states to your UI design and keep retry separate from a duplicate write.

Terminal folder: course-labs/intermediate/async-boundaries

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. fetch resolves for HTTP responses such as 404. Check response.ok before reading a successful data contract. A rejected Promise needs a catch path as well. The injected request below lets you reproduce both paths without a public service.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/async-boundaries. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: All three reference paths pass. The malformed-body case reaches an error state rather than treating an object as a task list.

Build your change

Test a 200 response containing an object instead of an array. Add explicit loading and empty states to your UI design and keep retry separate from a duplicate write.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. All three reference paths pass. The malformed-body case reaches an error state rather than treating an object as a task list.

Break, repair and explain

Deliberately violate this boundary: A successful HTTP status still does not prove the body matches the expected schema. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: All three reference paths pass. The malformed-body case reaches an error state rather than treating an object as a task list.

Troubleshoot: My result does not match Async requests: handle success and failure: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: fetch resolves for HTTP responses such as 404. Check response.ok before reading a successful data contract. A rejected Promise needs a catch path as well. The injected request below lets you reproduce both paths without a public service. Then inspect this limit: A successful HTTP status still does not prove the body matches the expected schema. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/async-boundaries/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Async requests: handle success and failure line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Waiting for a delivery is different from receiving a parcel containing a rejection notice.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: fetch receives status 503. Does that necessarily reject its Promise? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A successful HTTP status still does not prove the body matches the expected schema. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: fetch receives status 503. Does that necessarily reject its Promise?

Interview: fetch receives status 503. Does that necessarily reject its Promise? Defend your answer using your actual lab result and this boundary: A successful HTTP status still does not prove the body matches the expected schema.

Quiz: fetch receives status 503. Does that necessarily reject its Promise?

Yes, every non-200 status throws.

No; inspect the response status or ok property.

Only on mobile.

Reference: No; inspect the response status or ok property. — HTTP errors normally resolve fetch with a Response. Transport failures reject; body parsing and validation can also fail.

Sources:

MDN: using fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

### A real local HTTP service

A server listens for requests and writes responses. Start with one read-only route, bind only to your own machine for practice, and use an integration test that sends an actual request.

How it works
Node http creates a server. Binding port 0 asks the operating system for an unused port, which avoids hardcoded-port collisions in tests. Close the server even when the test fails.

Where the model stops
This route has no authentication or write behaviour and must not be advertised as a production server.

Make one change
Add GET /health and test its body and content type. Reject unsupported methods explicitly. Inspect the three responses in a local client without exposing the service on all interfaces.

Mental model: The handler is the service desk; the listening socket is its front door.

Boundary: This route has no authentication or write behaviour and must not be advertised as a production server.

Worked example: import http from 'node:http';
import assert from 'node:assert/strict';
const server = http.createServer((req,res) => {
  res.setHeader('Content-Type','application/json');
  res.writeHead(req.url === '/tasks' ? 200 : 404);
  res.end(JSON.stringify(req.url === '/tasks' ? [{id:1,title:'Read'}] : {error:'Not found'}));
});
await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
try {
  const base = 'http://127.0.0.1:' + server.address().port;
  assert.equal((await fetch(base + '/tasks')).status,200);
  assert.equal((await fetch(base + '/missing')).status,404);
  console.log('PASS: two real loopback HTTP requests');
} finally { await new Promise(resolve => server.close(resolve)); }


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/server-route. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add GET /health and test its body and content type. Reject unsupported methods explicitly. Inspect the three responses in a local client without exposing the service on all interfaces.

Terminal folder: course-labs/intermediate/server-route

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Node http creates a server. Binding port 0 asks the operating system for an unused port, which avoids hardcoded-port collisions in tests. Close the server even when the test fails.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/server-route. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Two real loopback requests pass and the server closes. Your health route has a documented response contract.

Build your change

Add GET /health and test its body and content type. Reject unsupported methods explicitly. Inspect the three responses in a local client without exposing the service on all interfaces.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Two real loopback requests pass and the server closes. Your health route has a documented response contract.

Break, repair and explain

Deliberately violate this boundary: This route has no authentication or write behaviour and must not be advertised as a production server. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Two real loopback requests pass and the server closes. Your health route has a documented response contract.

Troubleshoot: My result does not match A real local HTTP service: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Node http creates a server. Binding port 0 asks the operating system for an unused port, which avoids hardcoded-port collisions in tests. Close the server even when the test fails. Then inspect this limit: This route has no authentication or write behaviour and must not be advertised as a production server. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/server-route/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace A real local HTTP service line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The handler is the service desk; the listening socket is its front door.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Why use port 0 in this integration test? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This route has no authentication or write behaviour and must not be advertised as a production server. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why use port 0 in this integration test?

Interview: Why use port 0 in this integration test? Defend your answer using your actual lab result and this boundary: This route has no authentication or write behaviour and must not be advertised as a production server.

Quiz: Why use port 0 in this integration test?

It disables networking.

It guarantees port 80.

The OS chooses an available port.

Reference: The OS chooses an available port. — An ephemeral port reduces test collisions; it does not remove networking or secure the application.

Sources:

Node.js: HTTP API: https://nodejs.org/api/http.html

### Optimistic changes: reconcile with the server

An optimistic interface shows a predicted result before the server confirms it. This can feel responsive, but the application must keep enough information to reconcile a failure or a different server result.

How it works
Use a temporary client id only for the pending item. On success replace it with the canonical server record. On failure remove only that temporary item, preserving unrelated work.

Where the model stops
An undo operation that restores the entire old list can overwrite other changes made while the request was pending.

Make one change
Add another pending item and fail only pending-2. Verify the unrelated pending item remains, then specify what happens if the user edits a title before confirmation.

Mental model: A pencilled notebook entry is visible now; the confirmed receipt decides whether it stays.

Boundary: An undo operation that restores the entire old list can overwrite other changes made while the request was pending.

Worked example: import assert from 'node:assert/strict';
const pending = [{id:1,title:'Existing'},{id:'pending-2',title:'Draft',pending:true}];
const confirmed = {id:42,title:'Draft',pending:false};
const success = pending.map(t => t.id === 'pending-2' ? confirmed : t);
const failure = pending.filter(t => t.id !== 'pending-2');
assert.equal(success[1].id,42);
assert.deepEqual(failure,[{id:1,title:'Existing'}]);
console.log('PASS: targeted confirmation and rollback');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/optimistic-state. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add another pending item and fail only pending-2. Verify the unrelated pending item remains, then specify what happens if the user edits a title before confirmation.

Terminal folder: course-labs/intermediate/optimistic-state

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Use a temporary client id only for the pending item. On success replace it with the canonical server record. On failure remove only that temporary item, preserving unrelated work.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/optimistic-state. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The original item survives both paths. A targeted rollback preserves the second pending item in your new test.

Build your change

Add another pending item and fail only pending-2. Verify the unrelated pending item remains, then specify what happens if the user edits a title before confirmation.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The original item survives both paths. A targeted rollback preserves the second pending item in your new test.

Break, repair and explain

Deliberately violate this boundary: An undo operation that restores the entire old list can overwrite other changes made while the request was pending. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The original item survives both paths. A targeted rollback preserves the second pending item in your new test.

Troubleshoot: My result does not match Optimistic changes: reconcile with the server: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use a temporary client id only for the pending item. On success replace it with the canonical server record. On failure remove only that temporary item, preserving unrelated work. Then inspect this limit: An undo operation that restores the entire old list can overwrite other changes made while the request was pending. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/optimistic-state/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Optimistic changes: reconcile with the server line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A pencilled notebook entry is visible now; the confirmed receipt decides whether it stays.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Why avoid restoring an entire old list after one failed write? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An undo operation that restores the entire old list can overwrite other changes made while the request was pending. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why avoid restoring an entire old list after one failed write?

Interview: Why avoid restoring an entire old list after one failed write? Defend your answer using your actual lab result and this boundary: An undo operation that restores the entire old list can overwrite other changes made while the request was pending.

Quiz: Why avoid restoring an entire old list after one failed write?

It can erase unrelated concurrent edits.

It is always too slow.

HTTP requires a full-list rollback.

Reference: It can erase unrelated concurrent edits. — The state may have changed since the snapshot. Reconcile by operation or identity rather than blindly restoring unrelated state.

Sources:

MDN: JavaScript guide: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

### Authorisation: ownership is checked on the service

Authentication establishes who a caller is. Authorisation decides what that caller can do. A hidden button improves the interface but cannot protect an API record.

How it works
The policy below compares a trusted session user with the stored task owner. It never accepts an ownerId supplied by the request as proof. Default to denying access when the session is missing.

Where the model stops
This policy function does not implement secure session cookies, CSRF protection or identity verification.

Make one change
Add a read-only collaborator role with a separate canRead function. Test owner, collaborator, unrelated user and anonymous access without weakening canEdit.

Mental model: An identity badge opens the building; a separate permission list controls each room.

Boundary: This policy function does not implement secure session cookies, CSRF protection or identity verification.

Worked example: import assert from 'node:assert/strict';
function canEdit(session, task) { return !!session && session.userId === task.ownerId; }
const task = {id:1,ownerId:7};
assert.equal(canEdit({userId:7},task),true);
assert.equal(canEdit({userId:8},task),false);
assert.equal(canEdit(null,task),false);
console.log('PASS: owner, other user, anonymous');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/session-access. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a read-only collaborator role with a separate canRead function. Test owner, collaborator, unrelated user and anonymous access without weakening canEdit.

Terminal folder: course-labs/intermediate/session-access

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. The policy below compares a trusted session user with the stored task owner. It never accepts an ownerId supplied by the request as proof. Default to denying access when the session is missing.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/session-access. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Three reference policies pass. Your read collaborator can read but cannot edit, with a test for both actions.

Build your change

Add a read-only collaborator role with a separate canRead function. Test owner, collaborator, unrelated user and anonymous access without weakening canEdit.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Three reference policies pass. Your read collaborator can read but cannot edit, with a test for both actions.

Break, repair and explain

Deliberately violate this boundary: This policy function does not implement secure session cookies, CSRF protection or identity verification. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Three reference policies pass. Your read collaborator can read but cannot edit, with a test for both actions.

Troubleshoot: My result does not match Authorisation: ownership is checked on the service: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The policy below compares a trusted session user with the stored task owner. It never accepts an ownerId supplied by the request as proof. Default to denying access when the session is missing. Then inspect this limit: This policy function does not implement secure session cookies, CSRF protection or identity verification. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/session-access/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Authorisation: ownership is checked on the service line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An identity badge opens the building; a separate permission list controls each room.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: A request includes ownerId equal to the caller. Is that enough to edit a stored record? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This policy function does not implement secure session cookies, CSRF protection or identity verification. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A request includes ownerId equal to the caller. Is that enough to edit a stored record?

Interview: A request includes ownerId equal to the caller. Is that enough to edit a stored record? Defend your answer using your actual lab result and this boundary: This policy function does not implement secure session cookies, CSRF protection or identity verification.

Quiz: A request includes ownerId equal to the caller. Is that enough to edit a stored record?

Yes, trust submitted ownership.

No, use trusted identity and stored permissions.

Only if the UI hides the edit button.

Reference: No, use trusted identity and stored permissions. — The server owns the permission decision. Request fields and hidden controls can be altered by the caller.

Sources:

OWASP: authorisation guidance: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Integration checks: test both sides of the contract

A unit check proves a small rule under chosen inputs. A contract check verifies that data produced by one boundary is acceptable to its consumer. Both are useful, but neither proves a complete user journey.

How it works
Validate the response before rendering it. This parser rejects a wrong identifier type and an unexpected blank title. Keep protocol fixtures near the consumer tests so changes reveal a mismatch.

Where the model stops
A passing fixture is a sample, not proof that every live response conforms. Keep runtime validation at external boundaries.

Make one change
Add a done boolean to the contract. Decide whether unknown fields are ignored or rejected and test the policy with old and new fixtures.

Mental model: Two puzzle pieces need matching edges, even when each piece is correctly made.

Boundary: A passing fixture is a sample, not proof that every live response conforms. Keep runtime validation at external boundaries.

Worked example: import assert from 'node:assert/strict';
function parseTask(x) {
  if (!x || !Number.isInteger(x.id) || typeof x.title !== 'string' || !x.title.trim()) throw new Error('Invalid task');
  return {id:x.id,title:x.title};
}
assert.deepEqual(parseTask({id:4,title:'Read'}),{id:4,title:'Read'});
assert.throws(() => parseTask({id:'4',title:'Read'}),/Invalid/);
assert.throws(() => parseTask({id:4,title:' '}),/Invalid/);
console.log('PASS: contract and two invalid bodies');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/integration-contracts. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a done boolean to the contract. Decide whether unknown fields are ignored or rejected and test the policy with old and new fixtures.

Terminal folder: course-labs/intermediate/integration-contracts

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Validate the response before rendering it. This parser rejects a wrong identifier type and an unexpected blank title. Keep protocol fixtures near the consumer tests so changes reveal a mismatch.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/integration-contracts. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: A numeric id and nonblank title pass; a string id and blank title fail. Your done rule rejects the wrong type.

Build your change

Add a done boolean to the contract. Decide whether unknown fields are ignored or rejected and test the policy with old and new fixtures.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. A numeric id and nonblank title pass; a string id and blank title fail. Your done rule rejects the wrong type.

Break, repair and explain

Deliberately violate this boundary: A passing fixture is a sample, not proof that every live response conforms. Keep runtime validation at external boundaries. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: A numeric id and nonblank title pass; a string id and blank title fail. Your done rule rejects the wrong type.

Troubleshoot: My result does not match Integration checks: test both sides of the contract: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Validate the response before rendering it. This parser rejects a wrong identifier type and an unexpected blank title. Keep protocol fixtures near the consumer tests so changes reveal a mismatch. Then inspect this limit: A passing fixture is a sample, not proof that every live response conforms. Keep runtime validation at external boundaries. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/integration-contracts/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Integration checks: test both sides of the contract line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Two puzzle pieces need matching edges, even when each piece is correctly made.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Why validate a server response in the browser? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A passing fixture is a sample, not proof that every live response conforms. Keep runtime validation at external boundaries. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why validate a server response in the browser?

Interview: Why validate a server response in the browser? Defend your answer using your actual lab result and this boundary: A passing fixture is a sample, not proof that every live response conforms. Keep runtime validation at external boundaries.

Quiz: Why validate a server response in the browser?

TypeScript validates all network bodies automatically.

JSON guarantees the task shape.

The external data may violate the consumer contract.

Reference: The external data may violate the consumer contract. — Static types and valid JSON do not guarantee a runtime schema. Parse and handle invalid data explicitly.

Sources:

MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

MDN: JavaScript guide: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

### Validation at a boundary

Check input before storing or using it. Client checks help people; the server must also enforce the rule. In this role, work through: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. The practical workshop develops this into: Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Role application: Replace a filing cabinet while keeping the front desk request form unchanged.

Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details.

Worked example: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Shared foundation example: A blank title receives 400 and does not change task count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Full-stack Developer: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Predict the worked case

Read this case without running a tool: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in validation at a boundary.

Connect the concept to the role

Apply this rule: Check input before storing or using it. Client checks help people; the server must also enforce the rule. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid input can still be unauthorized; validation is not access control.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies validation at a boundary to this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Validation at a boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with validation at a boundary. Use the glossary below, then write your prediction for: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain validation at a boundary using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate validation at a boundary to a system or workflow you know. Explain validation at a boundary using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Explain validation at a boundary using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops.

Quiz: After the Storage adapter contract rehearsal, check this foundation: A browser rejects a blank field. A second client calls the API directly. Where must the same business rule be enforced?

Only in the browser to avoid duplicate logic.

At the server boundary before state changes.

Only after storing the input, in the dashboard.

Reference: At the server boundary before state changes. — Client checks improve feedback; the server must protect its contract for every caller.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Storage adapter contract

Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details. In this role, work through: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. The practical workshop develops this into: Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

Mental model: Replace a filing cabinet while keeping the front desk request form unchanged.

Boundary: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.

Worked example: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Full-stack Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

```
node app.mjs test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

Role workshop · debug and verify

If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save storage-adapter code, restart transcript and adapter contract tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

Troubleshoot: The role exercise differs from the prediction: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: storage-adapter code, restart transcript and adapter contract tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with storage adapter contract. Use the glossary below, then write your prediction for: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain storage adapter contract using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate storage adapter contract to a system or workflow you know. Explain storage adapter contract using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.

Interview: Explain storage adapter contract using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Ignore the failing case and keep only the successful screenshot.

Task A survives restart; invalid titles never reach storage; tests isolate their files.

Treat any successful command as proof that all business and access rules passed.

Reference: Task A survives restart; invalid titles never reach storage; tests isolate their files. — Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details. Task A survives restart; invalid titles never reach storage; tests isolate their files.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in Full-stack Developer: Use the concept to complete this role exercise: Write a rollout plan covering schema compatibility and rollback

Compatible feature rollout: Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning.

### Concurrent requests: stop stale results winning

Requests can finish in a different order from the order they started. A later search result should not be replaced by an older response that happened to take longer.

How it works
Increment a generation counter when a new operation starts. Before committing a result, compare its captured generation with the current value. Cancellation can save resources but a generation guard still defines ownership.

Where the model stops
Discarding a stale UI result does not roll back a server-side write. This is a read-result policy.

Make one change
Extend the guard to error and loading updates. Demonstrate that an old failure cannot clear the current loading indicator or replace the new result.

Mental model: Each search has a numbered ticket; only the latest ticket may update the screen.

Boundary: Discarding a stale UI result does not roll back a server-side write. This is a read-result policy.

Worked example: import assert from 'node:assert/strict';
let generation = 0, shown = '';
function begin() { const mine = ++generation; return value => { if (mine === generation) shown = value; }; }
const old = begin(); const recent = begin();
recent('new search'); old('old search');
assert.equal(shown,'new search');
console.log('PASS: out-of-order completion keeps newest result');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/request-races. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Extend the guard to error and loading updates. Demonstrate that an old failure cannot clear the current loading indicator or replace the new result.

Terminal folder: course-labs/advanced/request-races

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Increment a generation counter when a new operation starts. Before committing a result, compare its captured generation with the current value. Cancellation can save resources but a generation guard still defines ownership.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/request-races. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The new result remains visible. Your stale success and stale failure tests preserve current state.

Build your change

Extend the guard to error and loading updates. Demonstrate that an old failure cannot clear the current loading indicator or replace the new result.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The new result remains visible. Your stale success and stale failure tests preserve current state.

Break, repair and explain

Deliberately violate this boundary: Discarding a stale UI result does not roll back a server-side write. This is a read-result policy. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The new result remains visible. Your stale success and stale failure tests preserve current state.

Troubleshoot: My result does not match Concurrent requests: stop stale results winning: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Increment a generation counter when a new operation starts. Before committing a result, compare its captured generation with the current value. Cancellation can save resources but a generation guard still defines ownership. Then inspect this limit: Discarding a stale UI result does not roll back a server-side write. This is a read-result policy. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/request-races/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Concurrent requests: stop stale results winning line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Each search has a numbered ticket; only the latest ticket may update the screen.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Does ignoring a stale response undo a server write? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Discarding a stale UI result does not roll back a server-side write. This is a read-result policy. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does ignoring a stale response undo a server write?

Interview: Does ignoring a stale response undo a server write? Defend your answer using your actual lab result and this boundary: Discarding a stale UI result does not roll back a server-side write. This is a read-result policy.

Quiz: Does ignoring a stale response undo a server write?

No; it only controls this client state update.

Yes, automatically.

Only if the request uses JSON.

Reference: No; it only controls this client state update. — A client display policy does not reverse remote side effects. Writes need their own concurrency and reconciliation design.

Sources:

MDN: using fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

### Concurrent edits: detect lost updates

Two users can edit the same record from the same starting version. If both writes overwrite the whole record, the last writer can silently erase the first change. Optimistic concurrency makes the conflict visible.

How it works
The write includes the version it read. The service updates only if that version still matches, then increments the version. Real storage must perform the compare and update atomically.

Where the model stops
This single-process model is not a distributed lock or a complete merge strategy.

Make one change
Design the browser conflict message: preserve the unsaved edit and show the latest version. Add a refresh-and-retry test that does not silently overwrite without learner confirmation.

Mental model: A librarian accepts a replacement page only when its edition number matches the current edition.

Boundary: This single-process model is not a distributed lock or a complete merge strategy.

Worked example: import assert from 'node:assert/strict';
let record = {id:1,title:'Draft',version:1};
function update(expected, title) {
  if (record.version !== expected) return {status:409};
  record = {...record,title,version:record.version+1}; return {status:200};
}
assert.equal(update(1,'First edit').status,200);
assert.equal(update(1,'Stale edit').status,409);
assert.equal(record.title,'First edit');
console.log('PASS: stale write rejected');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/versioned-writes. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Design the browser conflict message: preserve the unsaved edit and show the latest version. Add a refresh-and-retry test that does not silently overwrite without learner confirmation.

Terminal folder: course-labs/advanced/versioned-writes

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. The write includes the version it read. The service updates only if that version still matches, then increments the version. Real storage must perform the compare and update atomically.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/versioned-writes. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The first edit survives and the stale write returns conflict. Your workflow retains both versions for an explicit decision.

Build your change

Design the browser conflict message: preserve the unsaved edit and show the latest version. Add a refresh-and-retry test that does not silently overwrite without learner confirmation.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The first edit survives and the stale write returns conflict. Your workflow retains both versions for an explicit decision.

Break, repair and explain

Deliberately violate this boundary: This single-process model is not a distributed lock or a complete merge strategy. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The first edit survives and the stale write returns conflict. Your workflow retains both versions for an explicit decision.

Troubleshoot: My result does not match Concurrent edits: detect lost updates: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The write includes the version it read. The service updates only if that version still matches, then increments the version. Real storage must perform the compare and update atomically. Then inspect this limit: This single-process model is not a distributed lock or a complete merge strategy. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/versioned-writes/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Concurrent edits: detect lost updates line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A librarian accepts a replacement page only when its edition number matches the current edition.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Where must the version comparison and update be atomic? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This single-process model is not a distributed lock or a complete merge strategy. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Where must the version comparison and update be atomic?

Interview: Where must the version comparison and update be atomic? Defend your answer using your actual lab result and this boundary: This single-process model is not a distributed lock or a complete merge strategy.

Quiz: Where must the version comparison and update be atomic?

Only in the browser.

At the storage write boundary.

In a CSS rule.

Reference: At the storage write boundary. — A read-then-write race remains possible unless the storage operation conditions the update on the version.

Sources:

PostgreSQL: relational database tutorial: https://www.postgresql.org/docs/current/tutorial.html

### Caching: define staleness and isolation

A cache reuses a previous result to reduce work. Its key, expiry and invalidation policy determine which result can be reused and for how long. A fast wrong result is still a defect.

How it works
Include tenant identity in the key when the same resource name belongs to different tenants. Use an injected clock to test expiry exactly at its boundary, without waiting in real time.

Where the model stops
A local Map is not a shared cache. This exercise does not handle eviction pressure or cross-process invalidation.

Make one change
Add explicit invalidation after a successful update. Test that one tenant invalidation does not delete another tenant entry and describe what a second server process would require.

Mental model: A dated photocopy is useful only if it belongs to the right person and has not expired.

Boundary: A local Map is not a shared cache. This exercise does not handle eviction pressure or cross-process invalidation.

Worked example: import assert from 'node:assert/strict';
const cache = new Map();
const key = (tenant,id) => JSON.stringify([tenant,id]);
function put(tenant,id,value,now) { cache.set(key(tenant,id),{value,expires:now+1000}); }
function get(tenant,id,now) { const e=cache.get(key(tenant,id)); return e && now<e.expires ? e.value : undefined; }
put('a',1,'Private A',0);
assert.equal(get('a',1,999),'Private A');
assert.equal(get('a',1,1000),undefined);
assert.equal(get('b',1,1),undefined);
console.log('PASS: expiry and tenant isolation');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/bounded-cache. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add explicit invalidation after a successful update. Test that one tenant invalidation does not delete another tenant entry and describe what a second server process would require.

Terminal folder: course-labs/advanced/bounded-cache

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Include tenant identity in the key when the same resource name belongs to different tenants. Use an injected clock to test expiry exactly at its boundary, without waiting in real time.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/bounded-cache. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The entry expires at 1000 and tenant b cannot receive tenant a data. Your update invalidates only its intended key.

Build your change

Add explicit invalidation after a successful update. Test that one tenant invalidation does not delete another tenant entry and describe what a second server process would require.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The entry expires at 1000 and tenant b cannot receive tenant a data. Your update invalidates only its intended key.

Break, repair and explain

Deliberately violate this boundary: A local Map is not a shared cache. This exercise does not handle eviction pressure or cross-process invalidation. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The entry expires at 1000 and tenant b cannot receive tenant a data. Your update invalidates only its intended key.

Troubleshoot: My result does not match Caching: define staleness and isolation: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Include tenant identity in the key when the same resource name belongs to different tenants. Use an injected clock to test expiry exactly at its boundary, without waiting in real time. Then inspect this limit: A local Map is not a shared cache. This exercise does not handle eviction pressure or cross-process invalidation. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/bounded-cache/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Caching: define staleness and isolation line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A dated photocopy is useful only if it belongs to the right person and has not expired.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: Why include tenant identity in this cache key? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A local Map is not a shared cache. This exercise does not handle eviction pressure or cross-process invalidation. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why include tenant identity in this cache key?

Interview: Why include tenant identity in this cache key? Defend your answer using your actual lab result and this boundary: A local Map is not a shared cache. This exercise does not handle eviction pressure or cross-process invalidation.

Quiz: Why include tenant identity in this cache key?

To compress the JSON.

To increase the timeout.

To prevent reuse across different data owners.

Reference: To prevent reuse across different data owners. — A shared resource id can refer to different tenants. Cache keys and permission checks both need the proper isolation boundary.

Sources:

OWASP: authorisation guidance: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Pagination: keep work and ordering bounded

An endpoint returning every record can overload both service and browser. Pagination limits one response. Stable ordering and a cursor make the next page meaningful as the dataset grows.

How it works
This example uses an increasing unique id as its ordering key. The cursor means strictly greater than the last id, and the server clamps the requested page size. Other sort orders need a matching compound cursor.

Where the model stops
This in-memory example scans a small array. A real database needs an appropriate index and a policy for concurrent inserts and deletes.

Make one change
Add a page after id 5 and a duplicate-id fixture. Explain why your chosen ordering must be unique or include a tie-breaker.

Mental model: A bookmark records the last item read, not just how many pages happened to exist.

Boundary: This in-memory example scans a small array. A real database needs an appropriate index and a policy for concurrent inserts and deletes.

Worked example: import assert from 'node:assert/strict';
const tasks=[1,2,3,4,5].map(id=>({id}));
function page(after=0,limit=2) {
  const size = Math.min(3,Math.max(1,Number.isInteger(limit)?limit:2));
  return tasks.filter(t=>t.id>after).sort((a,b)=>a.id-b.id).slice(0,size);
}
assert.deepEqual(page(2,2).map(t=>t.id),[3,4]);
assert.equal(page(0,1000).length,3);
console.log('PASS: cursor order and capped response');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/bounded-pagination. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a page after id 5 and a duplicate-id fixture. Explain why your chosen ordering must be unique or include a tie-breaker.

Terminal folder: course-labs/advanced/bounded-pagination

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. This example uses an increasing unique id as its ordering key. The cursor means strictly greater than the last id, and the server clamps the requested page size. Other sort orders need a matching compound cursor.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/bounded-pagination. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The cursor returns ids 3 and 4 and the large limit is capped. Your last page is empty and duplicate ordering has a documented policy.

Build your change

Add a page after id 5 and a duplicate-id fixture. Explain why your chosen ordering must be unique or include a tie-breaker.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The cursor returns ids 3 and 4 and the large limit is capped. Your last page is empty and duplicate ordering has a documented policy.

Break, repair and explain

Deliberately violate this boundary: This in-memory example scans a small array. A real database needs an appropriate index and a policy for concurrent inserts and deletes. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The cursor returns ids 3 and 4 and the large limit is capped. Your last page is empty and duplicate ordering has a documented policy.

Troubleshoot: My result does not match Pagination: keep work and ordering bounded: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: This example uses an increasing unique id as its ordering key. The cursor means strictly greater than the last id, and the server clamps the requested page size. Other sort orders need a matching compound cursor. Then inspect this limit: This in-memory example scans a small array. A real database needs an appropriate index and a policy for concurrent inserts and deletes. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/bounded-pagination/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Pagination: keep work and ordering bounded line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A bookmark records the last item read, not just how many pages happened to exist.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: A cursor sorted by timestamp alone encounters ties. What is missing? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This in-memory example scans a small array. A real database needs an appropriate index and a policy for concurrent inserts and deletes. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A cursor sorted by timestamp alone encounters ties. What is missing?

Interview: A cursor sorted by timestamp alone encounters ties. What is missing? Defend your answer using your actual lab result and this boundary: This in-memory example scans a small array. A real database needs an appropriate index and a policy for concurrent inserts and deletes.

Quiz: A cursor sorted by timestamp alone encounters ties. What is missing?

A deterministic tie-breaker such as id.

A brighter loading spinner.

A larger JSON parser.

Reference: A deterministic tie-breaker such as id. — A stable compound ordering prevents tied records from being skipped or repeated solely because their order is ambiguous.

Sources:

PostgreSQL: relational database tutorial: https://www.postgresql.org/docs/current/tutorial.html

### Release a vertical slice with honest evidence

A full-stack release connects user behaviour, service decisions and stored state. A useful release gate describes the behaviours checked and what can still fail. Tool names alone are not evidence.

How it works
List acceptance checks as named outcomes. Reject a release report when a required check is missing or failing. Keep security, accessibility and recovery as explicit test categories with actual observations.

Where the model stops
The gate below validates a report, not the application. Passing it does not run a browser, scan dependencies or deploy anything.

Make one change
Build a small task application using the earlier lessons. Replace each report flag with a linked observed result. Include a rollback rehearsal and a keyboard user journey before claiming them as tested.

Mental model: A bridge inspection follows the load across every joint, not just the newest bolt.

Boundary: The gate below validates a report, not the application. Passing it does not run a browser, scan dependencies or deploy anything.

Worked example: import assert from 'node:assert/strict';
const required=['create','invalid-input','owner-denial','conflict','recovery'];
const gate = report => required.every(name=>report[name] === true);
const report=Object.fromEntries(required.map(name=>[name,true]));
assert.equal(gate(report),true);
assert.equal(gate({...report,recovery:false}),false);
assert.equal(gate({create:true}),false);
console.log('PASS: complete, failing and incomplete report');


Setup: Download and extract fullstack.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/release-gate. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Build a small task application using the earlier lessons. Replace each report flag with a linked observed result. Include a rollback rehearsal and a keyboard user journey before claiming them as tested.

Terminal folder: course-labs/advanced/release-gate

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. List acceptance checks as named outcomes. Reject a release report when a required check is missing or failing. Keep security, accessibility and recovery as explicit test categories with actual observations.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/release-gate. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The report gate rejects missing or failed evidence. Your portfolio contains source, setup, test inputs/results and one repaired failure; it clearly separates executed checks from planned checks.

Build your change

Build a small task application using the earlier lessons. Replace each report flag with a linked observed result. Include a rollback rehearsal and a keyboard user journey before claiming them as tested.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The report gate rejects missing or failed evidence. Your portfolio contains source, setup, test inputs/results and one repaired failure; it clearly separates executed checks from planned checks.

Break, repair and explain

Deliberately violate this boundary: The gate below validates a report, not the application. Passing it does not run a browser, scan dependencies or deploy anything. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The report gate rejects missing or failed evidence. Your portfolio contains source, setup, test inputs/results and one repaired failure; it clearly separates executed checks from planned checks.

Troubleshoot: My result does not match Release a vertical slice with honest evidence: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: List acceptance checks as named outcomes. Reject a release report when a required check is missing or failing. Keep security, accessibility and recovery as explicit test categories with actual observations. Then inspect this limit: The gate below validates a report, not the application. Passing it does not run a browser, scan dependencies or deploy anything. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/release-gate/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Release a vertical slice with honest evidence line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A bridge inspection follows the load across every joint, not just the newest bolt.

seeker: Prepare a coursework example for Full-stack Developer. Answer this interview question before revealing the rubric: What does this report validator prove? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The gate below validates a report, not the application. Passing it does not run a browser, scan dependencies or deploy anything. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does this report validator prove?

Interview: What does this report validator prove? Defend your answer using your actual lab result and this boundary: The gate below validates a report, not the application. Passing it does not run a browser, scan dependencies or deploy anything.

Quiz: What does this report validator prove?

The application is production safe.

Only that the required report fields say true.

Every browser and cloud was tested.

Reference: Only that the required report fields say true. — A report validator cannot prove the observations are accurate. Review the linked artifacts and run the actual checks.

Sources:

Node.js: test runner: https://nodejs.org/api/test.html

OWASP: authorisation guidance: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### State and recovery

State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. In this role, work through: Add optional priority with a default while an older browser still sends only title. The practical workshop develops this into: Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Role application: Two editions of a form must be accepted while offices replace their stationery.

Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning.

Worked example: Add optional priority with a default while an older browser still sends only title.

Shared foundation example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Full-stack Developer: Add optional priority with a default while an older browser still sends only title.

Predict the worked case

Read this case without running a tool: Add optional priority with a default while an older browser still sends only title. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state and recovery.

Connect the concept to the role

Apply this rule: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database also fails; persistence needs backups and tested recovery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state and recovery to this case: Add optional priority with a default while an older browser still sends only title. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Add optional priority with a default while an older browser still sends only title. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for State and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state and recovery. Use the glossary below, then write your prediction for: Add optional priority with a default while an older browser still sends only title. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain state and recovery using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state and recovery to a system or workflow you know. Explain state and recovery using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Name two things required before calling this service production ready.

Interview: Explain state and recovery using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops.

Quiz: After the Compatible feature rollout rehearsal, check this foundation: A successful operation exists only in process memory. The process restarts. What can you promise?

The success response guarantees recovery after restart.

A retry will always reconstruct the original state.

Nothing about retention without a persistence and recovery design.

Reference: Nothing about retention without a persistence and recovery design. — An acknowledgment is not a storage guarantee. Identify the persistence boundary and verify restoration.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Compatible feature rollout

Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning. In this role, work through: Add optional priority with a default while an older browser still sends only title. The practical workshop develops this into: Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

Mental model: Two editions of a form must be accepted while offices replace their stationery.

Boundary: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.

Worked example: Add optional priority with a default while an older browser still sends only title.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Full-stack Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Add optional priority with a default while an older browser still sends only title. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

```
node app.mjs test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Role workshop · debug and verify

A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save compatibility-matrix.md and a versioned deployment rehearsal. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Troubleshoot: The role exercise differs from the prediction: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: compatibility-matrix.md and a versioned deployment rehearsal; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with compatible feature rollout. Use the glossary below, then write your prediction for: Add optional priority with a default while an older browser still sends only title. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain compatible feature rollout using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate compatible feature rollout to a system or workflow you know. Explain compatible feature rollout using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.

Interview: Explain compatible feature rollout using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Add optional priority with a default while an older browser still sends only title.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Reference: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand. — Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning. Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
