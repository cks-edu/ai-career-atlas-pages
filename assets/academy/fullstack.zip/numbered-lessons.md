# Full-stack Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in Full-stack Developer: Use the concept to complete this role exercise: Trace one task from form through HTTP to the server list

Trace a vertical slice: A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation.

### Request and response

A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. In this role, work through: Create Task A in the browser and match its returned ID to GET /api/tasks. The practical workshop develops this into: Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Role application: Follow one parcel through every desk until its receipt matches the original order.

A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation.

Worked example: Create Task A in the browser and match its returned ID to GET /api/tasks.

Shared foundation example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Full-stack Developer: Create Task A in the browser and match its returned ID to GET /api/tasks.

Predict the worked case

Read this case without running a tool: Create Task A in the browser and match its returned ID to GET /api/tasks. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in request and response.

Connect the concept to the role

Apply this rule: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Networks can time out; sending an order does not prove it was fulfilled.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies request and response to this case: Create Task A in the browser and match its returned ID to GET /api/tasks. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Create Task A in the browser and match its returned ID to GET /api/tasks. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Request and response; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request and response. Use the glossary below, then write your prediction for: Create Task A in the browser and match its returned ID to GET /api/tasks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain request and response using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request and response to a system or workflow you know. Explain request and response using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Draw the request and response for adding one task.

Interview: Explain request and response using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops.

Quiz: After the Trace a vertical slice rehearsal, check this foundation: A request returns HTTP 404. Which boundary has evidence of working?

An HTTP server returned a response; inspect the route next.

The request never reached any HTTP server.

The server has confirmed that the resource exists.

Reference: An HTTP server returned a response; inspect the route next. — 404 is an HTTP response, not a transport timeout. It does not prove which component generated it or that the business operation succeeded.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Trace a vertical slice

A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation. In this role, work through: Create Task A in the browser and match its returned ID to GET /api/tasks. The practical workshop develops this into: Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

Mental model: Follow one parcel through every desk until its receipt matches the original order.

Boundary: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.

Worked example: Create Task A in the browser and match its returned ID to GET /api/tasks.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Full-stack Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Create Task A in the browser and match its returned ID to GET /api/tasks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.

```
node app.mjs
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One ID and one title match across all five boundaries.

Role workshop · debug and verify

A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save vertical-slice.md with a sequence diagram and redacted HTTP examples. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One ID and one title match across all five boundaries.

Expected: One ID and one title match across all five boundaries.

Troubleshoot: The role exercise differs from the prediction: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: vertical-slice.md with a sequence diagram and redacted HTTP examples; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with trace a vertical slice. Use the glossary below, then write your prediction for: Create Task A in the browser and match its returned ID to GET /api/tasks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain trace a vertical slice using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate trace a vertical slice to a system or workflow you know. Explain trace a vertical slice using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.

Interview: Explain trace a vertical slice using this case: Create Task A in the browser and match its returned ID to GET /api/tasks. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Create Task A in the browser and match its returned ID to GET /api/tasks.

One ID and one title match across all five boundaries.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: One ID and one title match across all five boundaries. — A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation. One ID and one title match across all five boundaries.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in Full-stack Developer: Use the concept to complete this role exercise: Add a storage adapter and test the same request through UI and API

Storage adapter contract: Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details.

### Validation at a boundary

Check input before storing or using it. Client checks help people; the server must also enforce the rule. In this role, work through: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. The practical workshop develops this into: Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Role application: Replace a filing cabinet while keeping the front desk request form unchanged.

Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details.

Worked example: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Shared foundation example: A blank title receives 400 and does not change task count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Full-stack Developer: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Predict the worked case

Read this case without running a tool: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in validation at a boundary.

Connect the concept to the role

Apply this rule: Check input before storing or using it. Client checks help people; the server must also enforce the rule. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid input can still be unauthorized; validation is not access control.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies validation at a boundary to this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Validation at a boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with validation at a boundary. Use the glossary below, then write your prediction for: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain validation at a boundary using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate validation at a boundary to a system or workflow you know. Explain validation at a boundary using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Explain validation at a boundary using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops.

Quiz: After the Storage adapter contract rehearsal, check this foundation: A browser rejects a blank field. A second client calls the API directly. Where must the same business rule be enforced?

Only in the browser to avoid duplicate logic.

At the server boundary before state changes.

Only after storing the input, in the dashboard.

Reference: At the server boundary before state changes. — Client checks improve feedback; the server must protect its contract for every caller.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Storage adapter contract

Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details. In this role, work through: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. The practical workshop develops this into: Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

Mental model: Replace a filing cabinet while keeping the front desk request form unchanged.

Boundary: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.

Worked example: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Full-stack Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.

```
node app.mjs test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

Role workshop · debug and verify

If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save storage-adapter code, restart transcript and adapter contract tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

Expected: Task A survives restart; invalid titles never reach storage; tests isolate their files.

Troubleshoot: The role exercise differs from the prediction: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: storage-adapter code, restart transcript and adapter contract tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with storage adapter contract. Use the glossary below, then write your prediction for: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain storage adapter contract using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate storage adapter contract to a system or workflow you know. Explain storage adapter contract using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.

Interview: Explain storage adapter contract using this case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.

Ignore the failing case and keep only the successful screenshot.

Task A survives restart; invalid titles never reach storage; tests isolate their files.

Treat any successful command as proof that all business and access rules passed.

Reference: Task A survives restart; invalid titles never reach storage; tests isolate their files. — Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details. Task A survives restart; invalid titles never reach storage; tests isolate their files.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in Full-stack Developer: Use the concept to complete this role exercise: Write a rollout plan covering schema compatibility and rollback

Compatible feature rollout: Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning.

### State and recovery

State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. In this role, work through: Add optional priority with a default while an older browser still sends only title. The practical workshop develops this into: Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Role application: Two editions of a form must be accepted while offices replace their stationery.

Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning.

Worked example: Add optional priority with a default while an older browser still sends only title.

Shared foundation example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Full-stack Developer: Add optional priority with a default while an older browser still sends only title.

Predict the worked case

Read this case without running a tool: Add optional priority with a default while an older browser still sends only title. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state and recovery.

Connect the concept to the role

Apply this rule: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database also fails; persistence needs backups and tested recovery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state and recovery to this case: Add optional priority with a default while an older browser still sends only title. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Add optional priority with a default while an older browser still sends only title. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for State and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state and recovery. Use the glossary below, then write your prediction for: Add optional priority with a default while an older browser still sends only title. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain state and recovery using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state and recovery to a system or workflow you know. Explain state and recovery using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Name two things required before calling this service production ready.

Interview: Explain state and recovery using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops.

Quiz: After the Compatible feature rollout rehearsal, check this foundation: A successful operation exists only in process memory. The process restarts. What can you promise?

The success response guarantees recovery after restart.

A retry will always reconstruct the original state.

Nothing about retention without a persistence and recovery design.

Reference: Nothing about retention without a persistence and recovery design. — An acknowledgment is not a storage guarantee. Identify the persistence boundary and verify restoration.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Compatible feature rollout

Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning. In this role, work through: Add optional priority with a default while an older browser still sends only title. The practical workshop develops this into: Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

Mental model: Two editions of a form must be accepted while offices replace their stationery.

Boundary: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.

Worked example: Add optional priority with a default while an older browser still sends only title.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Full-stack Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Add optional priority with a default while an older browser still sends only title. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.

```
node app.mjs test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Role workshop · debug and verify

A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save compatibility-matrix.md and a versioned deployment rehearsal. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Expected: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Troubleshoot: The role exercise differs from the prediction: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: compatibility-matrix.md and a versioned deployment rehearsal; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with compatible feature rollout. Use the glossary below, then write your prediction for: Add optional priority with a default while an older browser still sends only title. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Full-stack Developer role interview. Explain compatible feature rollout using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate compatible feature rollout to a system or workflow you know. Explain compatible feature rollout using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.

Interview: Explain compatible feature rollout using this case: Add optional priority with a default while an older browser still sends only title. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Add optional priority with a default while an older browser still sends only title.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Reference: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand. — Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning. Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
