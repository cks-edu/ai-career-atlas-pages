# Full-stack Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Trace a vertical slice

A full-stack feature crosses UI, HTTP validation and storage. Give one request a traceable identity and compare the displayed result with the stored result rather than testing each layer in isolation.
Mental model: Follow one parcel through every desk until its receipt matches the original order.
Case: Create Task A in the browser and match its returned ID to GET /api/tasks.
Task: Run app.mjs, use the Network panel to capture the POST body and response, then request the list. Draw the sequence UI → handler → in-memory array → response → UI with exact field names.
Acceptance: One ID and one title match across all five boundaries.
Troubleshooting: A correct POST with a blank UI points to rendering; a missing GET record points to server state or a different server instance.
Deliverable: vertical-slice.md with a sequence diagram and redacted HTTP examples

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Storage adapter contract

Separate operations such as list and create from their storage implementation. This lets the same behavioral tests check both the initial array and a durable implementation without binding UI code to database details.
Mental model: Replace a filing cabinet while keeping the front desk request form unchanged.
Case: After restart an array loses Task A; a saved JSON or SQLite adapter should retain it.
Task: Extract list/create functions, add a file-backed adapter in a separate module and use a temporary file for tests. Validate before writing. Restart the service and compare IDs, count and titles. Record concurrent-write limitations of a simple file adapter.
Acceptance: Task A survives restart; invalid titles never reach storage; tests isolate their files.
Troubleshooting: If the file exists but data disappears, check startup loading and resolved path. Never silently replace an unreadable database with an empty one.
Deliverable: storage-adapter code, restart transcript and adapter contract tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Compatible feature rollout

Clients and servers may run different releases during deployment. Add fields compatibly, keep old requests valid and test recovery before removing a field or changing its meaning.
Mental model: Two editions of a form must be accepted while offices replace their stationery.
Case: Add optional priority with a default while an older browser still sends only title.
Task: Define v1 and v2 request fixtures. Implement an optional priority field, test both, then run the old client against the new handler. Write expand, deploy, observe and contract phases; include a data-backup checkpoint.
Acceptance: Both request versions work during rollout; rollback assumptions identify stored fields the older server cannot understand.
Troubleshooting: A failing old fixture is a compatibility break even if the new UI passes. Restore the previous contract before rollout.
Deliverable: compatibility-matrix.md and a versioned deployment rehearsal

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
