# Azure Data Engineer

Software Engineering

Start with adf connection, data and work objects. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Azure data operations portfolio with quality gate and recovery evidence.

## beginner

Run beginner, draw the source linked service/dataset → Copy activity → target dataset/linked service, and map each fixture field. Follow the official Blob-to-SQL tutorial only in a permitted subscription with an isolated resource group.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### ADF connection, data and work objects
In Azure Data Factory a linked service describes connectivity, a dataset describes data and an activity performs work. Identity and network permissions are additional requirements; successful connection tests do not prove a valid table mapping.
Mental model: An address book says where, a catalog says what and a work order says which operation to perform.
Limit: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary.
Example: The local contract copies valid orders to a target while reporting invalid rows separately.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary.

1. Inspect the business fixture
The local contract copies valid orders to a target while reporting invalid rows separately. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run beginner, draw the source linked service/dataset → Copy activity → target dataset/linked service, and map each fixture field. Follow the official Blob-to-SQL tutorial only in a permitted subscription with an isolated resource group.
```
python3 enterprise_lab.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py beginner --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Run the official Azure copy tutorial
Use an authorized subscription, approved region and a dedicated lab resource group. Review costs before creating Data Factory, storage and SQL resources. Follow the linked Blob-to-SQL tutorial for its exact sample/setup; record linked services, datasets and Copy activity. Keep the official tutorial’s expected results separate from our custom fixture.
Expected: The official sample completes and its row counts match its guide; paid cloud execution is optional and not represented by the local Python result.

6. Assemble the portfolio evidence
Create ADF object map and copy contract. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: ADF object map and copy contract
Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

Interview: Work through this Azure Data Engineer case: The local contract copies valid orders to a target while reporting invalid rows separately. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: In Azure Data Factory a linked service describes connectivity, a dataset describes data and an activity performs work. Identity and network permissions are additional requirements; successful connection tests do not prove a valid table mapping. Expected evidence: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately. Diagnosis: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary. State the limits of the mental model: An address book says where, a catalog says what and a work order says which operation to perform.

Resume: Built ADF object map and copy contract using Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run intermediate, inspect the old < version <= new predicate, and sketch Lookup old → Lookup new → Copy → quality gate → watermark update. Compare with Microsoft's incremental tutorial and document the extra quality gate.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Bounded incremental windows
Capture an old and new high watermark, process the intended window and advance state only after output is validated. The fixture uses monotonic integer versions; real timestamps need tie, late-arrival and delete policies.
Mental model: A courier takes a numbered batch and moves the bookmark after delivery is checked.
Limit: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation.
Example: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation.

1. Inspect the business fixture
Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run intermediate, inspect the old < version <= new predicate, and sketch Lookup old → Lookup new → Copy → quality gate → watermark update. Compare with Microsoft's incremental tutorial and document the extra quality gate.
```
python3 enterprise_lab.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Three unique target orders, total 37 and checkpoint 3.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py intermediate --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Add an incremental pipeline
Follow the separate Azure SQL-to-Blob incremental tutorial, which has a different source/sink direction from the beginner copy tutorial. Create old/new watermark Lookups, the bounded Copy query and the success-dependent watermark update. Then design the additional business reconciliation gate for your own fixture.
Expected: First and second runs copy their expected windows; checkpoint values and output files are recorded. Watermark semantics and source direction are explicit.

6. Assemble the portfolio evidence
Create incremental pipeline design and window-boundary tests. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Three unique target orders, total 37 and checkpoint 3.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: incremental pipeline design and window-boundary tests
Three unique target orders, total 37 and checkpoint 3.

Interview: Work through this Azure Data Engineer case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Capture an old and new high watermark, process the intended window and advance state only after output is validated. The fixture uses monotonic integer versions; real timestamps need tie, late-arrival and delete policies. Expected evidence: Three unique target orders, total 37 and checkpoint 3. Diagnosis: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation. State the limits of the mental model: A courier takes a numbered batch and moves the bookmark after delivery is checked.

Resume: Built incremental pipeline design and window-boundary tests using Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run advanced and the deliberate broken checkpoint case. Write a cloud runbook covering Monitor activity details, rejected IDs, managed-identity role assignment, network reachability, replay and deletion of only the lab resources.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Quality gates, failure and identity
A green activity can still produce incomplete business data. Gate publication on reconciled records and protect connection access with a minimally authorized identity; resource cleanup is part of a cloud lab.
Mental model: A delivered shipment is not accepted until its contents match the manifest.
Limit: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries.
Example: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries.

1. Inspect the business fixture
A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run advanced and the deliberate broken checkpoint case. Write a cloud runbook covering Monitor activity details, rejected IDs, managed-identity role assignment, network reachability, replay and deletion of only the lab resources.
```
python3 enterprise_lab.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py advanced --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Observe, authorize and clean up
Inspect Monitor → pipeline run → activity details, identify error codes and reconcile source/target IDs. For a managed-identity variant, configure the supported connector identity and its required data access using current docs. Stop triggers and remove only resources belonging to this dedicated lab after saving evidence.
Expected: A recovery report plus a checked resource inventory; no claim that a budget alert alone caps spending.

6. Assemble the portfolio evidence
Create Azure data operations portfolio with quality gate and recovery evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: Azure data operations portfolio with quality gate and recovery evidence
Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

Interview: Work through this Azure Data Engineer case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A green activity can still produce incomplete business data. Gate publication on reconciled records and protect connection access with a minimally authorized identity; resource cleanup is part of a cloud lab. Expected evidence: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals. Diagnosis: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries. State the limits of the mental model: A delivered shipment is not accepted until its contents match the manifest.

Resume: Built Azure data operations portfolio with quality gate and recovery evidence using Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Azure Data Factory: copy data tutorial: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-copy-data-portal
Microsoft: incremental copy with a watermark: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-incremental-copy-portal
Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer
