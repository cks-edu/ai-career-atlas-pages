# Azure Data Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Linked service, dataset and activity: In Azure Data Factory, a linked service describes connection information, a dataset describes data, and an activity performs an operation within a pipeline.

ADF: Azure Data Factory: a managed service for orchestrating data movement and transformation.

ADLS Gen2: Azure Data Lake Storage Gen2: data-lake capabilities built on Azure Blob Storage.

Managed identity: An Azure-managed identity for supported resources; it still needs the appropriate permissions.

Watermark: A saved source boundary used for incremental processing; its ordering and update semantics must be defined.

ADF connection, data and work objects: In Azure Data Factory a linked service describes connectivity, a dataset describes data and an activity performs work. Identity and network permissions are additional requirements; successful connection tests do not prove a valid table mapping.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: The local contract copies valid orders to a target while reporting invalid rows separately. The practical workshop develops this into: Run beginner, draw the source linked service/dataset → Copy activity → target dataset/linked service, and map each fixture field. Follow the official Blob-to-SQL tutorial only in a permitted subscription with an isolated resource group.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: An address book says where, a catalog says what and a work order says which operation to perform.

In Azure Data Factory a linked service describes connectivity, a dataset describes data and an activity performs work. Identity and network permissions are additional requirements; successful connection tests do not prove a valid table mapping.

Worked example: The local contract copies valid orders to a target while reporting invalid rows separately.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Azure Data Engineer: The local contract copies valid orders to a target while reporting invalid rows separately.

Predict the worked case

Read this case without running a tool: The local contract copies valid orders to a target while reporting invalid rows separately. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: The local contract copies valid orders to a target while reporting invalid rows separately. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The local contract copies valid orders to a target while reporting invalid rows separately. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: The local contract copies valid orders to a target while reporting invalid rows separately. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Azure Data Engineer role interview. Explain keys and constraints using this case: The local contract copies valid orders to a target while reporting invalid rows separately. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: The local contract copies valid orders to a target while reporting invalid rows separately. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: The local contract copies valid orders to a target while reporting invalid rows separately. State the evidence, one alternative and where the mental model stops.

Quiz: After the ADF connection, data and work objects rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Azure Data Factory: copy data tutorial: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-copy-data-portal

Microsoft: incremental copy with a watermark: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-incremental-copy-portal

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

### ADF connection, data and work objects

In Azure Data Factory a linked service describes connectivity, a dataset describes data and an activity performs work. Identity and network permissions are additional requirements; successful connection tests do not prove a valid table mapping. In this role, work through: The local contract copies valid orders to a target while reporting invalid rows separately. The practical workshop develops this into: Run beginner, draw the source linked service/dataset → Copy activity → target dataset/linked service, and map each fixture field. Follow the official Blob-to-SQL tutorial only in a permitted subscription with an isolated resource group.

Mental model: An address book says where, a catalog says what and a work order says which operation to perform.

Boundary: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary.

Worked example: The local contract copies valid orders to a target while reporting invalid rows separately.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run beginner, draw the source linked service/dataset → Copy activity → target dataset/linked service, and map each fixture field. Follow the official Blob-to-SQL tutorial only in a permitted subscription with an isolated resource group.

Inspect the business fixture

The local contract copies valid orders to a target while reporting invalid rows separately. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run beginner, draw the source linked service/dataset → Copy activity → target dataset/linked service, and map each fixture field. Follow the official Blob-to-SQL tutorial only in a permitted subscription with an isolated resource group.

```
python3 enterprise_lab.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py beginner --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Run the official Azure copy tutorial

Use an authorized subscription, approved region and a dedicated lab resource group. Review costs before creating Data Factory, storage and SQL resources. Follow the linked Blob-to-SQL tutorial for its exact sample/setup; record linked services, datasets and Copy activity. Keep the official tutorial’s expected results separate from our custom fixture.

Expected: The official sample completes and its row counts match its guide; paid cloud execution is optional and not represented by the local Python result.

Assemble the portfolio evidence

Create ADF object map and copy contract. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

Expected: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

Troubleshoot: The role exercise differs from the prediction: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-beginner-2.md: ADF object map and copy contract; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with adf connection, data and work objects. Use the glossary below, then write your prediction for: The local contract copies valid orders to a target while reporting invalid rows separately. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Azure Data Engineer role interview. Explain adf connection, data and work objects using this case: The local contract copies valid orders to a target while reporting invalid rows separately. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate adf connection, data and work objects to a system or workflow you know. Explain adf connection, data and work objects using this case: The local contract copies valid orders to a target while reporting invalid rows separately. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary.

Interview: Explain adf connection, data and work objects using this case: The local contract copies valid orders to a target while reporting invalid rows separately. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? The local contract copies valid orders to a target while reporting invalid rows separately.

Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately. — In Azure Data Factory a linked service describes connectivity, a dataset describes data and an activity performs work. Identity and network permissions are additional requirements; successful connection tests do not prove a valid table mapping. Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.

Sources:

Azure Data Factory: copy data tutorial: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-copy-data-portal

Microsoft: incremental copy with a watermark: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-incremental-copy-portal

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Incremental load and identity: Copy only the intended new or changed records and use an identity with minimal source/target access. Preserve replay evidence.

ADF: Azure Data Factory: a managed service for orchestrating data movement and transformation.

ADLS Gen2: Azure Data Lake Storage Gen2: data-lake capabilities built on Azure Blob Storage.

Managed identity: An Azure-managed identity for supported resources; it still needs the appropriate permissions.

Watermark: A saved source boundary used for incremental processing; its ordering and update semantics must be defined.

Bounded incremental windows: Capture an old and new high watermark, process the intended window and advance state only after output is validated. The fixture uses monotonic integer versions; real timestamps need tie, late-arrival and delete policies.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. The practical workshop develops this into: Run intermediate, inspect the old < version <= new predicate, and sketch Lookup old → Lookup new → Copy → quality gate → watermark update. Compare with Microsoft's incremental tutorial and document the extra quality gate.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: A courier takes a numbered batch and moves the bookmark after delivery is checked.

Capture an old and new high watermark, process the intended window and advance state only after output is validated. The fixture uses monotonic integer versions; real timestamps need tie, late-arrival and delete policies.

Worked example: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Azure Data Engineer: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37.

Predict the worked case

Read this case without running a tool: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Azure Data Engineer role interview. Explain idempotent processing using this case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. State the evidence, one alternative and where the mental model stops.

Quiz: After the Bounded incremental windows rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Azure Data Factory: copy data tutorial: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-copy-data-portal

Microsoft: incremental copy with a watermark: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-incremental-copy-portal

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

### Bounded incremental windows

Capture an old and new high watermark, process the intended window and advance state only after output is validated. The fixture uses monotonic integer versions; real timestamps need tie, late-arrival and delete policies. In this role, work through: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. The practical workshop develops this into: Run intermediate, inspect the old < version <= new predicate, and sketch Lookup old → Lookup new → Copy → quality gate → watermark update. Compare with Microsoft's incremental tutorial and document the extra quality gate.

Mental model: A courier takes a numbered batch and moves the bookmark after delivery is checked.

Boundary: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation.

Worked example: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run intermediate, inspect the old < version <= new predicate, and sketch Lookup old → Lookup new → Copy → quality gate → watermark update. Compare with Microsoft's incremental tutorial and document the extra quality gate.

Inspect the business fixture

Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run intermediate, inspect the old < version <= new predicate, and sketch Lookup old → Lookup new → Copy → quality gate → watermark update. Compare with Microsoft's incremental tutorial and document the extra quality gate.

```
python3 enterprise_lab.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Three unique target orders, total 37 and checkpoint 3.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py intermediate --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Add an incremental pipeline

Follow the separate Azure SQL-to-Blob incremental tutorial, which has a different source/sink direction from the beginner copy tutorial. Create old/new watermark Lookups, the bounded Copy query and the success-dependent watermark update. Then design the additional business reconciliation gate for your own fixture.

Expected: First and second runs copy their expected windows; checkpoint values and output files are recorded. Watermark semantics and source direction are explicit.

Assemble the portfolio evidence

Create incremental pipeline design and window-boundary tests. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Three unique target orders, total 37 and checkpoint 3.

Expected: Three unique target orders, total 37 and checkpoint 3.

Troubleshoot: The role exercise differs from the prediction: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-intermediate-2.md: incremental pipeline design and window-boundary tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with bounded incremental windows. Use the glossary below, then write your prediction for: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Azure Data Engineer role interview. Explain bounded incremental windows using this case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate bounded incremental windows to a system or workflow you know. Explain bounded incremental windows using this case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation.

Interview: Explain bounded incremental windows using this case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37.

Ignore the failing case and keep only the successful screenshot.

Three unique target orders, total 37 and checkpoint 3.

Treat any successful command as proof that all business and access rules passed.

Reference: Three unique target orders, total 37 and checkpoint 3. — Capture an old and new high watermark, process the intended window and advance state only after output is validated. The fixture uses monotonic integer versions; real timestamps need tie, late-arrival and delete policies. Three unique target orders, total 37 and checkpoint 3.

Sources:

Azure Data Factory: copy data tutorial: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-copy-data-portal

Microsoft: incremental copy with a watermark: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-incremental-copy-portal

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Orchestration and data quality: A pipeline coordinates dependent tasks. Release criteria should include completeness, freshness, reconciliation and recoverability.

ADF: Azure Data Factory: a managed service for orchestrating data movement and transformation.

ADLS Gen2: Azure Data Lake Storage Gen2: data-lake capabilities built on Azure Blob Storage.

Managed identity: An Azure-managed identity for supported resources; it still needs the appropriate permissions.

Watermark: A saved source boundary used for incremental processing; its ordering and update semantics must be defined.

Quality gates, failure and identity: A green activity can still produce incomplete business data. Gate publication on reconciled records and protect connection access with a minimally authorized identity; resource cleanup is part of a cloud lab.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. The practical workshop develops this into: Run advanced and the deliberate broken checkpoint case. Write a cloud runbook covering Monitor activity details, rejected IDs, managed-identity role assignment, network reachability, replay and deletion of only the lab resources.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: A delivered shipment is not accepted until its contents match the manifest.

A green activity can still produce incomplete business data. Gate publication on reconciled records and protect connection access with a minimally authorized identity; resource cleanup is part of a cloud lab.

Worked example: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Azure Data Engineer: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37.

Predict the worked case

Read this case without running a tool: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Azure Data Engineer role interview. Explain transaction and recovery using this case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. State the evidence, one alternative and where the mental model stops.

Quiz: After the Quality gates, failure and identity rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Azure Data Factory: copy data tutorial: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-copy-data-portal

Microsoft: incremental copy with a watermark: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-incremental-copy-portal

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

### Quality gates, failure and identity

A green activity can still produce incomplete business data. Gate publication on reconciled records and protect connection access with a minimally authorized identity; resource cleanup is part of a cloud lab. In this role, work through: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. The practical workshop develops this into: Run advanced and the deliberate broken checkpoint case. Write a cloud runbook covering Monitor activity details, rejected IDs, managed-identity role assignment, network reachability, replay and deletion of only the lab resources.

Mental model: A delivered shipment is not accepted until its contents match the manifest.

Boundary: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries.

Worked example: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Azure Data Factory, ADLS Gen2, Azure Databricks and Microsoft Fabric (Commercial cloud services); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run advanced and the deliberate broken checkpoint case. Write a cloud runbook covering Monitor activity details, rejected IDs, managed-identity role assignment, network reachability, replay and deletion of only the lab resources.

Inspect the business fixture

A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run advanced and the deliberate broken checkpoint case. Write a cloud runbook covering Monitor activity details, rejected IDs, managed-identity role assignment, network reachability, replay and deletion of only the lab resources.

```
python3 enterprise_lab.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py advanced --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Observe, authorize and clean up

Inspect Monitor → pipeline run → activity details, identify error codes and reconcile source/target IDs. For a managed-identity variant, configure the supported connector identity and its required data access using current docs. Stop triggers and remove only resources belonging to this dedicated lab after saving evidence.

Expected: A recovery report plus a checked resource inventory; no claim that a budget alert alone caps spending.

Assemble the portfolio evidence

Create Azure data operations portfolio with quality gate and recovery evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

Expected: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

Troubleshoot: The role exercise differs from the prediction: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-advanced-2.md: Azure data operations portfolio with quality gate and recovery evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with quality gates, failure and identity. Use the glossary below, then write your prediction for: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Azure Data Engineer role interview. Explain quality gates, failure and identity using this case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate quality gates, failure and identity to a system or workflow you know. Explain quality gates, failure and identity using this case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries.

Interview: Explain quality gates, failure and identity using this case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

Reference: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals. — A green activity can still produce incomplete business data. Gate publication on reconciled records and protect connection access with a minimally authorized identity; resource cleanup is part of a cloud lab. Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.

Sources:

Azure Data Factory: copy data tutorial: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-copy-data-portal

Microsoft: incremental copy with a watermark: https://learn.microsoft.com/en-us/azure/data-factory/tutorial-incremental-copy-portal

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer
