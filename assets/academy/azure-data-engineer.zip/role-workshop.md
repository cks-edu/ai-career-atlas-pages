# Azure Data Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
ADF connection, data and work objects

In Azure Data Factory a linked service describes connectivity, a dataset describes data and an activity performs work. Identity and network permissions are additional requirements; successful connection tests do not prove a valid table mapping.
Mental model: An address book says where, a catalog says what and a work order says which operation to perform.
Case: The local contract copies valid orders to a target while reporting invalid rows separately.
Task: Run beginner, draw the source linked service/dataset → Copy activity → target dataset/linked service, and map each fixture field. Follow the official Blob-to-SQL tutorial only in a permitted subscription with an isolated resource group.
Acceptance: Two accepted orders totaling 30 in the simulation; actual Azure results must be recorded separately.
Troubleshooting: A correct connection with a wrong dataset/table still fails; inspect the object configured at each boundary.
Deliverable: ADF object map and copy contract

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Bounded incremental windows

Capture an old and new high watermark, process the intended window and advance state only after output is validated. The fixture uses monotonic integer versions; real timestamps need tie, late-arrival and delete policies.
Mental model: A courier takes a numbered batch and moves the bookmark after delivery is checked.
Case: Versions greater than 1 and at most 3 update a to 12 and add e=5; target total becomes 37.
Task: Run intermediate, inspect the old < version <= new predicate, and sketch Lookup old → Lookup new → Copy → quality gate → watermark update. Compare with Microsoft's incremental tutorial and document the extra quality gate.
Acceptance: Three unique target orders, total 37 and checkpoint 3.
Troubleshooting: Using only the wall clock as a watermark can miss late updates; specify source semantics and lookback/reconciliation.
Deliverable: incremental pipeline design and window-boundary tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Quality gates, failure and identity

A green activity can still produce incomplete business data. Gate publication on reconciled records and protect connection access with a minimally authorized identity; resource cleanup is part of a cloud lab.
Mental model: A delivered shipment is not accepted until its contents match the manifest.
Case: A simulated target failure must leave checkpoint 1 and original total 30; a successful replay reaches 37.
Task: Run advanced and the deliberate broken checkpoint case. Write a cloud runbook covering Monitor activity details, rejected IDs, managed-identity role assignment, network reachability, replay and deletion of only the lab resources.
Acceptance: Failed work cannot advance the checkpoint in the reference; recovery has matching IDs and totals.
Troubleshooting: A 403 suggests authorization; a timeout may involve networking; neither is solved by blindly increasing retries.
Deliverable: Azure data operations portfolio with quality gate and recovery evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
