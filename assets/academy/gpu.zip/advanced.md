## advanced — GPU incident diagnosis

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### GPU incident diagnosis
Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse.
Mental model: A warning light prompts inspection of the vehicle, not just restarting the dashboard.
Boundary: Hardware maintenance requires authorized access and platform-specific procedures.
Worked example: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: GPU workload isolation and capacity lab
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Recall: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. Identify one observation that would contradict your claim.

### Terms
GPU incident diagnosis: Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.
Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.
Compare partitioning or sharing modes supported by your specific hardware, including unsupported cases and operational cost.
Deliverables: Hardware and driver inventory; Memory/latency sweep with raw logs; GPU allocation and isolation ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A reviewer must reproduce one result and identify which capabilities you implemented. Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

### Interview
Explain your advanced solution for GPU infrastructure engineer. Use this scenario: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Review: Start with the task and permitted scope. Explain gpu incident diagnosis: Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse. Show the input and observed output, then address Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Hardware and driver inventory; Memory/latency sweep with raw logs; GPU allocation and isolation ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

