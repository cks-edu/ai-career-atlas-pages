## intermediate — Placement and resource accounting

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build strong Linux, Kubernetes, networking and storage skills. Add CUDA/runtime literacy and distributed-system troubleshooting. Hardware-dependent skills cannot be demonstrated solely with a laptop simulation.

### Placement and resource accounting
GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations.
Mental model: Assign seats and luggage capacity before boarding a vehicle.
Boundary: A scheduler's GPU count does not represent every memory or bandwidth constraint.
Worked example: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: GPU workload isolation and capacity lab
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Recall: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. Identify one observation that would contradict your claim.

### Terms
Placement and resource accounting: GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.
Deliverables: Hardware and driver inventory; Memory/latency sweep with raw logs. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for GPU infrastructure engineer. Use this scenario: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Review: Start with the task and permitted scope. Explain placement and resource accounting: GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations. Show the input and observed output, then address Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Hardware and driver inventory; Memory/latency sweep with raw logs. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

