# GPU infrastructure engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Accelerator compatibility: A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Accelerator compatibility

A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components. In this role, work through: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An appliance needs the right socket, voltage and adapter together.

Boundary: A CPU fallback proves code execution, not GPU availability.

Worked example: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware); Kubernetes security contexts (Open source · local or cloud)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for GPU infrastructure engineer: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility.

Predict the worked case

Read this case without running a tool: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in accelerator compatibility.

Connect the concept to the role

Apply this rule: A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A CPU fallback proves code execution, not GPU availability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies accelerator compatibility to this case: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Accelerator compatibility; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with accelerator compatibility. Use the glossary below, then write your prediction for: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GPU infrastructure engineer role interview. Explain accelerator compatibility using this case: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate accelerator compatibility to a system or workflow you know. Explain accelerator compatibility using this case: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain accelerator compatibility using this case: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility.

A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components. — A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components. A CPU fallback proves code execution, not GPU availability.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Kubernetes: https://kubernetes.io/docs/tutorials/

Prometheus: https://prometheus.io/docs/introduction/overview/

### Diagnose: A job requests more memory than it has

For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Two jobs cannot fit the specified device memory, even if utilization looks low. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: An appliance needs the right socket, voltage and adapter together.

A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility.

Worked example: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware); Kubernetes security contexts (Open source · local or cloud)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Two jobs cannot fit the specified device memory, even if utilization looks low. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Apply this toy-case rule manually: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A GPU is a processor used for highly parallel work. Scheduling a job onto a GPU and having enough runtime memory are different problems.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Case A: a job is Pending because no GPU is available. Case B: a running job reports out-of-memory while generating output.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

Preparation · Try step 2

For each, list what is already known and what evidence you would request next.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

Preparation · Try step 3

Write one proposed investigation for available device allocation and one for memory use during execution.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

Preparation · Explain and check your result

You do not claim that reducing model memory solves missing device allocation, or that scheduling success proves enough memory. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A two-case diagnosis table with evidence requests. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Apply this toy-case rule manually: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two jobs cannot fit the specified device memory, even if utilization looks low. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two jobs cannot fit the specified device memory, even if utilization looks low. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a job requests more memory than it has. Use the glossary below, then write your prediction for: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GPU infrastructure engineer role interview. Explain diagnose: a job requests more memory than it has using this case: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a job requests more memory than it has to a system or workflow you know. Explain diagnose: a job requests more memory than it has using this case: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Check weights, runtime and cache memory under the intended concurrency. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a job requests more memory than it has using this case: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. State the evidence, one alternative and where the mental model stops.

Quiz: A job requests more memory than it has: For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition.

Change the acceptance rule after seeing an inconvenient result.

Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone.

Omit failed cases and report only the successful demonstrations.

Reference: Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. — Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. Check weights, runtime and cache memory under the intended concurrency.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Kubernetes: https://kubernetes.io/docs/tutorials/

Prometheus: https://prometheus.io/docs/introduction/overview/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build strong Linux, Kubernetes, networking and storage skills. Add CUDA/runtime literacy and distributed-system troubleshooting. Hardware-dependent skills cannot be demonstrated solely with a laptop simulation.

Terms:

Placement and resource accounting: GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

tensor: A multidimensional array of values with a shape and data type.

### Placement and resource accounting

GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations. In this role, work through: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Assign seats and luggage capacity before boarding a vehicle.

Boundary: A scheduler's GPU count does not represent every memory or bandwidth constraint.

Worked example: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build strong Linux, Kubernetes, networking and storage skills. Add CUDA/runtime literacy and distributed-system troubleshooting. Hardware-dependent skills cannot be demonstrated solely with a laptop simulation.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware); Kubernetes security contexts (Open source · local or cloud)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for GPU infrastructure engineer: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement.

Predict the worked case

Read this case without running a tool: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in placement and resource accounting.

Connect the concept to the role

Apply this rule: GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A scheduler's GPU count does not represent every memory or bandwidth constraint.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies placement and resource accounting to this case: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Placement and resource accounting; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with placement and resource accounting. Use the glossary below, then write your prediction for: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GPU infrastructure engineer role interview. Explain placement and resource accounting using this case: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate placement and resource accounting to a system or workflow you know. Explain placement and resource accounting using this case: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain placement and resource accounting using this case: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement.

Treat a passing starter as proof of the whole role workflow.

GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations.

Ignore the failure because the tool produced an output.

Reference: GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations. — GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations. A scheduler's GPU count does not represent every memory or bandwidth constraint.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Kubernetes: https://kubernetes.io/docs/tutorials/

Prometheus: https://prometheus.io/docs/introduction/overview/

### Integrate: GPU workload isolation and capacity lab

Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM. In this role, work through: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: Assign seats and luggage capacity before boarding a vehicle.

A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement.

Worked example: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware); Kubernetes security contexts (Open source · local or cloud)

Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-intermediate-2.md: Hardware and driver inventory; Memory/latency sweep with raw logs. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: gpu workload isolation and capacity lab. Use the glossary below, then write your prediction for: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GPU infrastructure engineer role interview. Explain integrate: gpu workload isolation and capacity lab using this case: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: gpu workload isolation and capacity lab to a system or workflow you know. Explain integrate: gpu workload isolation and capacity lab using this case: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. Identify one observation that would contradict your claim.

Interview: Explain integrate: gpu workload isolation and capacity lab using this case: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate GPU workload isolation and capacity lab at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.

Reference: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. — Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Kubernetes: https://kubernetes.io/docs/tutorials/

Prometheus: https://prometheus.io/docs/introduction/overview/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

GPU incident diagnosis: Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

tensor: A multidimensional array of values with a shape and data type.

### GPU incident diagnosis

Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse. In this role, work through: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A warning light prompts inspection of the vehicle, not just restarting the dashboard.

Boundary: Hardware maintenance requires authorized access and platform-specific procedures.

Worked example: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware); Kubernetes security contexts (Open source · local or cloud)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for GPU infrastructure engineer: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs.

Predict the worked case

Read this case without running a tool: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in gpu incident diagnosis.

Connect the concept to the role

Apply this rule: Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Hardware maintenance requires authorized access and platform-specific procedures.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies gpu incident diagnosis to this case: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for GPU incident diagnosis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with gpu incident diagnosis. Use the glossary below, then write your prediction for: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GPU infrastructure engineer role interview. Explain gpu incident diagnosis using this case: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate gpu incident diagnosis to a system or workflow you know. Explain gpu incident diagnosis using this case: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain gpu incident diagnosis using this case: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse.

Reference: Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse. — Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse. Hardware maintenance requires authorized access and platform-specific procedures.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Kubernetes: https://kubernetes.io/docs/tutorials/

Prometheus: https://prometheus.io/docs/introduction/overview/

### Defend: GPU workload isolation and capacity lab

Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate. In this role, work through: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: A warning light prompts inspection of the vehicle, not just restarting the dashboard.

Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs.

Worked example: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware); Kubernetes security contexts (Open source · local or cloud)

Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A reviewer must reproduce one result and identify which capabilities you implemented. Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-advanced-2.md: Hardware and driver inventory; Memory/latency sweep with raw logs; GPU allocation and isolation ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: gpu workload isolation and capacity lab. Use the glossary below, then write your prediction for: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GPU infrastructure engineer role interview. Explain defend: gpu workload isolation and capacity lab using this case: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: gpu workload isolation and capacity lab to a system or workflow you know. Explain defend: gpu workload isolation and capacity lab using this case: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. Identify one observation that would contradict your claim.

Interview: Explain defend: gpu workload isolation and capacity lab using this case: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate GPU workload isolation and capacity lab at this level?

Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone. — Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone. Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Kubernetes: https://kubernetes.io/docs/tutorials/

Prometheus: https://prometheus.io/docs/introduction/overview/
