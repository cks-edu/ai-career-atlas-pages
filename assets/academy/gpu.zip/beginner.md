## beginner — Accelerator compatibility

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Accelerator compatibility
A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components.
Mental model: An appliance needs the right socket, voltage and adapter together.
Boundary: A CPU fallback proves code execution, not GPU availability.
Worked example: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A job requests more memory than it has
For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Two jobs cannot fit the specified device memory, even if utilization looks low. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone.
Recall: Check weights, runtime and cache memory under the intended concurrency. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Accelerator compatibility: A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A GPU is a processor used for highly parallel work. Scheduling a job onto a GPU and having enough runtime memory are different problems.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Case A: a job is Pending because no GPU is available. Case B: a running job reports out-of-memory while generating output.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

3. Try step 2
For each, list what is already known and what evidence you would request next.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

4. Try step 3
Write one proposed investigation for available device allocation and one for memory use during execution.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

5. Explain and check your result
You do not claim that reducing model memory solves missing device allocation, or that scheduling success proves enough memory. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A two-case diagnosis table with evidence requests. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Apply this toy-case rule manually: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two jobs cannot fit the specified device memory, even if utilization looks low. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to GPU infrastructure engineer.
Case A: a job is Pending because no GPU is available. Case B: a running job reports out-of-memory while generating output.
For each, list what is already known and what evidence you would request next.
Write one proposed investigation for available device allocation and one for memory use during execution.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A two-case diagnosis table with evidence requests. Include beginner-worksheet.md and your completed GPU placement worksheet.
Check: You do not claim that reducing model memory solves missing device allocation, or that scheduling success proves enough memory.

### Interview
Explain your beginner solution for GPU infrastructure engineer. Use this scenario: For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition.
Review: Start with the task and permitted scope. Explain accelerator compatibility: A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components. Show the input and observed output, then address Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A two-case diagnosis table with evidence requests. Include beginner-worksheet.md and your completed GPU placement worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

