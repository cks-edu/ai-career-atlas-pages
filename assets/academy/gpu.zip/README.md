# GPU infrastructure engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Accelerator compatibility. A GPU is a processor used for highly parallel work. Scheduling a job onto a GPU and having enough runtime memory are different problems. Then try Classify two fictional failures. The three levels build toward GPU workload isolation and capacity lab. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Accelerator compatibility

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Accelerator compatibility
A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components.
Mental model: An appliance needs the right socket, voltage and adapter together.
Boundary: A CPU fallback proves code execution, not GPU availability.
Worked example: A framework reports no CUDA device: record driver and framework build, then check device visibility and runtime compatibility.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A job requests more memory than it has
For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Two jobs cannot fit the specified device memory, even if utilization looks low. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone.
Recall: Check weights, runtime and cache memory under the intended concurrency. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Accelerator compatibility: A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A GPU is a processor used for highly parallel work. Scheduling a job onto a GPU and having enough runtime memory are different problems.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Case A: a job is Pending because no GPU is available. Case B: a running job reports out-of-memory while generating output.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

3. Try step 2
For each, list what is already known and what evidence you would request next.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

4. Try step 3
Write one proposed investigation for available device allocation and one for memory use during execution.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-case diagnosis table with evidence requests.

5. Explain and check your result
You do not claim that reducing model memory solves missing device allocation, or that scheduling success proves enough memory. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A two-case diagnosis table with evidence requests. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Apply this toy-case rule manually: Review when requested_memory > 24 (GiB). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two jobs cannot fit the specified device memory, even if utilization looks low. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to GPU infrastructure engineer.
Case A: a job is Pending because no GPU is available. Case B: a running job reports out-of-memory while generating output.
For each, list what is already known and what evidence you would request next.
Write one proposed investigation for available device allocation and one for memory use during execution.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A two-case diagnosis table with evidence requests. Include beginner-worksheet.md and your completed GPU placement worksheet.
Check: You do not claim that reducing model memory solves missing device allocation, or that scheduling success proves enough memory.

### Interview
Explain your beginner solution for GPU infrastructure engineer. Use this scenario: For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition.
Review: Start with the task and permitted scope. Explain accelerator compatibility: A GPU workload needs compatible hardware, drivers, runtime libraries and framework builds. Identify which layer fails before changing unrelated components. Show the input and observed output, then address Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A two-case diagnosis table with evidence requests. Include beginner-worksheet.md and your completed GPU placement worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Placement and resource accounting

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build strong Linux, Kubernetes, networking and storage skills. Add CUDA/runtime literacy and distributed-system troubleshooting. Hardware-dependent skills cannot be demonstrated solely with a laptop simulation.

### Placement and resource accounting
GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations.
Mental model: Assign seats and luggage capacity before boarding a vehicle.
Boundary: A scheduler's GPU count does not represent every memory or bandwidth constraint.
Worked example: A model fits on one idle card but runs out of memory when another process shares it; inspect allocations and placement.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: GPU workload isolation and capacity lab
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Recall: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. Identify one observation that would contradict your claim.

### Terms
Placement and resource accounting: GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.
Deliverables: Hardware and driver inventory; Memory/latency sweep with raw logs. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for GPU infrastructure engineer. Use this scenario: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Review: Start with the task and permitted scope. Explain placement and resource accounting: GPU scheduling must account for device count, memory, topology and sharing policy. Measure the workload's actual needs and keep scheduling requests consistent with isolation expectations. Show the input and observed output, then address Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Hardware and driver inventory; Memory/latency sweep with raw logs. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — GPU incident diagnosis

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### GPU incident diagnosis
Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse.
Mental model: A warning light prompts inspection of the vehicle, not just restarting the dashboard.
Boundary: Hardware maintenance requires authorized access and platform-specific procedures.
Worked example: Repeated device errors on one node justify isolating it and testing a known workload after repair, while preserving logs.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: GPU workload isolation and capacity lab
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Recall: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. Identify one observation that would contradict your claim.

### Terms
GPU incident diagnosis: Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.
For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.
Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.
Compare partitioning or sharing modes supported by your specific hardware, including unsupported cases and operational cost.
Deliverables: Hardware and driver inventory; Memory/latency sweep with raw logs; GPU allocation and isolation ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A reviewer must reproduce one result and identify which capabilities you implemented. Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

### Interview
Explain your advanced solution for GPU infrastructure engineer. Use this scenario: Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.
Review: Start with the task and permitted scope. Explain gpu incident diagnosis: Correlate application failures with device health, memory, temperature and communication evidence. Drain affected workloads deliberately and verify recovery before reuse. Show the input and observed output, then address Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Hardware and driver inventory; Memory/latency sweep with raw logs; GPU allocation and isolation ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NVIDIA GPU Operator — Vendor software · NVIDIA hardware
Driver, device-plugin and GPU scheduling prerequisites.
Alternative: AMD ROCm is an alternative hardware/software ecosystem, not a drop-in NVIDIA GPU Operator replacement; validate framework and device support.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Kubernetes security contexts — Open source · local or cloud
Resource, identity and container security controls.
Alternative: A local container or Docker Compose can suit a small service; managed cloud Kubernetes adds provider fees and responsibilities.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html
Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/
NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html
Kubernetes: https://kubernetes.io/docs/tutorials/
Prometheus: https://prometheus.io/docs/introduction/overview/
