# Hardware and driver inventory

Project: GPU workload isolation and capacity lab
Status: blank work product — not completed evidence

## Purpose and audience
Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.

## Required content
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.

## Failure evidence
Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
