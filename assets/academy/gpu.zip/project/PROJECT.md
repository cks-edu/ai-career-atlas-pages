# GPU workload isolation and capacity lab

Career: GPU infrastructure engineer
Reviewed: 2026-10-22

Profile GPU memory and scheduling behavior, then turn the evidence into a capacity and isolation plan.

## Prerequisites
Build strong Linux, Kubernetes, networking and storage skills. Add CUDA/runtime literacy and distributed-system troubleshooting. Hardware-dependent skills cannot be demonstrated solely with a laptop simulation.

## Included starter versus your implementation
A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Use the CPU starter to inspect tensor shapes first. GPU experiments require a supported NVIDIA driver and CUDA-compatible PyTorch build; shared hardware needs owner approval.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run tensor_probe.py on CPU, then on CUDA after installing the correct build. Record device properties, allocated/reserved memory and matrix size.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Sweep batch or matrix sizes in separate processes; synchronize before timing. Record peak allocation and failures without repeatedly driving the host into OOM.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
For a sandbox GPU cluster, follow the NVIDIA device plugin guide, request nvidia.com/gpu explicitly and compare exclusive allocation with documented sharing options. Keep the local tensor probe and cluster evidence separate.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Run two bounded workloads under the chosen sharing mode. Record contention and whether a noisy neighbor affects latency; never infer memory isolation from a GPU count alone.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report utilization, peak memory, latency variance, placement and cleanup. A CPU-only run cannot support GPU capacity claims.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Hardware and driver inventory — artifact-1.md
2. Memory/latency sweep with raw logs — artifact-2.md
3. GPU allocation and isolation ADR — artifact-3.md

## Troubleshooting
- CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
- OOM: reduce batch/context size and inspect live allocations.
- Unstable timings: warm up, synchronize and isolate other workloads.

## Extension
Compare partitioning or sharing modes supported by your specific hardware, including unsupported cases and operational cost.

## Primary learning resources
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.
- NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html — Vendor software · NVIDIA hardware; Driver, device-plugin and GPU scheduling prerequisites.
- Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/ — Open source · local or cloud; Resource, identity and container security controls.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
