# SAMPLE — GPU placement worksheet
Role: GPU infrastructure engineer
Case: A job requests more memory than it has
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
For this synthetic scheduling exercise, requests above 24 GiB cannot fit the available device partition.

## Evidence table
| Record | requested_memory (GiB) | Decision |
|---|---:|---|
| case-1 | 12 | within_demo_bound |
| case-2 | 24 | within_demo_bound |
| case-3 | 25 | review |
| case-4 | 40 | review |
| case-5 | 18 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two jobs cannot fit the specified device memory, even if utilization looks low.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Choose a compatible partition or reduce verified memory use; avoid scheduling on utilization alone.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in gpu infrastructure engineer.
Before release: Check weights, runtime and cache memory under the intended concurrency.

## Design choice and trade-off
Model device memory and compatibility explicitly; record peak rather than only idle memory.
Smaller precision or context may reduce memory but can change quality or supported behavior.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Plan GPU memory from a device snapshot: Show every unit conversion and assumption. Use free memory rather than installed capacity in the admission check. List runtime overhead, fragmentation, model format and backend compatibility as further validation work.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
