# AI developer-tools engineer — Green tests hide changed tests

Local synthetic evidence-and-decision lab. The Python replay tests a numeric contract; it does not call a model, run a GPU workload, deploy cloud infrastructure or validate a real business decision.

## Brief
The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface.

## Contract
Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard.

## Setup
Extract this ZIP into a new empty folder. Open a terminal there for the optional Python replay. On macOS/Linux use python3; on Windows use py -3 instead. Python 3.9+; standard library only. No installation commands or paid resources. Spreadsheet/browser learners can complete the same table and memo without Python.

## 1. Set up and define the contract
Read the brief and patch-review record and independent test manifest template. Restate the acceptance rule in your own words, including its units. Download and extract the pack into a new folder; open a terminal in that folder. Python 3.9+ is sufficient and there are no external dependencies.

Exit check: You can distinguish the case contract from a general industry rule.

```sh
python3 --version
```

## 2. Inspect the evidence before checking the answer
Read evidence.csv. Make a five-row decision table using verifier_edits in count. Mark each record as review or within_demo_bound. Explain what a value exactly on the threshold means.

Exit check: All five records have a decision and an evidence-based reason; keep this first attempt.

```sh
python3 analyze.py
```

## 3. Reproduce and repair the broken review rule
The supplied rule uses 4 and misses the case failures. Use the threshold and comparison controls, or edit policy.json locally, to match the stated contract. Do not edit the evidence or answer contract to make a test pass. Run independent verifiers from a protected checkout and restrict patch paths. The threshold edit repairs only this replay, not the underlying system.

Exit check: Run Check policy. The fixture and boundary cases must agree with the contract.

```sh
python3 verify.py
python3 analyze.py
```

## 4. Write the role-specific deliverable
Complete the draft template as patch-review record and independent test manifest. Cite record IDs, state your decision, name a fictional accountable owner and distinguish observations from causal hypotheses. Address this trade-off: Hidden tests improve independence but need maintenance and clear task scope to avoid unfair failures.

Exit check: A reviewer can trace the recommendation to evidence and identify who must act.

## 5. Rehearse verification and challenge an assumption
A legitimate fix passes; deleting or weakening a verifier does not change the score. Add one new example on each side of the boundary and one exactly at it. Explain how missing or unreliable evidence should be handled. For this lab, an absent numeric field is an error, not an automatic pass.

Exit check: Document expected results, one rejected alternative and a condition that reopens the finding.

```sh
python3 verify.py
```

## 6. Compare, revise and present
Reveal the sample only after drafting. Compare the evidence table, decision, trade-off and limitations; revise your own artifact rather than copying it. Present a two-minute explanation. Then extend the work toward: Repository explainer — Index one public project.

Exit check: Export your notes and compare with a peer. Self-checkmarks do not certify the written deliverable.

## Expected execution
The original policy deliberately reports zero reviews; verify.py exits nonzero on the fixture and boundary checks. After repair, the report lists 3 review cases and all four tests pass. The report prints to standard output and does not overwrite your files.

## Troubleshooting
- Missing file: open the terminal in the extracted pack directory.
- Python missing: use the in-browser exercise; install Python only from its official distribution if you choose the local route.
- JSON error: use double quotes, numeric threshold and no trailing comma.
- Fixture passes but boundary fails: distinguish > from >= and keep the stated units.
- Missing evidence: reject the malformed record for review; do not silently treat missing as zero.

## Files and answer disclosure
policy.json is the intentionally broken rule; contract.json contains the check oracle. sample-deliverable.md is the worked answer. Keep them closed until you have made an attempt. learner-deliverable.md is your editable template. In-browser notes are separate from these local files.

## Sources
- Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
- GitHub Actions: https://docs.github.com/en/actions
- Kubernetes: https://kubernetes.io/docs/tutorials/
