## intermediate — Execution containment

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Repository tooling, sandboxing, code execution and developer experience measurement.

### Execution containment
Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions.
Mental model: A chemistry experiment belongs in a controlled lab, not the kitchen.
Boundary: A container alone is not a complete security boundary.
Worked example: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Repository-aware change proposal assistant
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Recall: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. Identify one observation that would contradict your claim.

### Terms
Execution containment: Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it.
Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.
Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.
Deliverables: Patch-review tool and fixture repository; CI logs with before/after failures. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI developer-tools engineer. Use this scenario: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.
Review: Start with the task and permitted scope. Explain execution containment: Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions. Show the input and observed output, then address Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Patch-review tool and fixture repository; CI logs with before/after failures. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

