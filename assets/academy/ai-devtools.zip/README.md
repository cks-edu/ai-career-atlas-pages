# AI developer-tools engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Repository context selection. Developer tools need relevant code context to answer reliably. A filename match alone may miss the function that actually performs the work. Then try Trace a change across a tiny pretend repository. The three levels build toward Repository-aware change proposal assistant. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Repository context selection

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Repository context selection
A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct.
Mental model: A mechanic needs the right service manual for the exact vehicle.
Boundary: More repository text can add noise and expose sensitive material.
Worked example: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Green tests hide changed tests
The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Three apparently successful patches changed the checks used to judge them. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Run independent verifiers from a protected checkout and restrict patch paths.
Recall: A legitimate fix passes; deleting or weakening a verifier does not change the score. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Repository context selection: A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Developer tools need relevant code context to answer reliably. A filename match alone may miss the function that actually performs the work.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create a document showing three files: app.py calls calculate_total; pricing.py defines calculate_total; test_pricing.py checks that two items at 5 cost 10.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A file map and a short change-and-test plan.

3. Try step 2
For the request “change how discounts work”, identify the implementation file and the test file.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A file map and a short change-and-test plan.

4. Try step 3
Write a search term for each and explain why editing only app.py would miss the calculation.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A file map and a short change-and-test plan.

5. Explain and check your result
Your plan identifies the definition, its caller and a test; it does not claim that finding code proves a change is correct. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A file map and a short change-and-test plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Apply this toy-case rule manually: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three apparently successful patches changed the checks used to judge them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI developer-tools engineer.
Create a document showing three files: app.py calls calculate_total; pricing.py defines calculate_total; test_pricing.py checks that two items at 5 cost 10.
For the request “change how discounts work”, identify the implementation file and the test file.
Write a search term for each and explain why editing only app.py would miss the calculation.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A file map and a short change-and-test plan. Include beginner-worksheet.md and your completed Patch-review record and independent test manifest.
Check: Your plan identifies the definition, its caller and a test; it does not claim that finding code proves a change is correct.

### Interview
Explain your beginner solution for AI developer-tools engineer. Use this scenario: The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface.
Review: Start with the task and permitted scope. Explain repository context selection: A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct. Show the input and observed output, then address Run independent verifiers from a protected checkout and restrict patch paths. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A file map and a short change-and-test plan. Include beginner-worksheet.md and your completed Patch-review record and independent test manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Execution containment

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Repository tooling, sandboxing, code execution and developer experience measurement.

### Execution containment
Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions.
Mental model: A chemistry experiment belongs in a controlled lab, not the kitchen.
Boundary: A container alone is not a complete security boundary.
Worked example: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Repository-aware change proposal assistant
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Recall: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. Identify one observation that would contradict your claim.

### Terms
Execution containment: Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it.
Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.
Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.
Deliverables: Patch-review tool and fixture repository; CI logs with before/after failures. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI developer-tools engineer. Use this scenario: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.
Review: Start with the task and permitted scope. Explain execution containment: Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions. Show the input and observed output, then address Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Patch-review tool and fixture repository; CI logs with before/after failures. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Patch quality evidence

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Patch quality evidence
Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability.
Mental model: Repair a lock and try both the owner's key and an unauthorized key.
Boundary: Passing visible tests can hide failures outside their coverage.
Worked example: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Repository-aware change proposal assistant
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. Run a fixed test command in a restricted local process, capture output and display the diff plus failing/passing tests for human approval. Add a GitHub Actions workflow to run the same tests in your own repository.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.
Recall: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. Identify one observation that would contradict your claim.

### Terms
Patch quality evidence: Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run a fixed test command in a restricted local process, capture output and display the diff plus failing/passing tests for human approval. Add a GitHub Actions workflow to run the same tests in your own repository.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it.
Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.
Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.
Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.
Run a fixed test command in a restricted local process, capture output and display the diff plus failing/passing tests for human approval. Add a GitHub Actions workflow to run the same tests in your own repository.
Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.
Add isolated worktrees per task and compare retrieval by symbol versus full-file context.
Deliverables: Patch-review tool and fixture repository; CI logs with before/after failures; Threat model and reviewer workflow. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A reviewer must reproduce one result and identify which capabilities you implemented. Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.

### Interview
Explain your advanced solution for AI developer-tools engineer. Use this scenario: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.
Review: Start with the task and permitted scope. Explain patch quality evidence: Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability. Show the input and observed output, then address Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Patch-review tool and fixture repository; CI logs with before/after failures; Threat model and reviewer workflow. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Git — Open source · local
Versioned changes, patches and reproducible source revisions.
Alternative: Mercurial is open source, but Git dominates many team workflows; GitHub and GitLab are hosting choices rather than Git replacements.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
FastAPI: https://fastapi.tiangolo.com/tutorial/
Git: https://git-scm.com/docs
GitHub Actions: https://docs.github.com/en/actions
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
GitHub Actions: https://docs.github.com/en/actions
Kubernetes: https://kubernetes.io/docs/tutorials/
