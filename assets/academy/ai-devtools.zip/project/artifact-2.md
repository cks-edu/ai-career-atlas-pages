# CI logs with before/after failures

Project: Repository-aware change proposal assistant
Status: blank work product — not completed evidence

## Purpose and audience
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it.

## Required content
Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.

## Failure evidence
Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
