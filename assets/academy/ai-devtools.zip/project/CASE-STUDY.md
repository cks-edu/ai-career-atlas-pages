# Repository-aware change proposal assistant

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.

## Limitations and next iteration
Add isolated worktrees per task and compare retrieval by symbol versus full-file context.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
