# AI developer-tools engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Repository context selection: A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Repository context selection

A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct. In this role, work through: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A mechanic needs the right service manual for the exact vehicle.

Boundary: More repository text can add noise and expose sensitive material.

Worked example: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI developer-tools engineer: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect.

Predict the worked case

Read this case without running a tool: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in repository context selection.

Connect the concept to the role

Apply this rule: A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More repository text can add noise and expose sensitive material.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies repository context selection to this case: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Repository context selection; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with repository context selection. Use the glossary below, then write your prediction for: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-tools engineer role interview. Explain repository context selection using this case: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate repository context selection to a system or workflow you know. Explain repository context selection using this case: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain repository context selection using this case: Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect.

A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct. — A coding assistant needs relevant files, constraints and tests. Supply a small coherent context and inspect its proposed patch rather than treating fluent code as correct. More repository text can add noise and expose sensitive material.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Diagnose: Green tests hide changed tests

The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Three apparently successful patches changed the checks used to judge them. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Run independent verifiers from a protected checkout and restrict patch paths. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A mechanic needs the right service manual for the exact vehicle.

Give a function and its failing test; exclude secrets and unrelated files. Check whether the patch changes the behavior the test was meant to protect.

Worked example: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Run independent verifiers from a protected checkout and restrict patch paths.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: FastAPI (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Three apparently successful patches changed the checks used to judge them. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Apply this toy-case rule manually: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Developer tools need relevant code context to answer reliably. A filename match alone may miss the function that actually performs the work.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Create a document showing three files: app.py calls calculate_total; pricing.py defines calculate_total; test_pricing.py checks that two items at 5 cost 10.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A file map and a short change-and-test plan.

Preparation · Try step 2

For the request “change how discounts work”, identify the implementation file and the test file.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A file map and a short change-and-test plan.

Preparation · Try step 3

Write a search term for each and explain why editing only app.py would miss the calculation.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A file map and a short change-and-test plan.

Preparation · Explain and check your result

Your plan identifies the definition, its caller and a test; it does not claim that finding code proves a change is correct. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A file map and a short change-and-test plan. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Apply this toy-case rule manually: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three apparently successful patches changed the checks used to judge them. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three apparently successful patches changed the checks used to judge them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: green tests hide changed tests. Use the glossary below, then write your prediction for: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Run independent verifiers from a protected checkout and restrict patch paths. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-tools engineer role interview. Explain diagnose: green tests hide changed tests using this case: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Run independent verifiers from a protected checkout and restrict patch paths. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: green tests hide changed tests to a system or workflow you know. Explain diagnose: green tests hide changed tests using this case: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Run independent verifiers from a protected checkout and restrict patch paths. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: A legitimate fix passes; deleting or weakening a verifier does not change the score. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: green tests hide changed tests using this case: Review when verifier_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Run independent verifiers from a protected checkout and restrict patch paths. State the evidence, one alternative and where the mental model stops.

Quiz: Green tests hide changed tests: The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface.

Change the acceptance rule after seeing an inconvenient result.

Run independent verifiers from a protected checkout and restrict patch paths.

Omit failed cases and report only the successful demonstrations.

Reference: Run independent verifiers from a protected checkout and restrict patch paths. — Run independent verifiers from a protected checkout and restrict patch paths. A legitimate fix passes; deleting or weakening a verifier does not change the score.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Repository tooling, sandboxing, code execution and developer experience measurement.

Terms:

Execution containment: Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Execution containment

Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions. In this role, work through: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A chemistry experiment belongs in a controlled lab, not the kitchen.

Boundary: A container alone is not a complete security boundary.

Worked example: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Repository tooling, sandboxing, code execution and developer experience measurement.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI developer-tools engineer: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory.

Predict the worked case

Read this case without running a tool: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in execution containment.

Connect the concept to the role

Apply this rule: Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A container alone is not a complete security boundary.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies execution containment to this case: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Execution containment; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with execution containment. Use the glossary below, then write your prediction for: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-tools engineer role interview. Explain execution containment using this case: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate execution containment to a system or workflow you know. Explain execution containment using this case: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain execution containment using this case: An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory.

Treat a passing starter as proof of the whole role workflow.

Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions.

Ignore the failure because the tool produced an output.

Reference: Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions. — Run untrusted proposed commands in a restricted disposable environment with bounded time, filesystem and network access. Keep approval for side effects separate from model suggestions. A container alone is not a complete security boundary.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Integrate: Repository-aware change proposal assistant

Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text. In this role, work through: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A chemistry experiment belongs in a controlled lab, not the kitchen.

An assistant proposes a dependency install script. Inspect it and run the exercise without production credentials or access to the home directory.

Worked example: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The coding-agent trial fails if an agent modifies any verifier file outside its allowed patch surface. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: Patch-review tool and fixture repository; CI logs with before/after failures. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: repository-aware change proposal assistant. Use the glossary below, then write your prediction for: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-tools engineer role interview. Explain integrate: repository-aware change proposal assistant using this case: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: repository-aware change proposal assistant to a system or workflow you know. Explain integrate: repository-aware change proposal assistant using this case: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. Identify one observation that would contradict your claim.

Interview: Explain integrate: repository-aware change proposal assistant using this case: Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Repository-aware change proposal assistant at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.

Reference: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. — Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Patch quality evidence: Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Patch quality evidence

Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability. In this role, work through: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Repair a lock and try both the owner's key and an unauthorized key.

Boundary: Passing visible tests can hide failures outside their coverage.

Worked example: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI developer-tools engineer: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked.

Predict the worked case

Read this case without running a tool: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in patch quality evidence.

Connect the concept to the role

Apply this rule: Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Passing visible tests can hide failures outside their coverage.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies patch quality evidence to this case: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Patch quality evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with patch quality evidence. Use the glossary below, then write your prediction for: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-tools engineer role interview. Explain patch quality evidence using this case: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate patch quality evidence to a system or workflow you know. Explain patch quality evidence using this case: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain patch quality evidence using this case: A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability.

Reference: Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability. — Evaluate whether a change solves the original task without weakening tests or creating regressions. Inspect the diff and test behavior, resource use and maintainability. Passing visible tests can hide failures outside their coverage.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Defend: Repository-aware change proposal assistant

Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. Run a fixed test command in a restricted local process, capture output and display the diff plus failing/passing tests for human approval. Add a GitHub Actions workflow to run the same tests in your own repository. In this role, work through: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: Repair a lock and try both the owner's key and an unauthorized key.

A patch deletes the failing assertion and reports green tests. Reject it because the original acceptance condition is no longer checked.

Worked example: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build a development assistant that proposes a bounded patch and proves it with tests before a developer accepts it.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create a tiny local repository with five deliberate bugs and five regression tests. Record clean baseline commits and expected fixes; use a repository you own.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Extend the API starter to accept a bug description and repository-relative allowlisted files. Reject absolute paths, traversal and attempts to read secrets.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Generate a patch file using a local model or write the first patch manually. Apply it only in a disposable checkout after git apply --check succeeds; never execute arbitrary model-provided shell text.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run a fixed test command in a restricted local process, capture output and display the diff plus failing/passing tests for human approval. Add a GitHub Actions workflow to run the same tests in your own repository.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. A reviewer must reproduce one result and identify which capabilities you implemented. Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: Patch-review tool and fixture repository; CI logs with before/after failures; Threat model and reviewer workflow. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: repository-aware change proposal assistant. Use the glossary below, then write your prediction for: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-tools engineer role interview. Explain defend: repository-aware change proposal assistant using this case: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: repository-aware change proposal assistant to a system or workflow you know. Explain defend: repository-aware change proposal assistant using this case: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results. Identify one observation that would contradict your claim.

Interview: Explain defend: repository-aware change proposal assistant using this case: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Repository-aware change proposal assistant at this level?

Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review. — Include a malicious instruction inside a source comment and a patch touching an unapproved file. The assistant must preserve file boundaries and require explicit review. Report accepted fixes, regressions, rejected out-of-scope edits and end-to-end time across all five tasks. Keep human fixes separate from assistant-only results.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/
