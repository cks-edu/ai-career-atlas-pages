# RAG, Agentic Workflows & AI Backend APIs — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## intermediate

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

RAG: Retrieval-augmented generation: retrieve evidence before generating an answer.

tenant: A customer or organization whose data must be isolated.

revision: A version identifier for a specific source state.

manifest: An explicit list of the evidence/artifacts in scope.

tool call: A structured request to execute an operation.

orchestration: Application logic coordinating several steps and their outcomes.

idempotency: Repeating an operation under its contract does not apply the same effect twice.

ADR: An architecture decision record: context, options, decision and consequences.

### Retrieval boundaries before vector search

A RAG system retrieves evidence before producing an answer. Its first responsibility is retrieving only what the caller may see. Keep tenant identity in authenticated application context and include it in the data query. Never ask the language model to decide which customer it represents.

The local exercise filters documents using a trusted tenant ID and a deletion flag. Apply this boundary in the database or search service too, before results enter model context. Test the same search with two customers and an archived record.

A tenant field alone does not authenticate a caller. Real services also require object-level permission and a deletion/index refresh policy.

Mental model: Authenticated request → scoped query → permitted documents → context. Picture the boundary as a checked gate between stages.

Boundary: A tenant field alone does not authenticate a caller. Real services also require object-level permission and a deletion/index refresh policy.

Worked example: function scopedDocs(docs, tenant) {
  if (typeof tenant !== 'string' || !tenant) return [];
  return docs.filter(d => d.tenant === tenant && d.deleted === false);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract rag-agents.zip, install Node.js LTS, then open production-ai/03-01-tenant-retrieval.

Tools for this exercise: JavaScript · local isolated workbench; Qdrant, LangGraph as documented optional extensions

Course tool and framework map: Qdrant (Open source · optional paid hosting); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement scopedDocs. Add an archived document and two tenants; record which exact IDs are visible in each run.

Terminal folder: production-ai/03-01-tenant-retrieval

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The local exercise filters documents using a trusted tenant ID and a deletion flag. Apply this boundary in the database or search service too, before results enter model context. Test the same search with two customers and an archived record.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement scopedDocs. Add an archived document and two tenants; record which exact IDs are visible in each run.

Expected: An active owned document is returned

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Other tenants and deleted records are excluded; Missing identity fails closed

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: An active owned document is returned; Other tenants and deleted records are excluded; Missing identity fails closed. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require matching tenant and exclude deleted records. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/03-01-tenant-retrieval/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Authenticated request → scoped query → permitted documents → context. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Where should tenant access be checked? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A generated filter cannot replace the server’s access rule. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Where should tenant access be checked?

Interview: Where should tenant access be checked? Explain the decision, a failing case and a production limitation.

Quiz: Where should tenant access be checked?

Only in the final answer.

In trusted application/search policy before context assembly.

Inside the source document’s prose.

Reference: In trusted application/search policy before context assembly. — Filtering after generation is too late: the model may already have received private evidence.

Sources:

Qdrant: filtering and payloads: https://qdrant.tech/documentation/search/filtering/

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Citations that survive a document update

A document URL can stay the same while its content changes. Save a source ID and revision with the retrieved passage. When the answer is checked later, verify that the cited revision is still the one permitted for that decision.

Match citation ID and revision against the current permitted source manifest. Reject unknown IDs and stale revisions. In a real system preserve versioned evidence where policy permits, rather than silently rewriting the citation to today’s content.

Revision equality proves identity, not that the passage supports the claim. Retention and deletion policies still apply.

Mental model: Retrieve passage → attach revision → generate claim → inspect citation. Picture the boundary as a checked gate between stages.

Boundary: Revision equality proves identity, not that the passage supports the claim. Retention and deletion policies still apply.

Worked example: function currentCitation(citation, manifest) {
  return !!citation && typeof citation.id === 'string' && typeof citation.revision === 'string' &&
    manifest.some(s => s.id === citation.id && s.revision === citation.revision);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract rag-agents.zip, install Node.js LTS, then open production-ai/03-02-source-revisions.

Tools for this exercise: JavaScript · local isolated workbench; Qdrant, LangGraph as documented optional extensions

Course tool and framework map: Qdrant (Open source · optional paid hosting); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement currentCitation and change one revision. Save the stale citation case and explain why matching IDs is insufficient.

Terminal folder: production-ai/03-02-source-revisions

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Match citation ID and revision against the current permitted source manifest. Reject unknown IDs and stale revisions. In a real system preserve versioned evidence where policy permits, rather than silently rewriting the citation to today’s content.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement currentCitation and change one revision. Save the stale citation case and explain why matching IDs is insufficient.

Expected: The exact revision is accepted

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Old revisions are detected; Unknown or malformed citations fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: The exact revision is accepted; Old revisions are detected; Unknown or malformed citations fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Compare IDs and revisions against a permitted manifest. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/03-02-source-revisions/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Retrieve passage → attach revision → generate claim → inspect citation. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A source URL now shows a different policy. What evidence is needed for the earlier answer? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A current URL cannot prove which past text was seen. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A source URL now shows a different policy. What evidence is needed for the earlier answer?

Interview: A source URL now shows a different policy. What evidence is needed for the earlier answer? Explain the decision, a failing case and a production limitation.

Quiz: A source URL now shows a different policy. What evidence is needed for the earlier answer?

Its original source revision and passage.

Only the current page title.

A higher similarity score.

Reference: Its original source revision and passage. — Record what the system actually used. A stable address alone does not preserve evidence history.

Sources:

Qdrant: filtering and payloads: https://qdrant.tech/documentation/search/filtering/

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Validate tool proposals before orchestration

An agent chooses a proposed operation; a backend decides whether that operation may run. Validate the tool name, argument types and caller scope before dispatch. A schema-valid proposal can still be unauthorized.

The fixture permits only lookup with exactly one nonempty ticketId string from the caller’s allowed ticket list. Reject extra fields rather than silently passing them into another layer. MCP can describe tool schemas; execution policy remains your responsibility.

The fixture does not connect to a ticket system or implement authentication. Real tools require authenticated principals, audit records and downstream access checks.

Mental model: Model proposal → exact contract → caller scope → tool execution. Picture the boundary as a checked gate between stages.

Boundary: The fixture does not connect to a ticket system or implement authentication. Real tools require authenticated principals, audit records and downstream access checks.

Worked example: function validTool(name, args, allowedTickets) {
  return name === 'lookup' && !!args && !Array.isArray(args) &&
    Object.keys(args).join(',') === 'ticketId' && typeof args.ticketId === 'string' &&
    args.ticketId.length > 0 && allowedTickets.includes(args.ticketId);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract rag-agents.zip, install Node.js LTS, then open production-ai/03-03-checked-tool-contract.

Tools for this exercise: JavaScript · local isolated workbench; Qdrant, LangGraph as documented optional extensions

Course tool and framework map: Qdrant (Open source · optional paid hosting); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement validTool and add an extra-key case. Draw schema and authorization as two separate gates in your backend diagram.

Terminal folder: production-ai/03-03-checked-tool-contract

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture permits only lookup with exactly one nonempty ticketId string from the caller’s allowed ticket list. Reject extra fields rather than silently passing them into another layer. MCP can describe tool schemas; execution policy remains your responsibility.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement validTool and add an extra-key case. Draw schema and authorization as two separate gates in your backend diagram.

Expected: Allowed ticket lookup passes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: A valid-shaped unauthorized lookup fails; Unknown tools, extra keys and wrong types fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Allowed ticket lookup passes; A valid-shaped unauthorized lookup fails; Unknown tools, extra keys and wrong types fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Check exact fields and permitted ticket IDs before dispatch. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/03-03-checked-tool-contract/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Model proposal → exact contract → caller scope → tool execution. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. An MCP tool schema accepts ticketId, but the ticket is not owned by the caller. What happens? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Valid JSON cannot grant access to another user’s ticket. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: An MCP tool schema accepts ticketId, but the ticket is not owned by the caller. What happens?

Interview: An MCP tool schema accepts ticketId, but the ticket is not owned by the caller. What happens? Explain the decision, a failing case and a production limitation.

Quiz: An MCP tool schema accepts ticketId, but the ticket is not owned by the caller. What happens?

The schema authorizes it.

Execute and hide the result.

The executor must deny it using caller policy.

Reference: The executor must deny it using caller policy. — A protocol and schema organize requests. They do not replace authentication or resource authorization.

Sources:

MCP: typed tools and user interaction: https://modelcontextprotocol.io/specification/2026-07-28/server/tools

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

JSON Schema: object validation: https://json-schema.org/understanding-json-schema/reference/object

### Recover a workflow without duplicating a write

Retries help recover from transient failures, but repeating a write can create duplicate orders or messages. Use a stable operation ID and persist the accepted payload with its result. A repeat with the same ID and different payload must be rejected.

This local store demonstrates idempotency with a canonical string payload. The first operation records its result, a matching repeat reuses it, and a changed payload reports conflict. Production storage must make the claim and write atomic and durable.

A JavaScript Map is not durable or safe across distributed workers. Canonicalization, transaction semantics, expiry and uncertain remote writes require explicit design.

Mental model: Proposed write → operation ID lookup → claim → side effect → stored result. Picture the boundary as a checked gate between stages.

Boundary: A JavaScript Map is not durable or safe across distributed workers. Canonicalization, transaction semantics, expiry and uncertain remote writes require explicit design.

Worked example: function once(store, id, payload) {
  if (!id || typeof payload !== 'string') return {status:'invalid'};
  if (store.has(id)) return store.get(id).payload === payload ? {status:'reused'} : {status:'conflict'};
  store.set(id,{payload}); return {status:'created'};
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract rag-agents.zip, install Node.js LTS, then open production-ai/03-04-workflow-recovery.

Tools for this exercise: JavaScript · local isolated workbench; Qdrant, LangGraph as documented optional extensions

Course tool and framework map: Qdrant (Open source · optional paid hosting); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement once and simulate a repeat after a lost response. Write an ADR describing how a real database transaction would replace the in-memory Map.

Terminal folder: production-ai/03-04-workflow-recovery

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This local store demonstrates idempotency with a canonical string payload. The first operation records its result, a matching repeat reuses it, and a changed payload reports conflict. Production storage must make the claim and write atomic and durable.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement once and simulate a repeat after a lost response. Write an ADR describing how a real database transaction would replace the in-memory Map.

Expected: First write is created

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: A matching retry reuses the operation; Changed payload and missing IDs are denied

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: First write is created; A matching retry reuses the operation; Changed payload and missing IDs are denied. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Reuse matching results and reject payload conflicts. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/03-04-workflow-recovery/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Proposed write → operation ID lookup → claim → side effect → stored result. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A write times out after the remote system may have committed. What is the safest next step? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Retry identity is independent of how persuasive the model is. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A write times out after the remote system may have committed. What is the safest next step?

Interview: A write times out after the remote system may have committed. What is the safest next step? Explain the decision, a failing case and a production limitation.

Quiz: A write times out after the remote system may have committed. What is the safest next step?

Retry with a new ID immediately.

Reconcile the same operation ID and recorded effect before repeating.

Assume timeout means no write occurred.

Reference: Reconcile the same operation ID and recorded effect before repeating. — Network uncertainty is not a rollback. Reconcile effects using a stable identity and a documented recovery policy.

Sources:

LangGraph: workflows and agents: https://docs.langchain.com/oss/python/langgraph/workflows-agents
