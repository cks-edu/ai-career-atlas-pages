# Validate tool proposals before orchestration

An agent chooses a proposed operation; a backend decides whether that operation may run. Validate the tool name, argument types and caller scope before dispatch. A schema-valid proposal can still be unauthorized.

The fixture permits only lookup with exactly one nonempty ticketId string from the caller’s allowed ticket list. Reject extra fields rather than silently passing them into another layer. MCP can describe tool schemas; execution policy remains your responsibility.

Task: Implement validTool and add an extra-key case. Draw schema and authorization as two separate gates in your backend diagram.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Model proposal → exact contract → caller scope → tool execution.
State: The tool name and argument object are proposals, not authority.
Boundary: Valid JSON cannot grant access to another user’s ticket.
Failure: The agent proposes a valid-shaped lookup for someone else’s ticket.
Control: Check exact fields and permitted ticket IDs before dispatch.
Observability: Record rejected tool, rule and request ID without ticket text.
Blast radius: All resources accessible to the tool credential.
Trade-off: Strict contracts reduce ambiguity but must evolve with versioned clients.

Limit: The fixture does not connect to a ticket system or implement authentication. Real tools require authenticated principals, audit records and downstream access checks.

Sources:
https://modelcontextprotocol.io/specification/2026-07-28/server/tools
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
https://json-schema.org/understanding-json-schema/reference/object
