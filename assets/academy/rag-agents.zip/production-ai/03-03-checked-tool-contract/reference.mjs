function validTool(name, args, allowedTickets) {
  return name === 'lookup' && !!args && !Array.isArray(args) &&
    Object.keys(args).join(',') === 'ticketId' && typeof args.ticketId === 'string' &&
    args.ticketId.length > 0 && allowedTickets.includes(args.ticketId);
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(validTool('lookup',{ticketId:'t1'},['t1']));
console.log("PASS: Allowed ticket lookup passes");
}
{
assert(!validTool('lookup',{ticketId:'t2'},['t1']));
console.log("PASS: A valid-shaped unauthorized lookup fails");
}
{
assert(!validTool('delete',{ticketId:'t1'},['t1'])); assert(!validTool('lookup',{ticketId:'t1',admin:true},['t1'])); assert(!validTool('lookup',{ticketId:1},['t1']));
console.log("PASS: Unknown tools, extra keys and wrong types fail");
}
