function currentCitation(citation, manifest) {
  return !!citation && typeof citation.id === 'string' && typeof citation.revision === 'string' &&
    manifest.some(s => s.id === citation.id && s.revision === citation.revision);
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(currentCitation({id:'policy',revision:'2'},[{id:'policy',revision:'2'}]));
console.log("PASS: The exact revision is accepted");
}
{
assert(!currentCitation({id:'policy',revision:'1'},[{id:'policy',revision:'2'}]));
console.log("PASS: Old revisions are detected");
}
{
assert(!currentCitation({id:'other',revision:'2'},[{id:'policy',revision:'2'}])); assert(!currentCitation(null,[]));
console.log("PASS: Unknown or malformed citations fail");
}
