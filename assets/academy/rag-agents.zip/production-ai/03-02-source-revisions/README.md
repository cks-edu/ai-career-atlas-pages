# Citations that survive a document update

A document URL can stay the same while its content changes. Save a source ID and revision with the retrieved passage. When the answer is checked later, verify that the cited revision is still the one permitted for that decision.

Match citation ID and revision against the current permitted source manifest. Reject unknown IDs and stale revisions. In a real system preserve versioned evidence where policy permits, rather than silently rewriting the citation to today’s content.

Task: Implement currentCitation and change one revision. Save the stale citation case and explain why matching IDs is insufficient.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Retrieve passage → attach revision → generate claim → inspect citation.
State: Citations retain source ID and revision together.
Boundary: A current URL cannot prove which past text was seen.
Failure: An updated policy makes yesterday’s answer obsolete.
Control: Compare IDs and revisions against a permitted manifest.
Observability: Report stale and missing citations distinctly.
Blast radius: Answers depending on the changed source.
Trade-off: Version retention improves auditability but adds storage and privacy obligations.

Limit: Revision equality proves identity, not that the passage supports the claim. Retention and deletion policies still apply.

Sources:
https://qdrant.tech/documentation/search/filtering/
https://www.nist.gov/itl/ai-risk-management-framework
