function scopedDocs(docs,tenant) { return docs; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(scopedDocs([{tenant:'a',deleted:false}], 'a').length===1);
console.log("PASS: An active owned document is returned");
}
{
assert(scopedDocs([{tenant:'b',deleted:false},{tenant:'a',deleted:true}], 'a').length===0);
console.log("PASS: Other tenants and deleted records are excluded");
}
{
assert(scopedDocs([{tenant:'a',deleted:false}], '').length===0); assert(scopedDocs([{tenant:'a'}], 'a').length===0);
console.log("PASS: Missing identity fails closed");
}
