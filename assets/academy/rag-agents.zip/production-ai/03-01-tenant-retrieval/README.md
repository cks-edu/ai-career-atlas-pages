# Retrieval boundaries before vector search

A RAG system retrieves evidence before producing an answer. Its first responsibility is retrieving only what the caller may see. Keep tenant identity in authenticated application context and include it in the data query. Never ask the language model to decide which customer it represents.

The local exercise filters documents using a trusted tenant ID and a deletion flag. Apply this boundary in the database or search service too, before results enter model context. Test the same search with two customers and an archived record.

Task: Implement scopedDocs. Add an archived document and two tenants; record which exact IDs are visible in each run.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Authenticated request → scoped query → permitted documents → context.
State: Tenant, document revision and deletion state stay attached to each hit.
Boundary: A generated filter cannot replace the server’s access rule.
Failure: A broad search returns another customer’s private document.
Control: Require matching tenant and exclude deleted records.
Observability: Trace permitted IDs and revisions; alert on authorization failures.
Blast radius: The indexed corpus across tenants if the filter is absent.
Trade-off: Filtering can lower recall; confidentiality takes priority over a richer answer.

Limit: A tenant field alone does not authenticate a caller. Real services also require object-level permission and a deletion/index refresh policy.

Sources:
https://qdrant.tech/documentation/search/filtering/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
