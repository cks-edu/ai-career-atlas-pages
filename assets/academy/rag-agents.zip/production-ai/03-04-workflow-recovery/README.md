# Recover a workflow without duplicating a write

Retries help recover from transient failures, but repeating a write can create duplicate orders or messages. Use a stable operation ID and persist the accepted payload with its result. A repeat with the same ID and different payload must be rejected.

This local store demonstrates idempotency with a canonical string payload. The first operation records its result, a matching repeat reuses it, and a changed payload reports conflict. Production storage must make the claim and write atomic and durable.

Task: Implement once and simulate a repeat after a lost response. Write an ADR describing how a real database transaction would replace the in-memory Map.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Proposed write → operation ID lookup → claim → side effect → stored result.
State: Operation ID, payload and outcome must remain consistent.
Boundary: Retry identity is independent of how persuasive the model is.
Failure: A timeout causes the same message to be sent twice.
Control: Reuse matching results and reject payload conflicts.
Observability: Track operation ID, repeat/conflict status and uncertain effects.
Blast radius: The side-effect target; duplicate external writes may be irreversible.
Trade-off: Idempotency adds storage and expiry rules but makes recovery safer.

Limit: A JavaScript Map is not durable or safe across distributed workers. Canonicalization, transaction semantics, expiry and uncertain remote writes require explicit design.

Sources:
https://docs.langchain.com/oss/python/langgraph/workflows-agents
