function once(store, id, payload) {
  if (!id || typeof payload !== 'string') return {status:'invalid'};
  if (store.has(id)) return store.get(id).payload === payload ? {status:'reused'} : {status:'conflict'};
  store.set(id,{payload}); return {status:'created'};
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(once(new Map(),'op1','hello').status==='created');
console.log("PASS: First write is created");
}
{
const s=new Map(); once(s,'op1','hello'); assert(once(s,'op1','hello').status==='reused' && s.size===1);
console.log("PASS: A matching retry reuses the operation");
}
{
const s=new Map(); once(s,'op1','hello'); assert(once(s,'op1','changed').status==='conflict'); assert(once(s,'','x').status==='invalid');
console.log("PASS: Changed payload and missing IDs are denied");
}
