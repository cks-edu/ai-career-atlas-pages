# Small-model economics begin with the whole device

A model with 1–7 billion parameters may fit some devices, but parameter count alone does not establish usability. Weights, caches, runtime buffers, download size and sustained battery use all matter. A local model has no inference-server bill, but it still consumes the learner’s resources.

Estimate a conservative memory envelope from supplied weight, cache and runtime sizes. Keep a reserve for the browser. These numbers are invented exercise inputs; a real admission decision requires measurements on each supported device and context length.

Task: Implement deviceFits. Make a fictional memory worksheet and clearly label its assumptions before trying an opt-in local model on a supported device.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Model choice → memory envelope → capability check → opt-in download.
State: Weights, context cache, runtime and reserve share device resources.
Boundary: Parameter count is not total memory usage.
Failure: Weights fit but runtime buffers exhaust the tab.
Control: Check the full supplied envelope before proposing local loading.
Observability: Measure actual peak usage, load time and interaction responsiveness.
Blast radius: The tab and device running the model.
Trade-off: Local privacy and offline use trade against download, speed and battery use.

Limit: Available GPU memory is not reliably known from a single universal browser API. Device hints must not be presented as an exact safe capacity.

Sources:
https://webllm.mlc.ai/docs/
https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API
https://huggingface.co/docs/transformers/llm_tutorial
