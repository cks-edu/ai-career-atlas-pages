function deviceFits(weights, cache, runtime, reserve, budget) {
  const parts=[weights,cache,runtime,reserve,budget];
  return parts.every(n=>Number.isFinite(n) && n>=0) && weights+cache+runtime+reserve <= budget;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(deviceFits(4,1,1,1,8));
console.log("PASS: Full envelope fits");
}
{
assert(!deviceFits(4,2,2,1,8)); assert(deviceFits(4,1,1,2,8));
console.log("PASS: Buffers can push it over capacity");
}
{
assert(!deviceFits(NaN,1,1,1,8)); assert(!deviceFits(4,-1,1,1,8));
console.log("PASS: Invalid estimates fail");
}
