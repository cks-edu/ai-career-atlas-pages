function deviceFits(weights,cache,runtime,reserve,budget) { return weights <= budget; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(deviceFits(4,1,1,1,8));
console.log("PASS: Full envelope fits");
}
{
assert(!deviceFits(4,2,2,1,8)); assert(deviceFits(4,1,1,2,8));
console.log("PASS: Buffers can push it over capacity");
}
{
assert(!deviceFits(NaN,1,1,1,8)); assert(!deviceFits(4,-1,1,1,8));
console.log("PASS: Invalid estimates fail");
}
