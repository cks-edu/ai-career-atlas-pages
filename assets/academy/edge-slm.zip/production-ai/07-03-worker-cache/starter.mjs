function cacheMatches(cached,wanted) { return !!cached; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(cacheMatches({model:'m2',tokenizer:'t2',format:'f',complete:true},{model:'m2',tokenizer:'t2',format:'f'}));
console.log("PASS: Complete matching cache is reused");
}
{
assert(!cacheMatches({model:'m2',tokenizer:'t1',format:'f',complete:true},{model:'m2',tokenizer:'t2',format:'f'}));
console.log("PASS: Stale tokenizer or format is invalidated");
}
{
assert(!cacheMatches({model:'m2',tokenizer:'t2',format:'f',complete:false},{model:'m2',tokenizer:'t2',format:'f'})); assert(!cacheMatches(null,{model:'m2',tokenizer:'t2',format:'f'}));
console.log("PASS: Partial or missing cache reloads");
}
