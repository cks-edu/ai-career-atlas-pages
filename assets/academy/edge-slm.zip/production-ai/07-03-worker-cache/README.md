# WebGPU loading, worker isolation and cache identity

Heavy model preparation on the main thread can freeze interaction. Use the runtime’s worker support and show download/load states. Cached model files also need an identity: a familiar filename does not prove it matches the current model and tokenizer.

Reuse a cache entry only when model revision, tokenizer revision and runtime format match the requested manifest. The sandbox checks metadata; a real cache also needs integrity validation, quota handling, eviction and recovery from partial downloads.

Task: Implement cacheMatches. Draw download, validating, loading, ready and failed states, with a recovery path for storage eviction.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Opt-in download → validated cache → worker initialization → ready state.
State: Model, tokenizer and format revisions identify a cache entry.
Boundary: A cached name alone cannot establish compatible weights.
Failure: An old tokenizer is reused with new weights.
Control: Match the manifest and validate downloaded artifacts before loading.
Observability: Report download progress, cache hit/miss and initialization failure.
Blast radius: The current model session and any shared cache entries.
Trade-off: Caching saves downloads but consumes storage and requires invalidation.

Limit: Workers do not create extra GPU memory or guarantee browser support. WebLLM defaults to the Cache API; IndexedDB is an optional documented cache backend. Check the installed SDK version before configuring it. Browser storage can be evicted, so offline availability must be checked.

Sources:
https://webllm.mlc.ai/docs/user/advanced_usage.html
https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers
https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API
https://webllm.mlc.ai/docs/
