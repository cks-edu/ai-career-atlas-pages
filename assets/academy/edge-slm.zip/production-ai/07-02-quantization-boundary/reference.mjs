function usableQuant(format, supported, qualityLoss, tolerance) {
  return supported.includes(format) && Number.isFinite(qualityLoss) && qualityLoss >= 0 &&
    Number.isFinite(tolerance) && tolerance >= 0 && qualityLoss <= tolerance;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(usableQuant('web-runtime-4bit',['web-runtime-4bit'],.01,.02));
console.log("PASS: Supported measured artifact passes");
}
{
assert(!usableQuant('GGUF',['web-runtime-4bit'],.01,.02)); assert(!usableQuant('web-runtime-4bit',['web-runtime-4bit'],.03,.02));
console.log("PASS: Incompatible formats and regressions fail");
}
{
assert(!usableQuant('web-runtime-4bit',['web-runtime-4bit'],NaN,.02)); assert(!usableQuant('x',['x'],-1,.02));
console.log("PASS: Unknown quality is not a pass");
}
