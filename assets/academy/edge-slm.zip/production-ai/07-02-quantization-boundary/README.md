# Quantization: size, format and quality are separate

Quantization represents weights with fewer bits to reduce storage or memory demand. Lower precision may change quality, and different formats need compatible runtimes. GGUF is a model container used by runtimes such as llama.cpp; AWQ is a quantization approach, not a promise of browser compatibility.

Choose only formats the supplied runtime supports and only when the measured task-quality loss stays within a declared tolerance. Never select a model based solely on the smallest weight file. Re-evaluate the actual quantized artifact, tokenizer and context setting.

Task: Implement usableQuant. Compare two documented runtime/artifact combinations and propose a held-out quality check before changing precision.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Artifact format → runtime compatibility → measured quality → selection.
State: Supported format and measured quality loss define eligibility.
Boundary: A quantization label does not prove runtime compatibility.
Failure: A compact GGUF file is selected for an incompatible browser runtime.
Control: Check exact format support and task-specific regression tolerance.
Observability: Record artifact hash, runtime revision and evaluation changes.
Blast radius: All sessions using the selected quantized artifact.
Trade-off: Smaller memory use can trade against quality, speed or supported features.

Limit: This policy does not quantize weights or calculate perplexity. Perplexity changes alone do not describe all task and safety regressions.

Sources:
https://huggingface.co/docs/transformers/quantization/overview
https://webllm.mlc.ai/docs/
