function routeInference(prompt,deviceCapabilities) { return deviceCapabilities.fits ? "local" : "cloud"; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(routeInference({pii:true,tokens:10},{webgpu:true,fits:true,maxContext:100,cloudAllowed:true})==='local');
console.log("PASS: Private input stays local when it fits");
}
{
assert(routeInference({pii:true,tokens:101},{webgpu:true,fits:true,maxContext:100,cloudAllowed:true})==='blocked'); assert(routeInference({pii:true,tokens:10},{webgpu:false,fits:false,maxContext:100,cloudAllowed:true})==='blocked');
console.log("PASS: Private overflow is blocked, never uploaded");
}
{
assert(routeInference({pii:false,tokens:10},{webgpu:false,fits:false,maxContext:100,cloudAllowed:false})==='blocked'); assert(routeInference({pii:false,tokens:10},{webgpu:false,fits:false,maxContext:100,cloudAllowed:true})==='cloud'); assert(routeInference({pii:false,lowLatency:true,tokens:10},{webgpu:true,fits:true,maxContext:100,cloudAllowed:true})==='local');
console.log("PASS: Public cloud needs permission; quick local work stays local");
}
