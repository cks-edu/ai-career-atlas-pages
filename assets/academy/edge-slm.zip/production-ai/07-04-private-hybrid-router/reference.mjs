function routeInference(prompt, deviceCapabilities) {
  const d=deviceCapabilities;
  if (!Number.isSafeInteger(prompt.tokens) || prompt.tokens < 0) return 'blocked';
  const local=d.webgpu === true && d.fits === true && Number.isSafeInteger(prompt.tokens) && prompt.tokens >= 0 && prompt.tokens <= d.maxContext;
  if (prompt.pii === true) return local ? 'local' : 'blocked';
  if (local && prompt.lowLatency === true) return 'local';
  if (d.cloudAllowed === true) return 'cloud';
  return local ? 'local' : 'blocked';
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(routeInference({pii:true,tokens:10},{webgpu:true,fits:true,maxContext:100,cloudAllowed:true})==='local');
console.log("PASS: Private input stays local when it fits");
}
{
assert(routeInference({pii:true,tokens:101},{webgpu:true,fits:true,maxContext:100,cloudAllowed:true})==='blocked'); assert(routeInference({pii:true,tokens:10},{webgpu:false,fits:false,maxContext:100,cloudAllowed:true})==='blocked');
console.log("PASS: Private overflow is blocked, never uploaded");
}
{
assert(routeInference({pii:false,tokens:10},{webgpu:false,fits:false,maxContext:100,cloudAllowed:false})==='blocked'); assert(routeInference({pii:false,tokens:10},{webgpu:false,fits:false,maxContext:100,cloudAllowed:true})==='cloud'); assert(routeInference({pii:false,lowLatency:true,tokens:10},{webgpu:true,fits:true,maxContext:100,cloudAllowed:true})==='local');
console.log("PASS: Public cloud needs permission; quick local work stays local");
}
