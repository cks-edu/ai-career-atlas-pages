# Hybrid routing must never silently export private input

A hybrid application may use a local model for private or quick tasks and a cloud model for explicitly permitted work. The privacy rule comes first. If private input does not fit the device, stop and explain the limit; do not treat memory pressure as consent to upload.

The fixture requires WebGPU availability, model fit and a context limit for local inference. Nonprivate work can use cloud only when cloudAllowed is explicitly true. PII protection uses a trusted policy flag; this code does not detect all personal information.

Task: Implement routeInference. Include private oversized input and denied cloud consent in your tests; document an honest user-facing blocked message.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Policy classification → local capacity → local, allowed cloud or blocked.
State: PII flag, capability and consent are independent inputs.
Boundary: Capacity failure cannot authorize data transfer.
Failure: A private prompt overflows local context and is silently sent to cloud.
Control: Block private overflow; require explicit permitted cloud routing for other work.
Observability: Record route and reason without logging the prompt.
Blast radius: The data sent off-device and its downstream recipients.
Trade-off: Local processing preserves a boundary but may be slower or unavailable.

Limit: A PII detector can miss sensitive content, and local execution is not a full privacy guarantee. Browser extensions, logs and stored files also need review.

Sources:
https://webllm.mlc.ai/docs/
https://www.nist.gov/itl/ai-risk-management-framework
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
