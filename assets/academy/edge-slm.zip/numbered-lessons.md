# Edge AI, Small Language Models & WebGPU — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

parameter: A learned model weight; count is only one factor in resource use.

memory envelope: A budget including weights, caches, runtime buffers and reserve.

quantization: Representing numerical values with a reduced precision scheme.

perplexity: A predictive language-model metric whose evaluation setup must be stated.

WebGPU: A browser API exposing supported GPU computation and rendering.

IndexedDB: Browser storage that can retain structured data and blobs, subject to quota/eviction.

PII: Personally identifiable information; flags and detectors have limits.

hybrid inference: Routing among local and remote computation under an explicit policy.

### Small-model economics begin with the whole device

A model with 1–7 billion parameters may fit some devices, but parameter count alone does not establish usability. Weights, caches, runtime buffers, download size and sustained battery use all matter. A local model has no inference-server bill, but it still consumes the learner’s resources.

Estimate a conservative memory envelope from supplied weight, cache and runtime sizes. Keep a reserve for the browser. These numbers are invented exercise inputs; a real admission decision requires measurements on each supported device and context length.

Available GPU memory is not reliably known from a single universal browser API. Device hints must not be presented as an exact safe capacity.

Mental model: Model choice → memory envelope → capability check → opt-in download. Picture the boundary as a checked gate between stages.

Boundary: Available GPU memory is not reliably known from a single universal browser API. Device hints must not be presented as an exact safe capacity.

Worked example: function deviceFits(weights, cache, runtime, reserve, budget) {
  const parts=[weights,cache,runtime,reserve,budget];
  return parts.every(n=>Number.isFinite(n) && n>=0) && weights+cache+runtime+reserve <= budget;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract edge-slm.zip, install Node.js LTS, then open production-ai/07-01-device-economics.

Tools for this exercise: JavaScript · local isolated workbench; WebLLM, WebGPU / IndexedDB / Web Workers as documented optional extensions

Course tool and framework map: WebLLM (Open source · device resources); WebGPU / IndexedDB / Web Workers (Open web APIs · browser dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement deviceFits. Make a fictional memory worksheet and clearly label its assumptions before trying an opt-in local model on a supported device.

Terminal folder: production-ai/07-01-device-economics

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Estimate a conservative memory envelope from supplied weight, cache and runtime sizes. Keep a reserve for the browser. These numbers are invented exercise inputs; a real admission decision requires measurements on each supported device and context length.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement deviceFits. Make a fictional memory worksheet and clearly label its assumptions before trying an opt-in local model on a supported device.

Expected: Full envelope fits

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Buffers can push it over capacity; Invalid estimates fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Full envelope fits; Buffers can push it over capacity; Invalid estimates fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Check the full supplied envelope before proposing local loading. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/07-01-device-economics/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Model choice → memory envelope → capability check → opt-in download. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does fitting the weight file alone prove a 7B model is usable on a phone? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Parameter count is not total memory usage. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does fitting the weight file alone prove a 7B model is usable on a phone?

Interview: Does fitting the weight file alone prove a 7B model is usable on a phone? Explain the decision, a failing case and a production limitation.

Quiz: Does fitting the weight file alone prove a 7B model is usable on a phone?

No; measure caches, buffers, latency and device behavior too.

Yes; the browser has unlimited memory.

Yes; quantization removes all runtime overhead.

Reference: No; measure caches, buffers, latency and device behavior too. — Model admission and user experience depend on the complete runtime and workload, not only file size.

Sources:

WebLLM: browser inference: https://webllm.mlc.ai/docs/

MDN: WebGPU: https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API

Hugging Face: LLM inference concepts: https://huggingface.co/docs/transformers/llm_tutorial

### Quantization: size, format and quality are separate

Quantization represents weights with fewer bits to reduce storage or memory demand. Lower precision may change quality, and different formats need compatible runtimes. GGUF is a model container used by runtimes such as llama.cpp; AWQ is a quantization approach, not a promise of browser compatibility.

Choose only formats the supplied runtime supports and only when the measured task-quality loss stays within a declared tolerance. Never select a model based solely on the smallest weight file. Re-evaluate the actual quantized artifact, tokenizer and context setting.

This policy does not quantize weights or calculate perplexity. Perplexity changes alone do not describe all task and safety regressions.

Mental model: Artifact format → runtime compatibility → measured quality → selection. Picture the boundary as a checked gate between stages.

Boundary: This policy does not quantize weights or calculate perplexity. Perplexity changes alone do not describe all task and safety regressions.

Worked example: function usableQuant(format, supported, qualityLoss, tolerance) {
  return supported.includes(format) && Number.isFinite(qualityLoss) && qualityLoss >= 0 &&
    Number.isFinite(tolerance) && tolerance >= 0 && qualityLoss <= tolerance;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract edge-slm.zip, install Node.js LTS, then open production-ai/07-02-quantization-boundary.

Tools for this exercise: JavaScript · local isolated workbench; WebLLM, WebGPU / IndexedDB / Web Workers as documented optional extensions

Course tool and framework map: WebLLM (Open source · device resources); WebGPU / IndexedDB / Web Workers (Open web APIs · browser dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement usableQuant. Compare two documented runtime/artifact combinations and propose a held-out quality check before changing precision.

Terminal folder: production-ai/07-02-quantization-boundary

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Choose only formats the supplied runtime supports and only when the measured task-quality loss stays within a declared tolerance. Never select a model based solely on the smallest weight file. Re-evaluate the actual quantized artifact, tokenizer and context setting.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement usableQuant. Compare two documented runtime/artifact combinations and propose a held-out quality check before changing precision.

Expected: Supported measured artifact passes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Incompatible formats and regressions fail; Unknown quality is not a pass

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Supported measured artifact passes; Incompatible formats and regressions fail; Unknown quality is not a pass. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Check exact format support and task-specific regression tolerance. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/07-02-quantization-boundary/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Artifact format → runtime compatibility → measured quality → selection. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Can a GGUF artifact be loaded by every WebGPU model runtime? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A quantization label does not prove runtime compatibility. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Can a GGUF artifact be loaded by every WebGPU model runtime?

Interview: Can a GGUF artifact be loaded by every WebGPU model runtime? Explain the decision, a failing case and a production limitation.

Quiz: Can a GGUF artifact be loaded by every WebGPU model runtime?

Yes, all four-bit formats are interchangeable.

No; check the exact runtime’s artifact requirements.

Yes, if the filename contains AI.

Reference: No; check the exact runtime’s artifact requirements. — Precision, container, quantization method and runtime support are distinct properties. Check each explicitly.

Sources:

Hugging Face: quantization concepts: https://huggingface.co/docs/transformers/quantization/overview

WebLLM: browser inference: https://webllm.mlc.ai/docs/

### WebGPU loading, worker isolation and cache identity

Heavy model preparation on the main thread can freeze interaction. Use the runtime’s worker support and show download/load states. Cached model files also need an identity: a familiar filename does not prove it matches the current model and tokenizer.

Reuse a cache entry only when model revision, tokenizer revision and runtime format match the requested manifest. The sandbox checks metadata; a real cache also needs integrity validation, quota handling, eviction and recovery from partial downloads.

Workers do not create extra GPU memory or guarantee browser support. WebLLM defaults to the Cache API; IndexedDB is an optional documented cache backend. Check the installed SDK version before configuring it. Browser storage can be evicted, so offline availability must be checked.

Mental model: Opt-in download → validated cache → worker initialization → ready state. Picture the boundary as a checked gate between stages.

Boundary: Workers do not create extra GPU memory or guarantee browser support. WebLLM defaults to the Cache API; IndexedDB is an optional documented cache backend. Check the installed SDK version before configuring it. Browser storage can be evicted, so offline availability must be checked.

Worked example: function cacheMatches(cached, wanted) {
  return !!cached && ['model','tokenizer','format'].every(k => typeof wanted[k] === 'string' && cached[k] === wanted[k]) && cached.complete === true;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract edge-slm.zip, install Node.js LTS, then open production-ai/07-03-worker-cache.

Tools for this exercise: JavaScript · local isolated workbench; WebLLM, WebGPU / IndexedDB / Web Workers as documented optional extensions

Course tool and framework map: WebLLM (Open source · device resources); WebGPU / IndexedDB / Web Workers (Open web APIs · browser dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement cacheMatches. Draw download, validating, loading, ready and failed states, with a recovery path for storage eviction.

Terminal folder: production-ai/07-03-worker-cache

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Reuse a cache entry only when model revision, tokenizer revision and runtime format match the requested manifest. The sandbox checks metadata; a real cache also needs integrity validation, quota handling, eviction and recovery from partial downloads.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement cacheMatches. Draw download, validating, loading, ready and failed states, with a recovery path for storage eviction.

Expected: Complete matching cache is reused

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Stale tokenizer or format is invalidated; Partial or missing cache reloads

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Complete matching cache is reused; Stale tokenizer or format is invalidated; Partial or missing cache reloads. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Match the manifest and validate downloaded artifacts before loading. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/07-03-worker-cache/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Opt-in download → validated cache → worker initialization → ready state. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does moving inference setup into a worker solve a device memory shortage? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A cached name alone cannot establish compatible weights. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does moving inference setup into a worker solve a device memory shortage?

Interview: Does moving inference setup into a worker solve a device memory shortage? Explain the decision, a failing case and a production limitation.

Quiz: Does moving inference setup into a worker solve a device memory shortage?

Yes, workers have unlimited GPU memory.

Yes, IndexedDB becomes VRAM.

No; worker isolation improves responsiveness but memory still needs budgeting.

Reference: No; worker isolation improves responsiveness but memory still needs budgeting. — CPU scheduling, persistent storage and GPU memory are different resources. A worker changes where code runs, not the device’s capacity.

Sources:

WebLLM: workers and optional IndexedDB cache configuration: https://webllm.mlc.ai/docs/user/advanced_usage.html

MDN: Web Workers: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

MDN: WebGPU: https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API

WebLLM: browser inference: https://webllm.mlc.ai/docs/

### Hybrid routing must never silently export private input

A hybrid application may use a local model for private or quick tasks and a cloud model for explicitly permitted work. The privacy rule comes first. If private input does not fit the device, stop and explain the limit; do not treat memory pressure as consent to upload.

The fixture requires WebGPU availability, model fit and a context limit for local inference. Nonprivate work can use cloud only when cloudAllowed is explicitly true. PII protection uses a trusted policy flag; this code does not detect all personal information.

A PII detector can miss sensitive content, and local execution is not a full privacy guarantee. Browser extensions, logs and stored files also need review.

Mental model: Policy classification → local capacity → local, allowed cloud or blocked. Picture the boundary as a checked gate between stages.

Boundary: A PII detector can miss sensitive content, and local execution is not a full privacy guarantee. Browser extensions, logs and stored files also need review.

Worked example: function routeInference(prompt, deviceCapabilities) {
  const d=deviceCapabilities;
  if (!Number.isSafeInteger(prompt.tokens) || prompt.tokens < 0) return 'blocked';
  const local=d.webgpu === true && d.fits === true && Number.isSafeInteger(prompt.tokens) && prompt.tokens >= 0 && prompt.tokens <= d.maxContext;
  if (prompt.pii === true) return local ? 'local' : 'blocked';
  if (local && prompt.lowLatency === true) return 'local';
  if (d.cloudAllowed === true) return 'cloud';
  return local ? 'local' : 'blocked';
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract edge-slm.zip, install Node.js LTS, then open production-ai/07-04-private-hybrid-router.

Tools for this exercise: JavaScript · local isolated workbench; WebLLM, WebGPU / IndexedDB / Web Workers as documented optional extensions

Course tool and framework map: WebLLM (Open source · device resources); WebGPU / IndexedDB / Web Workers (Open web APIs · browser dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement routeInference. Include private oversized input and denied cloud consent in your tests; document an honest user-facing blocked message.

Terminal folder: production-ai/07-04-private-hybrid-router

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture requires WebGPU availability, model fit and a context limit for local inference. Nonprivate work can use cloud only when cloudAllowed is explicitly true. PII protection uses a trusted policy flag; this code does not detect all personal information.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement routeInference. Include private oversized input and denied cloud consent in your tests; document an honest user-facing blocked message.

Expected: Private input stays local when it fits

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Private overflow is blocked, never uploaded; Public cloud needs permission; quick local work stays local

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Private input stays local when it fits; Private overflow is blocked, never uploaded; Public cloud needs permission; quick local work stays local. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Block private overflow; require explicit permitted cloud routing for other work. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/07-04-private-hybrid-router/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Policy classification → local capacity → local, allowed cloud or blocked. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Private input exceeds the local device’s capacity. What should the hybrid router do? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Capacity failure cannot authorize data transfer. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Private input exceeds the local device’s capacity. What should the hybrid router do?

Interview: Private input exceeds the local device’s capacity. What should the hybrid router do? Explain the decision, a failing case and a production limitation.

Quiz: Private input exceeds the local device’s capacity. What should the hybrid router do?

Block or offer a separately reviewed/redacted alternative.

Upload automatically to avoid frustrating the user.

Assume using the app is blanket consent.

Reference: Block or offer a separately reviewed/redacted alternative. — Availability pressure does not change the privacy boundary. A safer alternative requires an explicit data-handling decision.

Sources:

WebLLM: browser inference: https://webllm.mlc.ai/docs/

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
