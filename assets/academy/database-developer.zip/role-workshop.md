# Database / SQL Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
SQL grain and NULL

Define what one row represents before joining or aggregating. NULL means missing/unknown, so COUNT(column) and COUNT(*) can answer different questions.
Mental model: Count people or filled-in forms deliberately; they are not always the same number.
Case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30.
Task: Create that fixture in SQLite or PostgreSQL. Run all three aggregates, then join a two-row child table and explain why an unqualified sum can multiply values.
Acceptance: The aggregate values match the fixture and the join's row multiplication is explicitly shown.
Troubleshooting: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship.
Deliverable: grain diagram and SQL worksheet

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Indexes and selectivity

An index trades storage and write work for possible lookup efficiency. The planner considers data distribution; adding an index does not compel its use.
Mental model: A book index helps find a rare topic but not when you need nearly every page.
Case: Filtering one ID differs from selecting all rows in a two-record table.
Task: Create a larger synthetic fixture, capture EXPLAIN before and after an index on the filter key and compare selective versus broad predicates. Record row counts and engine version.
Acceptance: A plan comparison with actual selected rows and no claim that every query improves.
Troubleshooting: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan.
Deliverable: index experiment SQL and measured trade-offs

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Compatible schema migration

An expand-and-contract migration adds a compatible structure, migrates data, updates callers and only then removes obsolete fields. Rollback must account for writes made during transition.
Mental model: Keep the old entrance open while people learn the new route.
Case: A new priority column starts nullable/defaulted while old clients still insert title only.
Task: Write forward SQL, backfill in bounded batches and test old/new insert fixtures. Record when a NOT NULL constraint becomes safe and what evidence permits removing the old contract.
Acceptance: Both client versions work during expansion; backfill counts reconcile.
Troubleshooting: Enforcing a new required field before callers change causes avoidable write failures.
Deliverable: migration scripts, compatibility matrix and recovery decision

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
