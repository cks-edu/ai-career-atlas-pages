# Database / SQL Developer

Software Engineering

Start with sql grain and null. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward migration scripts, compatibility matrix and recovery decision.

## beginner

Create that fixture in SQLite or PostgreSQL. Run all three aggregates, then join a two-row child table and explain why an unqualified sum can multiply values.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### SQL grain and NULL
Define what one row represents before joining or aggregating. NULL means missing/unknown, so COUNT(column) and COUNT(*) can answer different questions.
Mental model: Count people or filled-in forms deliberately; they are not always the same number.
Limit: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship.
Example: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create that fixture in SQLite or PostgreSQL. Run all three aggregates, then join a two-row child table and explain why an unqualified sum can multiply values.
Expected: The aggregate values match the fixture and the join's row multiplication is explicitly shown.

6. Role workshop · debug and verify
An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save grain diagram and SQL worksheet. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The aggregate values match the fixture and the join's row multiplication is explicitly shown.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
SQL grain and NULL: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: grain diagram and SQL worksheet
The aggregate values match the fixture and the join's row multiplication is explicitly shown.

Interview: Work through this Database / SQL Developer case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Define what one row represents before joining or aggregating. NULL means missing/unknown, so COUNT(column) and COUNT(*) can answer different questions. Expected evidence: The aggregate values match the fixture and the join's row multiplication is explicitly shown. Diagnosis: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship. State the limits of the mental model: Count people or filled-in forms deliberately; they are not always the same number.

Resume: Built grain diagram and SQL worksheet using PostgreSQL SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a larger synthetic fixture, capture EXPLAIN before and after an index on the filter key and compare selective versus broad predicates. Record row counts and engine version.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Indexes and selectivity
An index trades storage and write work for possible lookup efficiency. The planner considers data distribution; adding an index does not compel its use.
Mental model: A book index helps find a rare topic but not when you need nearly every page.
Limit: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan.
Example: Filtering one ID differs from selecting all rows in a two-record table.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Filtering one ID differs from selecting all rows in a two-record table. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a larger synthetic fixture, capture EXPLAIN before and after an index on the filter key and compare selective versus broad predicates. Record row counts and engine version.
Expected: A plan comparison with actual selected rows and no claim that every query improves.

6. Role workshop · debug and verify
If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save index experiment SQL and measured trade-offs. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A plan comparison with actual selected rows and no claim that every query improves.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Indexes and selectivity: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: index experiment SQL and measured trade-offs
A plan comparison with actual selected rows and no claim that every query improves.

Interview: Work through this Database / SQL Developer case: Filtering one ID differs from selecting all rows in a two-record table. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An index trades storage and write work for possible lookup efficiency. The planner considers data distribution; adding an index does not compel its use. Expected evidence: A plan comparison with actual selected rows and no claim that every query improves. Diagnosis: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan. State the limits of the mental model: A book index helps find a rare topic but not when you need nearly every page.

Resume: Built index experiment SQL and measured trade-offs using PostgreSQL SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write forward SQL, backfill in bounded batches and test old/new insert fixtures. Record when a NOT NULL constraint becomes safe and what evidence permits removing the old contract.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Compatible schema migration
An expand-and-contract migration adds a compatible structure, migrates data, updates callers and only then removes obsolete fields. Rollback must account for writes made during transition.
Mental model: Keep the old entrance open while people learn the new route.
Limit: Enforcing a new required field before callers change causes avoidable write failures.
Example: A new priority column starts nullable/defaulted while old clients still insert title only.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Enforcing a new required field before callers change causes avoidable write failures.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A new priority column starts nullable/defaulted while old clients still insert title only. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write forward SQL, backfill in bounded batches and test old/new insert fixtures. Record when a NOT NULL constraint becomes safe and what evidence permits removing the old contract.
Expected: Both client versions work during expansion; backfill counts reconcile.

6. Role workshop · debug and verify
Enforcing a new required field before callers change causes avoidable write failures. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save migration scripts, compatibility matrix and recovery decision. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Both client versions work during expansion; backfill counts reconcile.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Compatible schema migration: Enforcing a new required field before callers change causes avoidable write failures.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: migration scripts, compatibility matrix and recovery decision
Both client versions work during expansion; backfill counts reconcile.

Interview: Work through this Database / SQL Developer case: A new priority column starts nullable/defaulted while old clients still insert title only. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An expand-and-contract migration adds a compatible structure, migrates data, updates callers and only then removes obsolete fields. Rollback must account for writes made during transition. Expected evidence: Both client versions work during expansion; backfill counts reconcile. Diagnosis: Enforcing a new required field before callers change causes avoidable write failures. State the limits of the mental model: Keep the old entrance open while people learn the new route.

Resume: Built migration scripts, compatibility matrix and recovery decision using PostgreSQL SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
