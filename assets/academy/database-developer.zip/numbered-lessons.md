# Database / SQL Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Database / SQL Developer: Use the concept to complete this role exercise: Write a grouped aggregate and explain NULL behavior

SQL grain and NULL: Define what one row represents before joining or aggregating. NULL means missing/unknown, so COUNT(column) and COUNT(*) can answer different questions.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. The practical workshop develops this into: Create that fixture in SQLite or PostgreSQL. Run all three aggregates, then join a two-row child table and explain why an unqualified sum can multiply values.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: Count people or filled-in forms deliberately; they are not always the same number.

Define what one row represents before joining or aggregating. NULL means missing/unknown, so COUNT(column) and COUNT(*) can answer different questions.

Worked example: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: PostgreSQL SQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Database / SQL Developer: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30.

Predict the worked case

Read this case without running a tool: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Database / SQL Developer role interview. Explain keys and constraints using this case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. State the evidence, one alternative and where the mental model stops.

Quiz: After the SQL grain and NULL rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### SQL grain and NULL

Define what one row represents before joining or aggregating. NULL means missing/unknown, so COUNT(column) and COUNT(*) can answer different questions. In this role, work through: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. The practical workshop develops this into: Create that fixture in SQLite or PostgreSQL. Run all three aggregates, then join a two-row child table and explain why an unqualified sum can multiply values.

Mental model: Count people or filled-in forms deliberately; they are not always the same number.

Boundary: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship.

Worked example: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PostgreSQL SQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Database / SQL Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create that fixture in SQLite or PostgreSQL. Run all three aggregates, then join a two-row child table and explain why an unqualified sum can multiply values.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create that fixture in SQLite or PostgreSQL. Run all three aggregates, then join a two-row child table and explain why an unqualified sum can multiply values.

Expected: The aggregate values match the fixture and the join's row multiplication is explicitly shown.

Role workshop · debug and verify

An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save grain diagram and SQL worksheet. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The aggregate values match the fixture and the join's row multiplication is explicitly shown.

Expected: The aggregate values match the fixture and the join's row multiplication is explicitly shown.

Troubleshoot: The role exercise differs from the prediction: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: grain diagram and SQL worksheet; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with sql grain and null. Use the glossary below, then write your prediction for: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Database / SQL Developer role interview. Explain sql grain and null using this case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate sql grain and null to a system or workflow you know. Explain sql grain and null using this case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: An inflated total usually means a grain mismatch; aggregate the child first or correct the relationship.

Interview: Explain sql grain and null using this case: Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Three rows with amounts 10,20,NULL have COUNT(*)=3, COUNT(amount)=2 and SUM(amount)=30.

The aggregate values match the fixture and the join's row multiplication is explicitly shown.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: The aggregate values match the fixture and the join's row multiplication is explicitly shown. — Define what one row represents before joining or aggregating. NULL means missing/unknown, so COUNT(column) and COUNT(*) can answer different questions. The aggregate values match the fixture and the join's row multiplication is explicitly shown.

Sources:

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Database / SQL Developer: Use the concept to complete this role exercise: Add a constraint and compare query plans before and after an index

Indexes and selectivity: An index trades storage and write work for possible lookup efficiency. The planner considers data distribution; adding an index does not compel its use.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: Filtering one ID differs from selecting all rows in a two-record table. The practical workshop develops this into: Create a larger synthetic fixture, capture EXPLAIN before and after an index on the filter key and compare selective versus broad predicates. Record row counts and engine version.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: A book index helps find a rare topic but not when you need nearly every page.

An index trades storage and write work for possible lookup efficiency. The planner considers data distribution; adding an index does not compel its use.

Worked example: Filtering one ID differs from selecting all rows in a two-record table.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: PostgreSQL SQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Database / SQL Developer: Filtering one ID differs from selecting all rows in a two-record table.

Predict the worked case

Read this case without running a tool: Filtering one ID differs from selecting all rows in a two-record table. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: Filtering one ID differs from selecting all rows in a two-record table. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Filtering one ID differs from selecting all rows in a two-record table. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: Filtering one ID differs from selecting all rows in a two-record table. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Database / SQL Developer role interview. Explain idempotent processing using this case: Filtering one ID differs from selecting all rows in a two-record table. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: Filtering one ID differs from selecting all rows in a two-record table. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: Filtering one ID differs from selecting all rows in a two-record table. State the evidence, one alternative and where the mental model stops.

Quiz: After the Indexes and selectivity rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Indexes and selectivity

An index trades storage and write work for possible lookup efficiency. The planner considers data distribution; adding an index does not compel its use. In this role, work through: Filtering one ID differs from selecting all rows in a two-record table. The practical workshop develops this into: Create a larger synthetic fixture, capture EXPLAIN before and after an index on the filter key and compare selective versus broad predicates. Record row counts and engine version.

Mental model: A book index helps find a rare topic but not when you need nearly every page.

Boundary: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan.

Worked example: Filtering one ID differs from selecting all rows in a two-record table.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PostgreSQL SQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Database / SQL Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a larger synthetic fixture, capture EXPLAIN before and after an index on the filter key and compare selective versus broad predicates. Record row counts and engine version.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Filtering one ID differs from selecting all rows in a two-record table. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a larger synthetic fixture, capture EXPLAIN before and after an index on the filter key and compare selective versus broad predicates. Record row counts and engine version.

Expected: A plan comparison with actual selected rows and no claim that every query improves.

Role workshop · debug and verify

If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save index experiment SQL and measured trade-offs. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A plan comparison with actual selected rows and no claim that every query improves.

Expected: A plan comparison with actual selected rows and no claim that every query improves.

Troubleshoot: The role exercise differs from the prediction: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: index experiment SQL and measured trade-offs; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with indexes and selectivity. Use the glossary below, then write your prediction for: Filtering one ID differs from selecting all rows in a two-record table. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Database / SQL Developer role interview. Explain indexes and selectivity using this case: Filtering one ID differs from selecting all rows in a two-record table. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate indexes and selectivity to a system or workflow you know. Explain indexes and selectivity using this case: Filtering one ID differs from selecting all rows in a two-record table. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the index is unused, inspect selectivity, statistics and expression compatibility before forcing a plan.

Interview: Explain indexes and selectivity using this case: Filtering one ID differs from selecting all rows in a two-record table. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Filtering one ID differs from selecting all rows in a two-record table.

Ignore the failing case and keep only the successful screenshot.

A plan comparison with actual selected rows and no claim that every query improves.

Treat any successful command as proof that all business and access rules passed.

Reference: A plan comparison with actual selected rows and no claim that every query improves. — An index trades storage and write work for possible lookup efficiency. The planner considers data distribution; adding an index does not compel its use. A plan comparison with actual selected rows and no claim that every query improves.

Sources:

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Database / SQL Developer: Use the concept to complete this role exercise: Plan a compatible schema migration with recovery evidence

Compatible schema migration: An expand-and-contract migration adds a compatible structure, migrates data, updates callers and only then removes obsolete fields. Rollback must account for writes made during transition.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: A new priority column starts nullable/defaulted while old clients still insert title only. The practical workshop develops this into: Write forward SQL, backfill in bounded batches and test old/new insert fixtures. Record when a NOT NULL constraint becomes safe and what evidence permits removing the old contract.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: Keep the old entrance open while people learn the new route.

An expand-and-contract migration adds a compatible structure, migrates data, updates callers and only then removes obsolete fields. Rollback must account for writes made during transition.

Worked example: A new priority column starts nullable/defaulted while old clients still insert title only.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: PostgreSQL SQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Database / SQL Developer: A new priority column starts nullable/defaulted while old clients still insert title only.

Predict the worked case

Read this case without running a tool: A new priority column starts nullable/defaulted while old clients still insert title only. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: A new priority column starts nullable/defaulted while old clients still insert title only. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new priority column starts nullable/defaulted while old clients still insert title only. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: A new priority column starts nullable/defaulted while old clients still insert title only. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Database / SQL Developer role interview. Explain transaction and recovery using this case: A new priority column starts nullable/defaulted while old clients still insert title only. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: A new priority column starts nullable/defaulted while old clients still insert title only. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: A new priority column starts nullable/defaulted while old clients still insert title only. State the evidence, one alternative and where the mental model stops.

Quiz: After the Compatible schema migration rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Compatible schema migration

An expand-and-contract migration adds a compatible structure, migrates data, updates callers and only then removes obsolete fields. Rollback must account for writes made during transition. In this role, work through: A new priority column starts nullable/defaulted while old clients still insert title only. The practical workshop develops this into: Write forward SQL, backfill in bounded batches and test old/new insert fixtures. Record when a NOT NULL constraint becomes safe and what evidence permits removing the old contract.

Mental model: Keep the old entrance open while people learn the new route.

Boundary: Enforcing a new required field before callers change causes avoidable write failures.

Worked example: A new priority column starts nullable/defaulted while old clients still insert title only.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PostgreSQL SQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Database / SQL Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write forward SQL, backfill in bounded batches and test old/new insert fixtures. Record when a NOT NULL constraint becomes safe and what evidence permits removing the old contract.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A new priority column starts nullable/defaulted while old clients still insert title only. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write forward SQL, backfill in bounded batches and test old/new insert fixtures. Record when a NOT NULL constraint becomes safe and what evidence permits removing the old contract.

Expected: Both client versions work during expansion; backfill counts reconcile.

Role workshop · debug and verify

Enforcing a new required field before callers change causes avoidable write failures. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save migration scripts, compatibility matrix and recovery decision. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Both client versions work during expansion; backfill counts reconcile.

Expected: Both client versions work during expansion; backfill counts reconcile.

Troubleshoot: The role exercise differs from the prediction: Enforcing a new required field before callers change causes avoidable write failures.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: migration scripts, compatibility matrix and recovery decision; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with compatible schema migration. Use the glossary below, then write your prediction for: A new priority column starts nullable/defaulted while old clients still insert title only. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Database / SQL Developer role interview. Explain compatible schema migration using this case: A new priority column starts nullable/defaulted while old clients still insert title only. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate compatible schema migration to a system or workflow you know. Explain compatible schema migration using this case: A new priority column starts nullable/defaulted while old clients still insert title only. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Enforcing a new required field before callers change causes avoidable write failures.

Interview: Explain compatible schema migration using this case: A new priority column starts nullable/defaulted while old clients still insert title only. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A new priority column starts nullable/defaulted while old clients still insert title only.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Both client versions work during expansion; backfill counts reconcile.

Reference: Both client versions work during expansion; backfill counts reconcile. — An expand-and-contract migration adds a compatible structure, migrates data, updates callers and only then removes obsolete fields. Rollback must account for writes made during transition. Both client versions work during expansion; backfill counts reconcile.

Sources:

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
