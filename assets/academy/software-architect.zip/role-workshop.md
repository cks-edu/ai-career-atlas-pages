# Software Architect — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Bounded responsibilities

Architecture assigns ownership and contracts to meet constraints. More services add deployment and failure boundaries, so decomposition needs a business or operational reason.
Mental model: Separate departments when their responsibilities differ, not simply to draw more boxes.
Case: Orders own purchase state while notifications own delivery attempts.
Task: Draw a modular system with data owners and allowed calls. List latency, consistency and team constraints; identify one reason to keep modules together.
Acceptance: A diagram and rationale tied to actual requirements.
Troubleshooting: A shared database edited by every service can defeat the ownership shown in the diagram.
Deliverable: context/container diagrams and ownership ADR

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Consistency and outbox choices

A local transaction can coordinate an order and an outbox record; remote delivery still needs retry and duplicate handling. State the exact consistency guarantee.
Mental model: Record the sale and mailing slip together, then track delivery separately.
Case: A crash after delivery but before acknowledgment can cause duplicate delivery.
Task: Run outbox.py, draw every crash point and extend the fixture with a poison event. Define retry, dead-letter and operator review behavior without blocking all later work.
Acceptance: One business effect for a repeated event and a visible failed-event path.
Troubleshooting: A global exactly-once claim hides scope; specify which effect is protected and by what key.
Deliverable: failure matrix and consistency ADR

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Architecture trade-offs under change

A design decision should be revisited when constraints change. Compare alternatives using explicit measures and migration costs rather than tool popularity.
Mental model: A bridge suitable for bicycles may need redesign when freight traffic arrives.
Case: A tenfold read increase may justify a projection, but stale reads must be acceptable.
Task: Propose a read model, define staleness tolerance and compare synchronous reads with an asynchronous projection. Include migration, backfill, failure and rollback steps.
Acceptance: A decision table with measurable acceptance criteria and rejected alternatives.
Troubleshooting: A faster design that violates required consistency is not an improvement for that use case.
Deliverable: evolution proposal and fitness-function checklist

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
