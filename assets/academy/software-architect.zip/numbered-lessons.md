# Software Architect — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Boundaries and ownership: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.

Apply boundaries and ownership in Software Architect: Use the concept to complete this role exercise: Draw a modular system and its data ownership

Bounded responsibilities: Architecture assigns ownership and contracts to meet constraints. More services add deployment and failure boundaries, so decomposition needs a business or operational reason.

### Boundaries and ownership

A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. In this role, work through: Orders own purchase state while notifications own delivery attempts. The practical workshop develops this into: Draw a modular system with data owners and allowed calls. List latency, consistency and team constraints; identify one reason to keep modules together.

Mental model: Departments own different ledgers and exchange agreed forms.

Boundary: Drawing more boxes does not make a system more reliable.

Role application: Separate departments when their responsibilities differ, not simply to draw more boxes.

Architecture assigns ownership and contracts to meet constraints. More services add deployment and failure boundaries, so decomposition needs a business or operational reason.

Worked example: Orders own purchase state while notifications own delivery attempts.

Shared foundation example: The order service owns orders; a notification consumer handles messages.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Architecture decision records and diagrams (Open documentation format); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Software Architect: Orders own purchase state while notifications own delivery attempts.

Predict the worked case

Read this case without running a tool: Orders own purchase state while notifications own delivery attempts. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in boundaries and ownership.

Connect the concept to the role

Apply this rule: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Drawing more boxes does not make a system more reliable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies boundaries and ownership to this case: Orders own purchase state while notifications own delivery attempts. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Orders own purchase state while notifications own delivery attempts. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Boundaries and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with boundaries and ownership. Use the glossary below, then write your prediction for: Orders own purchase state while notifications own delivery attempts. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Architect role interview. Explain boundaries and ownership using this case: Orders own purchase state while notifications own delivery attempts. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate boundaries and ownership to a system or workflow you know. Explain boundaries and ownership using this case: Orders own purchase state while notifications own delivery attempts. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which component owns the truth about whether an order exists?

Interview: Explain boundaries and ownership using this case: Orders own purchase state while notifications own delivery attempts. State the evidence, one alternative and where the mental model stops.

Quiz: After the Bounded responsibilities rehearsal, check this foundation: Two services both write one business record using incompatible rules. What should be clarified first?

The owning service and the contract through which others request changes.

Which service can issue writes faster.

Whether both services can share unrestricted credentials.

Reference: The owning service and the contract through which others request changes. — Ownership defines responsibility for invariants. Sharing write access does not resolve conflicting business rules.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Bounded responsibilities

Architecture assigns ownership and contracts to meet constraints. More services add deployment and failure boundaries, so decomposition needs a business or operational reason. In this role, work through: Orders own purchase state while notifications own delivery attempts. The practical workshop develops this into: Draw a modular system with data owners and allowed calls. List latency, consistency and team constraints; identify one reason to keep modules together.

Mental model: Separate departments when their responsibilities differ, not simply to draw more boxes.

Boundary: A shared database edited by every service can defeat the ownership shown in the diagram.

Worked example: Orders own purchase state while notifications own delivery attempts.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Architecture decision records and diagrams (Open documentation format); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Software Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Draw a modular system with data owners and allowed calls. List latency, consistency and team constraints; identify one reason to keep modules together.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Orders own purchase state while notifications own delivery attempts. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Draw a modular system with data owners and allowed calls. List latency, consistency and team constraints; identify one reason to keep modules together.

```
python3 outbox.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A diagram and rationale tied to actual requirements.

Role workshop · debug and verify

A shared database edited by every service can defeat the ownership shown in the diagram. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save context/container diagrams and ownership ADR. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A diagram and rationale tied to actual requirements.

Expected: A diagram and rationale tied to actual requirements.

Troubleshoot: The role exercise differs from the prediction: A shared database edited by every service can defeat the ownership shown in the diagram.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: context/container diagrams and ownership ADR; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with bounded responsibilities. Use the glossary below, then write your prediction for: Orders own purchase state while notifications own delivery attempts. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Architect role interview. Explain bounded responsibilities using this case: Orders own purchase state while notifications own delivery attempts. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate bounded responsibilities to a system or workflow you know. Explain bounded responsibilities using this case: Orders own purchase state while notifications own delivery attempts. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A shared database edited by every service can defeat the ownership shown in the diagram.

Interview: Explain bounded responsibilities using this case: Orders own purchase state while notifications own delivery attempts. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Orders own purchase state while notifications own delivery attempts.

A diagram and rationale tied to actual requirements.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A diagram and rationale tied to actual requirements. — Architecture assigns ownership and contracts to meet constraints. More services add deployment and failure boundaries, so decomposition needs a business or operational reason. A diagram and rationale tied to actual requirements.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Transactional outbox: Write business data and the event to publish in one local transaction, then deliver the event separately.

Apply transactional outbox in Software Architect: Use the concept to complete this role exercise: Compare two architecture options against explicit constraints

Consistency and outbox choices: A local transaction can coordinate an order and an outbox record; remote delivery still needs retry and duplicate handling. State the exact consistency guarantee.

### Transactional outbox

Write business data and the event to publish in one local transaction, then deliver the event separately. In this role, work through: A crash after delivery but before acknowledgment can cause duplicate delivery. The practical workshop develops this into: Run outbox.py, draw every crash point and extend the fixture with a poison event. Define retry, dead-letter and operator review behavior without blocking all later work.

Mental model: Record a sale and its mailing slip in the same ledger before dispatch.

Boundary: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Role application: Record the sale and mailing slip together, then track delivery separately.

A local transaction can coordinate an order and an outbox record; remote delivery still needs retry and duplicate handling. State the exact consistency guarantee.

Worked example: A crash after delivery but before acknowledgment can cause duplicate delivery.

Shared foundation example: The reference stores order-1 and its pending event together.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Architecture decision records and diagrams (Open documentation format); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Software Architect: A crash after delivery but before acknowledgment can cause duplicate delivery.

Predict the worked case

Read this case without running a tool: A crash after delivery but before acknowledgment can cause duplicate delivery. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transactional outbox.

Connect the concept to the role

Apply this rule: Write business data and the event to publish in one local transaction, then deliver the event separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transactional outbox to this case: A crash after delivery but before acknowledgment can cause duplicate delivery. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A crash after delivery but before acknowledgment can cause duplicate delivery. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Transactional outbox; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactional outbox. Use the glossary below, then write your prediction for: A crash after delivery but before acknowledgment can cause duplicate delivery. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Architect role interview. Explain transactional outbox using this case: A crash after delivery but before acknowledgment can cause duplicate delivery. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactional outbox to a system or workflow you know. Explain transactional outbox using this case: A crash after delivery but before acknowledgment can cause duplicate delivery. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why can publishing first lose consistency if the database write fails?

Interview: Explain transactional outbox using this case: A crash after delivery but before acknowledgment can cause duplicate delivery. State the evidence, one alternative and where the mental model stops.

Quiz: After the Consistency and outbox choices rehearsal, check this foundation: Business data commits but publishing its event fails. Which design closes this local write/publish gap?

Publish first, then hope the business write succeeds.

Commit the data and pending outbox entry in one local transaction.

Use a longer broker timeout without recording pending work.

Reference: Commit the data and pending outbox entry in one local transaction. — The outbox preserves a durable publication intent. Delivery can still repeat, so consumers need suitable deduplication.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Consistency and outbox choices

A local transaction can coordinate an order and an outbox record; remote delivery still needs retry and duplicate handling. State the exact consistency guarantee. In this role, work through: A crash after delivery but before acknowledgment can cause duplicate delivery. The practical workshop develops this into: Run outbox.py, draw every crash point and extend the fixture with a poison event. Define retry, dead-letter and operator review behavior without blocking all later work.

Mental model: Record the sale and mailing slip together, then track delivery separately.

Boundary: A global exactly-once claim hides scope; specify which effect is protected and by what key.

Worked example: A crash after delivery but before acknowledgment can cause duplicate delivery.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Architecture decision records and diagrams (Open documentation format); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Software Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run outbox.py, draw every crash point and extend the fixture with a poison event. Define retry, dead-letter and operator review behavior without blocking all later work.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A crash after delivery but before acknowledgment can cause duplicate delivery. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run outbox.py, draw every crash point and extend the fixture with a poison event. Define retry, dead-letter and operator review behavior without blocking all later work.

```
python3 outbox.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One business effect for a repeated event and a visible failed-event path.

Role workshop · debug and verify

A global exactly-once claim hides scope; specify which effect is protected and by what key. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save failure matrix and consistency ADR. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One business effect for a repeated event and a visible failed-event path.

Expected: One business effect for a repeated event and a visible failed-event path.

Troubleshoot: The role exercise differs from the prediction: A global exactly-once claim hides scope; specify which effect is protected and by what key.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: failure matrix and consistency ADR; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with consistency and outbox choices. Use the glossary below, then write your prediction for: A crash after delivery but before acknowledgment can cause duplicate delivery. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Architect role interview. Explain consistency and outbox choices using this case: A crash after delivery but before acknowledgment can cause duplicate delivery. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate consistency and outbox choices to a system or workflow you know. Explain consistency and outbox choices using this case: A crash after delivery but before acknowledgment can cause duplicate delivery. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A global exactly-once claim hides scope; specify which effect is protected and by what key.

Interview: Explain consistency and outbox choices using this case: A crash after delivery but before acknowledgment can cause duplicate delivery. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A crash after delivery but before acknowledgment can cause duplicate delivery.

Ignore the failing case and keep only the successful screenshot.

One business effect for a repeated event and a visible failed-event path.

Treat any successful command as proof that all business and access rules passed.

Reference: One business effect for a repeated event and a visible failed-event path. — A local transaction can coordinate an order and an outbox record; remote delivery still needs retry and duplicate handling. State the exact consistency guarantee. One business effect for a repeated event and a visible failed-event path.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Failure semantics: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.

Apply failure semantics in Software Architect: Use the concept to complete this role exercise: Rehearse crash and duplicate-delivery scenarios and defend trade-offs

Architecture trade-offs under change: A design decision should be revisited when constraints change. Compare alternatives using explicit measures and migration costs rather than tool popularity.

### Failure semantics

Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. In this role, work through: A tenfold read increase may justify a projection, but stale reads must be acceptable. The practical workshop develops this into: Propose a read model, define staleness tolerance and compare synchronous reads with an asynchronous projection. Include migration, backfill, failure and rollback steps.

Mental model: Track a parcel even when the receipt acknowledgment is lost.

Boundary: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Role application: A bridge suitable for bicycles may need redesign when freight traffic arrives.

A design decision should be revisited when constraints change. Compare alternatives using explicit measures and migration costs rather than tool popularity.

Worked example: A tenfold read increase may justify a projection, but stale reads must be acceptable.

Shared foundation example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Architecture decision records and diagrams (Open documentation format); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Software Architect: A tenfold read increase may justify a projection, but stale reads must be acceptable.

Predict the worked case

Read this case without running a tool: A tenfold read increase may justify a projection, but stale reads must be acceptable. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure semantics.

Connect the concept to the role

Apply this rule: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure semantics to this case: A tenfold read increase may justify a projection, but stale reads must be acceptable. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A tenfold read increase may justify a projection, but stale reads must be acceptable. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Failure semantics; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure semantics. Use the glossary below, then write your prediction for: A tenfold read increase may justify a projection, but stale reads must be acceptable. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Architect role interview. Explain failure semantics using this case: A tenfold read increase may justify a projection, but stale reads must be acceptable. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure semantics to a system or workflow you know. Explain failure semantics using this case: A tenfold read increase may justify a projection, but stale reads must be acceptable. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you recover a permanently failing event without blocking all orders?

Interview: Explain failure semantics using this case: A tenfold read increase may justify a projection, but stale reads must be acceptable. State the evidence, one alternative and where the mental model stops.

Quiz: After the Architecture trade-offs under change rehearsal, check this foundation: A consumer commits its effect and crashes before acknowledging. What must the design handle?

The broker can infer the effect and guarantee no replay.

The effect must be automatically rolled back by the broker.

The message can be delivered again after the effect already happened.

Reference: The message can be delivered again after the effect already happened. — Acknowledgment and the business effect are separate boundaries. Model the crash window and make replay safe.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Architecture trade-offs under change

A design decision should be revisited when constraints change. Compare alternatives using explicit measures and migration costs rather than tool popularity. In this role, work through: A tenfold read increase may justify a projection, but stale reads must be acceptable. The practical workshop develops this into: Propose a read model, define staleness tolerance and compare synchronous reads with an asynchronous projection. Include migration, backfill, failure and rollback steps.

Mental model: A bridge suitable for bicycles may need redesign when freight traffic arrives.

Boundary: A faster design that violates required consistency is not an improvement for that use case.

Worked example: A tenfold read increase may justify a projection, but stale reads must be acceptable.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Architecture decision records and diagrams (Open documentation format); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Software Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Propose a read model, define staleness tolerance and compare synchronous reads with an asynchronous projection. Include migration, backfill, failure and rollback steps.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A tenfold read increase may justify a projection, but stale reads must be acceptable. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Propose a read model, define staleness tolerance and compare synchronous reads with an asynchronous projection. Include migration, backfill, failure and rollback steps.

```
python3 outbox.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A decision table with measurable acceptance criteria and rejected alternatives.

Role workshop · debug and verify

A faster design that violates required consistency is not an improvement for that use case. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save evolution proposal and fitness-function checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A decision table with measurable acceptance criteria and rejected alternatives.

Expected: A decision table with measurable acceptance criteria and rejected alternatives.

Troubleshoot: The role exercise differs from the prediction: A faster design that violates required consistency is not an improvement for that use case.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: evolution proposal and fitness-function checklist; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with architecture trade-offs under change. Use the glossary below, then write your prediction for: A tenfold read increase may justify a projection, but stale reads must be acceptable. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Architect role interview. Explain architecture trade-offs under change using this case: A tenfold read increase may justify a projection, but stale reads must be acceptable. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate architecture trade-offs under change to a system or workflow you know. Explain architecture trade-offs under change using this case: A tenfold read increase may justify a projection, but stale reads must be acceptable. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A faster design that violates required consistency is not an improvement for that use case.

Interview: Explain architecture trade-offs under change using this case: A tenfold read increase may justify a projection, but stale reads must be acceptable. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A tenfold read increase may justify a projection, but stale reads must be acceptable.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A decision table with measurable acceptance criteria and rejected alternatives.

Reference: A decision table with measurable acceptance criteria and rejected alternatives. — A design decision should be revisited when constraints change. Compare alternatives using explicit measures and migration costs rather than tool popularity. A decision table with measurable acceptance criteria and rejected alternatives.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
