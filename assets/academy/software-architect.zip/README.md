# Software Architect

Software Engineering

Start with bounded responsibilities. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward evolution proposal and fitness-function checklist.

## beginner

Draw a modular system with data owners and allowed calls. List latency, consistency and team constraints; identify one reason to keep modules together.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Boundaries and ownership
A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: Drawing more boxes does not make a system more reliable.
Example: The order service owns orders; a notification consumer handles messages.
Recall: Which component owns the truth about whether an order exists?

### Bounded responsibilities
Architecture assigns ownership and contracts to meet constraints. More services add deployment and failure boundaries, so decomposition needs a business or operational reason.
Mental model: Separate departments when their responsibilities differ, not simply to draw more boxes.
Limit: A shared database edited by every service can defeat the ownership shown in the diagram.
Example: Orders own purchase state while notifications own delivery attempts.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A shared database edited by every service can defeat the ownership shown in the diagram.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Orders own purchase state while notifications own delivery attempts. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw a modular system with data owners and allowed calls. List latency, consistency and team constraints; identify one reason to keep modules together.
```
python3 outbox.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A diagram and rationale tied to actual requirements.

6. Role workshop · debug and verify
A shared database edited by every service can defeat the ownership shown in the diagram. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save context/container diagrams and ownership ADR. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A diagram and rationale tied to actual requirements.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Bounded responsibilities: A shared database edited by every service can defeat the ownership shown in the diagram.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: context/container diagrams and ownership ADR
A diagram and rationale tied to actual requirements.

Interview: Work through this Software Architect case: Orders own purchase state while notifications own delivery attempts. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Architecture assigns ownership and contracts to meet constraints. More services add deployment and failure boundaries, so decomposition needs a business or operational reason. Expected evidence: A diagram and rationale tied to actual requirements. Diagnosis: A shared database edited by every service can defeat the ownership shown in the diagram. State the limits of the mental model: Separate departments when their responsibilities differ, not simply to draw more boxes.

Resume: Built context/container diagrams and ownership ADR using Architecture decision records and diagrams; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run outbox.py, draw every crash point and extend the fixture with a poison event. Define retry, dead-letter and operator review behavior without blocking all later work.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transactional outbox
Write business data and the event to publish in one local transaction, then deliver the event separately.
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.
Example: The reference stores order-1 and its pending event together.
Recall: Why can publishing first lose consistency if the database write fails?

### Consistency and outbox choices
A local transaction can coordinate an order and an outbox record; remote delivery still needs retry and duplicate handling. State the exact consistency guarantee.
Mental model: Record the sale and mailing slip together, then track delivery separately.
Limit: A global exactly-once claim hides scope; specify which effect is protected and by what key.
Example: A crash after delivery but before acknowledgment can cause duplicate delivery.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A global exactly-once claim hides scope; specify which effect is protected and by what key.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A crash after delivery but before acknowledgment can cause duplicate delivery. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run outbox.py, draw every crash point and extend the fixture with a poison event. Define retry, dead-letter and operator review behavior without blocking all later work.
```
python3 outbox.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One business effect for a repeated event and a visible failed-event path.

6. Role workshop · debug and verify
A global exactly-once claim hides scope; specify which effect is protected and by what key. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save failure matrix and consistency ADR. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One business effect for a repeated event and a visible failed-event path.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Consistency and outbox choices: A global exactly-once claim hides scope; specify which effect is protected and by what key.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: failure matrix and consistency ADR
One business effect for a repeated event and a visible failed-event path.

Interview: Work through this Software Architect case: A crash after delivery but before acknowledgment can cause duplicate delivery. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A local transaction can coordinate an order and an outbox record; remote delivery still needs retry and duplicate handling. State the exact consistency guarantee. Expected evidence: One business effect for a repeated event and a visible failed-event path. Diagnosis: A global exactly-once claim hides scope; specify which effect is protected and by what key. State the limits of the mental model: Record the sale and mailing slip together, then track delivery separately.

Resume: Built failure matrix and consistency ADR using Architecture decision records and diagrams; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Propose a read model, define staleness tolerance and compare synchronous reads with an asynchronous projection. Include migration, backfill, failure and rollback steps.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Failure semantics
Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.
Recall: How would you recover a permanently failing event without blocking all orders?

### Architecture trade-offs under change
A design decision should be revisited when constraints change. Compare alternatives using explicit measures and migration costs rather than tool popularity.
Mental model: A bridge suitable for bicycles may need redesign when freight traffic arrives.
Limit: A faster design that violates required consistency is not an improvement for that use case.
Example: A tenfold read increase may justify a projection, but stale reads must be acceptable.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A faster design that violates required consistency is not an improvement for that use case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A tenfold read increase may justify a projection, but stale reads must be acceptable. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Propose a read model, define staleness tolerance and compare synchronous reads with an asynchronous projection. Include migration, backfill, failure and rollback steps.
```
python3 outbox.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A decision table with measurable acceptance criteria and rejected alternatives.

6. Role workshop · debug and verify
A faster design that violates required consistency is not an improvement for that use case. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save evolution proposal and fitness-function checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A decision table with measurable acceptance criteria and rejected alternatives.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Architecture trade-offs under change: A faster design that violates required consistency is not an improvement for that use case.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: evolution proposal and fitness-function checklist
A decision table with measurable acceptance criteria and rejected alternatives.

Interview: Work through this Software Architect case: A tenfold read increase may justify a projection, but stale reads must be acceptable. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A design decision should be revisited when constraints change. Compare alternatives using explicit measures and migration costs rather than tool popularity. Expected evidence: A decision table with measurable acceptance criteria and rejected alternatives. Diagnosis: A faster design that violates required consistency is not an improvement for that use case. State the limits of the mental model: A bridge suitable for bicycles may need redesign when freight traffic arrives.

Resume: Built evolution proposal and fitness-function checklist using Architecture decision records and diagrams; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
