# SAMPLE — Conversation flow and repair transcript
Role: Conversation designer
Case: Corrections are heard but not applied
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The scripted booking assistant must update every explicitly corrected critical field before confirmation.

## Evidence table
| Record | ignored_corrections (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three dialogues confirm stale values after the user has corrected them.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Add an explicit correction transition and read back the updated field before commitment.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in conversation designer.
Before release: Role-play correction, interruption, ambiguity and human handoff using new utterances.

## Design choice and trade-off
Keep tentative and confirmed slots separate; design repair paths for each critical field.
Repeated confirmations can frustrate users; focus them on ambiguity and high-cost errors.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Service conversation pack: Every branch preserves confirmed state and explains the next action.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
