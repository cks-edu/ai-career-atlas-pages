# Conversation designer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Intent and conversation goals: Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Intent and conversation goals

Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary. In this role, work through: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A helpful receptionist identifies the visit's purpose before giving directions.

Boundary: A single utterance can express several intents or none clearly.

Worked example: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Conversation designer: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly.

Predict the worked case

Read this case without running a tool: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in intent and conversation goals.

Connect the concept to the role

Apply this rule: Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A single utterance can express several intents or none clearly.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies intent and conversation goals to this case: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Intent and conversation goals; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with intent and conversation goals. Use the glossary below, then write your prediction for: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversation designer role interview. Explain intent and conversation goals using this case: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate intent and conversation goals to a system or workflow you know. Explain intent and conversation goals using this case: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain intent and conversation goals using this case: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly.

Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary. — Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary. A single utterance can express several intents or none clearly.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

### Diagnose: Corrections are heard but not applied

The scripted booking assistant must update every explicitly corrected critical field before confirmation. Three dialogues confirm stale values after the user has corrected them. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A helpful receptionist identifies the visit's purpose before giving directions.

A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly.

Worked example: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The scripted booking assistant must update every explicitly corrected critical field before confirmation. Three dialogues confirm stale values after the user has corrected them. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The scripted booking assistant must update every explicitly corrected critical field before confirmation. Apply this toy-case rule manually: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A conversation needs enough information to complete a task. Ask for missing details and confirm important choices instead of guessing.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Start with “Book a room for tomorrow.” List the missing date interpretation, time, group size and location.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

Preparation · Try step 2

Write a short dialogue that asks for missing information one useful step at a time.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

Preparation · Try step 3

Add branches for an unavailable room and a user changing their mind before confirmation.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

Preparation · Explain and check your result

The assistant does not confirm a booking with missing information, and the user can correct a choice. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A dialogue script with a happy path and two recovery branches. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The scripted booking assistant must update every explicitly corrected critical field before confirmation. Apply this toy-case rule manually: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three dialogues confirm stale values after the user has corrected them. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three dialogues confirm stale values after the user has corrected them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: corrections are heard but not applied. Use the glossary below, then write your prediction for: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversation designer role interview. Explain diagnose: corrections are heard but not applied using this case: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: corrections are heard but not applied to a system or workflow you know. Explain diagnose: corrections are heard but not applied using this case: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Role-play correction, interruption, ambiguity and human handoff using new utterances. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: corrections are heard but not applied using this case: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment. State the evidence, one alternative and where the mental model stops.

Quiz: Corrections are heard but not applied: The scripted booking assistant must update every explicitly corrected critical field before confirmation.

Change the acceptance rule after seeing an inconvenient result.

Add an explicit correction transition and read back the updated field before commitment.

Omit failed cases and report only the successful demonstrations.

Reference: Add an explicit correction transition and read back the updated field before commitment. — Add an explicit correction transition and read back the updated field before commitment. Role-play correction, interruption, ambiguity and human handoff using new utterances.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Clear writing, user research and dialogue design; basic understanding of model and speech-system limitations.

Terms:

Clarification and repair: Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Clarification and repair

Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity. In this role, work through: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A conversation partner asks which Tuesday you mean instead of repeating the calendar.

Boundary: Clarification adds effort and should be evaluated for necessity and wording.

Worked example: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Clear writing, user research and dialogue design; basic understanding of model and speech-system limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Conversation designer: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information.

Predict the worked case

Read this case without running a tool: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in clarification and repair.

Connect the concept to the role

Apply this rule: Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Clarification adds effort and should be evaluated for necessity and wording.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies clarification and repair to this case: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Clarification and repair; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with clarification and repair. Use the glossary below, then write your prediction for: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversation designer role interview. Explain clarification and repair using this case: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate clarification and repair to a system or workflow you know. Explain clarification and repair using this case: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain clarification and repair using this case: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For change my booking, ask which booking before asking for a new date; preserve already-confirmed information.

Treat a passing starter as proof of the whole role workflow.

Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity.

Ignore the failure because the tool produced an output.

Reference: Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity. — Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity. Clarification adds effort and should be evaluated for necessity and wording.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

### Integrate: Conversation repair and escalation playbook

Design a conversational service that handles corrections, ambiguity and handoff consistently. Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason. In this role, work through: Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A conversation partner asks which Tuesday you mean instead of repeating the calendar.

For change my booking, ask which booking before asking for a new date; preserve already-confirmed information.

Worked example: Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Design a conversational service that handles corrections, ambiguity and handoff consistently. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design a conversational service that handles corrections, ambiguity and handoff consistently.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

Prepare the project inputs

Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The scripted booking assistant must update every explicitly corrected critical field before confirmation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Conversation map and dialogue library; Repair/escalation rules. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: conversation repair and escalation playbook. Use the glossary below, then write your prediction for: Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversation designer role interview. Explain integrate: conversation repair and escalation playbook using this case: Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: conversation repair and escalation playbook to a system or workflow you know. Explain integrate: conversation repair and escalation playbook using this case: Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. Identify one observation that would contradict your claim.

Interview: Explain integrate: conversation repair and escalation playbook using this case: Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Conversation repair and escalation playbook at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.

Reference: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. — Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Escalation and dialogue evaluation: Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Escalation and dialogue evaluation

Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed. In this role, work through: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A relay runner hands over the baton and the race position together.

Boundary: Conversation logs require appropriate privacy and retention handling.

Worked example: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Conversation designer: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded.

Predict the worked case

Read this case without running a tool: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in escalation and dialogue evaluation.

Connect the concept to the role

Apply this rule: Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Conversation logs require appropriate privacy and retention handling.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies escalation and dialogue evaluation to this case: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Escalation and dialogue evaluation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with escalation and dialogue evaluation. Use the glossary below, then write your prediction for: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversation designer role interview. Explain escalation and dialogue evaluation using this case: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate escalation and dialogue evaluation to a system or workflow you know. Explain escalation and dialogue evaluation using this case: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain escalation and dialogue evaluation using this case: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed.

Reference: Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed. — Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed. Conversation logs require appropriate privacy and retention handling.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

### Defend: Conversation repair and escalation playbook

Design a conversational service that handles corrections, ambiguity and handoff consistently. Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules. In this role, work through: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A relay runner hands over the baton and the race position together.

After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded.

Worked example: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Design a conversational service that handles corrections, ambiguity and handoff consistently. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design a conversational service that handles corrections, ambiguity and handoff consistently.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

Prepare the project inputs

Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A reviewer must reproduce one result and identify which capabilities you implemented. Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Conversation map and dialogue library; Repair/escalation rules; Test transcript excerpts and iteration report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: conversation repair and escalation playbook. Use the glossary below, then write your prediction for: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversation designer role interview. Explain defend: conversation repair and escalation playbook using this case: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: conversation repair and escalation playbook to a system or workflow you know. Explain defend: conversation repair and escalation playbook using this case: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. Identify one observation that would contradict your claim.

Interview: Explain defend: conversation repair and escalation playbook using this case: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Conversation repair and escalation playbook at this level?

Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment. — Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment. Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/
