## beginner — Intent and conversation goals

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Intent and conversation goals
Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary.
Mental model: A helpful receptionist identifies the visit's purpose before giving directions.
Boundary: A single utterance can express several intents or none clearly.
Worked example: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Corrections are heard but not applied
The scripted booking assistant must update every explicitly corrected critical field before confirmation. Three dialogues confirm stale values after the user has corrected them. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment.
Recall: Role-play correction, interruption, ambiguity and human handoff using new utterances. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Intent and conversation goals: Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A conversation needs enough information to complete a task. Ask for missing details and confirm important choices instead of guessing.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Start with “Book a room for tomorrow.” List the missing date interpretation, time, group size and location.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

3. Try step 2
Write a short dialogue that asks for missing information one useful step at a time.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

4. Try step 3
Add branches for an unavailable room and a user changing their mind before confirmation.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

5. Explain and check your result
The assistant does not confirm a booking with missing information, and the user can correct a choice. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A dialogue script with a happy path and two recovery branches. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The scripted booking assistant must update every explicitly corrected critical field before confirmation. Apply this toy-case rule manually: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three dialogues confirm stale values after the user has corrected them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Conversation designer.
Start with “Book a room for tomorrow.” List the missing date interpretation, time, group size and location.
Write a short dialogue that asks for missing information one useful step at a time.
Add branches for an unavailable room and a user changing their mind before confirmation.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A dialogue script with a happy path and two recovery branches. Include beginner-worksheet.md and your completed Conversation flow and repair transcript.
Check: The assistant does not confirm a booking with missing information, and the user can correct a choice.

### Interview
Explain your beginner solution for Conversation designer. Use this scenario: The scripted booking assistant must update every explicitly corrected critical field before confirmation.
Review: Start with the task and permitted scope. Explain intent and conversation goals: Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary. Show the input and observed output, then address Add an explicit correction transition and read back the updated field before commitment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A dialogue script with a happy path and two recovery branches. Include beginner-worksheet.md and your completed Conversation flow and repair transcript.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

