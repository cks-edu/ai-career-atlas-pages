# Conversation designer

AI Engineering · Beginner → Intermediate → Advanced

Start with Intent and conversation goals. A conversation needs enough information to complete a task. Ask for missing details and confirm important choices instead of guessing. Then try Write a room-booking dialogue. The three levels build toward Conversation repair and escalation playbook. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Intent and conversation goals

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Intent and conversation goals
Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary.
Mental model: A helpful receptionist identifies the visit's purpose before giving directions.
Boundary: A single utterance can express several intents or none clearly.
Worked example: A refund conversation needs the purchase reference and issue; greeting style is secondary to collecting those facts clearly.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Corrections are heard but not applied
The scripted booking assistant must update every explicitly corrected critical field before confirmation. Three dialogues confirm stale values after the user has corrected them. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an explicit correction transition and read back the updated field before commitment.
Recall: Role-play correction, interruption, ambiguity and human handoff using new utterances. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Intent and conversation goals: Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A conversation needs enough information to complete a task. Ask for missing details and confirm important choices instead of guessing.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Start with “Book a room for tomorrow.” List the missing date interpretation, time, group size and location.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

3. Try step 2
Write a short dialogue that asks for missing information one useful step at a time.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

4. Try step 3
Add branches for an unavailable room and a user changing their mind before confirmation.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A dialogue script with a happy path and two recovery branches.

5. Explain and check your result
The assistant does not confirm a booking with missing information, and the user can correct a choice. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A dialogue script with a happy path and two recovery branches. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The scripted booking assistant must update every explicitly corrected critical field before confirmation. Apply this toy-case rule manually: Review when ignored_corrections >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three dialogues confirm stale values after the user has corrected them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Conversation designer.
Start with “Book a room for tomorrow.” List the missing date interpretation, time, group size and location.
Write a short dialogue that asks for missing information one useful step at a time.
Add branches for an unavailable room and a user changing their mind before confirmation.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A dialogue script with a happy path and two recovery branches. Include beginner-worksheet.md and your completed Conversation flow and repair transcript.
Check: The assistant does not confirm a booking with missing information, and the user can correct a choice.

### Interview
Explain your beginner solution for Conversation designer. Use this scenario: The scripted booking assistant must update every explicitly corrected critical field before confirmation.
Review: Start with the task and permitted scope. Explain intent and conversation goals: Define what a person is trying to accomplish and which information is required. Avoid designing only a list of chatbot phrases without a task boundary. Show the input and observed output, then address Add an explicit correction transition and read back the updated field before commitment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A dialogue script with a happy path and two recovery branches. Include beginner-worksheet.md and your completed Conversation flow and repair transcript.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Clarification and repair

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Clear writing, user research and dialogue design; basic understanding of model and speech-system limitations.

### Clarification and repair
Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity.
Mental model: A conversation partner asks which Tuesday you mean instead of repeating the calendar.
Boundary: Clarification adds effort and should be evaluated for necessity and wording.
Worked example: For change my booking, ask which booking before asking for a new date; preserve already-confirmed information.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Conversation repair and escalation playbook
Design a conversational service that handles corrections, ambiguity and handoff consistently. Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.
Recall: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. Identify one observation that would contradict your claim.

### Terms
Clarification and repair: Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design a conversational service that handles corrections, ambiguity and handoff consistently. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The scripted booking assistant must update every explicitly corrected critical field before confirmation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design a conversational service that handles corrections, ambiguity and handoff consistently.
Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.
Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.
Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.
Deliverables: Conversation map and dialogue library; Repair/escalation rules. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Conversation designer. Use this scenario: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Review: Start with the task and permitted scope. Explain clarification and repair: Design short clarifying questions and recovery paths when the system misunderstands. Avoid forcing users through repeated identical prompts that do not resolve ambiguity. Show the input and observed output, then address Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Conversation map and dialogue library; Repair/escalation rules. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Escalation and dialogue evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Escalation and dialogue evaluation
Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed.
Mental model: A relay runner hands over the baton and the race position together.
Boundary: Conversation logs require appropriate privacy and retention handling.
Worked example: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Conversation repair and escalation playbook
Design a conversational service that handles corrections, ambiguity and handoff consistently. Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Recall: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. Identify one observation that would contradict your claim.

### Terms
Escalation and dialogue evaluation: Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design a conversational service that handles corrections, ambiguity and handoff consistently. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design a conversational service that handles corrections, ambiguity and handoff consistently.
Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.
Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.
Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.
Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules.
Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.
Implement the flow with the voice-engineer project and compare designed versus observed behavior.
Deliverables: Conversation map and dialogue library; Repair/escalation rules; Test transcript excerpts and iteration report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A reviewer must reproduce one result and identify which capabilities you implemented. Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

### Interview
Explain your advanced solution for Conversation designer. Use this scenario: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Review: Start with the task and permitted scope. Explain escalation and dialogue evaluation: Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed. Show the input and observed output, then address Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Conversation map and dialogue library; Repair/escalation rules; Test transcript excerpts and iteration report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Penpot — Open source · hosted account or self-hosting
Connect prototype boards and test interaction flows; Figma is an alternative.
Alternative: Figma (commercial hosted service with plan-specific access); paper prototypes are sufficient for the first exercise.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Figma learning resources: https://help.figma.com/
Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction
W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/
