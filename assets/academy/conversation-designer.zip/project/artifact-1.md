# Conversation map and dialogue library

Project: Conversation repair and escalation playbook
Status: blank work product — not completed evidence

## Purpose and audience
Design a conversational service that handles corrections, ambiguity and handoff consistently.

## Required content
Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.

## Failure evidence
Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
