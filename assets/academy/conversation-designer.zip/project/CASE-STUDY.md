# Conversation repair and escalation playbook

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Design a conversational service that handles corrections, ambiguity and handoff consistently.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

## Limitations and next iteration
Implement the flow with the voice-engineer project and compare designed versus observed behavior.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
