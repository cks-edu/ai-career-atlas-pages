## advanced — Escalation and dialogue evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Escalation and dialogue evaluation
Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed.
Mental model: A relay runner hands over the baton and the race position together.
Boundary: Conversation logs require appropriate privacy and retention handling.
Worked example: After two failed identity checks, route to support with the issue summary and no claim that the account change succeeded.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Conversation repair and escalation playbook
Design a conversational service that handles corrections, ambiguity and handoff consistently. Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Recall: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. Identify one observation that would contradict your claim.

### Terms
Escalation and dialogue evaluation: Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design a conversational service that handles corrections, ambiguity and handoff consistently. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design a conversational service that handles corrections, ambiguity and handoff consistently.
Choose a fictional appointment assistant. Write 20 user utterances covering confirmations, corrections, silence, multiple intents and requests outside scope.
Map intents, entities and state transitions in Penpot. Define when the assistant asks a clarifying question and when it transfers to a human.
Write dialogues with concise prompts, confirmations and repair turns. Create a content sheet with state ID, user intent, system response, next state and escalation reason.
Conduct a Wizard-of-Oz test with consenting peers, or label a solo walkthrough as simulated. Record misunderstood turns and revise the dialogue rules.
Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors.
Implement the flow with the voice-engineer project and compare designed versus observed behavior.
Deliverables: Conversation map and dialogue library; Repair/escalation rules; Test transcript excerpts and iteration report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A reviewer must reproduce one result and identify which capabilities you implemented. Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.

### Interview
Explain your advanced solution for Conversation designer. Use this scenario: Have the user change a date after confirming a time and then ask to cancel. Prove the conversation updates the right slots and does not retain a stale commitment.
Review: Start with the task and permitted scope. Explain escalation and dialogue evaluation: Test full conversations, including failures and handoffs, against task outcomes. Preserve context for a human while explaining what was and was not completed. Show the input and observed output, then address Report successful task completion, repair turns, inappropriate confirmations and handoff clarity. Separate language design failures from speech-recognition errors. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Conversation map and dialogue library; Repair/escalation rules; Test transcript excerpts and iteration report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

