# Workday Integration Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Integration contract: An integration defines source fields, target fields, identity, allowed transformations and rejected-record handling. Start with synthetic worker data.

EIB: Enterprise Interface Builder: Workday tooling for supported inbound/outbound integrations; configuration requires permitted tenant access.

Effective date: The date a business change applies, which can differ from when it was entered or processed.

Reconciliation: Comparing source and destination IDs, values and outcomes to account for every intended change.

Worker identity and field mapping: Map stable worker identifiers, effective dates and department values before choosing an integration interface. Keep missing IDs in a rejection report and avoid real employee or payroll data in a learning project.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. The practical workshop develops this into: Read the synthetic fixture, run beginner and create a source-to-target mapping table including required, nullable and transformed fields. Compare accepted events and rejected reasons before considering EIB, reports or web services.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A translation form preserves the same person's identity while changing field names.

Map stable worker identifiers, effective dates and department values before choosing an integration interface. Keep missing IDs in a rejection report and avoid real employee or payroll data in a learning project.

Worked example: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Workday integration tools, reports and APIs (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Workday Integration Developer: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected.

Predict the worked case

Read this case without running a tool: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday Integration Developer role interview. Explain acceptance criteria using this case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. State the evidence, one alternative and where the mental model stops.

Quiz: After the Worker identity and field mapping rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

Workday: integration tools and platform overview (product overview; tenant configuration requires authorized documentation): https://forms.workday.com/content/dam/web/en-us/documents/whitepapers/it/workday-integration-on-demand-whitepaper.pdf

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

### Worker identity and field mapping

Map stable worker identifiers, effective dates and department values before choosing an integration interface. Keep missing IDs in a rejection report and avoid real employee or payroll data in a learning project. In this role, work through: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. The practical workshop develops this into: Read the synthetic fixture, run beginner and create a source-to-target mapping table including required, nullable and transformed fields. Compare accepted events and rejected reasons before considering EIB, reports or web services.

Mental model: A translation form preserves the same person's identity while changing field names.

Boundary: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros.

Worked example: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Workday integration tools, reports and APIs (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Read the synthetic fixture, run beginner and create a source-to-target mapping table including required, nullable and transformed fields. Compare accepted events and rejected reasons before considering EIB, reports or web services.

Inspect the business fixture

W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Read the synthetic fixture, run beginner and create a source-to-target mapping table including required, nullable and transformed fields. Compare accepted events and rejected reasons before considering EIB, reports or web services.

```
python3 enterprise_lab.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py beginner --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Obtain a permitted learning route

Use Learn with Workday to identify available training and ask the environment owner for an authorized training tenant plus its current integration documentation. Confirm synthetic-worker permission, intended integration identity and whether the exercise uses a report, outbound EIB or web service. Public learning access does not imply a free configuration tenant.

Expected: An access/prerequisite checklist or a clearly marked offline-only outcome; no guessed tenant menu sequence.

Assemble the portfolio evidence

Create worker integration contract and rejection evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

Expected: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

Troubleshoot: The role exercise differs from the prediction: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-beginner-2.md: worker integration contract and rejection evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with worker identity and field mapping. Use the glossary below, then write your prediction for: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday Integration Developer role interview. Explain worker identity and field mapping using this case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate worker identity and field mapping to a system or workflow you know. Explain worker identity and field mapping using this case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros.

Interview: Explain worker identity and field mapping using this case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected.

Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made. — Map stable worker identifiers, effective dates and department values before choosing an integration interface. Keep missing IDs in a rejection report and avoid real employee or payroll data in a learning project. Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

Sources:

Workday: integration tools and platform overview (product overview; tenant configuration requires authorized documentation): https://forms.workday.com/content/dam/web/en-us/documents/whitepapers/it/workday-integration-on-demand-whitepaper.pdf

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Effective dating: A change can be recorded now but take effect on another date. Preserve business-effective time separately from processing time.

EIB: Enterprise Interface Builder: Workday tooling for supported inbound/outbound integrations; configuration requires permitted tenant access.

Effective date: The date a business change applies, which can differ from when it was entered or processed.

Reconciliation: Comparing source and destination IDs, values and outcomes to account for every intended change.

Effective time versus processing time: A worker event can arrive today but take effect in the future. An as-of report must select the latest applicable effective event, while correction and rescind semantics require the actual tenant/API contract.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. The practical workshop develops this into: Run intermediate for both as-of dates. Use --broken to include future events too early and observe the assertion failure. Repair the effective-date filter and test an earlier as-of date.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: A calendar appointment is booked now but changes the schedule on its appointment date.

A worker event can arrive today but take effect in the future. An as-of report must select the latest applicable effective event, while correction and rescind semantics require the actual tenant/API contract.

Worked example: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Workday integration tools, reports and APIs (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Workday Integration Developer: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT.

Predict the worked case

Read this case without running a tool: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday Integration Developer role interview. Explain traceability using this case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. State the evidence, one alternative and where the mental model stops.

Quiz: After the Effective time versus processing time rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

Workday: integration tools and platform overview (product overview; tenant configuration requires authorized documentation): https://forms.workday.com/content/dam/web/en-us/documents/whitepapers/it/workday-integration-on-demand-whitepaper.pdf

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

### Effective time versus processing time

A worker event can arrive today but take effect in the future. An as-of report must select the latest applicable effective event, while correction and rescind semantics require the actual tenant/API contract. In this role, work through: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. The practical workshop develops this into: Run intermediate for both as-of dates. Use --broken to include future events too early and observe the assertion failure. Repair the effective-date filter and test an earlier as-of date.

Mental model: A calendar appointment is booked now but changes the schedule on its appointment date.

Boundary: Sorting by file arrival instead of business-effective date can produce the wrong department.

Worked example: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Workday integration tools, reports and APIs (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run intermediate for both as-of dates. Use --broken to include future events too early and observe the assertion failure. Repair the effective-date filter and test an earlier as-of date.

Inspect the business fixture

At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run intermediate for both as-of dates. Use --broken to include future events too early and observe the assertion failure. Repair the effective-date filter and test an earlier as-of date.

```
python3 enterprise_lab.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: The two baseline snapshots differ only where an event has become effective.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py intermediate --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Configure against the tenant contract

Using that tenant’s authorized guide, map the documented worker reference and effective-date parameters to the local mapping table. Review report/web-service field permissions with the owner, run a small permitted synthetic export and compare snapshots before and after the effective date.

Expected: A field-level comparison and run ID, with differences from the local model explained by the actual interface contract.

Assemble the portfolio evidence

Create as-of snapshot tests and effective-date decision record. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: The two baseline snapshots differ only where an event has become effective.

Expected: The two baseline snapshots differ only where an event has become effective.

Troubleshoot: The role exercise differs from the prediction: Sorting by file arrival instead of business-effective date can produce the wrong department.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-intermediate-2.md: as-of snapshot tests and effective-date decision record; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with effective time versus processing time. Use the glossary below, then write your prediction for: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday Integration Developer role interview. Explain effective time versus processing time using this case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate effective time versus processing time to a system or workflow you know. Explain effective time versus processing time using this case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Sorting by file arrival instead of business-effective date can produce the wrong department.

Interview: Explain effective time versus processing time using this case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT.

Ignore the failing case and keep only the successful screenshot.

The two baseline snapshots differ only where an event has become effective.

Treat any successful command as proof that all business and access rules passed.

Reference: The two baseline snapshots differ only where an event has become effective. — A worker event can arrive today but take effect in the future. An as-of report must select the latest applicable effective event, while correction and rescind semantics require the actual tenant/API contract. The two baseline snapshots differ only where an event has become effective.

Sources:

Workday: integration tools and platform overview (product overview; tenant configuration requires authorized documentation): https://forms.workday.com/content/dam/web/en-us/documents/whitepapers/it/workday-integration-on-demand-whitepaper.pdf

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Reconciliation and replay: Compare source, accepted, rejected and target records using stable identifiers. Replay only according to an explicit duplicate/correction policy.

EIB: Enterprise Interface Builder: Workday tooling for supported inbound/outbound integrations; configuration requires permitted tenant access.

Effective date: The date a business change applies, which can differ from when it was entered or processed.

Reconciliation: Comparing source and destination IDs, values and outcomes to account for every intended change.

Replay, permissions and handover: Integration recovery needs stable event identity, accepted/rejected reconciliation and minimally authorized execution. Counts alone do not prove the correct values reached the correct workers.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. The practical workshop develops this into: Run advanced and inspect duplicate-event evidence. Write an authorized-tenant checklist for integration identity, report/API field access, launch, monitoring and replay. Use Workday-provided learning access and tenant-specific documentation for exact configuration.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: Reconcile the manifest, tracking numbers and delivered contents together.

Integration recovery needs stable event identity, accepted/rejected reconciliation and minimally authorized execution. Counts alone do not prove the correct values reached the correct workers.

Worked example: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Workday integration tools, reports and APIs (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Workday Integration Developer: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT.

Predict the worked case

Read this case without running a tool: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday Integration Developer role interview. Explain release decision and ownership using this case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. State the evidence, one alternative and where the mental model stops.

Quiz: After the Replay, permissions and handover rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

Workday: integration tools and platform overview (product overview; tenant configuration requires authorized documentation): https://forms.workday.com/content/dam/web/en-us/documents/whitepapers/it/workday-integration-on-demand-whitepaper.pdf

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

### Replay, permissions and handover

Integration recovery needs stable event identity, accepted/rejected reconciliation and minimally authorized execution. Counts alone do not prove the correct values reached the correct workers. In this role, work through: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. The practical workshop develops this into: Run advanced and inspect duplicate-event evidence. Write an authorized-tenant checklist for integration identity, report/API field access, launch, monitoring and replay. Use Workday-provided learning access and tenant-specific documentation for exact configuration.

Mental model: Reconcile the manifest, tracking numbers and delivered contents together.

Boundary: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters.

Worked example: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Workday integration tools, reports and APIs (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run advanced and inspect duplicate-event evidence. Write an authorized-tenant checklist for integration identity, report/API field access, launch, monitoring and replay. Use Workday-provided learning access and tenant-specific documentation for exact configuration.

Inspect the business fixture

Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run advanced and inspect duplicate-event evidence. Write an authorized-tenant checklist for integration identity, report/API field access, launch, monitoring and replay. Use Workday-provided learning access and tenant-specific documentation for exact configuration.

```
python3 enterprise_lab.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py advanced --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Reconcile and rehearse a safe replay

Review the tenant’s integration event/monitoring output, export accepted/rejected IDs without personal data and reconcile values. Replay only the approved failed subset according to the interface’s update semantics. Document authentication, permissions, support owner and escalation.

Expected: A recovery record distinguishes transport replay, correction and rescind behavior. The local model does not claim to implement every Workday semantic.

Assemble the portfolio evidence

Create integration handover pack with reconciliation, access and recovery procedures. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

Expected: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

Troubleshoot: The role exercise differs from the prediction: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-advanced-2.md: integration handover pack with reconciliation, access and recovery procedures; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with replay, permissions and handover. Use the glossary below, then write your prediction for: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday Integration Developer role interview. Explain replay, permissions and handover using this case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate replay, permissions and handover to a system or workflow you know. Explain replay, permissions and handover using this case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters.

Interview: Explain replay, permissions and handover using this case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

Reference: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed. — Integration recovery needs stable event identity, accepted/rejected reconciliation and minimally authorized execution. Counts alone do not prove the correct values reached the correct workers. One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

Sources:

Workday: integration tools and platform overview (product overview; tenant configuration requires authorized documentation): https://forms.workday.com/content/dam/web/en-us/documents/whitepapers/it/workday-integration-on-demand-whitepaper.pdf

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html
