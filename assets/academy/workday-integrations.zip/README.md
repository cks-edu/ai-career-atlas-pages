# Workday Integration Developer

Software Engineering

Start with worker identity and field mapping. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward integration handover pack with reconciliation, access and recovery procedures.

## beginner

Read the synthetic fixture, run beginner and create a source-to-target mapping table including required, nullable and transformed fields. Compare accepted events and rejected reasons before considering EIB, reports or web services.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Worker identity and field mapping
Map stable worker identifiers, effective dates and department values before choosing an integration interface. Keep missing IDs in a rejection report and avoid real employee or payroll data in a learning project.
Mental model: A translation form preserves the same person's identity while changing field names.
Limit: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros.
Example: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros.

1. Inspect the business fixture
W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Read the synthetic fixture, run beginner and create a source-to-target mapping table including required, nullable and transformed fields. Compare accepted events and rejected reasons before considering EIB, reports or web services.
```
python3 enterprise_lab.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py beginner --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Obtain a permitted learning route
Use Learn with Workday to identify available training and ask the environment owner for an authorized training tenant plus its current integration documentation. Confirm synthetic-worker permission, intended integration identity and whether the exercise uses a report, outbound EIB or web service. Public learning access does not imply a free configuration tenant.
Expected: An access/prerequisite checklist or a clearly marked offline-only outcome; no guessed tenant menu sequence.

6. Assemble the portfolio evidence
Create worker integration contract and rejection evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: worker integration contract and rejection evidence
Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.

Interview: Work through this Workday Integration Developer case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Map stable worker identifiers, effective dates and department values before choosing an integration interface. Keep missing IDs in a rejection report and avoid real employee or payroll data in a learning project. Expected evidence: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made. Diagnosis: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros. State the limits of the mental model: A translation form preserves the same person's identity while changing field names.

Resume: Built worker integration contract and rejection evidence using Workday integration tools, reports and APIs; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run intermediate for both as-of dates. Use --broken to include future events too early and observe the assertion failure. Repair the effective-date filter and test an earlier as-of date.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Effective time versus processing time
A worker event can arrive today but take effect in the future. An as-of report must select the latest applicable effective event, while correction and rescind semantics require the actual tenant/API contract.
Mental model: A calendar appointment is booked now but changes the schedule on its appointment date.
Limit: Sorting by file arrival instead of business-effective date can produce the wrong department.
Example: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Sorting by file arrival instead of business-effective date can produce the wrong department.

1. Inspect the business fixture
At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run intermediate for both as-of dates. Use --broken to include future events too early and observe the assertion failure. Repair the effective-date filter and test an earlier as-of date.
```
python3 enterprise_lab.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: The two baseline snapshots differ only where an event has become effective.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py intermediate --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Configure against the tenant contract
Using that tenant’s authorized guide, map the documented worker reference and effective-date parameters to the local mapping table. Review report/web-service field permissions with the owner, run a small permitted synthetic export and compare snapshots before and after the effective date.
Expected: A field-level comparison and run ID, with differences from the local model explained by the actual interface contract.

6. Assemble the portfolio evidence
Create as-of snapshot tests and effective-date decision record. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: The two baseline snapshots differ only where an event has become effective.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Sorting by file arrival instead of business-effective date can produce the wrong department.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: as-of snapshot tests and effective-date decision record
The two baseline snapshots differ only where an event has become effective.

Interview: Work through this Workday Integration Developer case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A worker event can arrive today but take effect in the future. An as-of report must select the latest applicable effective event, while correction and rescind semantics require the actual tenant/API contract. Expected evidence: The two baseline snapshots differ only where an event has become effective. Diagnosis: Sorting by file arrival instead of business-effective date can produce the wrong department. State the limits of the mental model: A calendar appointment is booked now but changes the schedule on its appointment date.

Resume: Built as-of snapshot tests and effective-date decision record using Workday integration tools, reports and APIs; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run advanced and inspect duplicate-event evidence. Write an authorized-tenant checklist for integration identity, report/API field access, launch, monitoring and replay. Use Workday-provided learning access and tenant-specific documentation for exact configuration.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Replay, permissions and handover
Integration recovery needs stable event identity, accepted/rejected reconciliation and minimally authorized execution. Counts alone do not prove the correct values reached the correct workers.
Mental model: Reconcile the manifest, tracking numbers and delivered contents together.
Limit: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters.
Example: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters.

1. Inspect the business fixture
Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run advanced and inspect duplicate-event evidence. Write an authorized-tenant checklist for integration identity, report/API field access, launch, monitoring and replay. Use Workday-provided learning access and tenant-specific documentation for exact configuration.
```
python3 enterprise_lab.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py advanced --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Reconcile and rehearse a safe replay
Review the tenant’s integration event/monitoring output, export accepted/rejected IDs without personal data and reconcile values. Replay only the approved failed subset according to the interface’s update semantics. Document authentication, permissions, support owner and escalation.
Expected: A recovery record distinguishes transport replay, correction and rescind behavior. The local model does not claim to implement every Workday semantic.

6. Assemble the portfolio evidence
Create integration handover pack with reconciliation, access and recovery procedures. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: integration handover pack with reconciliation, access and recovery procedures
One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.

Interview: Work through this Workday Integration Developer case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Integration recovery needs stable event identity, accepted/rejected reconciliation and minimally authorized execution. Counts alone do not prove the correct values reached the correct workers. Expected evidence: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed. Diagnosis: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters. State the limits of the mental model: Reconcile the manifest, tracking numbers and delivered contents together.

Resume: Built integration handover pack with reconciliation, access and recovery procedures using Workday integration tools, reports and APIs; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html
Workday: integration tools and platform overview (product overview; tenant configuration requires authorized documentation): https://forms.workday.com/content/dam/web/en-us/documents/whitepapers/it/workday-integration-on-demand-whitepaper.pdf
