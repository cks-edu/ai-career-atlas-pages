# Workday Integration Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Worker identity and field mapping

Map stable worker identifiers, effective dates and department values before choosing an integration interface. Keep missing IDs in a rejection report and avoid real employee or payroll data in a learning project.
Mental model: A translation form preserves the same person's identity while changing field names.
Case: W1 changes department from Sales to Finance on 2026-02-01; a row with no worker ID is rejected.
Task: Read the synthetic fixture, run beginner and create a source-to-target mapping table including required, nullable and transformed fields. Compare accepted events and rejected reasons before considering EIB, reports or web services.
Acceptance: Three valid events and one missing-ID rejection in the baseline; no connection to Workday is made.
Troubleshooting: A display name is not a safe join key; use the agreed stable identifier and preserve leading zeros.
Deliverable: worker integration contract and rejection evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Effective time versus processing time

A worker event can arrive today but take effect in the future. An as-of report must select the latest applicable effective event, while correction and rescind semantics require the actual tenant/API contract.
Mental model: A calendar appointment is booked now but changes the schedule on its appointment date.
Case: At 2026-01-15 W1 is in Sales; at 2026-02-15 W1 is in Finance. W2 remains in IT.
Task: Run intermediate for both as-of dates. Use --broken to include future events too early and observe the assertion failure. Repair the effective-date filter and test an earlier as-of date.
Acceptance: The two baseline snapshots differ only where an event has become effective.
Troubleshooting: Sorting by file arrival instead of business-effective date can produce the wrong department.
Deliverable: as-of snapshot tests and effective-date decision record

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Replay, permissions and handover

Integration recovery needs stable event identity, accepted/rejected reconciliation and minimally authorized execution. Counts alone do not prove the correct values reached the correct workers.
Mental model: Reconcile the manifest, tracking numbers and delivered contents together.
Case: Replaying e1 must not create an extra worker change; the final snapshot has W1 Finance and W2 IT.
Task: Run advanced and inspect duplicate-event evidence. Write an authorized-tenant checklist for integration identity, report/API field access, launch, monitoring and replay. Use Workday-provided learning access and tenant-specific documentation for exact configuration.
Acceptance: One replay is identified; two workers have the expected values; tenant steps remain explicitly pending unless performed.
Troubleshooting: Do not infer that an empty report means no workers changed; check effective-date parameters, permissions and filters.
Deliverable: integration handover pack with reconciliation, access and recovery procedures

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
