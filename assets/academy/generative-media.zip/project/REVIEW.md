# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Finished short sequence and accessible variants.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
