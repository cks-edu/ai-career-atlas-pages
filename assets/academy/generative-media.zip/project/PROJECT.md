# Rights-aware generative media production

Career: Generative-media producer / technical artist
Reviewed: 2026-10-22

Produce a small media campaign with a repeatable creative process and a documented asset trail.

## Prerequisites
Art direction and editing fundamentals; technical-artist variants add scripting, 3D and pipeline automation.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Build an asset ledger linking every final element to its origin and edits. If using C2PA, distinguish manifest validity from the truth of depicted events or rights ownership.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```

## Portfolio deliverables
1. Finished short sequence and accessible variants — artifact-1.md
2. Storyboard and creative iteration breakdown — artifact-2.md
3. Asset/rights ledger and production case study — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Create a second format from the same assets and document reproducibility plus platform-specific compromises.

## Primary learning resources
- Blender: https://docs.blender.org/manual/en/latest/ — Open source · local; Storyboarding, editing and compositing; version-specific UI may vary.
- Runway: https://dev.runwayml.com/ — Commercial · account/credits; Optional generative-media production; check terms and current costs.
- C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/ — Open source · trust credentials separate; Read provenance manifests; integrity does not establish truth or rights.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
