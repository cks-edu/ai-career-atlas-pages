# Rights-aware generative media production

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Produce a small media campaign with a repeatable creative process and a documented asset trail.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.

## Limitations and next iteration
Create a second format from the same assets and document reproducibility plus platform-specific compromises.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
