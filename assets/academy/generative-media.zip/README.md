# Generative-media producer / technical artist

AI Engineering · Beginner → Intermediate → Advanced

Start with Creative briefs and rights. A creative brief defines the intended result and constraints. Track where source material comes from before producing media. Then try Make a poster brief and storyboard. The three levels build toward Rights-aware generative media production. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Creative briefs and rights

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Creative briefs and rights
Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality.
Mental model: A film production starts with a brief and asset permissions, not only a camera.
Boundary: Access to a generation tool does not grant rights to every subject or training source.
Worked example: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A shot has no rights record
The fictional production requires a documented source and permitted use for every visible asset before delivery. Three shots contain assets with unresolved provenance; visual quality does not clear delivery. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export.
Recall: Review the final edit against the asset ledger, including references, likenesses and audio. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Creative briefs and rights: Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A creative brief defines the intended result and constraints. Track where source material comes from before producing media.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose a fictional free library workshop and specify audience, message, format and accessibility needs.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

3. Try step 2
Sketch three poster layouts on paper using your own shapes and placeholder text.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

4. Try step 3
Make an asset list stating which materials you created and which would need permission or a license check.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

5. Explain and check your result
The message is readable, assets have known status, and unverified material is not described as cleared for publication. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A creative brief, three sketches and an asset register. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional production requires a documented source and permitted use for every visible asset before delivery. Apply this toy-case rule manually: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three shots contain assets with unresolved provenance; visual quality does not clear delivery. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Generative-media producer / technical artist.
Choose a fictional free library workshop and specify audience, message, format and accessibility needs.
Sketch three poster layouts on paper using your own shapes and placeholder text.
Make an asset list stating which materials you created and which would need permission or a license check.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A creative brief, three sketches and an asset register. Include beginner-worksheet.md and your completed Production breakdown and asset-rights ledger.
Check: The message is readable, assets have known status, and unverified material is not described as cleared for publication.

### Interview
Explain your beginner solution for Generative-media producer / technical artist. Use this scenario: The fictional production requires a documented source and permitted use for every visible asset before delivery.
Review: Start with the task and permitted scope. Explain creative briefs and rights: Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality. Show the input and observed output, then address Replace, license or hold those assets and update the production ledger before export. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A creative brief, three sketches and an asset register. Include beginner-worksheet.md and your completed Production breakdown and asset-rights ledger.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Controlled iteration

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Art direction and editing fundamentals; technical-artist variants add scripting, 3D and pipeline automation.

### Controlled iteration
Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs.
Mental model: A photographer adjusts lighting deliberately instead of changing every camera setting at once.
Boundary: A fixed seed may not reproduce outputs across changed models or tool versions.
Worked example: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Rights-aware generative media production
Produce a small media campaign with a repeatable creative process and a documented asset trail. Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Recall: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. Identify one observation that would contradict your claim.

### Terms
Controlled iteration: Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Produce a small media campaign with a repeatable creative process and a documented asset trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

2. Prepare the project inputs
Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The fictional production requires a documented source and permitted use for every visible asset before delivery. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Produce a small media campaign with a repeatable creative process and a documented asset trail.
Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.
Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.
Deliverables: Finished short sequence and accessible variants; Storyboard and creative iteration breakdown. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Generative-media producer / technical artist. Use this scenario: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.
Review: Start with the task and permitted scope. Explain controlled iteration: Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs. Show the input and observed output, then address Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Finished short sequence and accessible variants; Storyboard and creative iteration breakdown. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Production handoff and provenance

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Production handoff and provenance
Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps.
Mental model: A workshop hands over the finished object with care instructions and component records.
Boundary: Provenance records describe history and do not prove the message is true or legally cleared.
Worked example: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Rights-aware generative media production
Produce a small media campaign with a repeatable creative process and a documented asset trail. Build an asset ledger linking every final element to its origin and edits. If using C2PA, distinguish manifest validity from the truth of depicted events or rights ownership.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.
Recall: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. Identify one observation that would contradict your claim.

### Terms
Production handoff and provenance: Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Produce a small media campaign with a repeatable creative process and a documented asset trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

2. Prepare the project inputs
Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Build an asset ledger linking every final element to its origin and edits. If using C2PA, distinguish manifest validity from the truth of depicted events or rights ownership.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Produce a small media campaign with a repeatable creative process and a documented asset trail.
Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.
Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Build an asset ledger linking every final element to its origin and edits. If using C2PA, distinguish manifest validity from the truth of depicted events or rights ownership.
Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.
Create a second format from the same assets and document reproducibility plus platform-specific compromises.
Deliverables: Finished short sequence and accessible variants; Storyboard and creative iteration breakdown; Asset/rights ledger and production case study. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A reviewer must reproduce one result and identify which capabilities you implemented. Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.

### Interview
Explain your advanced solution for Generative-media producer / technical artist. Use this scenario: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.
Review: Start with the task and permitted scope. Explain production handoff and provenance: Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps. Show the input and observed output, then address Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Finished short sequence and accessible variants; Storyboard and creative iteration breakdown; Asset/rights ledger and production case study. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Blender — Open source · local
Storyboarding, editing and compositing; version-specific UI may vary.
Alternative: Autodesk Maya (commercial) or other licensed media tools; ensure editable exports and asset rights travel with the work.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Runway — Commercial · account/credits
Optional generative-media production; check terms and current costs.
Alternative: Blender provides an open-source editing/3D route; local generative models have separate licenses and hardware requirements and are not equivalent products.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

C2PA Tool — Open source · trust credentials separate
Read provenance manifests; integrity does not establish truth or rights.
Alternative: Another C2PA-compatible verifier can inspect credentials; an unsigned checksum checks integrity only and does not provide signer provenance.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Blender: https://docs.blender.org/manual/en/latest/
Runway: https://dev.runwayml.com/
C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/
Runway developer documentation: https://dev.runwayml.com/
Blender manual: https://docs.blender.org/manual/en/latest/
C2PA specifications: https://spec.c2pa.org/specifications/
