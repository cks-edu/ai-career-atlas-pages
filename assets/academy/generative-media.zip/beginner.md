## beginner — Creative briefs and rights

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Creative briefs and rights
Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality.
Mental model: A film production starts with a brief and asset permissions, not only a camera.
Boundary: Access to a generation tool does not grant rights to every subject or training source.
Worked example: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A shot has no rights record
The fictional production requires a documented source and permitted use for every visible asset before delivery. Three shots contain assets with unresolved provenance; visual quality does not clear delivery. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export.
Recall: Review the final edit against the asset ledger, including references, likenesses and audio. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Creative briefs and rights: Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A creative brief defines the intended result and constraints. Track where source material comes from before producing media.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose a fictional free library workshop and specify audience, message, format and accessibility needs.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

3. Try step 2
Sketch three poster layouts on paper using your own shapes and placeholder text.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

4. Try step 3
Make an asset list stating which materials you created and which would need permission or a license check.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

5. Explain and check your result
The message is readable, assets have known status, and unverified material is not described as cleared for publication. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A creative brief, three sketches and an asset register. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional production requires a documented source and permitted use for every visible asset before delivery. Apply this toy-case rule manually: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three shots contain assets with unresolved provenance; visual quality does not clear delivery. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Generative-media producer / technical artist.
Choose a fictional free library workshop and specify audience, message, format and accessibility needs.
Sketch three poster layouts on paper using your own shapes and placeholder text.
Make an asset list stating which materials you created and which would need permission or a license check.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A creative brief, three sketches and an asset register. Include beginner-worksheet.md and your completed Production breakdown and asset-rights ledger.
Check: The message is readable, assets have known status, and unverified material is not described as cleared for publication.

### Interview
Explain your beginner solution for Generative-media producer / technical artist. Use this scenario: The fictional production requires a documented source and permitted use for every visible asset before delivery.
Review: Start with the task and permitted scope. Explain creative briefs and rights: Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality. Show the input and observed output, then address Replace, license or hold those assets and update the production ledger before export. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A creative brief, three sketches and an asset register. Include beginner-worksheet.md and your completed Production breakdown and asset-rights ledger.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

