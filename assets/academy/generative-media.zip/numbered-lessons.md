# Generative-media producer / technical artist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Creative briefs and rights: Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Creative briefs and rights

Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality. In this role, work through: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A film production starts with a brief and asset permissions, not only a camera.

Boundary: Access to a generation tool does not grant rights to every subject or training source.

Worked example: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Blender (Open source · local); Runway (Commercial · account/credits); C2PA Tool (Open source · trust credentials separate)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Generative-media producer / technical artist: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element.

Predict the worked case

Read this case without running a tool: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in creative briefs and rights.

Connect the concept to the role

Apply this rule: Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Access to a generation tool does not grant rights to every subject or training source.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies creative briefs and rights to this case: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Creative briefs and rights; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with creative briefs and rights. Use the glossary below, then write your prediction for: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Generative-media producer / technical artist role interview. Explain creative briefs and rights using this case: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate creative briefs and rights to a system or workflow you know. Explain creative briefs and rights using this case: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain creative briefs and rights using this case: Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element.

Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality. — Specify audience, message, visual constraints and permitted source material before generation. Track rights and consent separately from aesthetic quality. Access to a generation tool does not grant rights to every subject or training source.

Sources:

Blender: https://docs.blender.org/manual/en/latest/

Runway: https://dev.runwayml.com/

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Runway developer documentation: https://dev.runwayml.com/

Blender manual: https://docs.blender.org/manual/en/latest/

C2PA specifications: https://spec.c2pa.org/specifications/

### Diagnose: A shot has no rights record

The fictional production requires a documented source and permitted use for every visible asset before delivery. Three shots contain assets with unresolved provenance; visual quality does not clear delivery. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A film production starts with a brief and asset permissions, not only a camera.

Create a fictional campaign with original assets, a consistent color palette and a rights register for every imported element.

Worked example: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Blender (Open source · local); Runway (Commercial · account/credits); C2PA Tool (Open source · trust credentials separate)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The fictional production requires a documented source and permitted use for every visible asset before delivery. Three shots contain assets with unresolved provenance; visual quality does not clear delivery. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional production requires a documented source and permitted use for every visible asset before delivery. Apply this toy-case rule manually: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A creative brief defines the intended result and constraints. Track where source material comes from before producing media.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Choose a fictional free library workshop and specify audience, message, format and accessibility needs.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

Preparation · Try step 2

Sketch three poster layouts on paper using your own shapes and placeholder text.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

Preparation · Try step 3

Make an asset list stating which materials you created and which would need permission or a license check.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A creative brief, three sketches and an asset register.

Preparation · Explain and check your result

The message is readable, assets have known status, and unverified material is not described as cleared for publication. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A creative brief, three sketches and an asset register. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional production requires a documented source and permitted use for every visible asset before delivery. Apply this toy-case rule manually: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three shots contain assets with unresolved provenance; visual quality does not clear delivery. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three shots contain assets with unresolved provenance; visual quality does not clear delivery. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a shot has no rights record. Use the glossary below, then write your prediction for: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Generative-media producer / technical artist role interview. Explain diagnose: a shot has no rights record using this case: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a shot has no rights record to a system or workflow you know. Explain diagnose: a shot has no rights record using this case: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Review the final edit against the asset ledger, including references, likenesses and audio. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a shot has no rights record using this case: Review when unresolved_assets >= 1 (count). This is a declared toy-case contract, not an industry standard. Replace, license or hold those assets and update the production ledger before export. State the evidence, one alternative and where the mental model stops.

Quiz: A shot has no rights record: The fictional production requires a documented source and permitted use for every visible asset before delivery.

Change the acceptance rule after seeing an inconvenient result.

Replace, license or hold those assets and update the production ledger before export.

Omit failed cases and report only the successful demonstrations.

Reference: Replace, license or hold those assets and update the production ledger before export. — Replace, license or hold those assets and update the production ledger before export. Review the final edit against the asset ledger, including references, likenesses and audio.

Sources:

Blender: https://docs.blender.org/manual/en/latest/

Runway: https://dev.runwayml.com/

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Runway developer documentation: https://dev.runwayml.com/

Blender manual: https://docs.blender.org/manual/en/latest/

C2PA specifications: https://spec.c2pa.org/specifications/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Art direction and editing fundamentals; technical-artist variants add scripting, 3D and pipeline automation.

Terms:

Controlled iteration: Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Controlled iteration

Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs. In this role, work through: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A photographer adjusts lighting deliberately instead of changing every camera setting at once.

Boundary: A fixed seed may not reproduce outputs across changed models or tool versions.

Worked example: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Art direction and editing fundamentals; technical-artist variants add scripting, 3D and pipeline automation.

Tools for this exercise: Document or text editor

Course tool and framework map: Blender (Open source · local); Runway (Commercial · account/credits); C2PA Tool (Open source · trust credentials separate)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Generative-media producer / technical artist: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better.

Predict the worked case

Read this case without running a tool: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in controlled iteration.

Connect the concept to the role

Apply this rule: Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A fixed seed may not reproduce outputs across changed models or tool versions.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies controlled iteration to this case: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Controlled iteration; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with controlled iteration. Use the glossary below, then write your prediction for: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Generative-media producer / technical artist role interview. Explain controlled iteration using this case: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate controlled iteration to a system or workflow you know. Explain controlled iteration using this case: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain controlled iteration using this case: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better.

Treat a passing starter as proof of the whole role workflow.

Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs.

Ignore the failure because the tool produced an output.

Reference: Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs. — Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs. A fixed seed may not reproduce outputs across changed models or tool versions.

Sources:

Blender: https://docs.blender.org/manual/en/latest/

Runway: https://dev.runwayml.com/

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Runway developer documentation: https://dev.runwayml.com/

Blender manual: https://docs.blender.org/manual/en/latest/

C2PA specifications: https://spec.c2pa.org/specifications/

### Integrate: Rights-aware generative media production

Produce a small media campaign with a repeatable creative process and a documented asset trail. Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback. In this role, work through: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A photographer adjusts lighting deliberately instead of changing every camera setting at once.

Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better.

Worked example: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Blender (Open source · local); Runway (Commercial · account/credits); C2PA Tool (Open source · trust credentials separate)

Produce a small media campaign with a repeatable creative process and a documented asset trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Produce a small media campaign with a repeatable creative process and a documented asset trail.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

Prepare the project inputs

Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The fictional production requires a documented source and permitted use for every visible asset before delivery. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Finished short sequence and accessible variants; Storyboard and creative iteration breakdown. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: rights-aware generative media production. Use the glossary below, then write your prediction for: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Generative-media producer / technical artist role interview. Explain integrate: rights-aware generative media production using this case: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: rights-aware generative media production to a system or workflow you know. Explain integrate: rights-aware generative media production using this case: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. Identify one observation that would contradict your claim.

Interview: Explain integrate: rights-aware generative media production using this case: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Rights-aware generative media production at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.

Reference: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. — Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.

Sources:

Blender: https://docs.blender.org/manual/en/latest/

Runway: https://dev.runwayml.com/

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Runway developer documentation: https://dev.runwayml.com/

Blender manual: https://docs.blender.org/manual/en/latest/

C2PA specifications: https://spec.c2pa.org/specifications/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Production handoff and provenance: Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Production handoff and provenance

Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps. In this role, work through: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A workshop hands over the finished object with care instructions and component records.

Boundary: Provenance records describe history and do not prove the message is true or legally cleared.

Worked example: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Blender (Open source · local); Runway (Commercial · account/credits); C2PA Tool (Open source · trust credentials separate)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Generative-media producer / technical artist: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable.

Predict the worked case

Read this case without running a tool: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in production handoff and provenance.

Connect the concept to the role

Apply this rule: Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Provenance records describe history and do not prove the message is true or legally cleared.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies production handoff and provenance to this case: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Production handoff and provenance; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with production handoff and provenance. Use the glossary below, then write your prediction for: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Generative-media producer / technical artist role interview. Explain production handoff and provenance using this case: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate production handoff and provenance to a system or workflow you know. Explain production handoff and provenance using this case: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain production handoff and provenance using this case: Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps.

Reference: Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps. — Package editable assets, export specifications, accessibility text and provenance information. Inspect final files for artifacts and disclose relevant AI-assisted steps. Provenance records describe history and do not prove the message is true or legally cleared.

Sources:

Blender: https://docs.blender.org/manual/en/latest/

Runway: https://dev.runwayml.com/

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Runway developer documentation: https://dev.runwayml.com/

Blender manual: https://docs.blender.org/manual/en/latest/

C2PA specifications: https://spec.c2pa.org/specifications/

### Defend: Rights-aware generative media production

Produce a small media campaign with a repeatable creative process and a documented asset trail. Build an asset ledger linking every final element to its origin and edits. If using C2PA, distinguish manifest validity from the truth of depicted events or rights ownership. In this role, work through: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A workshop hands over the finished object with care instructions and component records.

Export the campaign in required sizes, inspect text legibility and include source/edit history with the deliverable.

Worked example: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Blender (Open source · local); Runway (Commercial · account/credits); C2PA Tool (Open source · trust credentials separate)

Produce a small media campaign with a repeatable creative process and a documented asset trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Produce a small media campaign with a repeatable creative process and a documented asset trail.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

Prepare the project inputs

Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Build an asset ledger linking every final element to its origin and edits. If using C2PA, distinguish manifest validity from the truth of depicted events or rights ownership.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A reviewer must reproduce one result and identify which capabilities you implemented. Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Finished short sequence and accessible variants; Storyboard and creative iteration breakdown; Asset/rights ledger and production case study. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: rights-aware generative media production. Use the glossary below, then write your prediction for: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Generative-media producer / technical artist role interview. Explain defend: rights-aware generative media production using this case: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: rights-aware generative media production to a system or workflow you know. Explain defend: rights-aware generative media production using this case: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. Identify one observation that would contradict your claim.

Interview: Explain defend: rights-aware generative media production using this case: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Rights-aware generative media production at this level?

Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership. — Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership. Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.

Sources:

Blender: https://docs.blender.org/manual/en/latest/

Runway: https://dev.runwayml.com/

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Runway developer documentation: https://dev.runwayml.com/

Blender manual: https://docs.blender.org/manual/en/latest/

C2PA specifications: https://spec.c2pa.org/specifications/
