# SAMPLE — Production breakdown and asset-rights ledger
Role: Generative-media producer / technical artist
Case: A shot has no rights record
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The fictional production requires a documented source and permitted use for every visible asset before delivery.

## Evidence table
| Record | unresolved_assets (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 3 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three shots contain assets with unresolved provenance; visual quality does not clear delivery.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Replace, license or hold those assets and update the production ledger before export.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in generative-media producer / technical artist.
Before release: Review the final edit against the asset ledger, including references, likenesses and audio.

## Design choice and trade-off
Track original, licensed and generated ingredients; preserve human edits and approval history.
A fast generative pipeline still needs art direction, continuity and rights review; tool output alone is not clearance.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Generative short-film sequence: Deliver an edit breakdown and asset provenance ledger.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
