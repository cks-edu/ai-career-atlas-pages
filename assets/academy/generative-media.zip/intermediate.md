## intermediate — Controlled iteration

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Art direction and editing fundamentals; technical-artist variants add scripting, 3D and pipeline automation.

### Controlled iteration
Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs.
Mental model: A photographer adjusts lighting deliberately instead of changing every camera setting at once.
Boundary: A fixed seed may not reproduce outputs across changed models or tool versions.
Worked example: Compare three compositions with the same message and asset set; record why the chosen version communicates the hierarchy better.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Rights-aware generative media production
Produce a small media campaign with a repeatable creative process and a documented asset trail. Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Recall: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. Identify one observation that would contradict your claim.

### Terms
Controlled iteration: Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Produce a small media campaign with a repeatable creative process and a documented asset trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

2. Prepare the project inputs
Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The fictional production requires a documented source and permitted use for every visible asset before delivery. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Produce a small media campaign with a repeatable creative process and a documented asset trail.
Write a fictional campaign brief and create or license source assets. Record creator, license, permitted use and any model/tool terms; do not use someone’s likeness without permission.
Create a storyboard and style frame in Blender or a design tool. Define aspect ratios, accessibility requirements and review criteria before generating variations.
Generate or manually create three variations, recording tool/model version and editing decisions. Use Blender for compositing and export a short sequence with captions and a static fallback.
Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims.
Deliverables: Finished short sequence and accessible variants; Storyboard and creative iteration breakdown. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Generative-media producer / technical artist. Use this scenario: Find an asset with unclear permission or a missing source record. Replace it or withhold it, and document the change rather than silently asserting ownership.
Review: Start with the task and permitted scope. Explain controlled iteration: Change selected creative variables while preserving a record of prompts, settings and edits. Evaluate variants against the brief rather than collecting unlimited attractive outputs. Show the input and observed output, then address Review brief alignment, visual continuity, caption accuracy and provenance completeness. Label AI-assisted elements and avoid fabricated commercial performance claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Finished short sequence and accessible variants; Storyboard and creative iteration breakdown. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

