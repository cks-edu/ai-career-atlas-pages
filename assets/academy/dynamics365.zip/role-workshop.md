# Dynamics 365 / Power Platform Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Dataverse tables and relationships

A business application model defines tables, columns and relationships. Choose required fields and ownership based on the process, not only the appearance of a form.
Mental model: A filing system needs relationships between folders as well as labels inside them.
Case: A service request belongs to a customer and has a status and owner.
Task: Create a data dictionary offline, then follow Microsoft training to build the model in an authorized Dataverse environment. Test a missing customer and a valid request.
Acceptance: The relationship and required-field behavior match the contract.
Troubleshooting: A displayed lookup is not evidence that the relationship is enforced in every write path.
Deliverable: Dataverse model and validation cases

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Security roles and automation

Business-unit scope, roles and automation context affect which records an action can access. A flow may run with privileges different from the initiating user.
Mental model: A delegated assistant may carry a different key from the person requesting help.
Case: A requester should not gain access to another team's records through an automation.
Task: Write an access matrix, test two synthetic users where licensed access permits, and inspect the flow connection/context. Add a negative case for cross-team data.
Acceptance: Denied access stays denied through the automated route.
Troubleshooting: A flow's successful run does not establish that it used the right identity.
Deliverable: security/automation review and test log

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Solutions and environment configuration

Package customizations with dependencies and separate environment-specific connections. Promotion must include validation of references, permissions and existing records.
Mental model: Ship the machine with its parts list, then connect it to the destination's utilities.
Case: A test connection must not be carried blindly into the production environment.
Task: Create a solution inventory, identify environment variables/connection references and write import, validation and recovery steps. Rehearse only in authorized development environments.
Acceptance: A complete dependency manifest and post-import acceptance checks.
Troubleshooting: An import success can still leave a broken connection reference; exercise the business flow.
Deliverable: Dynamics solution release pack

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
