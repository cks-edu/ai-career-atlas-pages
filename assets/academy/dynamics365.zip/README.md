# Dynamics 365 / Power Platform Developer

Software Engineering

Start with dataverse tables and relationships. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Dynamics solution release pack.

## beginner

Create a data dictionary offline, then follow Microsoft training to build the model in an authorized Dataverse environment. Test a missing customer and a valid request.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Dataverse tables and relationships
A business application model defines tables, columns and relationships. Choose required fields and ownership based on the process, not only the appearance of a form.
Mental model: A filing system needs relationships between folders as well as labels inside them.
Limit: A displayed lookup is not evidence that the relationship is enforced in every write path.
Example: A service request belongs to a customer and has a status and owner.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A displayed lookup is not evidence that the relationship is enforced in every write path.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A service request belongs to a customer and has a status and owner. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a data dictionary offline, then follow Microsoft training to build the model in an authorized Dataverse environment. Test a missing customer and a valid request.
Expected: The relationship and required-field behavior match the contract.

6. Role workshop · debug and verify
A displayed lookup is not evidence that the relationship is enforced in every write path. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Dataverse model and validation cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The relationship and required-field behavior match the contract.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Dataverse tables and relationships: A displayed lookup is not evidence that the relationship is enforced in every write path.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Dataverse model and validation cases
The relationship and required-field behavior match the contract.

Interview: Work through this Dynamics 365 / Power Platform Developer case: A service request belongs to a customer and has a status and owner. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A business application model defines tables, columns and relationships. Choose required fields and ownership based on the process, not only the appearance of a form. Expected evidence: The relationship and required-field behavior match the contract. Diagnosis: A displayed lookup is not evidence that the relationship is enforced in every write path. State the limits of the mental model: A filing system needs relationships between folders as well as labels inside them.

Resume: Built Dataverse model and validation cases using Dynamics 365, Dataverse, Power Apps and Power Automate; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Write an access matrix, test two synthetic users where licensed access permits, and inspect the flow connection/context. Add a negative case for cross-team data.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Security roles and automation
Business-unit scope, roles and automation context affect which records an action can access. A flow may run with privileges different from the initiating user.
Mental model: A delegated assistant may carry a different key from the person requesting help.
Limit: A flow's successful run does not establish that it used the right identity.
Example: A requester should not gain access to another team's records through an automation.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A flow's successful run does not establish that it used the right identity.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A requester should not gain access to another team's records through an automation. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write an access matrix, test two synthetic users where licensed access permits, and inspect the flow connection/context. Add a negative case for cross-team data.
Expected: Denied access stays denied through the automated route.

6. Role workshop · debug and verify
A flow's successful run does not establish that it used the right identity. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save security/automation review and test log. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Denied access stays denied through the automated route.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Security roles and automation: A flow's successful run does not establish that it used the right identity.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: security/automation review and test log
Denied access stays denied through the automated route.

Interview: Work through this Dynamics 365 / Power Platform Developer case: A requester should not gain access to another team's records through an automation. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Business-unit scope, roles and automation context affect which records an action can access. A flow may run with privileges different from the initiating user. Expected evidence: Denied access stays denied through the automated route. Diagnosis: A flow's successful run does not establish that it used the right identity. State the limits of the mental model: A delegated assistant may carry a different key from the person requesting help.

Resume: Built security/automation review and test log using Dynamics 365, Dataverse, Power Apps and Power Automate; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create a solution inventory, identify environment variables/connection references and write import, validation and recovery steps. Rehearse only in authorized development environments.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Solutions and environment configuration
Package customizations with dependencies and separate environment-specific connections. Promotion must include validation of references, permissions and existing records.
Mental model: Ship the machine with its parts list, then connect it to the destination's utilities.
Limit: An import success can still leave a broken connection reference; exercise the business flow.
Example: A test connection must not be carried blindly into the production environment.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An import success can still leave a broken connection reference; exercise the business flow.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A test connection must not be carried blindly into the production environment. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a solution inventory, identify environment variables/connection references and write import, validation and recovery steps. Rehearse only in authorized development environments.
Expected: A complete dependency manifest and post-import acceptance checks.

6. Role workshop · debug and verify
An import success can still leave a broken connection reference; exercise the business flow. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Dynamics solution release pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A complete dependency manifest and post-import acceptance checks.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Solutions and environment configuration: An import success can still leave a broken connection reference; exercise the business flow.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Dynamics solution release pack
A complete dependency manifest and post-import acceptance checks.

Interview: Work through this Dynamics 365 / Power Platform Developer case: A test connection must not be carried blindly into the production environment. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Package customizations with dependencies and separate environment-specific connections. Promotion must include validation of references, permissions and existing records. Expected evidence: A complete dependency manifest and post-import acceptance checks. Diagnosis: An import success can still leave a broken connection reference; exercise the business flow. State the limits of the mental model: Ship the machine with its parts list, then connect it to the destination's utilities.

Resume: Built Dynamics solution release pack using Dynamics 365, Dataverse, Power Apps and Power Automate; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft Dynamics 365 training: https://learn.microsoft.com/en-us/training/dynamics365/
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
