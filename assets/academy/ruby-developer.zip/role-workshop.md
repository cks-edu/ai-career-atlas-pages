# Ruby / Rails Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Rails routes and model rules

A Rails route selects controller behavior; a model validation enforces a domain rule before persistence. A pretty form alone cannot protect alternate entry points.
Mental model: The counter routes the request, while the records office enforces the filing rule.
Case: Task title must be present whether created through a form or the model directly.
Task: Use the official Rails Getting Started project in a fresh directory. Add a Task model with a title and presence validation, migrate the development database and create one valid and one blank task in the console.
Acceptance: Valid record persists; blank record exposes validation errors and does not persist.
Troubleshooting: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used.
Deliverable: Rails model, migration and console transcript

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Request tests and isolation

Request tests exercise routing, validation and persistence together. Use isolated test data and assert both response behavior and database effects.
Mental model: Check the whole service counter transaction, not just the clerk's greeting.
Case: A blank create request should not increase Task.count.
Task: Add a request test for valid and blank task creation. Assert the expected response for your chosen HTML/API contract and the change in Task.count; run bin/rails test with a dedicated test database.
Acceptance: Valid request increases count once; invalid request leaves it unchanged.
Troubleshooting: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests.
Deliverable: request test suite with independent cases

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Migrations and job retries

Schema changes and background jobs outlive a single request. Roll out compatible schema additions before removing old fields, and make repeated jobs safe using stable business keys.
Mental model: Changing the warehouse layout must not lose parcels already on the conveyor.
Case: Retrying notification for task 1 twice should create one recorded delivery.
Task: Write a migration plan adding an optional field, then a job prototype that checks a unique delivery key. Test duplicate invocation and failure before acknowledgment; state how the database enforces uniqueness under concurrency.
Acceptance: A duplicate-retry test and a rollback plan that accounts for already changed data.
Troubleshooting: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary.
Deliverable: migration sequence and retry-safe job tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
