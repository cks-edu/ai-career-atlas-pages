# Ruby / Rails Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in Ruby / Rails Developer: Use the concept to complete this role exercise: Create the official Rails sample and trace a route to its controller

Rails routes and model rules: A Rails route selects controller behavior; a model validation enforces a domain rule before persistence. A pretty form alone cannot protect alternate entry points.

### Request and response

A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. In this role, work through: Task title must be present whether created through a form or the model directly. The practical workshop develops this into: Use the official Rails Getting Started project in a fresh directory. Add a Task model with a title and presence validation, migrate the development database and create one valid and one blank task in the console.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Role application: The counter routes the request, while the records office enforces the filing rule.

A Rails route selects controller behavior; a model validation enforces a domain rule before persistence. A pretty form alone cannot protect alternate entry points.

Worked example: Task title must be present whether created through a form or the model directly.

Shared foundation example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Ruby and Rails (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Ruby / Rails Developer: Task title must be present whether created through a form or the model directly.

Predict the worked case

Read this case without running a tool: Task title must be present whether created through a form or the model directly. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in request and response.

Connect the concept to the role

Apply this rule: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Networks can time out; sending an order does not prove it was fulfilled.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies request and response to this case: Task title must be present whether created through a form or the model directly. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Task title must be present whether created through a form or the model directly. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Request and response; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request and response. Use the glossary below, then write your prediction for: Task title must be present whether created through a form or the model directly. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Ruby / Rails Developer role interview. Explain request and response using this case: Task title must be present whether created through a form or the model directly. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request and response to a system or workflow you know. Explain request and response using this case: Task title must be present whether created through a form or the model directly. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Draw the request and response for adding one task.

Interview: Explain request and response using this case: Task title must be present whether created through a form or the model directly. State the evidence, one alternative and where the mental model stops.

Quiz: After the Rails routes and model rules rehearsal, check this foundation: A request returns HTTP 404. Which boundary has evidence of working?

An HTTP server returned a response; inspect the route next.

The request never reached any HTTP server.

The server has confirmed that the resource exists.

Reference: An HTTP server returned a response; inspect the route next. — 404 is an HTTP response, not a transport timeout. It does not prove which component generated it or that the business operation succeeded.

Sources:

Rails: getting started: https://guides.rubyonrails.org/getting_started.html

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Rails routes and model rules

A Rails route selects controller behavior; a model validation enforces a domain rule before persistence. A pretty form alone cannot protect alternate entry points. In this role, work through: Task title must be present whether created through a form or the model directly. The practical workshop develops this into: Use the official Rails Getting Started project in a fresh directory. Add a Task model with a title and presence validation, migrate the development database and create one valid and one blank task in the console.

Mental model: The counter routes the request, while the records office enforces the filing rule.

Boundary: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used.

Worked example: Task title must be present whether created through a form or the model directly.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Ruby and Rails (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Ruby / Rails Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use the official Rails Getting Started project in a fresh directory. Add a Task model with a title and presence validation, migrate the development database and create one valid and one blank task in the console.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Task title must be present whether created through a form or the model directly. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use the official Rails Getting Started project in a fresh directory. Add a Task model with a title and presence validation, migrate the development database and create one valid and one blank task in the console.

```
rails new atlas_tasks
cd atlas_tasks
bin/rails generate model Task title:string
bin/rails db:migrate
bin/rails console
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Valid record persists; blank record exposes validation errors and does not persist.

Role workshop · debug and verify

If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Rails model, migration and console transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Valid record persists; blank record exposes validation errors and does not persist.

Expected: Valid record persists; blank record exposes validation errors and does not persist.

Troubleshoot: The role exercise differs from the prediction: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: Rails model, migration and console transcript; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rails routes and model rules. Use the glossary below, then write your prediction for: Task title must be present whether created through a form or the model directly. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Ruby / Rails Developer role interview. Explain rails routes and model rules using this case: Task title must be present whether created through a form or the model directly. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rails routes and model rules to a system or workflow you know. Explain rails routes and model rules using this case: Task title must be present whether created through a form or the model directly. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used.

Interview: Explain rails routes and model rules using this case: Task title must be present whether created through a form or the model directly. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Task title must be present whether created through a form or the model directly.

Valid record persists; blank record exposes validation errors and does not persist.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Valid record persists; blank record exposes validation errors and does not persist. — A Rails route selects controller behavior; a model validation enforces a domain rule before persistence. A pretty form alone cannot protect alternate entry points. Valid record persists; blank record exposes validation errors and does not persist.

Sources:

Rails: getting started: https://guides.rubyonrails.org/getting_started.html

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in Ruby / Rails Developer: Use the concept to complete this role exercise: Add a model validation and request test

Request tests and isolation: Request tests exercise routing, validation and persistence together. Use isolated test data and assert both response behavior and database effects.

### Validation at a boundary

Check input before storing or using it. Client checks help people; the server must also enforce the rule. In this role, work through: A blank create request should not increase Task.count. The practical workshop develops this into: Add a request test for valid and blank task creation. Assert the expected response for your chosen HTML/API contract and the change in Task.count; run bin/rails test with a dedicated test database.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Role application: Check the whole service counter transaction, not just the clerk's greeting.

Request tests exercise routing, validation and persistence together. Use isolated test data and assert both response behavior and database effects.

Worked example: A blank create request should not increase Task.count.

Shared foundation example: A blank title receives 400 and does not change task count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Ruby and Rails (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Ruby / Rails Developer: A blank create request should not increase Task.count.

Predict the worked case

Read this case without running a tool: A blank create request should not increase Task.count. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in validation at a boundary.

Connect the concept to the role

Apply this rule: Check input before storing or using it. Client checks help people; the server must also enforce the rule. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid input can still be unauthorized; validation is not access control.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies validation at a boundary to this case: A blank create request should not increase Task.count. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A blank create request should not increase Task.count. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Validation at a boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with validation at a boundary. Use the glossary below, then write your prediction for: A blank create request should not increase Task.count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Ruby / Rails Developer role interview. Explain validation at a boundary using this case: A blank create request should not increase Task.count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate validation at a boundary to a system or workflow you know. Explain validation at a boundary using this case: A blank create request should not increase Task.count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Explain validation at a boundary using this case: A blank create request should not increase Task.count. State the evidence, one alternative and where the mental model stops.

Quiz: After the Request tests and isolation rehearsal, check this foundation: A browser rejects a blank field. A second client calls the API directly. Where must the same business rule be enforced?

Only in the browser to avoid duplicate logic.

At the server boundary before state changes.

Only after storing the input, in the dashboard.

Reference: At the server boundary before state changes. — Client checks improve feedback; the server must protect its contract for every caller.

Sources:

Rails: getting started: https://guides.rubyonrails.org/getting_started.html

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Request tests and isolation

Request tests exercise routing, validation and persistence together. Use isolated test data and assert both response behavior and database effects. In this role, work through: A blank create request should not increase Task.count. The practical workshop develops this into: Add a request test for valid and blank task creation. Assert the expected response for your chosen HTML/API contract and the change in Task.count; run bin/rails test with a dedicated test database.

Mental model: Check the whole service counter transaction, not just the clerk's greeting.

Boundary: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests.

Worked example: A blank create request should not increase Task.count.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Ruby and Rails (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Ruby / Rails Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add a request test for valid and blank task creation. Assert the expected response for your chosen HTML/API contract and the change in Task.count; run bin/rails test with a dedicated test database.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

A blank create request should not increase Task.count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add a request test for valid and blank task creation. Assert the expected response for your chosen HTML/API contract and the change in Task.count; run bin/rails test with a dedicated test database.

```
bin/rails test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Valid request increases count once; invalid request leaves it unchanged.

Role workshop · debug and verify

A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save request test suite with independent cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Valid request increases count once; invalid request leaves it unchanged.

Expected: Valid request increases count once; invalid request leaves it unchanged.

Troubleshoot: The role exercise differs from the prediction: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: request test suite with independent cases; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request tests and isolation. Use the glossary below, then write your prediction for: A blank create request should not increase Task.count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Ruby / Rails Developer role interview. Explain request tests and isolation using this case: A blank create request should not increase Task.count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request tests and isolation to a system or workflow you know. Explain request tests and isolation using this case: A blank create request should not increase Task.count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests.

Interview: Explain request tests and isolation using this case: A blank create request should not increase Task.count. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A blank create request should not increase Task.count.

Ignore the failing case and keep only the successful screenshot.

Valid request increases count once; invalid request leaves it unchanged.

Treat any successful command as proof that all business and access rules passed.

Reference: Valid request increases count once; invalid request leaves it unchanged. — Request tests exercise routing, validation and persistence together. Use isolated test data and assert both response behavior and database effects. Valid request increases count once; invalid request leaves it unchanged.

Sources:

Rails: getting started: https://guides.rubyonrails.org/getting_started.html

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in Ruby / Rails Developer: Use the concept to complete this role exercise: Plan a reversible database migration and background-job retry policy

Migrations and job retries: Schema changes and background jobs outlive a single request. Roll out compatible schema additions before removing old fields, and make repeated jobs safe using stable business keys.

### State and recovery

State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. In this role, work through: Retrying notification for task 1 twice should create one recorded delivery. The practical workshop develops this into: Write a migration plan adding an optional field, then a job prototype that checks a unique delivery key. Test duplicate invocation and failure before acknowledgment; state how the database enforces uniqueness under concurrency.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Role application: Changing the warehouse layout must not lose parcels already on the conveyor.

Schema changes and background jobs outlive a single request. Roll out compatible schema additions before removing old fields, and make repeated jobs safe using stable business keys.

Worked example: Retrying notification for task 1 twice should create one recorded delivery.

Shared foundation example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Ruby and Rails (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Ruby / Rails Developer: Retrying notification for task 1 twice should create one recorded delivery.

Predict the worked case

Read this case without running a tool: Retrying notification for task 1 twice should create one recorded delivery. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state and recovery.

Connect the concept to the role

Apply this rule: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database also fails; persistence needs backups and tested recovery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state and recovery to this case: Retrying notification for task 1 twice should create one recorded delivery. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Retrying notification for task 1 twice should create one recorded delivery. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for State and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state and recovery. Use the glossary below, then write your prediction for: Retrying notification for task 1 twice should create one recorded delivery. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Ruby / Rails Developer role interview. Explain state and recovery using this case: Retrying notification for task 1 twice should create one recorded delivery. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state and recovery to a system or workflow you know. Explain state and recovery using this case: Retrying notification for task 1 twice should create one recorded delivery. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Name two things required before calling this service production ready.

Interview: Explain state and recovery using this case: Retrying notification for task 1 twice should create one recorded delivery. State the evidence, one alternative and where the mental model stops.

Quiz: After the Migrations and job retries rehearsal, check this foundation: A successful operation exists only in process memory. The process restarts. What can you promise?

The success response guarantees recovery after restart.

A retry will always reconstruct the original state.

Nothing about retention without a persistence and recovery design.

Reference: Nothing about retention without a persistence and recovery design. — An acknowledgment is not a storage guarantee. Identify the persistence boundary and verify restoration.

Sources:

Rails: getting started: https://guides.rubyonrails.org/getting_started.html

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Migrations and job retries

Schema changes and background jobs outlive a single request. Roll out compatible schema additions before removing old fields, and make repeated jobs safe using stable business keys. In this role, work through: Retrying notification for task 1 twice should create one recorded delivery. The practical workshop develops this into: Write a migration plan adding an optional field, then a job prototype that checks a unique delivery key. Test duplicate invocation and failure before acknowledgment; state how the database enforces uniqueness under concurrency.

Mental model: Changing the warehouse layout must not lose parcels already on the conveyor.

Boundary: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary.

Worked example: Retrying notification for task 1 twice should create one recorded delivery.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Ruby and Rails (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Ruby / Rails Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a migration plan adding an optional field, then a job prototype that checks a unique delivery key. Test duplicate invocation and failure before acknowledgment; state how the database enforces uniqueness under concurrency.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Retrying notification for task 1 twice should create one recorded delivery. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a migration plan adding an optional field, then a job prototype that checks a unique delivery key. Test duplicate invocation and failure before acknowledgment; state how the database enforces uniqueness under concurrency.

```
bin/rails test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A duplicate-retry test and a rollback plan that accounts for already changed data.

Role workshop · debug and verify

A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save migration sequence and retry-safe job tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A duplicate-retry test and a rollback plan that accounts for already changed data.

Expected: A duplicate-retry test and a rollback plan that accounts for already changed data.

Troubleshoot: The role exercise differs from the prediction: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: migration sequence and retry-safe job tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with migrations and job retries. Use the glossary below, then write your prediction for: Retrying notification for task 1 twice should create one recorded delivery. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Ruby / Rails Developer role interview. Explain migrations and job retries using this case: Retrying notification for task 1 twice should create one recorded delivery. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate migrations and job retries to a system or workflow you know. Explain migrations and job retries using this case: Retrying notification for task 1 twice should create one recorded delivery. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary.

Interview: Explain migrations and job retries using this case: Retrying notification for task 1 twice should create one recorded delivery. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Retrying notification for task 1 twice should create one recorded delivery.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A duplicate-retry test and a rollback plan that accounts for already changed data.

Reference: A duplicate-retry test and a rollback plan that accounts for already changed data. — Schema changes and background jobs outlive a single request. Roll out compatible schema additions before removing old fields, and make repeated jobs safe using stable business keys. A duplicate-retry test and a rollback plan that accounts for already changed data.

Sources:

Rails: getting started: https://guides.rubyonrails.org/getting_started.html

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
