# Ruby / Rails Developer

Software Engineering

Start with rails routes and model rules. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward migration sequence and retry-safe job tests.

## beginner

Use the official Rails Getting Started project in a fresh directory. Add a Task model with a title and presence validation, migrate the development database and create one valid and one blank task in the console.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Request and response
A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.
Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.
Recall: Draw the request and response for adding one task.

### Rails routes and model rules
A Rails route selects controller behavior; a model validation enforces a domain rule before persistence. A pretty form alone cannot protect alternate entry points.
Mental model: The counter routes the request, while the records office enforces the filing rule.
Limit: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used.
Example: Task title must be present whether created through a form or the model directly.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Task title must be present whether created through a form or the model directly. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use the official Rails Getting Started project in a fresh directory. Add a Task model with a title and presence validation, migrate the development database and create one valid and one blank task in the console.
```
rails new atlas_tasks
cd atlas_tasks
bin/rails generate model Task title:string
bin/rails db:migrate
bin/rails console
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Valid record persists; blank record exposes validation errors and does not persist.

6. Role workshop · debug and verify
If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Rails model, migration and console transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Valid record persists; blank record exposes validation errors and does not persist.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Rails routes and model rules: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: Rails model, migration and console transcript
Valid record persists; blank record exposes validation errors and does not persist.

Interview: Work through this Ruby / Rails Developer case: Task title must be present whether created through a form or the model directly. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A Rails route selects controller behavior; a model validation enforces a domain rule before persistence. A pretty form alone cannot protect alternate entry points. Expected evidence: Valid record persists; blank record exposes validation errors and does not persist. Diagnosis: If invalid data persists, confirm validation is on the actual model and no validation-bypassing write was used. State the limits of the mental model: The counter routes the request, while the records office enforces the filing rule.

Resume: Built Rails model, migration and console transcript using Ruby and Rails; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add a request test for valid and blank task creation. Assert the expected response for your chosen HTML/API contract and the change in Task.count; run bin/rails test with a dedicated test database.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Validation at a boundary
Check input before storing or using it. Client checks help people; the server must also enforce the rule.
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.
Example: A blank title receives 400 and does not change task count.
Recall: Why must the server reject invalid input even if the form already checks it?

### Request tests and isolation
Request tests exercise routing, validation and persistence together. Use isolated test data and assert both response behavior and database effects.
Mental model: Check the whole service counter transaction, not just the clerk's greeting.
Limit: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests.
Example: A blank create request should not increase Task.count.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A blank create request should not increase Task.count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add a request test for valid and blank task creation. Assert the expected response for your chosen HTML/API contract and the change in Task.count; run bin/rails test with a dedicated test database.
```
bin/rails test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Valid request increases count once; invalid request leaves it unchanged.

6. Role workshop · debug and verify
A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save request test suite with independent cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Valid request increases count once; invalid request leaves it unchanged.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Request tests and isolation: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: request test suite with independent cases
Valid request increases count once; invalid request leaves it unchanged.

Interview: Work through this Ruby / Rails Developer case: A blank create request should not increase Task.count. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Request tests exercise routing, validation and persistence together. Use isolated test data and assert both response behavior and database effects. Expected evidence: Valid request increases count once; invalid request leaves it unchanged. Diagnosis: A test passing only after another test suggests shared state or order dependence; use fixtures/factories and reset between tests. State the limits of the mental model: Check the whole service counter transaction, not just the clerk's greeting.

Resume: Built request test suite with independent cases using Ruby and Rails; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write a migration plan adding an optional field, then a job prototype that checks a unique delivery key. Test duplicate invocation and failure before acknowledgment; state how the database enforces uniqueness under concurrency.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State and recovery
State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.
Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database.
Recall: Name two things required before calling this service production ready.

### Migrations and job retries
Schema changes and background jobs outlive a single request. Roll out compatible schema additions before removing old fields, and make repeated jobs safe using stable business keys.
Mental model: Changing the warehouse layout must not lose parcels already on the conveyor.
Limit: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary.
Example: Retrying notification for task 1 twice should create one recorded delivery.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Retrying notification for task 1 twice should create one recorded delivery. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a migration plan adding an optional field, then a job prototype that checks a unique delivery key. Test duplicate invocation and failure before acknowledgment; state how the database enforces uniqueness under concurrency.
```
bin/rails test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A duplicate-retry test and a rollback plan that accounts for already changed data.

6. Role workshop · debug and verify
A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save migration sequence and retry-safe job tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A duplicate-retry test and a rollback plan that accounts for already changed data.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Migrations and job retries: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: migration sequence and retry-safe job tests
A duplicate-retry test and a rollback plan that accounts for already changed data.

Interview: Work through this Ruby / Rails Developer case: Retrying notification for task 1 twice should create one recorded delivery. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Schema changes and background jobs outlive a single request. Roll out compatible schema additions before removing old fields, and make repeated jobs safe using stable business keys. Expected evidence: A duplicate-retry test and a rollback plan that accounts for already changed data. Diagnosis: A check-then-create without a database constraint can race; document and enforce the atomic uniqueness boundary. State the limits of the mental model: Changing the warehouse layout must not lose parcels already on the conveyor.

Resume: Built migration sequence and retry-safe job tests using Ruby and Rails; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Rails: getting started: https://guides.rubyonrails.org/getting_started.html
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
