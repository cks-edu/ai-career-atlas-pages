# Collect scoped startup and incident evidence

Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

```sh
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE logs YOUR_POD --tail=100
```

Expected evidence: Record startup versus liveness/readiness observations, relevant timestamps and a reviewed PR proposal. Stop before any mutation not explicitly authorized for the experiment.

Cleanup: these inspection commands create no resources. Stop only separately started learning servers and remove only your own temporary resources after retaining evidence. No cloud resources are provisioned by this pack.
