# GitOps remediation: propose a PR, never direct mutation

A remediation agent can collect evidence and draft a change for review. Keep its execution authority narrower than its reasoning ability. A pull request still needs an approved repository, scope and safe content; it is not automatically harmless.

The fixture permits named scoped diagnostics and a GitOps remediation PR only for an authenticated caller with the matching permission. It explicitly refuses direct destructive tools, unknown operations and exhausted attempt budgets.

Task: Implement authorizeSreAgentAction and add wrong-namespace, missing-permission and unapproved-repository cases. Draft a remediation PR template with evidence and rollback criteria.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Alert → scoped diagnosis → proposed Git change → authorized human/controller review.
State: Trusted permissions, namespace, tool name and remaining attempts.
Boundary: Generated remediation text cannot expand cluster privileges.
Failure: An agent deletes a namespace while attempting to repair slow startup.
Control: Allow diagnostics and bounded PR proposals; deny direct destructive mutation.
Observability: Audit policy decisions, proposed diffs, reviewer and rollout outcome.
Blast radius: The namespace or wider cluster if direct credentials are available.
Trade-off: Human review adds latency but limits uncontrolled blast radius.

Limit: The model cannot supply its own trusted principal or approval. Native integration needs server-owned authorization, human review, branch protections and deployment checks; this fixture does not open a PR or mutate a cluster.

Sources:
https://kubernetes.io/docs/concepts/security/rbac-good-practices/
https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/
https://modelcontextprotocol.io/specification/2026-07-28/server/tools
