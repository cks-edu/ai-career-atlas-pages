function authorizeSreAgentAction(a) {
  if(!a || a.authenticated!==true || !Number.isSafeInteger(a.attemptsRemaining) || a.attemptsRemaining<1 || typeof a.namespace!=='string' || !Array.isArray(a.allowedNamespaces) || !a.allowedNamespaces.includes(a.namespace) || !Array.isArray(a.permissions)) return false;
  if(['get_pod_logs','query_prometheus'].includes(a.tool)) return a.permissions.includes('diagnose');
  return a.tool==='create_gitops_remediation_pr' && a.permissions.includes('propose') && a.repositoryApproved===true;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const a={authenticated:true,attemptsRemaining:1,namespace:'lab',allowedNamespaces:['lab'],permissions:['diagnose','propose']};assert(authorizeSreAgentAction({...a,tool:'get_pod_logs'}));assert(authorizeSreAgentAction({...a,tool:'create_gitops_remediation_pr',repositoryApproved:true}));
console.log("PASS: Allow scoped diagnosis and proposal");
}
{
const a={authenticated:true,attemptsRemaining:3,namespace:'lab',allowedNamespaces:['lab'],permissions:['diagnose','propose','admin']};assert(!authorizeSreAgentAction({...a,tool:'delete_namespace'}));assert(!authorizeSreAgentAction({...a,tool:'kubectl_exec_write'}));
console.log("PASS: Deny direct mutations regardless of permissions");
}
{
assert(!authorizeSreAgentAction(null));assert(!authorizeSreAgentAction({authenticated:true,attemptsRemaining:0,namespace:'lab',allowedNamespaces:['lab'],permissions:['diagnose'],tool:'get_pod_logs'}));
console.log("PASS: Enforce identity and attempt budget");
}
