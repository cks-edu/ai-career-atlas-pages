function correlateAlerts(events,service,anchor) {
  if(!Array.isArray(events) || typeof service!=='string' || !service || !Number.isFinite(anchor)) return [];
  return events.filter(e=>e && e.service===service && typeof e.id==='string' && Number.isFinite(e.atSeconds) && Math.abs(e.atSeconds-anchor)<=60).map(e=>e.id);
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(JSON.stringify(correlateAlerts([{id:'a',service:'s',atSeconds:40},{id:'b',service:'s',atSeconds:100}],'s',100))==='["a","b"]');
console.log("PASS: Group bounded events");
}
{
assert(correlateAlerts([{id:'x',service:'other',atSeconds:100},{id:'y',service:'s',atSeconds:39}],'s',100).length===0);
console.log("PASS: Exclude different scope and time");
}
{
assert(correlateAlerts([{id:'x',service:'s',atSeconds:NaN}],'s',1).length===0);assert(correlateAlerts(null,'s',1).length===0);
console.log("PASS: Reject unknown timestamps");
}
