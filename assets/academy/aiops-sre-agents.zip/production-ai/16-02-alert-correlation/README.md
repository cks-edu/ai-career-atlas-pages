# Alert correlation & cautious root-cause analysis

Related alerts can share a cause, but timing alone does not prove causation. Correlate within a declared service scope and time window, then test a hypothesis against deployment, capacity and user-impact evidence.

The fixture returns IDs of validated events for the chosen service within an inclusive 60-second window around an anchor. It does not rank a root cause or authorize remediation.

Task: Implement correlateAlerts. Build a synthetic incident timeline with an unrelated alert, clock uncertainty and a falsifiable root-cause hypothesis.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Scoped alerts → time-window grouping → hypothesis → diagnostic check.
State: Service identity, timestamps in seconds and retained event IDs.
Boundary: Correlation is evidence to investigate, not proof of cause.
Failure: An unrelated alert becomes the reason for a destructive restart.
Control: Require scope and timestamps, then confirm the hypothesis separately.
Observability: Inspect timeline, deployment changes and dependency health.
Blast radius: Services affected by an incorrectly chosen recovery action.
Trade-off: Small windows miss delayed effects; wide windows add unrelated events.

Limit: Clock skew, missing telemetry and shared dependencies can break simple correlation. Record uncertainty and counterevidence; distinguish a suspected cause from a demonstrated one.

Sources:
https://opentelemetry.io/docs/specs/semconv/gen-ai/
https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
