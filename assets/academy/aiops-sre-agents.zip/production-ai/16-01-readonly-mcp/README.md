# Read-only Kubernetes & Prometheus MCP tools

MCP describes tool interactions; it does not grant Kubernetes permissions. Expose narrowly scoped diagnostic tools through a trusted service identity. Restrict namespaces, query cost and returned data; logs can contain secrets.

The fixture accepts only a named diagnostic tool, an authenticated principal and an authorized namespace. It rejects shell-like tools rather than trying to infer whether an arbitrary command is read-only.

Task: Implement allowDiagnosticTool. Define a read-only tool schema and a response-redaction test; explicitly exclude arbitrary shell execution.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Authenticated caller → tool schema → namespace policy → diagnostic API.
State: Allowed tool names, principal and permitted namespaces.
Boundary: A model-selected tool is not an authorization decision.
Failure: An unrestricted diagnostic tool leaks another namespace’s logs.
Control: Allow named reads only and enforce namespace ownership server side.
Observability: Audit scoped calls, redaction results and bounded query durations.
Blast radius: Data accessible through the tool service identity.
Trade-off: Narrow diagnostic tools reduce flexibility while improving reviewability.

Limit: Real enforcement needs server-side authentication, Kubernetes RBAC, query limits and output redaction. A read-only API can still reveal sensitive information or overload a service.

Sources:
https://kubernetes.io/docs/concepts/security/rbac-good-practices/
https://modelcontextprotocol.io/specification/2026-07-28/server/tools
