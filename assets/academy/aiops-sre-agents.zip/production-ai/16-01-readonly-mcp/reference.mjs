function allowDiagnosticTool(p) {
  return !!p && p.authenticated===true && ['get_pod_logs','query_prometheus'].includes(p.tool) && typeof p.namespace==='string' && Array.isArray(p.allowedNamespaces) && p.allowedNamespaces.includes(p.namespace);
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(allowDiagnosticTool({authenticated:true,tool:'get_pod_logs',namespace:'lab',allowedNamespaces:['lab']}));
console.log("PASS: Allow a scoped diagnostic");
}
{
assert(!allowDiagnosticTool({authenticated:true,tool:'exec',namespace:'lab',allowedNamespaces:['lab']}));assert(!allowDiagnosticTool({authenticated:true,tool:'get_pod_logs',namespace:'prod',allowedNamespaces:['lab']}));
console.log("PASS: Deny shell and cross-namespace reads");
}
{
assert(!allowDiagnosticTool({authenticated:false,tool:'query_prometheus',namespace:'lab',allowedNamespaces:['lab']}));assert(!allowDiagnosticTool(null));
console.log("PASS: Require authentication");
}
