function allowDiagnosticTool(...args) {
  return null; // Implement the declared policy. Keep the supplied checks.
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(allowDiagnosticTool({authenticated:true,tool:'get_pod_logs',namespace:'lab',allowedNamespaces:['lab']}));
console.log("PASS: Allow a scoped diagnostic");
}
{
assert(!allowDiagnosticTool({authenticated:true,tool:'exec',namespace:'lab',allowedNamespaces:['lab']}));assert(!allowDiagnosticTool({authenticated:true,tool:'get_pod_logs',namespace:'prod',allowedNamespaces:['lab']}));
console.log("PASS: Deny shell and cross-namespace reads");
}
{
assert(!allowDiagnosticTool({authenticated:false,tool:'query_prometheus',namespace:'lab',allowedNamespaces:['lab']}));assert(!allowDiagnosticTool(null));
console.log("PASS: Require authentication");
}
