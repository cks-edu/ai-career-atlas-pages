function allowAiChaos(p) {
  return !!p && p.environment==='learning' && p.namespace===p.approvedNamespace && typeof p.namespace==='string' && p.namespace.startsWith('lab-') && typeof p.owner==='string' && p.owner.trim().length>0 && Number.isSafeInteger(p.durationSeconds) && p.durationSeconds>0 && p.durationSeconds<=300 && p.rollbackReady===true;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(allowAiChaos({environment:'learning',namespace:'lab-ai',approvedNamespace:'lab-ai',owner:'learner',durationSeconds:300,rollbackReady:true}));
console.log("PASS: Approve bounded lab rehearsal");
}
{
const p={environment:'learning',namespace:'lab-ai',approvedNamespace:'lab-ai',owner:'learner',durationSeconds:301,rollbackReady:true};assert(!allowAiChaos(p));assert(!allowAiChaos({...p,durationSeconds:60,environment:'production'}));
console.log("PASS: Deny production and excessive duration");
}
{
assert(!allowAiChaos(null));assert(!allowAiChaos({environment:'learning',namespace:'lab-ai',approvedNamespace:'lab-other',owner:'learner',durationSeconds:30,rollbackReady:true}));
console.log("PASS: Require recovery and exact scope");
}
