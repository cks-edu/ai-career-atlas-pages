# Chaos rehearsals for GPU & vector infrastructure

Rehearse a failure only in an explicitly authorized environment with synthetic data, a known target and a stop condition. Model warmup is not automatically a hung process. Startup probes, readiness and liveness have distinct purposes.

The fixture authorizes a declared learning experiment only in the exact approved namespace, with an owner, a bounded duration of at most 300 seconds and a ready rollback. Production targets and unbounded durations are denied.

Task: Implement allowAiChaos. Write an experiment card for a GPU worker or vector store, including scope, hypotheses, diagnostic commands, abort criteria, restoration and untested assumptions.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Approved experiment plan → scoped failure → observed impact → stop and restore.
State: Environment, namespace, owner, duration and rollback readiness.
Boundary: A learning experiment must never infer permission to affect production.
Failure: A slow warmup is repeatedly killed by an unbounded repair loop.
Control: Use startup-aware signals, fixed attempt/time bounds and an explicit abort.
Observability: Record readiness timeline, restart count and observed recovery.
Blast radius: Only the approved learning namespace and its synthetic dependents.
Trade-off: More realistic failures improve learning but need tighter containment.

Limit: This policy does not execute chaos or prove recovery. A native rehearsal must verify actual abort behavior, backups, permissions, user-impact limits and any GPU model-load delay.

Sources:
https://github.com/chaos-mesh/website/blob/master/docs/define-chaos-experiment-scope.md
https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
