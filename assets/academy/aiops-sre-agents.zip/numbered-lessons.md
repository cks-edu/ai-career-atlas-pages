# AIOps: SRE Agents & Safe Incident Remediation — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## advanced

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

RBAC: Role-based access control enforced by the relevant service.

MCP tool: A declared callable interface, not a permission grant.

Correlation: A relationship suggesting investigation, without establishing causation.

RCA: Root-cause analysis using evidence and explicit uncertainty.

GitOps remediation PR: A reviewed proposal to change authoritative desired state.

Attempt budget: A bound on repeated actions; it must be enforced outside the model.

Startup probe: A startup-time health gate separate from normal readiness/liveness.

Chaos rehearsal: An authorized bounded experiment that tests a declared recovery hypothesis.

### Read-only Kubernetes & Prometheus MCP tools

MCP describes tool interactions; it does not grant Kubernetes permissions. Expose narrowly scoped diagnostic tools through a trusted service identity. Restrict namespaces, query cost and returned data; logs can contain secrets.

The fixture accepts only a named diagnostic tool, an authenticated principal and an authorized namespace. It rejects shell-like tools rather than trying to infer whether an arbitrary command is read-only.

Real enforcement needs server-side authentication, Kubernetes RBAC, query limits and output redaction. A read-only API can still reveal sensitive information or overload a service.

Mental model: Authenticated caller → tool schema → namespace policy → diagnostic API. Picture the boundary as a checked gate between stages.

Boundary: Real enforcement needs server-side authentication, Kubernetes RBAC, query limits and output redaction. A read-only API can still reveal sensitive information or overload a service.

Worked example: function allowDiagnosticTool(p) {
  return !!p && p.authenticated===true && ['get_pod_logs','query_prometheus'].includes(p.tool) && typeof p.namespace==='string' && Array.isArray(p.allowedNamespaces) && p.allowedNamespaces.includes(p.namespace);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract aiops-sre-agents.zip, install Node.js LTS, then open production-ai/16-01-readonly-mcp.

Tools for this exercise: JavaScript · local isolated workbench; MCP / Kubernetes RBAC / Prometheus, GitOps PR workflow / Chaos Mesh as documented optional extensions

Course tool and framework map: MCP / Kubernetes RBAC / Prometheus (Open protocols and projects); GitOps PR workflow / Chaos Mesh (Open source tooling · repository hosting terms vary)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

Implement allowDiagnosticTool. Define a read-only tool schema and a response-redaction test; explicitly exclude arbitrary shell execution.

Terminal folder: production-ai/16-01-readonly-mcp

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture accepts only a named diagnostic tool, an authenticated principal and an authorized namespace. It rejects shell-like tools rather than trying to infer whether an arbitrary command is read-only.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement allowDiagnosticTool. Define a read-only tool schema and a response-redaction test; explicitly exclude arbitrary shell execution.

Expected: Allow a scoped diagnostic

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny shell and cross-namespace reads; Require authentication

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Collect scoped startup and incident evidence

Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE logs YOUR_POD --tail=100
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record startup versus liveness/readiness observations, relevant timestamps and a reviewed PR proposal. Stop before any mutation not explicitly authorized for the experiment.

Expected: Allow a scoped diagnostic; Deny shell and cross-namespace reads; Require authentication. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Allow named reads only and enforce namespace ownership server side. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/16-01-readonly-mcp/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Authenticated caller → tool schema → namespace policy → diagnostic API. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does registering a read-only MCP tool replace Kubernetes RBAC? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A model-selected tool is not an authorization decision. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does registering a read-only MCP tool replace Kubernetes RBAC?

Interview: Does registering a read-only MCP tool replace Kubernetes RBAC? Explain the decision, a failing case and a production limitation.

Quiz: Does registering a read-only MCP tool replace Kubernetes RBAC?

No; the server still needs authenticated scoped authorization.

Yes, MCP makes all queries safe.

Yes, because logs never contain private data.

Reference: No; the server still needs authenticated scoped authorization. — No; the server still needs authenticated scoped authorization. Real enforcement needs server-side authentication, Kubernetes RBAC, query limits and output redaction. A read-only API can still reveal sensitive information or overload a service.

Sources:

Kubernetes: RBAC good practices: https://kubernetes.io/docs/concepts/security/rbac-good-practices/

MCP: typed tools and user interaction: https://modelcontextprotocol.io/specification/2026-07-28/server/tools

### Alert correlation & cautious root-cause analysis

Related alerts can share a cause, but timing alone does not prove causation. Correlate within a declared service scope and time window, then test a hypothesis against deployment, capacity and user-impact evidence.

The fixture returns IDs of validated events for the chosen service within an inclusive 60-second window around an anchor. It does not rank a root cause or authorize remediation.

Clock skew, missing telemetry and shared dependencies can break simple correlation. Record uncertainty and counterevidence; distinguish a suspected cause from a demonstrated one.

Mental model: Scoped alerts → time-window grouping → hypothesis → diagnostic check. Picture the boundary as a checked gate between stages.

Boundary: Clock skew, missing telemetry and shared dependencies can break simple correlation. Record uncertainty and counterevidence; distinguish a suspected cause from a demonstrated one.

Worked example: function correlateAlerts(events,service,anchor) {
  if(!Array.isArray(events) || typeof service!=='string' || !service || !Number.isFinite(anchor)) return [];
  return events.filter(e=>e && e.service===service && typeof e.id==='string' && Number.isFinite(e.atSeconds) && Math.abs(e.atSeconds-anchor)<=60).map(e=>e.id);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract aiops-sre-agents.zip, install Node.js LTS, then open production-ai/16-02-alert-correlation.

Tools for this exercise: JavaScript · local isolated workbench; MCP / Kubernetes RBAC / Prometheus, GitOps PR workflow / Chaos Mesh as documented optional extensions

Course tool and framework map: MCP / Kubernetes RBAC / Prometheus (Open protocols and projects); GitOps PR workflow / Chaos Mesh (Open source tooling · repository hosting terms vary)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

Implement correlateAlerts. Build a synthetic incident timeline with an unrelated alert, clock uncertainty and a falsifiable root-cause hypothesis.

Terminal folder: production-ai/16-02-alert-correlation

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture returns IDs of validated events for the chosen service within an inclusive 60-second window around an anchor. It does not rank a root cause or authorize remediation.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement correlateAlerts. Build a synthetic incident timeline with an unrelated alert, clock uncertainty and a falsifiable root-cause hypothesis.

Expected: Group bounded events

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Exclude different scope and time; Reject unknown timestamps

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Collect scoped startup and incident evidence

Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE logs YOUR_POD --tail=100
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record startup versus liveness/readiness observations, relevant timestamps and a reviewed PR proposal. Stop before any mutation not explicitly authorized for the experiment.

Expected: Group bounded events; Exclude different scope and time; Reject unknown timestamps. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require scope and timestamps, then confirm the hypothesis separately. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/16-02-alert-correlation/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Scoped alerts → time-window grouping → hypothesis → diagnostic check. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Two alerts occur together. What conclusion is justified? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Correlation is evidence to investigate, not proof of cause. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Two alerts occur together. What conclusion is justified?

Interview: Two alerts occur together. What conclusion is justified? Explain the decision, a failing case and a production limitation.

Quiz: Two alerts occur together. What conclusion is justified?

The first alert certainly caused the second.

Restart every related service.

They form a hypothesis for investigation; confirm cause with further evidence.

Reference: They form a hypothesis for investigation; confirm cause with further evidence. — They form a hypothesis for investigation; confirm cause with further evidence. Clock skew, missing telemetry and shared dependencies can break simple correlation. Record uncertainty and counterevidence; distinguish a suspected cause from a demonstrated one.

Sources:

OpenTelemetry: GenAI semantic conventions: https://opentelemetry.io/docs/specs/semconv/gen-ai/

Kubernetes: startup, liveness and readiness probes: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/

### GitOps remediation: propose a PR, never direct mutation

A remediation agent can collect evidence and draft a change for review. Keep its execution authority narrower than its reasoning ability. A pull request still needs an approved repository, scope and safe content; it is not automatically harmless.

The fixture permits named scoped diagnostics and a GitOps remediation PR only for an authenticated caller with the matching permission. It explicitly refuses direct destructive tools, unknown operations and exhausted attempt budgets.

The model cannot supply its own trusted principal or approval. Native integration needs server-owned authorization, human review, branch protections and deployment checks; this fixture does not open a PR or mutate a cluster.

Mental model: Alert → scoped diagnosis → proposed Git change → authorized human/controller review. Picture the boundary as a checked gate between stages.

Boundary: The model cannot supply its own trusted principal or approval. Native integration needs server-owned authorization, human review, branch protections and deployment checks; this fixture does not open a PR or mutate a cluster.

Worked example: function authorizeSreAgentAction(a) {
  if(!a || a.authenticated!==true || !Number.isSafeInteger(a.attemptsRemaining) || a.attemptsRemaining<1 || typeof a.namespace!=='string' || !Array.isArray(a.allowedNamespaces) || !a.allowedNamespaces.includes(a.namespace) || !Array.isArray(a.permissions)) return false;
  if(['get_pod_logs','query_prometheus'].includes(a.tool)) return a.permissions.includes('diagnose');
  return a.tool==='create_gitops_remediation_pr' && a.permissions.includes('propose') && a.repositoryApproved===true;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract aiops-sre-agents.zip, install Node.js LTS, then open production-ai/16-03-gitops-agent-boundary.

Tools for this exercise: JavaScript · local isolated workbench; MCP / Kubernetes RBAC / Prometheus, GitOps PR workflow / Chaos Mesh as documented optional extensions

Course tool and framework map: MCP / Kubernetes RBAC / Prometheus (Open protocols and projects); GitOps PR workflow / Chaos Mesh (Open source tooling · repository hosting terms vary)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

Implement authorizeSreAgentAction and add wrong-namespace, missing-permission and unapproved-repository cases. Draft a remediation PR template with evidence and rollback criteria.

Terminal folder: production-ai/16-03-gitops-agent-boundary

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture permits named scoped diagnostics and a GitOps remediation PR only for an authenticated caller with the matching permission. It explicitly refuses direct destructive tools, unknown operations and exhausted attempt budgets.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement authorizeSreAgentAction and add wrong-namespace, missing-permission and unapproved-repository cases. Draft a remediation PR template with evidence and rollback criteria.

Expected: Allow scoped diagnosis and proposal

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny direct mutations regardless of permissions; Enforce identity and attempt budget

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Collect scoped startup and incident evidence

Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE logs YOUR_POD --tail=100
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record startup versus liveness/readiness observations, relevant timestamps and a reviewed PR proposal. Stop before any mutation not explicitly authorized for the experiment.

Expected: Allow scoped diagnosis and proposal; Deny direct mutations regardless of permissions; Enforce identity and attempt budget. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Allow diagnostics and bounded PR proposals; deny direct destructive mutation. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/16-03-gitops-agent-boundary/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Alert → scoped diagnosis → proposed Git change → authorized human/controller review. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. What should an SRE agent do when it suspects a configuration repair? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Generated remediation text cannot expand cluster privileges. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: What should an SRE agent do when it suspects a configuration repair?

Interview: What should an SRE agent do when it suspects a configuration repair? Explain the decision, a failing case and a production limitation.

Quiz: What should an SRE agent do when it suspects a configuration repair?

Apply any generated kubectl command directly.

Gather scoped evidence and propose an authorized GitOps PR for review.

Give itself admin privileges.

Reference: Gather scoped evidence and propose an authorized GitOps PR for review. — Gather scoped evidence and propose an authorized GitOps PR for review. The model cannot supply its own trusted principal or approval. Native integration needs server-owned authorization, human review, branch protections and deployment checks; this fixture does not open a PR or mutate a cluster.

Sources:

Kubernetes: RBAC good practices: https://kubernetes.io/docs/concepts/security/rbac-good-practices/

Argo CD: automated sync policy: https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/

MCP: typed tools and user interaction: https://modelcontextprotocol.io/specification/2026-07-28/server/tools

### Chaos rehearsals for GPU & vector infrastructure

Rehearse a failure only in an explicitly authorized environment with synthetic data, a known target and a stop condition. Model warmup is not automatically a hung process. Startup probes, readiness and liveness have distinct purposes.

The fixture authorizes a declared learning experiment only in the exact approved namespace, with an owner, a bounded duration of at most 300 seconds and a ready rollback. Production targets and unbounded durations are denied.

This policy does not execute chaos or prove recovery. A native rehearsal must verify actual abort behavior, backups, permissions, user-impact limits and any GPU model-load delay.

Mental model: Approved experiment plan → scoped failure → observed impact → stop and restore. Picture the boundary as a checked gate between stages.

Boundary: This policy does not execute chaos or prove recovery. A native rehearsal must verify actual abort behavior, backups, permissions, user-impact limits and any GPU model-load delay.

Worked example: function allowAiChaos(p) {
  return !!p && p.environment==='learning' && p.namespace===p.approvedNamespace && typeof p.namespace==='string' && p.namespace.startsWith('lab-') && typeof p.owner==='string' && p.owner.trim().length>0 && Number.isSafeInteger(p.durationSeconds) && p.durationSeconds>0 && p.durationSeconds<=300 && p.rollbackReady===true;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract aiops-sre-agents.zip, install Node.js LTS, then open production-ai/16-04-bounded-chaos.

Tools for this exercise: JavaScript · local isolated workbench; MCP / Kubernetes RBAC / Prometheus, GitOps PR workflow / Chaos Mesh as documented optional extensions

Course tool and framework map: MCP / Kubernetes RBAC / Prometheus (Open protocols and projects); GitOps PR workflow / Chaos Mesh (Open source tooling · repository hosting terms vary)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

Implement allowAiChaos. Write an experiment card for a GPU worker or vector store, including scope, hypotheses, diagnostic commands, abort criteria, restoration and untested assumptions.

Terminal folder: production-ai/16-04-bounded-chaos

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture authorizes a declared learning experiment only in the exact approved namespace, with an owner, a bounded duration of at most 300 seconds and a ready rollback. Production targets and unbounded durations are denied.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement allowAiChaos. Write an experiment card for a GPU worker or vector store, including scope, hypotheses, diagnostic commands, abort criteria, restoration and untested assumptions.

Expected: Approve bounded lab rehearsal

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny production and excessive duration; Require recovery and exact scope

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Collect scoped startup and incident evidence

Use a read-only authorized identity in your learning namespace and replace placeholders. Logs may contain private information; redact before retaining or sharing. No delete, restart or exec-write command is provided to the agent.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE logs YOUR_POD --tail=100
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record startup versus liveness/readiness observations, relevant timestamps and a reviewed PR proposal. Stop before any mutation not explicitly authorized for the experiment.

Expected: Approve bounded lab rehearsal; Deny production and excessive duration; Require recovery and exact scope. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Use startup-aware signals, fixed attempt/time bounds and an explicit abort. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/16-04-bounded-chaos/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Approved experiment plan → scoped failure → observed impact → stop and restore. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A model needs two minutes to warm up. What prevents a restart loop? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A learning experiment must never infer permission to affect production. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A model needs two minutes to warm up. What prevents a restart loop?

Interview: A model needs two minutes to warm up. What prevents a restart loop? Explain the decision, a failing case and a production limitation.

Quiz: A model needs two minutes to warm up. What prevents a restart loop?

Treat every slow startup as a deadlock.

Disable every health check forever.

Use measured startup probes and bounded, reviewed recovery actions.

Reference: Use measured startup probes and bounded, reviewed recovery actions. — Use measured startup probes and bounded, reviewed recovery actions. This policy does not execute chaos or prove recovery. A native rehearsal must verify actual abort behavior, backups, permissions, user-impact limits and any GPU model-load delay.

Sources:

Chaos Mesh: experiment safety and scope: https://github.com/chaos-mesh/website/blob/master/docs/define-chaos-experiment-scope.md

Kubernetes: startup, liveness and readiness probes: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
