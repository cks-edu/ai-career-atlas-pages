# Azure Cloud Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Azure identity and resource scope

Entra ID provides identities; Azure RBAC grants actions at scopes such as resource groups and resources. Authentication does not automatically grant access to an application or database.
Mental model: A badge identifies the person; a scoped key determines which room opens.
Case: A managed identity exists but cannot read a storage container until permissions are granted.
Task: Map a sample web app to App Service, storage/database, identity and Monitor. Draw control-plane and data-plane access separately and list the minimum role required for each proposed action.
Acceptance: A diagram that does not confuse sign-in with authorization.
Troubleshooting: An access failure may involve the data-plane role even when the resource is visible in the portal.
Deliverable: Azure identity and scope worksheet

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Private connectivity and diagnostics

A private endpoint, DNS resolution and application authorization must all agree. Private addressing alone does not prove the intended client can resolve and reach the service.
Mental model: A private driveway still needs a correct address and an unlocked destination door.
Case: An internal client resolves a private address while an external client should not gain unrestricted access.
Task: Create a network design with subnets, name resolution and allowed flows. In an authorized sandbox, test resolution and connection from the intended client; otherwise annotate each check as planned.
Acceptance: A flow table with observable DNS, connection and authorization checks.
Troubleshooting: Inspect DNS and routing before widening firewall rules to solve an unexplained timeout.
Deliverable: network diagram and layered diagnostic runbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Restore and deployment readiness

Deployments need compatible configuration, monitored health and recovery of persistent state. Resource-group organization helps ownership but deletion must be scoped to the disposable lab.
Mental model: The building plan, operating instructions and archive must all survive a renovation.
Case: Restoring an app without its database does not restore the user journey.
Task: Write an App Service and database release sequence, define a synthetic health transaction and rehearse a data restore in a sandbox if available. Include budget, identity and cleanup checks.
Acceptance: A recovery sequence that verifies the full user operation and records unexecuted cloud steps.
Troubleshooting: A successful deployment status is not proof of a healthy application or restored data.
Deliverable: Azure release and recovery pack

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
