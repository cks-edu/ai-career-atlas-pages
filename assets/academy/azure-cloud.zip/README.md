# Azure Cloud Engineer

Software Engineering

Start with azure identity and resource scope. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Azure release and recovery pack.

## beginner

Map a sample web app to App Service, storage/database, identity and Monitor. Draw control-plane and data-plane access separately and list the minimum role required for each proposed action.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Azure identity and resource scope
Entra ID provides identities; Azure RBAC grants actions at scopes such as resource groups and resources. Authentication does not automatically grant access to an application or database.
Mental model: A badge identifies the person; a scoped key determines which room opens.
Limit: An access failure may involve the data-plane role even when the resource is visible in the portal.
Example: A managed identity exists but cannot read a storage container until permissions are granted.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An access failure may involve the data-plane role even when the resource is visible in the portal.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
A managed identity exists but cannot read a storage container until permissions are granted. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Map a sample web app to App Service, storage/database, identity and Monitor. Draw control-plane and data-plane access separately and list the minimum role required for each proposed action.
Expected: A diagram that does not confuse sign-in with authorization.

6. Role workshop · debug and verify
An access failure may involve the data-plane role even when the resource is visible in the portal. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Azure identity and scope worksheet. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A diagram that does not confuse sign-in with authorization.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Azure identity and resource scope: An access failure may involve the data-plane role even when the resource is visible in the portal.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: Azure identity and scope worksheet
A diagram that does not confuse sign-in with authorization.

Interview: Work through this Azure Cloud Engineer case: A managed identity exists but cannot read a storage container until permissions are granted. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Entra ID provides identities; Azure RBAC grants actions at scopes such as resource groups and resources. Authentication does not automatically grant access to an application or database. Expected evidence: A diagram that does not confuse sign-in with authorization. Diagnosis: An access failure may involve the data-plane role even when the resource is visible in the portal. State the limits of the mental model: A badge identifies the person; a scoped key determines which room opens.

Resume: Built Azure identity and scope worksheet using Microsoft Entra ID, Virtual Network, App Service, Azure SQL and Monitor; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a network design with subnets, name resolution and allowed flows. In an authorized sandbox, test resolution and connection from the intended client; otherwise annotate each check as planned.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Private connectivity and diagnostics
A private endpoint, DNS resolution and application authorization must all agree. Private addressing alone does not prove the intended client can resolve and reach the service.
Mental model: A private driveway still needs a correct address and an unlocked destination door.
Limit: Inspect DNS and routing before widening firewall rules to solve an unexplained timeout.
Example: An internal client resolves a private address while an external client should not gain unrestricted access.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Inspect DNS and routing before widening firewall rules to solve an unexplained timeout.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
An internal client resolves a private address while an external client should not gain unrestricted access. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a network design with subnets, name resolution and allowed flows. In an authorized sandbox, test resolution and connection from the intended client; otherwise annotate each check as planned.
Expected: A flow table with observable DNS, connection and authorization checks.

6. Role workshop · debug and verify
Inspect DNS and routing before widening firewall rules to solve an unexplained timeout. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save network diagram and layered diagnostic runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A flow table with observable DNS, connection and authorization checks.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Private connectivity and diagnostics: Inspect DNS and routing before widening firewall rules to solve an unexplained timeout.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: network diagram and layered diagnostic runbook
A flow table with observable DNS, connection and authorization checks.

Interview: Work through this Azure Cloud Engineer case: An internal client resolves a private address while an external client should not gain unrestricted access. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A private endpoint, DNS resolution and application authorization must all agree. Private addressing alone does not prove the intended client can resolve and reach the service. Expected evidence: A flow table with observable DNS, connection and authorization checks. Diagnosis: Inspect DNS and routing before widening firewall rules to solve an unexplained timeout. State the limits of the mental model: A private driveway still needs a correct address and an unlocked destination door.

Resume: Built network diagram and layered diagnostic runbook using Microsoft Entra ID, Virtual Network, App Service, Azure SQL and Monitor; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write an App Service and database release sequence, define a synthetic health transaction and rehearse a data restore in a sandbox if available. Include budget, identity and cleanup checks.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Restore and deployment readiness
Deployments need compatible configuration, monitored health and recovery of persistent state. Resource-group organization helps ownership but deletion must be scoped to the disposable lab.
Mental model: The building plan, operating instructions and archive must all survive a renovation.
Limit: A successful deployment status is not proof of a healthy application or restored data.
Example: Restoring an app without its database does not restore the user journey.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful deployment status is not proof of a healthy application or restored data.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
Restoring an app without its database does not restore the user journey. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write an App Service and database release sequence, define a synthetic health transaction and rehearse a data restore in a sandbox if available. Include budget, identity and cleanup checks.
Expected: A recovery sequence that verifies the full user operation and records unexecuted cloud steps.

6. Role workshop · debug and verify
A successful deployment status is not proof of a healthy application or restored data. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Azure release and recovery pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A recovery sequence that verifies the full user operation and records unexecuted cloud steps.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Restore and deployment readiness: A successful deployment status is not proof of a healthy application or restored data.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: Azure release and recovery pack
A recovery sequence that verifies the full user operation and records unexecuted cloud steps.

Interview: Work through this Azure Cloud Engineer case: Restoring an app without its database does not restore the user journey. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Deployments need compatible configuration, monitored health and recovery of persistent state. Resource-group organization helps ownership but deletion must be scoped to the disposable lab. Expected evidence: A recovery sequence that verifies the full user operation and records unexecuted cloud steps. Diagnosis: A successful deployment status is not proof of a healthy application or restored data. State the limits of the mental model: The building plan, operating instructions and archive must all survive a renovation.

Resume: Built Azure release and recovery pack using Microsoft Entra ID, Virtual Network, App Service, Azure SQL and Monitor; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
Google SRE book: https://sre.google/sre-book/table-of-contents/
