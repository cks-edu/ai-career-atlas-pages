# Performance Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Latency distributions

Latency is a distribution measured under stated conditions. A mean can hide slow users; throughput and concurrency must be reported with response-time percentiles.
Mental model: Average queue length does not describe the person who waited an hour.
Case: Samples 10,10,10,10,200 ms have a low median but a long tail.
Task: Time repeated local HTTP requests with a monotonic clock. Save raw durations, compute median and a documented nearest-rank p95, and include warm-up and environment details.
Acceptance: Reproducible raw samples and correctly calculated percentiles.
Troubleshooting: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately.
Deliverable: latency.csv and calculation script

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Controlled load experiments

Increase load in steps while measuring client saturation and server signals. A local load generator can be the bottleneck, so throughput alone does not identify server capacity.
Mental model: A narrow measuring funnel can limit flow before the pipe being tested.
Case: Compare one and five concurrent requests to the loopback service with a fixed total count.
Task: Use a bounded local script or k6 against only your lab. Set duration, maximum concurrency and an abort threshold before running. Record errors, latency and CPU on both sides.
Acceptance: A comparison table with no unbounded stress or external targets.
Troubleshooting: If the generator CPU saturates first, the result is not a server capacity limit.
Deliverable: load plan, raw results and bottleneck hypothesis

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
SLO-based performance gates

A performance gate translates a user objective into a reproducible workload and an observation window. Compare like environments and retain variance before calling a change a regression.
Mental model: A race time matters only when the course and starting conditions match.
Case: A proposed p95 under 200 ms must specify request mix, payload and concurrency.
Task: Run baseline and changed code with the same seeded workload three times. Calculate variation, inspect traces or profiles for the largest difference and write an accept/reject recommendation.
Acceptance: The decision cites measured deltas and environment limits, not one fast sample.
Troubleshooting: A different dataset or warm cache can invalidate the comparison; rerun controlled cases.
Deliverable: performance budget, regression report and profile evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
