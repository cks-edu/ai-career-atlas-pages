# Performance Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Observable behavior: A test compares a defined observation with an expected result for a chosen input.

Apply observable behavior in Performance Engineer: Use the concept to complete this role exercise: Measure a single request and state the environment

Latency distributions: Latency is a distribution measured under stated conditions. A mean can hide slow users; throughput and concurrency must be reported with response-time percentiles.

### Observable behavior

A test compares a defined observation with an expected result for a chosen input. In this role, work through: Samples 10,10,10,10,200 ms have a low median but a long tail. The practical workshop develops this into: Time repeated local HTTP requests with a monotonic clock. Save raw durations, compute median and a documented nearest-rank p95, and include warm-up and environment details.

Mental model: A recipe with a taste check rather than a photograph of ingredients.

Boundary: Passing examples do not prove every possible input works.

Role application: Average queue length does not describe the person who waited an hour.

Latency is a distribution measured under stated conditions. A mean can hide slow users; throughput and concurrency must be reported with response-time percentiles.

Worked example: Samples 10,10,10,10,200 ms have a low median but a long tail.

Shared foundation example: An empty task must not be added and the error must be understandable.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js timing APIs and browser performance tools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Performance Engineer: Samples 10,10,10,10,200 ms have a low median but a long tail.

Predict the worked case

Read this case without running a tool: Samples 10,10,10,10,200 ms have a low median but a long tail. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in observable behavior.

Connect the concept to the role

Apply this rule: A test compares a defined observation with an expected result for a chosen input. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Passing examples do not prove every possible input works.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies observable behavior to this case: Samples 10,10,10,10,200 ms have a low median but a long tail. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Samples 10,10,10,10,200 ms have a low median but a long tail. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Observable behavior; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with observable behavior. Use the glossary below, then write your prediction for: Samples 10,10,10,10,200 ms have a low median but a long tail. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Performance Engineer role interview. Explain observable behavior using this case: Samples 10,10,10,10,200 ms have a low median but a long tail. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate observable behavior to a system or workflow you know. Explain observable behavior using this case: Samples 10,10,10,10,200 ms have a low median but a long tail. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Write a test case with input, action and expected observation.

Interview: Explain observable behavior using this case: Samples 10,10,10,10,200 ms have a low median but a long tail. State the evidence, one alternative and where the mental model stops.

Quiz: After the Latency distributions rehearsal, check this foundation: A test reports success because the page loaded. The requirement is to reject blank submissions. Which evidence is missing?

The rejection behavior and unchanged stored state for blank input.

Only the browser version string.

The number of CSS files that loaded.

Reference: The rejection behavior and unchanged stored state for blank input. — An observation must match the contract being tested. Page availability alone does not test the invalid-input rule.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Latency distributions

Latency is a distribution measured under stated conditions. A mean can hide slow users; throughput and concurrency must be reported with response-time percentiles. In this role, work through: Samples 10,10,10,10,200 ms have a low median but a long tail. The practical workshop develops this into: Time repeated local HTTP requests with a monotonic clock. Save raw durations, compute median and a documented nearest-rank p95, and include warm-up and environment details.

Mental model: Average queue length does not describe the person who waited an hour.

Boundary: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately.

Worked example: Samples 10,10,10,10,200 ms have a low median but a long tail.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js timing APIs and browser performance tools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Performance Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Time repeated local HTTP requests with a monotonic clock. Save raw durations, compute median and a documented nearest-rank p95, and include warm-up and environment details.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Samples 10,10,10,10,200 ms have a low median but a long tail. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Time repeated local HTTP requests with a monotonic clock. Save raw durations, compute median and a documented nearest-rank p95, and include warm-up and environment details.

Expected: Reproducible raw samples and correctly calculated percentiles.

Role workshop · debug and verify

Mixing failed requests into successful latency silently can distort results; classify status and timeout separately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save latency.csv and calculation script. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Reproducible raw samples and correctly calculated percentiles.

Expected: Reproducible raw samples and correctly calculated percentiles.

Troubleshoot: The role exercise differs from the prediction: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: latency.csv and calculation script; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with latency distributions. Use the glossary below, then write your prediction for: Samples 10,10,10,10,200 ms have a low median but a long tail. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Performance Engineer role interview. Explain latency distributions using this case: Samples 10,10,10,10,200 ms have a low median but a long tail. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate latency distributions to a system or workflow you know. Explain latency distributions using this case: Samples 10,10,10,10,200 ms have a low median but a long tail. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately.

Interview: Explain latency distributions using this case: Samples 10,10,10,10,200 ms have a low median but a long tail. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Samples 10,10,10,10,200 ms have a low median but a long tail.

Reproducible raw samples and correctly calculated percentiles.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Reproducible raw samples and correctly calculated percentiles. — Latency is a distribution measured under stated conditions. A mean can hide slow users; throughput and concurrency must be reported with response-time percentiles. Reproducible raw samples and correctly calculated percentiles.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Test boundaries: Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.

Apply test boundaries in Performance Engineer: Use the concept to complete this role exercise: Measure a distribution under a controlled local workload

Controlled load experiments: Increase load in steps while measuring client saturation and server signals. A local load generator can be the bottleneck, so throughput alone does not identify server capacity.

### Test boundaries

Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow. In this role, work through: Compare one and five concurrent requests to the loopback service with a fixed total count. The practical workshop develops this into: Use a bounded local script or k6 against only your lab. Set duration, maximum concurrency and an abort threshold before running. Record errors, latency and CPU on both sides.

Mental model: Check a component, then an assembled bicycle, then a ride.

Boundary: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.

Role application: A narrow measuring funnel can limit flow before the pipe being tested.

Increase load in steps while measuring client saturation and server signals. A local load generator can be the bottleneck, so throughput alone does not identify server capacity.

Worked example: Compare one and five concurrent requests to the loopback service with a fixed total count.

Shared foundation example: Validate title alone, then HTTP request, then keyboard submission in the browser.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js timing APIs and browser performance tools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Performance Engineer: Compare one and five concurrent requests to the loopback service with a fixed total count.

Predict the worked case

Read this case without running a tool: Compare one and five concurrent requests to the loopback service with a fixed total count. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in test boundaries.

Connect the concept to the role

Apply this rule: Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies test boundaries to this case: Compare one and five concurrent requests to the loopback service with a fixed total count. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Compare one and five concurrent requests to the loopback service with a fixed total count. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Test boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with test boundaries. Use the glossary below, then write your prediction for: Compare one and five concurrent requests to the loopback service with a fixed total count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Performance Engineer role interview. Explain test boundaries using this case: Compare one and five concurrent requests to the loopback service with a fixed total count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate test boundaries to a system or workflow you know. Explain test boundaries using this case: Compare one and five concurrent requests to the loopback service with a fixed total count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which layer should identify whether a failure is parsing or rendering?

Interview: Explain test boundaries using this case: Compare one and five concurrent requests to the loopback service with a fixed total count. State the evidence, one alternative and where the mental model stops.

Quiz: After the Controlled load experiments rehearsal, check this foundation: A function test passes. Which check would examine whether HTTP parsing and the function work together?

Rerun the same isolated function test.

An integration test through the request boundary.

Only inspect a screenshot of the editor.

Reference: An integration test through the request boundary. — Integration tests exercise cooperating parts. They complement rather than replace focused unit checks.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Controlled load experiments

Increase load in steps while measuring client saturation and server signals. A local load generator can be the bottleneck, so throughput alone does not identify server capacity. In this role, work through: Compare one and five concurrent requests to the loopback service with a fixed total count. The practical workshop develops this into: Use a bounded local script or k6 against only your lab. Set duration, maximum concurrency and an abort threshold before running. Record errors, latency and CPU on both sides.

Mental model: A narrow measuring funnel can limit flow before the pipe being tested.

Boundary: If the generator CPU saturates first, the result is not a server capacity limit.

Worked example: Compare one and five concurrent requests to the loopback service with a fixed total count.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js timing APIs and browser performance tools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Performance Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use a bounded local script or k6 against only your lab. Set duration, maximum concurrency and an abort threshold before running. Record errors, latency and CPU on both sides.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Compare one and five concurrent requests to the loopback service with a fixed total count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use a bounded local script or k6 against only your lab. Set duration, maximum concurrency and an abort threshold before running. Record errors, latency and CPU on both sides.

Expected: A comparison table with no unbounded stress or external targets.

Role workshop · debug and verify

If the generator CPU saturates first, the result is not a server capacity limit. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save load plan, raw results and bottleneck hypothesis. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A comparison table with no unbounded stress or external targets.

Expected: A comparison table with no unbounded stress or external targets.

Troubleshoot: The role exercise differs from the prediction: If the generator CPU saturates first, the result is not a server capacity limit.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: load plan, raw results and bottleneck hypothesis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with controlled load experiments. Use the glossary below, then write your prediction for: Compare one and five concurrent requests to the loopback service with a fixed total count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Performance Engineer role interview. Explain controlled load experiments using this case: Compare one and five concurrent requests to the loopback service with a fixed total count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate controlled load experiments to a system or workflow you know. Explain controlled load experiments using this case: Compare one and five concurrent requests to the loopback service with a fixed total count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the generator CPU saturates first, the result is not a server capacity limit.

Interview: Explain controlled load experiments using this case: Compare one and five concurrent requests to the loopback service with a fixed total count. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Compare one and five concurrent requests to the loopback service with a fixed total count.

Ignore the failing case and keep only the successful screenshot.

A comparison table with no unbounded stress or external targets.

Treat any successful command as proof that all business and access rules passed.

Reference: A comparison table with no unbounded stress or external targets. — Increase load in steps while measuring client saturation and server signals. A local load generator can be the bottleneck, so throughput alone does not identify server capacity. A comparison table with no unbounded stress or external targets.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Risk-based release: Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.

Apply risk-based release in Performance Engineer: Use the concept to complete this role exercise: Define an SLO-based load experiment with limits, abort conditions and bottleneck evidence

SLO-based performance gates: A performance gate translates a user objective into a reproducible workload and an observation window. Compare like environments and retain variance before calling a change a regression.

### Risk-based release

Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery. In this role, work through: A proposed p95 under 200 ms must specify request mix, payload and concurrency. The practical workshop develops this into: Run baseline and changed code with the same seeded workload three times. Calculate variation, inspect traces or profiles for the largest difference and write an accept/reject recommendation.

Mental model: Inspect brakes before polishing the paint.

Boundary: Risk ranking is judgment informed by users, not an excuse to skip known defects.

Role application: A race time matters only when the course and starting conditions match.

A performance gate translates a user objective into a reproducible workload and an observation window. Compare like environments and retain variance before calling a change a regression.

Worked example: A proposed p95 under 200 ms must specify request mix, payload and concurrency.

Shared foundation example: Test invalid input, double submission, keyboard focus and server restart; record results.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js timing APIs and browser performance tools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Performance Engineer: A proposed p95 under 200 ms must specify request mix, payload and concurrency.

Predict the worked case

Read this case without running a tool: A proposed p95 under 200 ms must specify request mix, payload and concurrency. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in risk-based release.

Connect the concept to the role

Apply this rule: Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Risk ranking is judgment informed by users, not an excuse to skip known defects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies risk-based release to this case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Risk-based release; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with risk-based release. Use the glossary below, then write your prediction for: A proposed p95 under 200 ms must specify request mix, payload and concurrency. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Performance Engineer role interview. Explain risk-based release using this case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate risk-based release to a system or workflow you know. Explain risk-based release using this case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What evidence would make you hold a release despite a high pass count?

Interview: Explain risk-based release using this case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. State the evidence, one alternative and where the mental model stops.

Quiz: After the SLO-based performance gates rehearsal, check this foundation: Happy-path tests pass, but a plausible high-impact failure is untested. What is a defensible next step?

Declare zero release risk because automated checks passed.

Remove the uncertain case from the report.

Assess its impact, test or mitigate it, and record residual risk for the release owner.

Reference: Assess its impact, test or mitigate it, and record residual risk for the release owner. — Risk-based testing prioritizes harmful plausible failures; passing a limited suite is not proof of complete coverage.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### SLO-based performance gates

A performance gate translates a user objective into a reproducible workload and an observation window. Compare like environments and retain variance before calling a change a regression. In this role, work through: A proposed p95 under 200 ms must specify request mix, payload and concurrency. The practical workshop develops this into: Run baseline and changed code with the same seeded workload three times. Calculate variation, inspect traces or profiles for the largest difference and write an accept/reject recommendation.

Mental model: A race time matters only when the course and starting conditions match.

Boundary: A different dataset or warm cache can invalidate the comparison; rerun controlled cases.

Worked example: A proposed p95 under 200 ms must specify request mix, payload and concurrency.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js timing APIs and browser performance tools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Performance Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run baseline and changed code with the same seeded workload three times. Calculate variation, inspect traces or profiles for the largest difference and write an accept/reject recommendation.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

A proposed p95 under 200 ms must specify request mix, payload and concurrency. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run baseline and changed code with the same seeded workload three times. Calculate variation, inspect traces or profiles for the largest difference and write an accept/reject recommendation.

Expected: The decision cites measured deltas and environment limits, not one fast sample.

Role workshop · debug and verify

A different dataset or warm cache can invalidate the comparison; rerun controlled cases. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save performance budget, regression report and profile evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The decision cites measured deltas and environment limits, not one fast sample.

Expected: The decision cites measured deltas and environment limits, not one fast sample.

Troubleshoot: The role exercise differs from the prediction: A different dataset or warm cache can invalidate the comparison; rerun controlled cases.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: performance budget, regression report and profile evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with slo-based performance gates. Use the glossary below, then write your prediction for: A proposed p95 under 200 ms must specify request mix, payload and concurrency. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Performance Engineer role interview. Explain slo-based performance gates using this case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate slo-based performance gates to a system or workflow you know. Explain slo-based performance gates using this case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A different dataset or warm cache can invalidate the comparison; rerun controlled cases.

Interview: Explain slo-based performance gates using this case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A proposed p95 under 200 ms must specify request mix, payload and concurrency.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

The decision cites measured deltas and environment limits, not one fast sample.

Reference: The decision cites measured deltas and environment limits, not one fast sample. — A performance gate translates a user objective into a reproducible workload and an observation window. Compare like environments and retain variance before calling a change a regression. The decision cites measured deltas and environment limits, not one fast sample.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
