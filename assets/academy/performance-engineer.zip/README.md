# Performance Engineer

Software Engineering

Start with latency distributions. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward performance budget, regression report and profile evidence.

## beginner

Time repeated local HTTP requests with a monotonic clock. Save raw durations, compute median and a documented nearest-rank p95, and include warm-up and environment details.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Observable behavior
A test compares a defined observation with an expected result for a chosen input.
Mental model: A recipe with a taste check rather than a photograph of ingredients.
Limit: Passing examples do not prove every possible input works.
Example: An empty task must not be added and the error must be understandable.
Recall: Write a test case with input, action and expected observation.

### Latency distributions
Latency is a distribution measured under stated conditions. A mean can hide slow users; throughput and concurrency must be reported with response-time percentiles.
Mental model: Average queue length does not describe the person who waited an hour.
Limit: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately.
Example: Samples 10,10,10,10,200 ms have a low median but a long tail.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Samples 10,10,10,10,200 ms have a low median but a long tail. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Time repeated local HTTP requests with a monotonic clock. Save raw durations, compute median and a documented nearest-rank p95, and include warm-up and environment details.
Expected: Reproducible raw samples and correctly calculated percentiles.

6. Role workshop · debug and verify
Mixing failed requests into successful latency silently can distort results; classify status and timeout separately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save latency.csv and calculation script. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Reproducible raw samples and correctly calculated percentiles.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Latency distributions: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: latency.csv and calculation script
Reproducible raw samples and correctly calculated percentiles.

Interview: Work through this Performance Engineer case: Samples 10,10,10,10,200 ms have a low median but a long tail. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Latency is a distribution measured under stated conditions. A mean can hide slow users; throughput and concurrency must be reported with response-time percentiles. Expected evidence: Reproducible raw samples and correctly calculated percentiles. Diagnosis: Mixing failed requests into successful latency silently can distort results; classify status and timeout separately. State the limits of the mental model: Average queue length does not describe the person who waited an hour.

Resume: Built latency.csv and calculation script using Node.js timing APIs and browser performance tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Use a bounded local script or k6 against only your lab. Set duration, maximum concurrency and an abort threshold before running. Record errors, latency and CPU on both sides.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Test boundaries
Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.
Mental model: Check a component, then an assembled bicycle, then a ride.
Limit: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.
Example: Validate title alone, then HTTP request, then keyboard submission in the browser.
Recall: Which layer should identify whether a failure is parsing or rendering?

### Controlled load experiments
Increase load in steps while measuring client saturation and server signals. A local load generator can be the bottleneck, so throughput alone does not identify server capacity.
Mental model: A narrow measuring funnel can limit flow before the pipe being tested.
Limit: If the generator CPU saturates first, the result is not a server capacity limit.
Example: Compare one and five concurrent requests to the loopback service with a fixed total count.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the generator CPU saturates first, the result is not a server capacity limit.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Compare one and five concurrent requests to the loopback service with a fixed total count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use a bounded local script or k6 against only your lab. Set duration, maximum concurrency and an abort threshold before running. Record errors, latency and CPU on both sides.
Expected: A comparison table with no unbounded stress or external targets.

6. Role workshop · debug and verify
If the generator CPU saturates first, the result is not a server capacity limit. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save load plan, raw results and bottleneck hypothesis. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A comparison table with no unbounded stress or external targets.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Controlled load experiments: If the generator CPU saturates first, the result is not a server capacity limit.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: load plan, raw results and bottleneck hypothesis
A comparison table with no unbounded stress or external targets.

Interview: Work through this Performance Engineer case: Compare one and five concurrent requests to the loopback service with a fixed total count. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Increase load in steps while measuring client saturation and server signals. A local load generator can be the bottleneck, so throughput alone does not identify server capacity. Expected evidence: A comparison table with no unbounded stress or external targets. Diagnosis: If the generator CPU saturates first, the result is not a server capacity limit. State the limits of the mental model: A narrow measuring funnel can limit flow before the pipe being tested.

Resume: Built load plan, raw results and bottleneck hypothesis using Node.js timing APIs and browser performance tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run baseline and changed code with the same seeded workload three times. Calculate variation, inspect traces or profiles for the largest difference and write an accept/reject recommendation.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Risk-based release
Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.
Mental model: Inspect brakes before polishing the paint.
Limit: Risk ranking is judgment informed by users, not an excuse to skip known defects.
Example: Test invalid input, double submission, keyboard focus and server restart; record results.
Recall: What evidence would make you hold a release despite a high pass count?

### SLO-based performance gates
A performance gate translates a user objective into a reproducible workload and an observation window. Compare like environments and retain variance before calling a change a regression.
Mental model: A race time matters only when the course and starting conditions match.
Limit: A different dataset or warm cache can invalidate the comparison; rerun controlled cases.
Example: A proposed p95 under 200 ms must specify request mix, payload and concurrency.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A different dataset or warm cache can invalidate the comparison; rerun controlled cases.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A proposed p95 under 200 ms must specify request mix, payload and concurrency. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run baseline and changed code with the same seeded workload three times. Calculate variation, inspect traces or profiles for the largest difference and write an accept/reject recommendation.
Expected: The decision cites measured deltas and environment limits, not one fast sample.

6. Role workshop · debug and verify
A different dataset or warm cache can invalidate the comparison; rerun controlled cases. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save performance budget, regression report and profile evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The decision cites measured deltas and environment limits, not one fast sample.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
SLO-based performance gates: A different dataset or warm cache can invalidate the comparison; rerun controlled cases.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: performance budget, regression report and profile evidence
The decision cites measured deltas and environment limits, not one fast sample.

Interview: Work through this Performance Engineer case: A proposed p95 under 200 ms must specify request mix, payload and concurrency. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A performance gate translates a user objective into a reproducible workload and an observation window. Compare like environments and retain variance before calling a change a regression. Expected evidence: The decision cites measured deltas and environment limits, not one fast sample. Diagnosis: A different dataset or warm cache can invalidate the comparison; rerun controlled cases. State the limits of the mental model: A race time matters only when the course and starting conditions match.

Resume: Built performance budget, regression report and profile evidence using Node.js timing APIs and browser performance tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Google SRE book: https://sre.google/sre-book/table-of-contents/
Playwright: installation and first tests: https://playwright.dev/docs/intro
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
