# Go Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Boundaries and ownership: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.

Apply boundaries and ownership in Go Developer: Use the concept to complete this role exercise: Run the official Go hello-world example and define a typed ticket

Errors as return values: Go functions return errors explicitly so callers can choose how to recover. Validate domain values independently of HTTP and write table-driven tests for the rule.

### Boundaries and ownership

A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. In this role, work through: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. The practical workshop develops this into: In a fresh Go module create ticket.go with Normalize(string) (string,error). Add ticket_test.go with normal, blank and oversized inputs, run go test ./..., and assert the returned value as well as error presence.

Mental model: Departments own different ledgers and exchange agreed forms.

Boundary: Drawing more boxes does not make a system more reliable.

Role application: Each worker returns both the parcel and a delivery-status slip.

Go functions return errors explicitly so callers can choose how to recover. Validate domain values independently of HTTP and write table-driven tests for the rule.

Worked example: Normalize(" A ") returns A,nil; Normalize(" ") returns an error.

Shared foundation example: The order service owns orders; a notification consumer handles messages.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Go toolchain (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Go Developer: Normalize(" A ") returns A,nil; Normalize(" ") returns an error.

Predict the worked case

Read this case without running a tool: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in boundaries and ownership.

Connect the concept to the role

Apply this rule: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Drawing more boxes does not make a system more reliable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies boundaries and ownership to this case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Boundaries and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with boundaries and ownership. Use the glossary below, then write your prediction for: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Go Developer role interview. Explain boundaries and ownership using this case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate boundaries and ownership to a system or workflow you know. Explain boundaries and ownership using this case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which component owns the truth about whether an order exists?

Interview: Explain boundaries and ownership using this case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. State the evidence, one alternative and where the mental model stops.

Quiz: After the Errors as return values rehearsal, check this foundation: Two services both write one business record using incompatible rules. What should be clarified first?

The owning service and the contract through which others request changes.

Which service can issue writes faster.

Whether both services can share unrestricted credentials.

Reference: The owning service and the contract through which others request changes. — Ownership defines responsibility for invariants. Sharing write access does not resolve conflicting business rules.

Sources:

Go: add a test: https://go.dev/doc/tutorial/add-a-test

Go: first program: https://go.dev/doc/tutorial/getting-started

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Errors as return values

Go functions return errors explicitly so callers can choose how to recover. Validate domain values independently of HTTP and write table-driven tests for the rule. In this role, work through: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. The practical workshop develops this into: In a fresh Go module create ticket.go with Normalize(string) (string,error). Add ticket_test.go with normal, blank and oversized inputs, run go test ./..., and assert the returned value as well as error presence.

Mental model: Each worker returns both the parcel and a delivery-status slip.

Boundary: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter.

Worked example: Normalize(" A ") returns A,nil; Normalize(" ") returns an error.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Go toolchain (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Go Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

In a fresh Go module create ticket.go with Normalize(string) (string,error). Add ticket_test.go with normal, blank and oversized inputs, run go test ./..., and assert the returned value as well as error presence.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

In a fresh Go module create ticket.go with Normalize(string) (string,error). Add ticket_test.go with normal, blank and oversized inputs, run go test ./..., and assert the returned value as well as error presence.

```
go mod init example.com/atlas-tickets
go test ./...
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: All table rows pass; errors do not silently become empty valid titles.

Role workshop · debug and verify

If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Go module with table-driven tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: All table rows pass; errors do not silently become empty valid titles.

Expected: All table rows pass; errors do not silently become empty valid titles.

Troubleshoot: The role exercise differs from the prediction: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: Go module with table-driven tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with errors as return values. Use the glossary below, then write your prediction for: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Go Developer role interview. Explain errors as return values using this case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate errors as return values to a system or workflow you know. Explain errors as return values using this case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter.

Interview: Explain errors as return values using this case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Normalize(" A ") returns A,nil; Normalize(" ") returns an error.

All table rows pass; errors do not silently become empty valid titles.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: All table rows pass; errors do not silently become empty valid titles. — Go functions return errors explicitly so callers can choose how to recover. Validate domain values independently of HTTP and write table-driven tests for the rule. All table rows pass; errors do not silently become empty valid titles.

Sources:

Go: add a test: https://go.dev/doc/tutorial/add-a-test

Go: first program: https://go.dev/doc/tutorial/getting-started

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Transactional outbox: Write business data and the event to publish in one local transaction, then deliver the event separately.

Apply transactional outbox in Go Developer: Use the concept to complete this role exercise: Write a handler with context timeout and a table-driven test

Context deadlines: A context carries cancellation across a request tree. Call the returned cancel function and pass the context into downstream operations rather than starting unbounded background work.

### Transactional outbox

Write business data and the event to publish in one local transaction, then deliver the event separately. In this role, work through: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. The practical workshop develops this into: Write a test with httptest.NewServer, context.WithTimeout and http.NewRequestWithContext. Close the test server and response body where present. Verify the timeout error and a separate fast response.

Mental model: Record a sale and its mailing slip in the same ledger before dispatch.

Boundary: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Role application: A deadline follows the parcel through every processing station.

A context carries cancellation across a request tree. Call the returned cancel function and pass the context into downstream operations rather than starting unbounded background work.

Worked example: A local httptest server delays 200 ms; a 20 ms client context should terminate the request.

Shared foundation example: The reference stores order-1 and its pending event together.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Go toolchain (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Go Developer: A local httptest server delays 200 ms; a 20 ms client context should terminate the request.

Predict the worked case

Read this case without running a tool: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transactional outbox.

Connect the concept to the role

Apply this rule: Write business data and the event to publish in one local transaction, then deliver the event separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transactional outbox to this case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Transactional outbox; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactional outbox. Use the glossary below, then write your prediction for: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Go Developer role interview. Explain transactional outbox using this case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactional outbox to a system or workflow you know. Explain transactional outbox using this case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why can publishing first lose consistency if the database write fails?

Interview: Explain transactional outbox using this case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. State the evidence, one alternative and where the mental model stops.

Quiz: After the Context deadlines rehearsal, check this foundation: Business data commits but publishing its event fails. Which design closes this local write/publish gap?

Publish first, then hope the business write succeeds.

Commit the data and pending outbox entry in one local transaction.

Use a longer broker timeout without recording pending work.

Reference: Commit the data and pending outbox entry in one local transaction. — The outbox preserves a durable publication intent. Delivery can still repeat, so consumers need suitable deduplication.

Sources:

Go: add a test: https://go.dev/doc/tutorial/add-a-test

Go: first program: https://go.dev/doc/tutorial/getting-started

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Context deadlines

A context carries cancellation across a request tree. Call the returned cancel function and pass the context into downstream operations rather than starting unbounded background work. In this role, work through: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. The practical workshop develops this into: Write a test with httptest.NewServer, context.WithTimeout and http.NewRequestWithContext. Close the test server and response body where present. Verify the timeout error and a separate fast response.

Mental model: A deadline follows the parcel through every processing station.

Boundary: Using http.Get without the context leaves your deadline unused. Inspect the request construction.

Worked example: A local httptest server delays 200 ms; a 20 ms client context should terminate the request.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Go toolchain (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Go Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a test with httptest.NewServer, context.WithTimeout and http.NewRequestWithContext. Close the test server and response body where present. Verify the timeout error and a separate fast response.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a test with httptest.NewServer, context.WithTimeout and http.NewRequestWithContext. Close the test server and response body where present. Verify the timeout error and a separate fast response.

```
go test ./...
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

Role workshop · debug and verify

Using http.Get without the context leaves your deadline unused. Inspect the request construction. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save deadline_test.go and resource cleanup notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

Expected: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

Troubleshoot: The role exercise differs from the prediction: Using http.Get without the context leaves your deadline unused. Inspect the request construction.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: deadline_test.go and resource cleanup notes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with context deadlines. Use the glossary below, then write your prediction for: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Go Developer role interview. Explain context deadlines using this case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate context deadlines to a system or workflow you know. Explain context deadlines using this case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Using http.Get without the context leaves your deadline unused. Inspect the request construction.

Interview: Explain context deadlines using this case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A local httptest server delays 200 ms; a 20 ms client context should terminate the request.

Ignore the failing case and keep only the successful screenshot.

Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

Treat any successful command as proof that all business and access rules passed.

Reference: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required. — A context carries cancellation across a request tree. Call the returned cancel function and pass the context into downstream operations rather than starting unbounded background work. Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

Sources:

Go: add a test: https://go.dev/doc/tutorial/add-a-test

Go: first program: https://go.dev/doc/tutorial/getting-started

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Failure semantics: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.

Apply failure semantics in Go Developer: Use the concept to complete this role exercise: Design graceful shutdown and bounded worker concurrency

Bounded worker concurrency: Goroutines are cheap but not unlimited. Bound concurrency, stop accepting work during shutdown and decide what happens to queued versus running tasks.

### Failure semantics

Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. In this role, work through: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. The practical workshop develops this into: Implement a channel-based queue with two workers, track maximum active jobs using synchronization and wait with sync.WaitGroup. Add cancellation and run go test -race ./... on a supported environment.

Mental model: Track a parcel even when the receipt acknowledgment is lost.

Boundary: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Role application: A workshop has a fixed number of benches and a waiting area.

Goroutines are cheap but not unlimited. Bound concurrency, stop accepting work during shutdown and decide what happens to queued versus running tasks.

Worked example: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success.

Shared foundation example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Go toolchain (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Go Developer: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success.

Predict the worked case

Read this case without running a tool: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure semantics.

Connect the concept to the role

Apply this rule: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure semantics to this case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Failure semantics; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure semantics. Use the glossary below, then write your prediction for: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Go Developer role interview. Explain failure semantics using this case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure semantics to a system or workflow you know. Explain failure semantics using this case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you recover a permanently failing event without blocking all orders?

Interview: Explain failure semantics using this case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. State the evidence, one alternative and where the mental model stops.

Quiz: After the Bounded worker concurrency rehearsal, check this foundation: A consumer commits its effect and crashes before acknowledging. What must the design handle?

The broker can infer the effect and guarantee no replay.

The effect must be automatically rolled back by the broker.

The message can be delivered again after the effect already happened.

Reference: The message can be delivered again after the effect already happened. — Acknowledgment and the business effect are separate boundaries. Model the crash window and make replay safe.

Sources:

Go: add a test: https://go.dev/doc/tutorial/add-a-test

Go: first program: https://go.dev/doc/tutorial/getting-started

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Bounded worker concurrency

Goroutines are cheap but not unlimited. Bound concurrency, stop accepting work during shutdown and decide what happens to queued versus running tasks. In this role, work through: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. The practical workshop develops this into: Implement a channel-based queue with two workers, track maximum active jobs using synchronization and wait with sync.WaitGroup. Add cancellation and run go test -race ./... on a supported environment.

Mental model: A workshop has a fixed number of benches and a waiting area.

Boundary: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it.

Worked example: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Go toolchain (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Go Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Implement a channel-based queue with two workers, track maximum active jobs using synchronization and wait with sync.WaitGroup. Add cancellation and run go test -race ./... on a supported environment.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Implement a channel-based queue with two workers, track maximum active jobs using synchronization and wait with sync.WaitGroup. Add cancellation and run go test -race ./... on a supported environment.

```
go test -race ./...
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Maximum concurrency at most two; every submitted job has one terminal outcome.

Role workshop · debug and verify

A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save worker-pool source, race-test log and shutdown contract. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Maximum concurrency at most two; every submitted job has one terminal outcome.

Expected: Maximum concurrency at most two; every submitted job has one terminal outcome.

Troubleshoot: The role exercise differs from the prediction: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: worker-pool source, race-test log and shutdown contract; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with bounded worker concurrency. Use the glossary below, then write your prediction for: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Go Developer role interview. Explain bounded worker concurrency using this case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate bounded worker concurrency to a system or workflow you know. Explain bounded worker concurrency using this case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it.

Interview: Explain bounded worker concurrency using this case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Five jobs with two workers never exceed two active jobs; canceled jobs do not report success.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Maximum concurrency at most two; every submitted job has one terminal outcome.

Reference: Maximum concurrency at most two; every submitted job has one terminal outcome. — Goroutines are cheap but not unlimited. Bound concurrency, stop accepting work during shutdown and decide what happens to queued versus running tasks. Maximum concurrency at most two; every submitted job has one terminal outcome.

Sources:

Go: add a test: https://go.dev/doc/tutorial/add-a-test

Go: first program: https://go.dev/doc/tutorial/getting-started

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
