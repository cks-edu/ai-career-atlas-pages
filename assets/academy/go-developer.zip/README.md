# Go Developer

Software Engineering

Start with errors as return values. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward worker-pool source, race-test log and shutdown contract.

## beginner

In a fresh Go module create ticket.go with Normalize(string) (string,error). Add ticket_test.go with normal, blank and oversized inputs, run go test ./..., and assert the returned value as well as error presence.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Boundaries and ownership
A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: Drawing more boxes does not make a system more reliable.
Example: The order service owns orders; a notification consumer handles messages.
Recall: Which component owns the truth about whether an order exists?

### Errors as return values
Go functions return errors explicitly so callers can choose how to recover. Validate domain values independently of HTTP and write table-driven tests for the rule.
Mental model: Each worker returns both the parcel and a delivery-status slip.
Limit: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter.
Example: Normalize(" A ") returns A,nil; Normalize(" ") returns an error.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
In a fresh Go module create ticket.go with Normalize(string) (string,error). Add ticket_test.go with normal, blank and oversized inputs, run go test ./..., and assert the returned value as well as error presence.
```
go mod init example.com/atlas-tickets
go test ./...
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: All table rows pass; errors do not silently become empty valid titles.

6. Role workshop · debug and verify
If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Go module with table-driven tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: All table rows pass; errors do not silently become empty valid titles.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Errors as return values: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Go module with table-driven tests
All table rows pass; errors do not silently become empty valid titles.

Interview: Work through this Go Developer case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Go functions return errors explicitly so callers can choose how to recover. Validate domain values independently of HTTP and write table-driven tests for the rule. Expected evidence: All table rows pass; errors do not silently become empty valid titles. Diagnosis: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter. State the limits of the mental model: Each worker returns both the parcel and a delivery-status slip.

Resume: Built Go module with table-driven tests using Go toolchain; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Write a test with httptest.NewServer, context.WithTimeout and http.NewRequestWithContext. Close the test server and response body where present. Verify the timeout error and a separate fast response.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transactional outbox
Write business data and the event to publish in one local transaction, then deliver the event separately.
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.
Example: The reference stores order-1 and its pending event together.
Recall: Why can publishing first lose consistency if the database write fails?

### Context deadlines
A context carries cancellation across a request tree. Call the returned cancel function and pass the context into downstream operations rather than starting unbounded background work.
Mental model: A deadline follows the parcel through every processing station.
Limit: Using http.Get without the context leaves your deadline unused. Inspect the request construction.
Example: A local httptest server delays 200 ms; a 20 ms client context should terminate the request.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Using http.Get without the context leaves your deadline unused. Inspect the request construction.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a test with httptest.NewServer, context.WithTimeout and http.NewRequestWithContext. Close the test server and response body where present. Verify the timeout error and a separate fast response.
```
go test ./...
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

6. Role workshop · debug and verify
Using http.Get without the context leaves your deadline unused. Inspect the request construction. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save deadline_test.go and resource cleanup notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Context deadlines: Using http.Get without the context leaves your deadline unused. Inspect the request construction.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: deadline_test.go and resource cleanup notes
Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.

Interview: Work through this Go Developer case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A context carries cancellation across a request tree. Call the returned cancel function and pass the context into downstream operations rather than starting unbounded background work. Expected evidence: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required. Diagnosis: Using http.Get without the context leaves your deadline unused. Inspect the request construction. State the limits of the mental model: A deadline follows the parcel through every processing station.

Resume: Built deadline_test.go and resource cleanup notes using Go toolchain; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Implement a channel-based queue with two workers, track maximum active jobs using synchronization and wait with sync.WaitGroup. Add cancellation and run go test -race ./... on a supported environment.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Failure semantics
Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.
Recall: How would you recover a permanently failing event without blocking all orders?

### Bounded worker concurrency
Goroutines are cheap but not unlimited. Bound concurrency, stop accepting work during shutdown and decide what happens to queued versus running tasks.
Mental model: A workshop has a fixed number of benches and a waiting area.
Limit: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it.
Example: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Implement a channel-based queue with two workers, track maximum active jobs using synchronization and wait with sync.WaitGroup. Add cancellation and run go test -race ./... on a supported environment.
```
go test -race ./...
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Maximum concurrency at most two; every submitted job has one terminal outcome.

6. Role workshop · debug and verify
A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save worker-pool source, race-test log and shutdown contract. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Maximum concurrency at most two; every submitted job has one terminal outcome.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Bounded worker concurrency: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: worker-pool source, race-test log and shutdown contract
Maximum concurrency at most two; every submitted job has one terminal outcome.

Interview: Work through this Go Developer case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Goroutines are cheap but not unlimited. Bound concurrency, stop accepting work during shutdown and decide what happens to queued versus running tasks. Expected evidence: Maximum concurrency at most two; every submitted job has one terminal outcome. Diagnosis: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it. State the limits of the mental model: A workshop has a fixed number of benches and a waiting area.

Resume: Built worker-pool source, race-test log and shutdown contract using Go toolchain; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Go: first program: https://go.dev/doc/tutorial/getting-started
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
Go: add a test: https://go.dev/doc/tutorial/add-a-test
