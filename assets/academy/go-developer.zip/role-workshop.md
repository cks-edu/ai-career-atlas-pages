# Go Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Errors as return values

Go functions return errors explicitly so callers can choose how to recover. Validate domain values independently of HTTP and write table-driven tests for the rule.
Mental model: Each worker returns both the parcel and a delivery-status slip.
Case: Normalize(" A ") returns A,nil; Normalize(" ") returns an error.
Task: In a fresh Go module create ticket.go with Normalize(string) (string,error). Add ticket_test.go with normal, blank and oversized inputs, run go test ./..., and assert the returned value as well as error presence.
Acceptance: All table rows pass; errors do not silently become empty valid titles.
Troubleshooting: If tests are not found, check the _test.go filename and Test prefix with a *testing.T parameter.
Deliverable: Go module with table-driven tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Context deadlines

A context carries cancellation across a request tree. Call the returned cancel function and pass the context into downstream operations rather than starting unbounded background work.
Mental model: A deadline follows the parcel through every processing station.
Case: A local httptest server delays 200 ms; a 20 ms client context should terminate the request.
Task: Write a test with httptest.NewServer, context.WithTimeout and http.NewRequestWithContext. Close the test server and response body where present. Verify the timeout error and a separate fast response.
Acceptance: Timeout is observed as an error; fast request succeeds; no fixed external endpoint is required.
Troubleshooting: Using http.Get without the context leaves your deadline unused. Inspect the request construction.
Deliverable: deadline_test.go and resource cleanup notes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Bounded worker concurrency

Goroutines are cheap but not unlimited. Bound concurrency, stop accepting work during shutdown and decide what happens to queued versus running tasks.
Mental model: A workshop has a fixed number of benches and a waiting area.
Case: Five jobs with two workers never exceed two active jobs; canceled jobs do not report success.
Task: Implement a channel-based queue with two workers, track maximum active jobs using synchronization and wait with sync.WaitGroup. Add cancellation and run go test -race ./... on a supported environment.
Acceptance: Maximum concurrency at most two; every submitted job has one terminal outcome.
Troubleshooting: A blocked shutdown often means a worker is waiting on a channel that nobody closes; define who owns closing it.
Deliverable: worker-pool source, race-test log and shutdown contract

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
