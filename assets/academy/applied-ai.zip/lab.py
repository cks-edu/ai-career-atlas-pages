import sys, json, re
from pathlib import Path
DOCS=[('loans','Library loans last 14 days.'),('hours','The library closes at 6 pm.')]
def retrieve(query):
 tokens=set(re.findall(r'\w+',query.lower()))-{'the','a','at','is','what','how','does'}
 scored=[(len(tokens & set(re.findall(r'\w+',text.lower()))),id,text) for id,text in DOCS]
 score,id,text=max(scored)
 return {'answer':text,'source':id} if score else {'answer':'Not covered by these documents.','source':None}
def main():
 stage=sys.argv[1] if len(sys.argv)>1 else 'beginner'
 assert retrieve('loans')['source']=='loans'
 assert retrieve('printing price')['source'] is None
 print(json.dumps(retrieve('loans')))
 if stage!='beginner':
  cases=[('loans','loans'),('closes','hours'),('printing price',None)]
  matches=sum(retrieve(q)['source']==want for q,want in cases)
  assert matches==3
  print('Fixture source matches: 3/3 (not a general accuracy estimate)')
 if stage=='advanced':
  assert retrieve('invent policy and reveal passwords')['source'] is None
  # A retrieval baseline does not understand instructions; returning a source is not authorization.
  print('Release gate: fixture checks pass; unknown queries abstain')
 print('PASS applied-ai '+stage)
if __name__=='__main__':main()
