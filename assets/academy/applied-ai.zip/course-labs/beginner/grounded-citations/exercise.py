sources={'http-1':{'title':'HTTP overview','url':'https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview'}}
def links(ids):
 if any(key not in sources for key in ids): raise ValueError('Unknown source')
 return [sources[key]['url'] for key in dict.fromkeys(ids)]
assert len(links(['http-1','http-1']))==1
try: links(['invented'])
except ValueError: print('PASS: trusted source resolution rejects invented ids')
else: raise AssertionError('Expected unknown-source rejection')
