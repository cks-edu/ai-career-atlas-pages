def route(has_reviewed_evidence):
 if not has_reviewed_evidence:
  return {'mode':'unsure','message':'I cannot verify this from the supplied lesson. Open the source or ask a more specific lesson question.'}
 return {'mode':'lesson','message':'Use the reviewed explanation and its source links.'}
assert route(False)['mode']=='unsure'
assert route(True)['mode']=='lesson'
print(route(False)['message'])
