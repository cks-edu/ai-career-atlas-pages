capacity=4096
instructions=400
history=600
evidence=1200
reserved_output=800
remaining=capacity-instructions-history-evidence-reserved_output
assert remaining==1096
assert remaining>=0
print('Remaining measured-token allowance:',remaining)
