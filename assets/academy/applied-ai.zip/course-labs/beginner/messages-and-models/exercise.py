import json
request={'model':'replace-with-your-installed-model','messages':[{'role':'system','content':'Help explain the supplied lesson. If evidence is missing, say so.'},{'role':'user','content':'What is an HTTP response?'}],'stream':False}
assert request['messages'][0]['role']=='system'
assert request['messages'][1]['role']=='user'
print(json.dumps(request,indent=2))
