# Structured output: parse before using

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.python.org/3/library/json.html
https://docs.ollama.com/api/chat
