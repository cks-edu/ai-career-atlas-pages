import json
def parse(text):
 value=json.loads(text)
 if not isinstance(value,dict) or not isinstance(value.get('answer'),str): raise ValueError('Answer required')
 ids=value.get('source_ids')
 if not isinstance(ids,list) or not all(isinstance(x,str) for x in ids): raise ValueError('Source ids required')
 return value
assert parse('{"answer":"A response carries a status.","source_ids":["http-1"]}')['source_ids']==['http-1']
try: parse('{"answer":42,"source_ids":[]}')
except ValueError: print('PASS: valid shape accepted; numeric answer rejected')
else: raise AssertionError('Expected schema failure')
