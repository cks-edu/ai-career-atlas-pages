# GenAI application engineer — core lessons

Build a bounded lesson assistant. Learn messages, context, output validation, trusted source links and uncertainty; then retrieval, tool authority, evaluation and release safeguards. Authored fallbacks work without model downloads; optional local inference needs device resources.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A lesson assistant with authored fallback, opt-in local generation, source-id validation, uncertainty routes and a held-out evaluation report.
