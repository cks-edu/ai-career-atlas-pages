def publish(supported,high_impact,reviewed):
 return supported and (not high_impact or reviewed)
assert publish(True,False,False)
assert not publish(False,False,True)
assert not publish(True,True,False)
assert publish(True,True,True)
print('PASS: unsupported claims remain blocked even after a review flag')
