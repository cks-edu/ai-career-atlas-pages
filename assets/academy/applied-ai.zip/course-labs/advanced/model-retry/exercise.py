def recovery(kind,attempt):
 if kind=='transport' and attempt<2: return 'retry'
 if kind=='unsupported': return 'unsure-and-lesson-link'
 return 'authored-fallback'
assert recovery('transport',1)=='retry'
assert recovery('transport',2)=='authored-fallback'
assert recovery('unsupported',0)=='unsure-and-lesson-link'
assert recovery('schema',0)=='authored-fallback'
print('PASS: bounded transport retry; no retry pretending missing evidence exists')
