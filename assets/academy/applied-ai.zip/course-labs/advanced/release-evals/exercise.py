def gate(report):
 required=['source_ids_valid','unknowns_admitted','tools_denied','heldout_reviewed']
 return all(report.get(name) is True for name in required)
base={'source_ids_valid':True,'unknowns_admitted':True,'tools_denied':True,'heldout_reviewed':True}
assert gate(base)
assert not gate({**base,'source_ids_valid':False})
assert not gate({'source_ids_valid':True})
print('PASS: critical and missing evidence block promotion')
