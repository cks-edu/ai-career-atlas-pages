requests=6
output_tokens=120
measured_tokens_per_second=20
serial_seconds=requests*output_tokens/measured_tokens_per_second
assert serial_seconds==36
print('Illustrative serial generation seconds:',serial_seconds)
