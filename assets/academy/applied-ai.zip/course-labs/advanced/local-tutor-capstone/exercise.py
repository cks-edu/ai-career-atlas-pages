import json
sources={'http-1':'https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview'}
response={'answer':'An HTTP response includes a status code.','source_ids':['http-1'],'mode':'authored'}
assert isinstance(response['answer'],str)
assert response['source_ids'] and all(key in sources for key in response['source_ids'])
assert response['mode']=='authored'
print(json.dumps(response))
