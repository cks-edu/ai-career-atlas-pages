# Capstone: a bounded local lesson assistant

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.ollama.com/api/chat
https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview
https://genai.owasp.org/llmrisk/llm01-prompt-injection/
