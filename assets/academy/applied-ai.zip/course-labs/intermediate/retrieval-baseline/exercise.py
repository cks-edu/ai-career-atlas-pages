import re
def words(text): return set(re.findall(r'\w+',text.lower()))
docs=[{'id':'http','text':'HTTP response status and headers'},{'id':'css','text':'CSS layout and selectors'}]
def search(query):
 ranked=sorted(docs,key=lambda d:(-len(words(query)&words(d['text'])),d['id']))
 return [d['id'] for d in ranked if words(query)&words(d['text'])]
assert search('response status')==['http']
assert search('photosynthesis')==[]
print('PASS: relevant baseline result and no-match case')
