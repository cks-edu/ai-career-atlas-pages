cases=[{'id':'a','expected':'answer','actual':'answer'},{'id':'b','expected':'unsure','actual':'answer'},{'id':'c','expected':'unsure','actual':'unsure'}]
wrong=[c['id'] for c in cases if c['expected']!=c['actual']]
assert wrong==['b']
assert sum(c['expected']==c['actual'] for c in cases)==2
print('Correct: 2/3; investigate:',wrong)
