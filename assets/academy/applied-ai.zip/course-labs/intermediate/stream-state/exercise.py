import json
chunks=['{"answer":','"A response has a status",','"source_ids":["http"]}']
state={'phase':'streaming','text':''}
for chunk in chunks: state['text']+=chunk
assert state['phase']=='streaming'
value=json.loads(state['text'])
assert isinstance(value['answer'],str)
state['phase']='parsed'
assert state['phase']!='verified'
print('PASS: complete JSON can be parsed without falsely claiming factual verification')
