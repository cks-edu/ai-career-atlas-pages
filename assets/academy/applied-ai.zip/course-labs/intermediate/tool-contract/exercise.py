lessons={'http':'An HTTP response includes a status code.'}
def call(name,args):
 if name!='read_lesson': raise ValueError('Tool not allowed')
 if not isinstance(args,dict) or set(args)!={'id'} or args['id'] not in lessons: raise ValueError('Invalid arguments')
 return lessons[args['id']]
assert 'status' in call('read_lesson',{'id':'http'})
try: call('run_shell',{'command':'anything'})
except ValueError: print('PASS: only the declared read tool can run')
else: raise AssertionError('Unexpected authority')
