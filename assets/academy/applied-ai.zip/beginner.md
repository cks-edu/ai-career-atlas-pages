## beginner — Schema validity and factual validity

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Schema validity and factual validity
A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications.
Mental model: A completed delivery form can still contain the wrong address.
Boundary: A schema checks structure, not truth or authorization.
Worked example: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Invalid extractions reach the queue
A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay.
Recall: Valid tickets proceed; each invalid output is held with its field errors. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Schema validity and factual validity: A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A rule follows a fixed instruction; a language model generates a likely response. Decide what a correct answer looks like before connecting a model.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Copy these fictional messages: “reset password”, “charged twice”, “cannot sign in”, “refund please”, “help”.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

3. Try step 2
Make three labels: account, billing and needs clarification. Label each message and write why.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

4. Try step 3
Write a rule using keywords for each label. Test “charged twice and cannot sign in” and decide how to handle two possible labels.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

5. Explain and check your result
The vague and mixed messages have an explicit review or clarification route; you can explain a limitation of keyword rules. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A table of six messages, expected labels and rule decisions. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Apply this toy-case rule manually: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to GenAI application engineer.
Copy these fictional messages: “reset password”, “charged twice”, “cannot sign in”, “refund please”, “help”.
Make three labels: account, billing and needs clarification. Label each message and write why.
Write a rule using keywords for each label. Test “charged twice and cannot sign in” and decide how to handle two possible labels.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A table of six messages, expected labels and rule decisions. Include beginner-worksheet.md and your completed Validation report and API contract.
Check: The vague and mixed messages have an explicit review or clarification route; you can explain a limitation of keyword rules.

### Interview
Explain your beginner solution for GenAI application engineer. Use this scenario: A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output.
Review: Start with the task and permitted scope. Explain schema validity and factual validity: A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications. Show the input and observed output, then address Put deterministic schema validation before queue publication; repair the review threshold in the local replay. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A table of six messages, expected labels and rule decisions. Include beginner-worksheet.md and your completed Validation report and API contract.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

