# Incident drill and human-review runbook

Project: Auditable support-triage service
Status: blank work product — not completed evidence

## Purpose and audience
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.

## Required content
Add a bounded timeout, one retry only for transient failures, and a persistent review queue. Compare the rule baseline with two prompt versions on the frozen cases; store model digest, prompt hash and evaluator version.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.

## Failure evidence
Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
