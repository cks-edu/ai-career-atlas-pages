# Versioned evaluation CSV with baseline comparison

Project: Auditable support-triage service
Status: blank work product — not completed evidence

## Purpose and audience
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.

## Required content
Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.

## Failure evidence
Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
