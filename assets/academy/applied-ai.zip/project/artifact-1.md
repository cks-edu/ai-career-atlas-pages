# OpenAPI schema and runnable service

Project: Auditable support-triage service
Status: blank work product — not completed evidence

## Purpose and audience
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.

## Required content
Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.

## Failure evidence
Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
