# GenAI application engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Schema validity and factual validity. A rule follows a fixed instruction; a language model generates a likely response. Decide what a correct answer looks like before connecting a model. Then try Sort five support messages. The three levels build toward Auditable support-triage service. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Schema validity and factual validity

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Schema validity and factual validity
A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications.
Mental model: A completed delivery form can still contain the wrong address.
Boundary: A schema checks structure, not truth or authorization.
Worked example: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Invalid extractions reach the queue
A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay.
Recall: Valid tickets proceed; each invalid output is held with its field errors. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Schema validity and factual validity: A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A rule follows a fixed instruction; a language model generates a likely response. Decide what a correct answer looks like before connecting a model.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Copy these fictional messages: “reset password”, “charged twice”, “cannot sign in”, “refund please”, “help”.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

3. Try step 2
Make three labels: account, billing and needs clarification. Label each message and write why.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

4. Try step 3
Write a rule using keywords for each label. Test “charged twice and cannot sign in” and decide how to handle two possible labels.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

5. Explain and check your result
The vague and mixed messages have an explicit review or clarification route; you can explain a limitation of keyword rules. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A table of six messages, expected labels and rule decisions. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Apply this toy-case rule manually: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to GenAI application engineer.
Copy these fictional messages: “reset password”, “charged twice”, “cannot sign in”, “refund please”, “help”.
Make three labels: account, billing and needs clarification. Label each message and write why.
Write a rule using keywords for each label. Test “charged twice and cannot sign in” and decide how to handle two possible labels.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A table of six messages, expected labels and rule decisions. Include beginner-worksheet.md and your completed Validation report and API contract.
Check: The vague and mixed messages have an explicit review or clarification route; you can explain a limitation of keyword rules.

### Interview
Explain your beginner solution for GenAI application engineer. Use this scenario: A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output.
Review: Start with the task and permitted scope. Explain schema validity and factual validity: A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications. Show the input and observed output, then address Put deterministic schema validation before queue publication; repair the review threshold in the local replay. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A table of six messages, expected labels and rule decisions. Include beginner-worksheet.md and your completed Validation report and API contract.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Bounded model requests

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python or TypeScript, HTTP, tests and basic data handling. Learn model behavior before adding complex frameworks.

### Bounded model requests
A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated.
Mental model: A courier has a delivery deadline and a numbered parcel, not unlimited attempts.
Boundary: Retrying does not recover an invalid prompt or guarantee a model will answer.
Worked example: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Auditable support-triage service
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Recall: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. Identify one observation that would contradict your claim.

### Terms
Bounded model requests: A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
F1: The harmonic mean of precision and recall. Macro F1 averages class F1 scores equally; it differs from accuracy.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
p50: The median: about half of measured values are at or below it.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.
Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.
Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.
Deliverables: OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for GenAI application engineer. Use this scenario: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.
Review: Start with the task and permitted scope. Explain bounded model requests: A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated. Show the input and observed output, then address Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Frozen evaluation sets

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Frozen evaluation sets
Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures.
Mental model: Use the same examination paper to compare two practice methods, without teaching to its answers.
Boundary: A small synthetic set cannot establish real customer performance.
Worked example: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Auditable support-triage service
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. Add a bounded timeout, one retry only for transient failures, and a persistent review queue. Compare the rule baseline with two prompt versions on the frozen cases; store model digest, prompt hash and evaluator version.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.
Recall: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. Identify one observation that would contradict your claim.

### Terms
Frozen evaluation sets: Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
F1: The harmonic mean of precision and recall. Macro F1 averages class F1 scores equally; it differs from accuracy.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
p50: The median: about half of measured values are at or below it.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add a bounded timeout, one retry only for transient failures, and a persistent review queue. Compare the rule baseline with two prompt versions on the frozen cases; store model digest, prompt hash and evaluator version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.
Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.
Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Add a bounded timeout, one retry only for transient failures, and a persistent review queue. Compare the rule baseline with two prompt versions on the frozen cases; store model digest, prompt hash and evaluator version.
Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.
Add a second model and use MLflow to track quality, latency and local resource use; avoid claiming cloud cost savings from local timing alone.
Deliverables: OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison; Incident drill and human-review runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A reviewer must reproduce one result and identify which capabilities you implemented. Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

### Interview
Explain your advanced solution for GenAI application engineer. Use this scenario: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.
Review: Start with the task and permitted scope. Explain frozen evaluation sets: Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures. Show the input and observed output, then address Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison; Incident drill and human-review runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Ollama — Open source runtime · model licenses vary
Local generation; choose a model that fits memory and permitted use.
Alternative: llama.cpp (open source) for local inference, or a commercial hosted API; model licenses and memory requirements remain separate.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
FastAPI: https://fastapi.tiangolo.com/tutorial/
Ollama: https://docs.ollama.com/api/generate
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
MLflow: https://mlflow.org/docs/latest/
Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html
