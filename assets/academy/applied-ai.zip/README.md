# Applied AI Engineer

AI Engineering

Begin with retrieval before generation. Run a grounded retrieval baseline and inspect its source. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Run a grounded retrieval baseline and inspect its source

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. This pack is a keyword retrieval baseline; it does not train an ML model or run a language model. Use the linked scikit-learn tutorial for the next model-based experiment.

### Retrieval before generation
Retrieval finds relevant stored material. Generation produces new text and may introduce errors.
Mental model: Find a page in a library before trying to explain it.
Limit: A retrieved page may be irrelevant, stale or malicious; its presence is not proof.
Example: The baseline returns the exact loan-policy passage and a source identifier.
Recall: Why should an answer link to the passage actually used?

### Apply retrieval before generation in Applied AI Engineer
Use the concept to complete this role exercise: Run a grounded retrieval baseline and inspect its source
Mental model: Find a page in a library before trying to explain it.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: The baseline returns the exact loan-policy passage and a source identifier. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 lab.py beginner
```
Expected: The loan question returns a source-backed passage; unknown printing policy abstains. A tiny fixture pass rate is not general accuracy.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Run a grounded retrieval baseline and inspect its source
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: applied-ai-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Run a grounded retrieval baseline and inspect its source? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Retrieval finds relevant stored material. Generation produces new text and may introduce errors. For this role, explicitly address: Run a grounded retrieval baseline and inspect its source.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Add answerable, ambiguous and unknown evaluation cases

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. This pack is a keyword retrieval baseline; it does not train an ML model or run a language model. Use the linked scikit-learn tutorial for the next model-based experiment.

### Evaluation fixtures
A fixture is a known input with an expected behavior. Include answerable and unanswerable cases.
Mental model: A small driving test checks defined maneuvers, not every road.
Limit: A tiny passing set does not establish real-world accuracy.
Example: Check loan question, opening time and unknown printing policy separately.
Recall: Add an ambiguous query and explain what a safe result looks like.

### Apply evaluation fixtures in Applied AI Engineer
Use the concept to complete this role exercise: Add answerable, ambiguous and unknown evaluation cases
Mental model: A small driving test checks defined maneuvers, not every road.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Check loan question, opening time and unknown printing policy separately. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 lab.py intermediate
```
Expected: The loan question returns a source-backed passage; unknown printing policy abstains. A tiny fixture pass rate is not general accuracy.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Add answerable, ambiguous and unknown evaluation cases
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: applied-ai-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Add answerable, ambiguous and unknown evaluation cases? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A fixture is a known input with an expected behavior. Include answerable and unanswerable cases. For this role, explicitly address: Add answerable, ambiguous and unknown evaluation cases.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Design a guarded model adapter with abstention and a release gate

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. This pack is a keyword retrieval baseline; it does not train an ML model or run a language model. Use the linked scikit-learn tutorial for the next model-based experiment.

### Abstention and release gates
When evidence is missing, say so and route to a source or human. Gate a release on measured behavior and known limits.
Mental model: A librarian says the catalog does not contain the answer instead of inventing a book.
Limit: Abstention rules can also reject valid questions; evaluate both errors.
Example: An unknown policy returns no answer. A model adapter must preserve this behavior.
Recall: Which tests would you rerun after changing the model or source collection?

### Apply abstention and release gates in Applied AI Engineer
Use the concept to complete this role exercise: Design a guarded model adapter with abstention and a release gate
Mental model: A librarian says the catalog does not contain the answer instead of inventing a book.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: An unknown policy returns no answer. A model adapter must preserve this behavior. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 lab.py advanced
```
Expected: The loan question returns a source-backed passage; unknown printing policy abstains. A tiny fixture pass rate is not general accuracy.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Design a guarded model adapter with abstention and a release gate
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: applied-ai-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Design a guarded model adapter with abstention and a release gate? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: When evidence is missing, say so and route to a source or human. Gate a release on measured behavior and known limits. For this role, explicitly address: Design a guarded model adapter with abstention and a release gate.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
scikit-learn: getting started: https://scikit-learn.org/stable/getting_started.html
Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
