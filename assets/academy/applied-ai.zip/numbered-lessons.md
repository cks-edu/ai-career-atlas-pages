# GenAI application engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Schema validity and factual validity: A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

### Schema validity and factual validity

A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications. In this role, work through: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A completed delivery form can still contain the wrong address.

Boundary: A schema checks structure, not truth or authorization.

Worked example: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for GenAI application engineer: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected.

Predict the worked case

Read this case without running a tool: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in schema validity and factual validity.

Connect the concept to the role

Apply this rule: A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A schema checks structure, not truth or authorization.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies schema validity and factual validity to this case: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Schema validity and factual validity; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with schema validity and factual validity. Use the glossary below, then write your prediction for: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GenAI application engineer role interview. Explain schema validity and factual validity using this case: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate schema validity and factual validity to a system or workflow you know. Explain schema validity and factual validity using this case: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain schema validity and factual validity using this case: A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected.

A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications. — A generated result must satisfy the application's field rules before it can be used. A valid structure still needs evidence for its contents. Separate parsing failures from incorrect classifications. A schema checks structure, not truth or authorization.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

MLflow: https://mlflow.org/docs/latest/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

### Diagnose: Invalid extractions reach the queue

A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A completed delivery form can still contain the wrong address.

A ticket says charged twice. {queue: billing} fits the allowed queues; {queue: sales} also parses but needs a correctness check. An empty queue must be rejected.

Worked example: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: FastAPI (Open source · local); Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Apply this toy-case rule manually: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A rule follows a fixed instruction; a language model generates a likely response. Decide what a correct answer looks like before connecting a model.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Copy these fictional messages: “reset password”, “charged twice”, “cannot sign in”, “refund please”, “help”.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

Preparation · Try step 2

Make three labels: account, billing and needs clarification. Label each message and write why.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

Preparation · Try step 3

Write a rule using keywords for each label. Test “charged twice and cannot sign in” and decide how to handle two possible labels.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A table of six messages, expected labels and rule decisions.

Preparation · Explain and check your result

The vague and mixed messages have an explicit review or clarification route; you can explain a limitation of keyword rules. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A table of six messages, expected labels and rule decisions. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Apply this toy-case rule manually: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three of five outputs violate the contract; HTTP success alone concealed invalid extraction. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: invalid extractions reach the queue. Use the glossary below, then write your prediction for: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GenAI application engineer role interview. Explain diagnose: invalid extractions reach the queue using this case: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: invalid extractions reach the queue to a system or workflow you know. Explain diagnose: invalid extractions reach the queue using this case: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Valid tickets proceed; each invalid output is held with its field errors. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: invalid extractions reach the queue using this case: Review when schema_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Put deterministic schema validation before queue publication; repair the review threshold in the local replay. State the evidence, one alternative and where the mental model stops.

Quiz: Invalid extractions reach the queue: A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output.

Change the acceptance rule after seeing an inconvenient result.

Put deterministic schema validation before queue publication; repair the review threshold in the local replay.

Omit failed cases and report only the successful demonstrations.

Reference: Put deterministic schema validation before queue publication; repair the review threshold in the local replay. — Put deterministic schema validation before queue publication; repair the review threshold in the local replay. Valid tickets proceed; each invalid output is held with its field errors.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

MLflow: https://mlflow.org/docs/latest/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python or TypeScript, HTTP, tests and basic data handling. Learn model behavior before adding complex frameworks.

Terms:

Bounded model requests: A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

F1: The harmonic mean of precision and recall. Macro F1 averages class F1 scores equally; it differs from accuracy.

p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.

p50: The median: about half of measured values are at or below it.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Bounded model requests

A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated. In this role, work through: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A courier has a delivery deadline and a numbered parcel, not unlimited attempts.

Boundary: Retrying does not recover an invalid prompt or guarantee a model will answer.

Worked example: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python or TypeScript, HTTP, tests and basic data handling. Learn model behavior before adding complex frameworks.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for GenAI application engineer: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue.

Predict the worked case

Read this case without running a tool: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in bounded model requests.

Connect the concept to the role

Apply this rule: A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Retrying does not recover an invalid prompt or guarantee a model will answer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies bounded model requests to this case: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Bounded model requests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with bounded model requests. Use the glossary below, then write your prediction for: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GenAI application engineer role interview. Explain bounded model requests using this case: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate bounded model requests to a system or workflow you know. Explain bounded model requests using this case: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain bounded model requests using this case: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue.

Treat a passing starter as proof of the whole role workflow.

A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated.

Ignore the failure because the tool produced an output.

Reference: A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated. — A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated. Retrying does not recover an invalid prompt or guarantee a model will answer.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

MLflow: https://mlflow.org/docs/latest/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

### Integrate: Auditable support-triage service

Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review. In this role, work through: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A courier has a delivery deadline and a numbered parcel, not unlimited attempts.

If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue.

Worked example: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional)

Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: auditable support-triage service. Use the glossary below, then write your prediction for: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GenAI application engineer role interview. Explain integrate: auditable support-triage service using this case: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: auditable support-triage service to a system or workflow you know. Explain integrate: auditable support-triage service using this case: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. Identify one observation that would contradict your claim.

Interview: Explain integrate: auditable support-triage service using this case: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Auditable support-triage service at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.

Reference: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. — Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

MLflow: https://mlflow.org/docs/latest/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Frozen evaluation sets: Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

F1: The harmonic mean of precision and recall. Macro F1 averages class F1 scores equally; it differs from accuracy.

p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.

p50: The median: about half of measured values are at or below it.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Frozen evaluation sets

Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures. In this role, work through: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Use the same examination paper to compare two practice methods, without teaching to its answers.

Boundary: A small synthetic set cannot establish real customer performance.

Worked example: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for GenAI application engineer: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%.

Predict the worked case

Read this case without running a tool: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in frozen evaluation sets.

Connect the concept to the role

Apply this rule: Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A small synthetic set cannot establish real customer performance.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies frozen evaluation sets to this case: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Frozen evaluation sets; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with frozen evaluation sets. Use the glossary below, then write your prediction for: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GenAI application engineer role interview. Explain frozen evaluation sets using this case: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate frozen evaluation sets to a system or workflow you know. Explain frozen evaluation sets using this case: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain frozen evaluation sets using this case: Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures.

Reference: Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures. — Keep a set of labeled cases unchanged while comparing prompt or model changes. Count invalid, unavailable and abstained responses separately so success is not inflated by dropping failures. A small synthetic set cannot establish real customer performance.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

MLflow: https://mlflow.org/docs/latest/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

### Defend: Auditable support-triage service

Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. Add a bounded timeout, one retry only for transient failures, and a persistent review queue. Compare the rule baseline with two prompt versions on the frozen cases; store model digest, prompt hash and evaluator version. In this role, work through: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: Use the same examination paper to compare two practice methods, without teaching to its answers.

Out of 20 held-out tickets, 15 correct, 2 wrong and 3 held for review gives 75% correct over all requests; review rate is 15%.

Worked example: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional)

Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add a bounded timeout, one retry only for transient failures, and a persistent review queue. Compare the rule baseline with two prompt versions on the frozen cases; store model digest, prompt hash and evaluator version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A reviewer must reproduce one result and identify which capabilities you implemented. Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison; Incident drill and human-review runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: auditable support-triage service. Use the glossary below, then write your prediction for: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the GenAI application engineer role interview. Explain defend: auditable support-triage service using this case: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: auditable support-triage service to a system or workflow you know. Explain defend: auditable support-triage service using this case: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. Identify one observation that would contradict your claim.

Interview: Explain defend: auditable support-triage service using this case: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Auditable support-triage service at this level?

Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created. — Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created. Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

MLflow: https://mlflow.org/docs/latest/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html
