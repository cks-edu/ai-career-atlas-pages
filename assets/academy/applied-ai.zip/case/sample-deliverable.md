# SAMPLE — Validation report and API contract
Role: GenAI application engineer
Case: Invalid extractions reach the queue
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output.

## Evidence table
| Record | schema_errors (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 3 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three of five outputs violate the contract; HTTP success alone concealed invalid extraction.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Put deterministic schema validation before queue publication; repair the review threshold in the local replay.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in genai application engineer.
Before release: Valid tickets proceed; each invalid output is held with its field errors.

## Design choice and trade-off
Validate outputs before side effects; preserve invalid examples for regression tests.
A stricter schema reduces malformed data but may increase manual review; schema validity does not establish factual accuracy.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Support-ticket triage API: Report confusion matrix, refusals and manual-review rate.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
