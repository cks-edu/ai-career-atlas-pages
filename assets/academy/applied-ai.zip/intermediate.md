## intermediate — Bounded model requests

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python or TypeScript, HTTP, tests and basic data handling. Learn model behavior before adding complex frameworks.

### Bounded model requests
A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated.
Mental model: A courier has a delivery deadline and a numbered parcel, not unlimited attempts.
Boundary: Retrying does not recover an invalid prompt or guarantee a model will answer.
Worked example: If a local model is unavailable, return an unavailable or review result. Do not silently label the ticket technical merely because that is the default queue.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Auditable support-triage service
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Recall: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. Identify one observation that would contradict your claim.

### Terms
Bounded model requests: A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
F1: The harmonic mean of precision and recall. Macro F1 averages class F1 scores equally; it differs from accuracy.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
p50: The median: about half of measured values are at or below it.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
A ticket extractor must send any result with one or more schema violations to human review. The demo currently forwards every output. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a triage assistant for a fictional software vendor. Suggest a queue and an explanation, while leaving dispatch under human control.
Author 60 synthetic tickets in cases.csv: 20 billing, 20 access and 20 technical. Include empty text, mixed intent and instructions embedded in a ticket. Freeze 20 cases before editing prompts; record expected queue and review reason.
Run the supplied FastAPI endpoint and its tests. Extend the Request schema with ticket_id and allowed queue values; keep max input length and return a request identifier. Save a successful request and the 422 response for missing text.
Install Ollama from its official site, pull a model whose license and memory needs fit your machine, and set OLLAMA_MODEL. Run model_probe.py to make a real local generation call. Replace the baseline response with schema-validated queue suggestions; put unparsable answers into manual review.
Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute.
Deliverables: OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for GenAI application engineer. Use this scenario: Stop Ollama during ten requests. Demonstrate bounded waiting, explicit unavailable status and no automatic dispatch; replay one request twice and show that only one review item is created.
Review: Start with the task and permitted scope. Explain bounded model requests: A request needs an input limit, deadline and explicit fallback. Retry only a classified transient failure and preserve the same request identity when downstream work could be repeated. Show the input and observed output, then address Report macro F1, invalid output rate, review rate and p50/p95 latency separately. Count failed requests in the denominator. Manually inspect every high-confidence misroute. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [OpenAPI schema and runnable service; Versioned evaluation CSV with baseline comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

