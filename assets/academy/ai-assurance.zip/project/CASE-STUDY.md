# Independent model validation dossier

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Act as an independent reviewer of a model’s intended use, evidence and limitations.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Receive a new model artifact with the same display name but different hash. Detect the mismatch and suspend the previous validation conclusion until change impact is assessed.

## Limitations and next iteration
Add a periodic review trigger based on data, model and intended-use changes.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
