# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Independent validation plan and scripts.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
