# Validation opinion with scope and limitations

Project: Independent model validation dossier
Status: blank work product — not completed evidence

## Purpose and audience
Act as an independent reviewer of a model’s intended use, evidence and limitations.

## Required content
Write a challenge memo separating verified claims, unverified claims and unacceptable gaps. Require evidence for each remediation before closing a finding.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use.

## Failure evidence
Receive a new model artifact with the same display name but different hash. Detect the mismatch and suspend the previous validation conclusion until change impact is assessed.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
