## intermediate — Challenger tests

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Statistical evaluation and independent review; regulated domains may require substantial domain qualifications.

### Challenger tests
Use alternative baselines, negative controls and subgroup tests to probe a reported result. Preserve discrepancies and investigate before averaging them away.
Mental model: Try another measuring tape when a dimension looks surprising.
Boundary: A failed negative control identifies a problem but may not identify its root cause.
Worked example: Shuffle labels in a test copy; unexpectedly high performance suggests leakage or a faulty evaluation rather than a breakthrough.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Independent model validation dossier
Act as an independent reviewer of a model’s intended use, evidence and limitations. Run independent stress tests on missing features, shifted distributions and relevant slices. Maintain a findings register with severity, evidence, owner and closure criteria.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Use the included model baseline as the system under review. Write an intended-use statement and obtain the training/evaluation manifest before inspecting headline metrics.
Recall: Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use. Identify one observation that would contradict your claim.

### Terms
Challenger tests: Use alternative baselines, negative controls and subgroup tests to probe a reported result. Preserve discrepancies and investigate before averaging them away.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Act as an independent reviewer of a model’s intended use, evidence and limitations. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use the included model baseline as the system under review. Write an intended-use statement and obtain the training/evaluation manifest before inspecting headline metrics.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Reproduce the baseline in a clean environment. Audit data provenance, split design, preprocessing and whether claimed metrics match the intended use.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run independent stress tests on missing features, shifted distributions and relevant slices. Maintain a findings register with severity, evidence, owner and closure criteria.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The independent review protocol requires zero unreviewed material claims in the release evidence pack. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Act as an independent reviewer of a model’s intended use, evidence and limitations.
Use the included model baseline as the system under review. Write an intended-use statement and obtain the training/evaluation manifest before inspecting headline metrics.
Reproduce the baseline in a clean environment. Audit data provenance, split design, preprocessing and whether claimed metrics match the intended use.
Run independent stress tests on missing features, shifted distributions and relevant slices. Maintain a findings register with severity, evidence, owner and closure criteria.
Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use.
Deliverables: Independent validation plan and scripts; Findings/remediation register. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI assurance / model validation specialist. Use this scenario: Receive a new model artifact with the same display name but different hash. Detect the mismatch and suspend the previous validation conclusion until change impact is assessed.
Review: Start with the task and permitted scope. Explain challenger tests: Use alternative baselines, negative controls and subgroup tests to probe a reported result. Preserve discrepancies and investigate before averaging them away. Show the input and observed output, then address Report reproducibility, scope coverage, unresolved findings and residual uncertainty. Avoid claiming regulatory approval or universal fitness for use. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Independent validation plan and scripts; Findings/remediation register. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

