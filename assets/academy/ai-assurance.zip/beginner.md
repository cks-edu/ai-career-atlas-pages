## beginner — Independent validation scope

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Independent validation scope
Define the claim being assessed, evidence needed and independence from the team that built the system. Separate completeness review from performance validation.
Mental model: A building inspector checks the builder's claim rather than simply repeating it.
Boundary: Independence helps challenge assumptions but does not guarantee a correct conclusion.
Worked example: The claim is that a model beats a baseline on held-out data; request split provenance, scoring code and raw predictions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The validator relies on the builder’s examples
The independent review protocol requires zero unreviewed material claims in the release evidence pack. Three submissions contain claims without independent evidence, so validation cannot close. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unsupported_claims >= 1 (count). This is a declared toy-case contract, not an industry standard. Map each claim to a reproducible test or explicit limitation and request missing evidence.
Recall: Reproduce key results and record unresolved findings with severity and owner. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Independent validation scope: Define the claim being assessed, evidence needed and independence from the team that built the system. Separate completeness review from performance validation.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Assurance examines whether evidence supports a claim. A small successful test cannot establish reliability in every situation.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use this fictional statement: “The assistant answered 9 of 10 examples correctly, so it is safe for all customers.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence review with claim, observation, limitation and next check.

3. Try step 2
Separate the measured result from the broader claim. List what is unknown about sample selection, error severity and intended users.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence review with claim, observation, limitation and next check.

4. Try step 3
Write a short review conclusion stating what the test supports and what additional evidence is needed.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence review with claim, observation, limitation and next check.

5. Explain and check your result
You can report 9/10 on these examples without endorsing universal safety or deployment readiness. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An evidence review with claim, observation, limitation and next check. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The independent review protocol requires zero unreviewed material claims in the release evidence pack. Apply this toy-case rule manually: Review when unsupported_claims >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three submissions contain claims without independent evidence, so validation cannot close. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI assurance / model validation specialist.
Use this fictional statement: “The assistant answered 9 of 10 examples correctly, so it is safe for all customers.”
Separate the measured result from the broader claim. List what is unknown about sample selection, error severity and intended users.
Write a short review conclusion stating what the test supports and what additional evidence is needed.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An evidence review with claim, observation, limitation and next check. Include beginner-worksheet.md and your completed Assurance findings report.
Check: You can report 9/10 on these examples without endorsing universal safety or deployment readiness.

### Interview
Explain your beginner solution for AI assurance / model validation specialist. Use this scenario: The independent review protocol requires zero unreviewed material claims in the release evidence pack.
Review: Start with the task and permitted scope. Explain independent validation scope: Define the claim being assessed, evidence needed and independence from the team that built the system. Separate completeness review from performance validation. Show the input and observed output, then address Map each claim to a reproducible test or explicit limitation and request missing evidence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An evidence review with claim, observation, limitation and next check. Include beginner-worksheet.md and your completed Assurance findings report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

