# SAMPLE — Assurance findings report
Role: AI assurance / model validation specialist
Case: The validator relies on the builder’s examples
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The independent review protocol requires zero unreviewed material claims in the release evidence pack.

## Evidence table
| Record | unsupported_claims (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 3 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three submissions contain claims without independent evidence, so validation cannot close.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Map each claim to a reproducible test or explicit limitation and request missing evidence.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai assurance / model validation specialist.
Before release: Reproduce key results and record unresolved findings with severity and owner.

## Design choice and trade-off
Maintain independent challenge and test selection; distinguish evidence absence from confirmed failure.
Additional validation costs time; prioritize material claims without silently treating unchecked claims as true.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Independent model review: Conclusions include data limitations and unresolved findings.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
