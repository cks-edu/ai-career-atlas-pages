# Backend Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
HTTP resource contracts

A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier.
Mental model: A library catalog number stays attached to a book when the shelf order changes.
Case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.
Task: Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.
Acceptance: One successful record and zero records from the two failures.
Troubleshooting: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.
Deliverable: api-contract.md and three reproducible requests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Cursor pagination

A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy.
Mental model: A bookmark names the last item read instead of counting pages in a changing binder.
Case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].
Task: Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.
Acceptance: Each original ID appears once in the unchanged fixture; malformed limit receives 400.
Troubleshooting: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.
Deliverable: pagination tests, request examples and consistency contract

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Idempotent creation

Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict.
Mental model: A numbered claim ticket can retrieve the same parcel without ordering another one.
Case: Key k1/title A twice gives one task; k1/title B is rejected.
Task: Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.
Acceptance: Exactly one task for two identical retries; a conflict response for changed content.
Troubleshooting: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.
Deliverable: idempotency tests and a durable-storage design note

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
