# Backend Engineer

Software Engineering

Start with http resource contracts. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward idempotency tests and a durable-storage design note.

## beginner

Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Request and response
A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.
Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.
Recall: Draw the request and response for adding one task.

### HTTP resource contracts
A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier.
Mental model: A library catalog number stays attached to a book when the shelf order changes.
Limit: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.
Example: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.
```
node app.mjs
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One successful record and zero records from the two failures.

6. Role workshop · debug and verify
If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save api-contract.md and three reproducible requests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One successful record and zero records from the two failures.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
HTTP resource contracts: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: api-contract.md and three reproducible requests
One successful record and zero records from the two failures.

Interview: Work through this Backend Engineer case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier. Expected evidence: One successful record and zero records from the two failures. Diagnosis: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward. State the limits of the mental model: A library catalog number stays attached to a book when the shelf order changes.

Resume: Built api-contract.md and three reproducible requests using Node.js HTTP and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Validation at a boundary
Check input before storing or using it. Client checks help people; the server must also enforce the rule.
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.
Example: A blank title receives 400 and does not change task count.
Recall: Why must the server reject invalid input even if the form already checks it?

### Cursor pagination
A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy.
Mental model: A bookmark names the last item read instead of counting pages in a changing binder.
Limit: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.
Example: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].
Recall: Explain the expected result before running the exercise, then diagnose this failure: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.
```
node app.mjs test intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

6. Role workshop · debug and verify
Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save pagination tests, request examples and consistency contract. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Cursor pagination: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: pagination tests, request examples and consistency contract
Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Interview: Work through this Backend Engineer case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy. Expected evidence: Each original ID appears once in the unchanged fixture; malformed limit receives 400. Diagnosis: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it. State the limits of the mental model: A bookmark names the last item read instead of counting pages in a changing binder.

Resume: Built pagination tests, request examples and consistency contract using Node.js HTTP and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State and recovery
State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.
Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database.
Recall: Name two things required before calling this service production ready.

### Idempotent creation
Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict.
Mental model: A numbered claim ticket can retrieve the same parcel without ordering another one.
Limit: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.
Example: Key k1/title A twice gives one task; k1/title B is rejected.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Key k1/title A twice gives one task; k1/title B is rejected. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.
```
node app.mjs test advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Exactly one task for two identical retries; a conflict response for changed content.

6. Role workshop · debug and verify
If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save idempotency tests and a durable-storage design note. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Exactly one task for two identical retries; a conflict response for changed content.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Idempotent creation: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: idempotency tests and a durable-storage design note
Exactly one task for two identical retries; a conflict response for changed content.

Interview: Work through this Backend Engineer case: Key k1/title A twice gives one task; k1/title B is rejected. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict. Expected evidence: Exactly one task for two identical retries; a conflict response for changed content. Diagnosis: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint. State the limits of the mental model: A numbered claim ticket can retrieve the same parcel without ordering another one.

Resume: Built idempotency tests and a durable-storage design note using Node.js HTTP and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
