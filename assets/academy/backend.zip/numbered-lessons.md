# Backend Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in Backend Engineer: Use the concept to complete this role exercise: Document GET and POST request/response examples

HTTP resource contracts: A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier.

### Functions: turn input into a result

A backend starts with rules, not a framework. A function gives a rule a name, accepts values and returns a result. Invalid input needs a deliberate outcome rather than accidental coercion.

How it works
Check the type before using string methods. Return a cleaned value only when it satisfies the contract. This pure function has no network or database, making its decisions easy to test.

Where the model stops
Trimming does not make arbitrary text safe for every output context. Rendering and database boundaries need their own rules.

Make one change
Test empty, whitespace-only, 80-character and 81-character titles. Add an acceptance table before changing the rule.

Mental model: A function is a small machine with labelled input and output trays.

Boundary: Trimming does not make arbitrary text safe for every output context. Rendering and database boundaries need their own rules.

Worked example: import assert from 'node:assert/strict';
function title(value) {
 if(typeof value !== 'string') throw new TypeError('Expected text');
 const clean=value.trim(); if(clean.length<1 || clean.length>80) throw new Error('Length 1 to 80');
 return clean;
}
assert.equal(title(' Read '),'Read');
assert.throws(()=>title(null),TypeError);
assert.throws(()=>title('x'.repeat(81)),/Length/);
console.log('PASS: clean text, wrong type, length boundary');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/functions-and-errors. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Test empty, whitespace-only, 80-character and 81-character titles. Add an acceptance table before changing the rule.

Terminal folder: course-labs/beginner/functions-and-errors

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Check the type before using string methods. Return a cleaned value only when it satisfies the contract. This pure function has no network or database, making its decisions easy to test.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/functions-and-errors. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The reference assertions pass. Your acceptance table and checks agree on both ends of the allowed length.

Build your change

Test empty, whitespace-only, 80-character and 81-character titles. Add an acceptance table before changing the rule.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The reference assertions pass. Your acceptance table and checks agree on both ends of the allowed length.

Break, repair and explain

Deliberately violate this boundary: Trimming does not make arbitrary text safe for every output context. Rendering and database boundaries need their own rules. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The reference assertions pass. Your acceptance table and checks agree on both ends of the allowed length.

Troubleshoot: My result does not match Functions: turn input into a result: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Check the type before using string methods. Return a cleaned value only when it satisfies the contract. This pure function has no network or database, making its decisions easy to test. Then inspect this limit: Trimming does not make arbitrary text safe for every output context. Rendering and database boundaries need their own rules. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/functions-and-errors/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Functions: turn input into a result line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A function is a small machine with labelled input and output trays.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Why inspect type before calling trim? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Trimming does not make arbitrary text safe for every output context. Rendering and database boundaries need their own rules. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why inspect type before calling trim?

Interview: Why inspect type before calling trim? Defend your answer using your actual lab result and this boundary: Trimming does not make arbitrary text safe for every output context. Rendering and database boundaries need their own rules.

Quiz: Why inspect type before calling trim?

It prevents a string method from being called on an incompatible value.

It encrypts the value.

It stores the value.

Reference: It prevents a string method from being called on an incompatible value. — A null or object input does not satisfy the text contract. Validation is a boundary decision, not encryption or persistence.

Sources:

MDN: JavaScript guide: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

### HTTP responses: make outcomes explicit

A client needs to distinguish a successful read from a missing resource. HTTP status describes the outcome class; a response body carries additional data. Keep both consistent.

How it works
A lookup may find no row without the server crashing. Model that case with a not-found response. Do not expose internal stack traces as a client error message.

Where the model stops
This pure lookup does not parse an HTTP request or enforce permissions.

Make one change
Add invalid-id handling before lookup. Decide how the adapter parses a URL id and test a nonnumeric id separately from a valid but missing id.

Mental model: The receipt says whether the request succeeded before listing the result.

Boundary: This pure lookup does not parse an HTTP request or enforce permissions.

Worked example: import assert from 'node:assert/strict';
const tasks=new Map([[1,{id:1,title:'Read'}]]);
function read(id){return tasks.has(id)?{status:200,body:tasks.get(id)}:{status:404,body:{error:'Task not found'}};}
assert.equal(read(1).status,200);
assert.equal(read(2).status,404);
console.log(JSON.stringify(read(2)));


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/http-status. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add invalid-id handling before lookup. Decide how the adapter parses a URL id and test a nonnumeric id separately from a valid but missing id.

Terminal folder: course-labs/beginner/http-status

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. A lookup may find no row without the server crashing. Model that case with a not-found response. Do not expose internal stack traces as a client error message.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/http-status. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Missing id 2 returns status 404 with a useful message. Your adapter distinguishes malformed input from absence.

Build your change

Add invalid-id handling before lookup. Decide how the adapter parses a URL id and test a nonnumeric id separately from a valid but missing id.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Missing id 2 returns status 404 with a useful message. Your adapter distinguishes malformed input from absence.

Break, repair and explain

Deliberately violate this boundary: This pure lookup does not parse an HTTP request or enforce permissions. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Missing id 2 returns status 404 with a useful message. Your adapter distinguishes malformed input from absence.

Troubleshoot: My result does not match HTTP responses: make outcomes explicit: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: A lookup may find no row without the server crashing. Model that case with a not-found response. Do not expose internal stack traces as a client error message. Then inspect this limit: This pure lookup does not parse an HTTP request or enforce permissions. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/http-status/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace HTTP responses: make outcomes explicit line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The receipt says whether the request succeeded before listing the result.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: A valid task id is absent. Must that be an unhandled server exception? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This pure lookup does not parse an HTTP request or enforce permissions. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A valid task id is absent. Must that be an unhandled server exception?

Interview: A valid task id is absent. Must that be an unhandled server exception? Defend your answer using your actual lab result and this boundary: This pure lookup does not parse an HTTP request or enforce permissions.

Quiz: A valid task id is absent. Must that be an unhandled server exception?

Yes, all missing rows are crashes.

No; return an intentional not-found result.

Return a fabricated row.

Reference: No; return an intentional not-found result. — An absent resource is a normal API outcome. Internal failures and invalid input are separate cases.

Sources:

MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### JSON: parse safely and validate separately

JSON encodes values as text. Parsing checks that the text follows JSON syntax; validation checks that the resulting value fits your application. A valid JSON string can still contain the wrong kind of data.

How it works
Catch syntax errors at the parsing boundary. Then reject arrays, null or objects without a meaningful title. Do not let a parser error become an unexplained application crash.

Where the model stops
The example is size-unbounded because it receives a tiny string. A real HTTP adapter must also cap request bytes and time.

Make one change
Test an array, a numeric title and a JSON object with extra fields. Choose and document the extra-field policy.

Mental model: Opening an envelope is not the same as verifying the form inside.

Boundary: The example is size-unbounded because it receives a tiny string. A real HTTP adapter must also cap request bytes and time.

Worked example: import assert from 'node:assert/strict';
function parse(text){
 let value; try{value=JSON.parse(text)}catch{return {ok:false,error:'Invalid JSON'}}
 if(!value || Array.isArray(value) || typeof value.title!=='string' || !value.title.trim()) return {ok:false,error:'Title required'};
 return {ok:true,title:value.title.trim()};
}
assert.equal(parse('{').error,'Invalid JSON');
assert.equal(parse('null').error,'Title required');
assert.deepEqual(parse('{"title":" Read "}'),{ok:true,title:'Read'});
console.log('PASS: syntax and schema are separate checks');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/json-boundary. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Test an array, a numeric title and a JSON object with extra fields. Choose and document the extra-field policy.

Terminal folder: course-labs/beginner/json-boundary

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Catch syntax errors at the parsing boundary. Then reject arrays, null or objects without a meaningful title. Do not let a parser error become an unexplained application crash.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/json-boundary. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Malformed syntax and wrong shapes produce different errors; a valid title is trimmed. Your policy handles extra fields deliberately.

Build your change

Test an array, a numeric title and a JSON object with extra fields. Choose and document the extra-field policy.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Malformed syntax and wrong shapes produce different errors; a valid title is trimmed. Your policy handles extra fields deliberately.

Break, repair and explain

Deliberately violate this boundary: The example is size-unbounded because it receives a tiny string. A real HTTP adapter must also cap request bytes and time. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Malformed syntax and wrong shapes produce different errors; a valid title is trimmed. Your policy handles extra fields deliberately.

Troubleshoot: My result does not match JSON: parse safely and validate separately: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Catch syntax errors at the parsing boundary. Then reject arrays, null or objects without a meaningful title. Do not let a parser error become an unexplained application crash. Then inspect this limit: The example is size-unbounded because it receives a tiny string. A real HTTP adapter must also cap request bytes and time. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/json-boundary/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace JSON: parse safely and validate separately line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Opening an envelope is not the same as verifying the form inside.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Does JSON.parse prove that a title field exists? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The example is size-unbounded because it receives a tiny string. A real HTTP adapter must also cap request bytes and time. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does JSON.parse prove that a title field exists?

Interview: Does JSON.parse prove that a title field exists? Defend your answer using your actual lab result and this boundary: The example is size-unbounded because it receives a tiny string. A real HTTP adapter must also cap request bytes and time.

Quiz: Does JSON.parse prove that a title field exists?

Yes.

Only for HTTPS.

No, it validates JSON syntax rather than this schema.

Reference: No, it validates JSON syntax rather than this schema. — Parsing can return null, arrays, primitives or unexpected objects. Application validation follows parsing.

Sources:

MDN: JavaScript guide: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide

### Files: distinguish memory from persistence

Memory is lost when a process stops. A file can preserve data across runs, but reading and writing files introduces paths, formats and failure cases. Start with an isolated temporary folder.

How it works
Write JSON, read it back and compare the parsed record. Use a unique temporary directory so your test cannot overwrite real application files. Remove only that directory when finished.

Where the model stops
A direct write is not a crash-safe transaction and concurrent writers can overwrite each other. Use a database when those guarantees are needed.

Make one change
Add a corrupt-JSON case and a missing-file case. Explain whether an empty initial file is permitted, and never silently replace corrupt learner data with an empty array.

Mental model: Memory is a whiteboard; a saved file is a dated notebook that must be opened again.

Boundary: A direct write is not a crash-safe transaction and concurrent writers can overwrite each other. Use a database when those guarantees are needed.

Worked example: import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os'; import {join} from 'node:path';
import assert from 'node:assert/strict';
const dir=await mkdtemp(join(tmpdir(),'skillbadi-backend-'));
try {
 const path=join(dir,'tasks.json'); const tasks=[{id:1,title:'Read'}];
 await writeFile(path,JSON.stringify(tasks));
 assert.deepEqual(JSON.parse(await readFile(path,'utf8')),tasks);
 console.log('PASS: file round trip');
}finally{await rm(dir,{recursive:true,force:true})}


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/file-persistence. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a corrupt-JSON case and a missing-file case. Explain whether an empty initial file is permitted, and never silently replace corrupt learner data with an empty array.

Terminal folder: course-labs/beginner/file-persistence

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Write JSON, read it back and compare the parsed record. Use a unique temporary directory so your test cannot overwrite real application files. Remove only that directory when finished.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/file-persistence. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The saved record survives a read and the temporary folder is removed. Your corrupt-file case preserves evidence and reports the problem.

Build your change

Add a corrupt-JSON case and a missing-file case. Explain whether an empty initial file is permitted, and never silently replace corrupt learner data with an empty array.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The saved record survives a read and the temporary folder is removed. Your corrupt-file case preserves evidence and reports the problem.

Break, repair and explain

Deliberately violate this boundary: A direct write is not a crash-safe transaction and concurrent writers can overwrite each other. Use a database when those guarantees are needed. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The saved record survives a read and the temporary folder is removed. Your corrupt-file case preserves evidence and reports the problem.

Troubleshoot: My result does not match Files: distinguish memory from persistence: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Write JSON, read it back and compare the parsed record. Use a unique temporary directory so your test cannot overwrite real application files. Remove only that directory when finished. Then inspect this limit: A direct write is not a crash-safe transaction and concurrent writers can overwrite each other. Use a database when those guarantees are needed. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/file-persistence/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Files: distinguish memory from persistence line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Memory is a whiteboard; a saved file is a dated notebook that must be opened again.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Does writing JSON directly guarantee atomic multi-writer updates? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A direct write is not a crash-safe transaction and concurrent writers can overwrite each other. Use a database when those guarantees are needed. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does writing JSON directly guarantee atomic multi-writer updates?

Interview: Does writing JSON directly guarantee atomic multi-writer updates? Defend your answer using your actual lab result and this boundary: A direct write is not a crash-safe transaction and concurrent writers can overwrite each other. Use a database when those guarantees are needed.

Quiz: Does writing JSON directly guarantee atomic multi-writer updates?

No.

Yes, JSON is transactional.

Only when the file ends in .json.

Reference: No. — A format does not provide concurrency or crash-safety. Storage guarantees depend on the operation and filesystem/database semantics.

Sources:

Node.js: filesystem API: https://nodejs.org/api/fs.html

### Tests: check the edge, not only the example

A useful test exercises a rule that could break. Normal inputs show intended use; boundary and invalid inputs reveal hidden assumptions. A test should fail when the rule is deliberately broken.

How it works
Use table-driven cases to cover one threshold. Keep the function and expectation simple enough that the test does not reproduce the implementation in disguise.

Where the model stops
Three tests cannot prove all inputs. Decide which risks need additional cases and integration checks.

Make one change
Temporarily change <=100 to <100 and confirm the boundary test fails. Restore the rule, then add NaN and Infinity cases.

Mental model: Test the fence at its posts as well as walking through the centre of the field.

Boundary: Three tests cannot prove all inputs. Decide which risks need additional cases and integration checks.

Worked example: import assert from 'node:assert/strict';
const allowed=size=>Number.isInteger(size)&&size>=1&&size<=100;
for(const [value,want] of [[0,false],[1,true],[100,true],[101,false],[1.5,false],['1',false]]) assert.equal(allowed(value),want,String(value));
console.log('PASS: lower/upper boundaries, fractional and string inputs');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/beginner/tests-and-boundaries. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Temporarily change <=100 to <100 and confirm the boundary test fails. Restore the rule, then add NaN and Infinity cases.

Terminal folder: course-labs/beginner/tests-and-boundaries

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Use table-driven cases to cover one threshold. Keep the function and expectation simple enough that the test does not reproduce the implementation in disguise.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/tests-and-boundaries. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Six reference cases pass. The deliberate mutation fails at 100, showing the test can detect that defect.

Build your change

Temporarily change <=100 to <100 and confirm the boundary test fails. Restore the rule, then add NaN and Infinity cases.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Six reference cases pass. The deliberate mutation fails at 100, showing the test can detect that defect.

Break, repair and explain

Deliberately violate this boundary: Three tests cannot prove all inputs. Decide which risks need additional cases and integration checks. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Six reference cases pass. The deliberate mutation fails at 100, showing the test can detect that defect.

Troubleshoot: My result does not match Tests: check the edge, not only the example: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use table-driven cases to cover one threshold. Keep the function and expectation simple enough that the test does not reproduce the implementation in disguise. Then inspect this limit: Three tests cannot prove all inputs. Decide which risks need additional cases and integration checks. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/tests-and-boundaries/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Tests: check the edge, not only the example line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Test the fence at its posts as well as walking through the centre of the field.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Which new case most directly checks the upper allowed boundary? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Three tests cannot prove all inputs. Decide which risks need additional cases and integration checks. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which new case most directly checks the upper allowed boundary?

Interview: Which new case most directly checks the upper allowed boundary? Defend your answer using your actual lab result and this boundary: Three tests cannot prove all inputs. Decide which risks need additional cases and integration checks.

Quiz: Which new case most directly checks the upper allowed boundary?

50

100

A screenshot of the editor.

Reference: 100 — The exact threshold catches an off-by-one change. Evidence should include the observed test result.

Sources:

Node.js: test runner: https://nodejs.org/api/test.html

### Request and response

A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. In this role, work through: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. The practical workshop develops this into: Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Role application: A library catalog number stays attached to a book when the shelf order changes.

A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier.

Worked example: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

Shared foundation example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Backend Engineer: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

Predict the worked case

Read this case without running a tool: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in request and response.

Connect the concept to the role

Apply this rule: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Networks can time out; sending an order does not prove it was fulfilled.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies request and response to this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Request and response; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request and response. Use the glossary below, then write your prediction for: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain request and response using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request and response to a system or workflow you know. Explain request and response using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Draw the request and response for adding one task.

Interview: Explain request and response using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops.

Quiz: After the HTTP resource contracts rehearsal, check this foundation: A request returns HTTP 404. Which boundary has evidence of working?

An HTTP server returned a response; inspect the route next.

The request never reached any HTTP server.

The server has confirmed that the resource exists.

Reference: An HTTP server returned a response; inspect the route next. — 404 is an HTTP response, not a transport timeout. It does not prove which component generated it or that the business operation succeeded.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### HTTP resource contracts

A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier. In this role, work through: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. The practical workshop develops this into: Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

Mental model: A library catalog number stays attached to a book when the shelf order changes.

Boundary: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.

Worked example: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Backend Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

```
node app.mjs
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One successful record and zero records from the two failures.

Role workshop · debug and verify

If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save api-contract.md and three reproducible requests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One successful record and zero records from the two failures.

Expected: One successful record and zero records from the two failures.

Troubleshoot: The role exercise differs from the prediction: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: api-contract.md and three reproducible requests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with http resource contracts. Use the glossary below, then write your prediction for: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain http resource contracts using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate http resource contracts to a system or workflow you know. Explain http resource contracts using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.

Interview: Explain http resource contracts using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

One successful record and zero records from the two failures.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: One successful record and zero records from the two failures. — A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier. One successful record and zero records from the two failures.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in Backend Engineer: Use the concept to complete this role exercise: Specify pagination and stable identifiers for a task API

Cursor pagination: A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy.

### Errors: classify and redact at the boundary

Internal failures can contain secrets or database details. A service translates its internal error into a safe client contract while retaining enough private context to investigate.

How it works
Give known validation errors a stable public code. Return a generic message for unknown failures. Correlate the client response and protected logs with a request id rather than exposing the stack.

Where the model stops
Redaction is not achieved by this function alone; logs, traces and reverse proxies need consistent data-handling rules.

Make one change
Add a not-found error category. Write a log-field allowlist containing request id and error category, and test that request bodies and tokens are excluded.

Mental model: A public incident notice and an engineer incident log serve different audiences.

Boundary: Redaction is not achieved by this function alone; logs, traces and reverse proxies need consistent data-handling rules.

Worked example: import assert from 'node:assert/strict';
function publicError(error,requestId){
 return error.code==='INVALID_TITLE'?{status:422,body:{code:error.code,requestId}}:{status:500,body:{code:'INTERNAL',requestId}};
}
const r=publicError(new Error('password=secret'),'req-7');
assert.equal(r.status,500);assert.equal(JSON.stringify(r).includes('secret'),false);
assert.equal(publicError({code:'INVALID_TITLE'},'req-8').status,422);
console.log('PASS: classified error and public redaction');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/error-contract. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a not-found error category. Write a log-field allowlist containing request id and error category, and test that request bodies and tokens are excluded.

Terminal folder: course-labs/intermediate/error-contract

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Give known validation errors a stable public code. Return a generic message for unknown failures. Correlate the client response and protected logs with a request id rather than exposing the stack.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/error-contract. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The unknown error response contains no secret and retains a request id. Your additional category has a stable public result.

Build your change

Add a not-found error category. Write a log-field allowlist containing request id and error category, and test that request bodies and tokens are excluded.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The unknown error response contains no secret and retains a request id. Your additional category has a stable public result.

Break, repair and explain

Deliberately violate this boundary: Redaction is not achieved by this function alone; logs, traces and reverse proxies need consistent data-handling rules. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The unknown error response contains no secret and retains a request id. Your additional category has a stable public result.

Troubleshoot: My result does not match Errors: classify and redact at the boundary: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Give known validation errors a stable public code. Return a generic message for unknown failures. Correlate the client response and protected logs with a request id rather than exposing the stack. Then inspect this limit: Redaction is not achieved by this function alone; logs, traces and reverse proxies need consistent data-handling rules. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/error-contract/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Errors: classify and redact at the boundary line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A public incident notice and an engineer incident log serve different audiences.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Where should a raw database password in an exception appear? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Redaction is not achieved by this function alone; logs, traces and reverse proxies need consistent data-handling rules. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Where should a raw database password in an exception appear?

Interview: Where should a raw database password in an exception appear? Defend your answer using your actual lab result and this boundary: Redaction is not achieved by this function alone; logs, traces and reverse proxies need consistent data-handling rules.

Quiz: Where should a raw database password in an exception appear?

In the response body.

In a public trace URL.

In neither public responses nor ordinary logs.

Reference: In neither public responses nor ordinary logs. — Keep secrets out of outputs and routine telemetry. Diagnose with safe categories and protected, minimised evidence.

Sources:

OWASP: logging guidance: https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html

### SQL transactions: commit all or none

A transaction groups related writes into one unit. Moving a value between two accounts should not leave one side changed when the second write fails. Practise with synthetic balances only.

How it works
Python sqlite3 can manage commit and rollback with a connection context manager. Start with a committed fixture. An exception inside the context rolls back that transaction; closing the connection is a separate responsibility.

Where the model stops
SQLite is useful for this local demonstration. Production isolation, concurrency, financial correctness and connection management need a separate design.

Make one change
Add a successful transfer of 20 using bound parameters. Test both final balances and the total, then force a failure after the first successful update to verify rollback of that update.

Mental model: Two ledger entries belong inside one sealed envelope: either both enter the book or neither does.

Boundary: SQLite is useful for this local demonstration. Production isolation, concurrency, financial correctness and connection management need a separate design.

Worked example: import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.execute('create table accounts(id integer primary key, balance integer check(balance >= 0))')
 con.executemany('insert into accounts values(?,?)',[(1,100),(2,50)])
 con.commit()
 try:
  with con:
   con.execute('update accounts set balance=balance-200 where id=1')
   con.execute('update accounts set balance=balance+200 where id=2')
 except sqlite3.IntegrityError:
  pass
 assert con.execute('select balance from accounts order by id').fetchall()==[(100,),(50,)]
 print('PASS: failed transfer leaves both committed balances unchanged')
finally:
 con.close()


Setup: Download and extract backend.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/sqlite-transaction. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python sqlite3 / SQLite

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a successful transfer of 20 using bound parameters. Test both final balances and the total, then force a failure after the first successful update to verify rollback of that update.

Terminal folder: course-labs/intermediate/sqlite-transaction

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Python sqlite3 can manage commit and rollback with a connection context manager. Start with a committed fixture. An exception inside the context rolls back that transaction; closing the connection is a separate responsibility.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/sqlite-transaction. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The invalid transfer leaves balances 100 and 50. Your successful case yields 80 and 70; the injected mid-transaction failure restores the previous committed pair.

Build your change

Add a successful transfer of 20 using bound parameters. Test both final balances and the total, then force a failure after the first successful update to verify rollback of that update.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The invalid transfer leaves balances 100 and 50. Your successful case yields 80 and 70; the injected mid-transaction failure restores the previous committed pair.

Break, repair and explain

Deliberately violate this boundary: SQLite is useful for this local demonstration. Production isolation, concurrency, financial correctness and connection management need a separate design. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The invalid transfer leaves balances 100 and 50. Your successful case yields 80 and 70; the injected mid-transaction failure restores the previous committed pair.

Troubleshoot: My result does not match SQL transactions: commit all or none: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Python sqlite3 can manage commit and rollback with a connection context manager. Start with a committed fixture. An exception inside the context rolls back that transaction; closing the connection is a separate responsibility. Then inspect this limit: SQLite is useful for this local demonstration. Production isolation, concurrency, financial correctness and connection management need a separate design. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/sqlite-transaction/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace SQL transactions: commit all or none line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Two ledger entries belong inside one sealed envelope: either both enter the book or neither does.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: The first update succeeds but the second raises inside the transaction context. What should happen? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: SQLite is useful for this local demonstration. Production isolation, concurrency, financial correctness and connection management need a separate design. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: The first update succeeds but the second raises inside the transaction context. What should happen?

Interview: The first update succeeds but the second raises inside the transaction context. What should happen? Defend your answer using your actual lab result and this boundary: SQLite is useful for this local demonstration. Production isolation, concurrency, financial correctness and connection management need a separate design.

Quiz: The first update succeeds but the second raises inside the transaction context. What should happen?

Commit the first anyway.

Rollback the transaction.

Delete both accounts.

Reference: Rollback the transaction. — Atomicity keeps the related writes together. A transaction does not remove the need for constraints and validation.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### SQL parameters: keep values out of query syntax

A query has instructions and values. String concatenation lets a value accidentally become an instruction. Bound parameters keep the database responsible for interpreting each value as data.

How it works
Use ? placeholders with sqlite3 and pass a separate sequence of values. Do not put the placeholder inside quotes. Parameters bind values, not arbitrary table or column names.

Where the model stops
Bound values reduce injection risk for this query. Dynamic identifiers still require an allowlist and permissions still apply.

Make one change
Query a title containing an apostrophe and verify the exact returned text. Add an allowlisted sort-column selector without trying to bind a column name as a value.

Mental model: A printed form has fixed field labels; the handwriting belongs in the fields rather than rewriting the instructions.

Boundary: Bound values reduce injection risk for this query. Dynamic identifiers still require an allowlist and permissions still apply.

Worked example: import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.execute('create table tasks(title text)')
 attack="x'); drop table tasks; --"
 con.execute('insert into tasks(title) values(?)',(attack,))
 assert con.execute('select title from tasks').fetchone()[0]==attack
 assert con.execute('select count(*) from tasks').fetchone()[0]==1
 print('PASS: SQL-looking input stored as literal data')
finally:
 con.close()


Setup: Download and extract backend.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/sql-parameters. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python sqlite3 / SQLite

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Query a title containing an apostrophe and verify the exact returned text. Add an allowlisted sort-column selector without trying to bind a column name as a value.

Terminal folder: course-labs/intermediate/sql-parameters

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Use ? placeholders with sqlite3 and pass a separate sequence of values. Do not put the placeholder inside quotes. Parameters bind values, not arbitrary table or column names.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/sql-parameters. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The table still exists and the entire SQL-looking title is stored literally. Your apostrophe case round trips unchanged.

Build your change

Query a title containing an apostrophe and verify the exact returned text. Add an allowlisted sort-column selector without trying to bind a column name as a value.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The table still exists and the entire SQL-looking title is stored literally. Your apostrophe case round trips unchanged.

Break, repair and explain

Deliberately violate this boundary: Bound values reduce injection risk for this query. Dynamic identifiers still require an allowlist and permissions still apply. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The table still exists and the entire SQL-looking title is stored literally. Your apostrophe case round trips unchanged.

Troubleshoot: My result does not match SQL parameters: keep values out of query syntax: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use ? placeholders with sqlite3 and pass a separate sequence of values. Do not put the placeholder inside quotes. Parameters bind values, not arbitrary table or column names. Then inspect this limit: Bound values reduce injection risk for this query. Dynamic identifiers still require an allowlist and permissions still apply. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/sql-parameters/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace SQL parameters: keep values out of query syntax line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A printed form has fixed field labels; the handwriting belongs in the fields rather than rewriting the instructions.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Can a value placeholder safely choose an arbitrary SQL column name? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Bound values reduce injection risk for this query. Dynamic identifiers still require an allowlist and permissions still apply. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Can a value placeholder safely choose an arbitrary SQL column name?

Interview: Can a value placeholder safely choose an arbitrary SQL column name? Defend your answer using your actual lab result and this boundary: Bound values reduce injection risk for this query. Dynamic identifiers still require an allowlist and permissions still apply.

Quiz: Can a value placeholder safely choose an arbitrary SQL column name?

Yes, it becomes an identifier.

Only with double quotes.

No; validate identifiers separately.

Reference: No; validate identifiers separately. — Value binding does not replace identifier construction. Choose identifiers from a fixed trusted allowlist.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Idempotency: recognise a repeated operation

A client can retry after a timeout without knowing whether the first request committed. An idempotency key lets the service recognise a repeated operation and return its original result.

How it works
Store the request fingerprint with the key and result. Reusing the same key for a different payload is a conflict. Real storage must coordinate creation and result recording atomically.

Where the model stops
A process-local Map loses records on restart and is not safe coordination across multiple servers. This is a policy model.

Make one change
Test a second key with the same title and decide whether it represents a new operation. Specify expiry and the durable unique constraint needed for two server instances.

Mental model: A numbered receipt prevents a repeated payment instruction from becoming a second purchase.

Boundary: A process-local Map loses records on restart and is not safe coordination across multiple servers. This is a policy model.

Worked example: import assert from 'node:assert/strict';
const seen=new Map();let writes=0;
function create(key,title){
 if(seen.has(key)){const old=seen.get(key);if(old.title!==title)throw new Error('Key conflict');return old.result}
 const result={id:++writes,title};seen.set(key,{title,result});return result;
}
assert.deepEqual(create('a','Read'),create('a','Read'));
assert.equal(writes,1);assert.throws(()=>create('a','Other'),/conflict/);
console.log('PASS: duplicate returns original; mismatched replay conflicts');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/idempotency. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Test a second key with the same title and decide whether it represents a new operation. Specify expiry and the durable unique constraint needed for two server instances.

Terminal folder: course-labs/intermediate/idempotency

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Store the request fingerprint with the key and result. Reusing the same key for a different payload is a conflict. Real storage must coordinate creation and result recording atomically.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/idempotency. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: A duplicate key writes once and a changed payload is rejected. Your design distinguishes key replay from merely identical content.

Build your change

Test a second key with the same title and decide whether it represents a new operation. Specify expiry and the durable unique constraint needed for two server instances.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. A duplicate key writes once and a changed payload is rejected. Your design distinguishes key replay from merely identical content.

Break, repair and explain

Deliberately violate this boundary: A process-local Map loses records on restart and is not safe coordination across multiple servers. This is a policy model. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: A duplicate key writes once and a changed payload is rejected. Your design distinguishes key replay from merely identical content.

Troubleshoot: My result does not match Idempotency: recognise a repeated operation: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Store the request fingerprint with the key and result. Reusing the same key for a different payload is a conflict. Real storage must coordinate creation and result recording atomically. Then inspect this limit: A process-local Map loses records on restart and is not safe coordination across multiple servers. This is a policy model. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/idempotency/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Idempotency: recognise a repeated operation line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A numbered receipt prevents a repeated payment instruction from becoming a second purchase.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Should the same key with a different payload silently return a new result? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A process-local Map loses records on restart and is not safe coordination across multiple servers. This is a policy model. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Should the same key with a different payload silently return a new result?

Interview: Should the same key with a different payload silently return a new result? Defend your answer using your actual lab result and this boundary: A process-local Map loses records on restart and is not safe coordination across multiple servers. This is a policy model.

Quiz: Should the same key with a different payload silently return a new result?

No, reject or explicitly handle the conflict.

Yes, always create twice.

Only after a timeout.

Reference: No, reject or explicitly handle the conflict. — The key identifies one operation. Accepting incompatible payloads hides a client or replay error.

Sources:

MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### Rate limits: bound work per caller

Rate limiting constrains how much work a caller can request. Choose the identity, window and allowed burst deliberately. A shared IP may represent many people and is not always the right key.

How it works
The fixed-window example resets at a boundary and counts accepted requests. Use an injected clock so reset behaviour is reproducible. A distributed deployment requires coordinated counters or an explicit approximation.

Where the model stops
A fixed window permits bursts around its boundary. This local model does not defend against every denial-of-service pattern.

Make one change
Demonstrate the maximum burst immediately before and after a window boundary. Compare a token-bucket policy and document why an authenticated account or API key might be better than IP alone.

Mental model: Each caller receives a small refillable set of entry tickets.

Boundary: A fixed window permits bursts around its boundary. This local model does not defend against every denial-of-service pattern.

Worked example: import assert from 'node:assert/strict';
const usage=new Map();
function allow(user,now){const window=Math.floor(now/1000);const old=usage.get(user);const n=old?.window===window?old.count:0;if(n>=2)return false;usage.set(user,{window,count:n+1});return true}
assert.equal(allow('a',0),true);assert.equal(allow('a',1),true);assert.equal(allow('a',2),false);
assert.equal(allow('b',2),true);assert.equal(allow('a',1000),true);
console.log('PASS: limit, caller isolation and next window');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/intermediate/rate-limits. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Demonstrate the maximum burst immediately before and after a window boundary. Compare a token-bucket policy and document why an authenticated account or API key might be better than IP alone.

Terminal folder: course-labs/intermediate/rate-limits

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. The fixed-window example resets at a boundary and counts accepted requests. Use an injected clock so reset behaviour is reproducible. A distributed deployment requires coordinated counters or an explicit approximation.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/rate-limits. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: A third same-window request is rejected, user b has its own allowance and the new window resets user a.

Build your change

Demonstrate the maximum burst immediately before and after a window boundary. Compare a token-bucket policy and document why an authenticated account or API key might be better than IP alone.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. A third same-window request is rejected, user b has its own allowance and the new window resets user a.

Break, repair and explain

Deliberately violate this boundary: A fixed window permits bursts around its boundary. This local model does not defend against every denial-of-service pattern. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: A third same-window request is rejected, user b has its own allowance and the new window resets user a.

Troubleshoot: My result does not match Rate limits: bound work per caller: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixed-window example resets at a boundary and counts accepted requests. Use an injected clock so reset behaviour is reproducible. A distributed deployment requires coordinated counters or an explicit approximation. Then inspect this limit: A fixed window permits bursts around its boundary. This local model does not defend against every denial-of-service pattern. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/rate-limits/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Rate limits: bound work per caller line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Each caller receives a small refillable set of entry tickets.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Do process-local counters enforce a global limit across three replicas? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A fixed window permits bursts around its boundary. This local model does not defend against every denial-of-service pattern. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Do process-local counters enforce a global limit across three replicas?

Interview: Do process-local counters enforce a global limit across three replicas? Defend your answer using your actual lab result and this boundary: A fixed window permits bursts around its boundary. This local model does not defend against every denial-of-service pattern.

Quiz: Do process-local counters enforce a global limit across three replicas?

Yes, automatically.

No, replicas need coordination or a stated approximation.

Only if the route is GET.

Reference: No, replicas need coordination or a stated approximation. — Each process has independent memory. Deployment topology changes the actual enforced limit.

Sources:

MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### Validation at a boundary

Check input before storing or using it. Client checks help people; the server must also enforce the rule. In this role, work through: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. The practical workshop develops this into: Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Role application: A bookmark names the last item read instead of counting pages in a changing binder.

A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy.

Worked example: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Shared foundation example: A blank title receives 400 and does not change task count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Backend Engineer: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Predict the worked case

Read this case without running a tool: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in validation at a boundary.

Connect the concept to the role

Apply this rule: Check input before storing or using it. Client checks help people; the server must also enforce the rule. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid input can still be unauthorized; validation is not access control.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies validation at a boundary to this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Validation at a boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with validation at a boundary. Use the glossary below, then write your prediction for: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain validation at a boundary using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate validation at a boundary to a system or workflow you know. Explain validation at a boundary using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Explain validation at a boundary using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops.

Quiz: After the Cursor pagination rehearsal, check this foundation: A browser rejects a blank field. A second client calls the API directly. Where must the same business rule be enforced?

Only in the browser to avoid duplicate logic.

At the server boundary before state changes.

Only after storing the input, in the dashboard.

Reference: At the server boundary before state changes. — Client checks improve feedback; the server must protect its contract for every caller.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Cursor pagination

A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy. In this role, work through: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. The practical workshop develops this into: Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

Mental model: A bookmark names the last item read instead of counting pages in a changing binder.

Boundary: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.

Worked example: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Backend Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

```
node app.mjs test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Role workshop · debug and verify

Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save pagination tests, request examples and consistency contract. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Troubleshoot: The role exercise differs from the prediction: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: pagination tests, request examples and consistency contract; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cursor pagination. Use the glossary below, then write your prediction for: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain cursor pagination using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cursor pagination to a system or workflow you know. Explain cursor pagination using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.

Interview: Explain cursor pagination using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Ignore the failing case and keep only the successful screenshot.

Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Treat any successful command as proof that all business and access rules passed.

Reference: Each original ID appears once in the unchanged fixture; malformed limit receives 400. — A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy. Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in Backend Engineer: Use the concept to complete this role exercise: Design idempotent creation, rate limits and recovery tests

Idempotent creation: Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict.

### Timeouts: stop waiting within a budget

A service needs a bounded wait for dependencies. A timeout decides when the caller stops waiting; cancellation decides whether the underlying work is also stopped. They are related but different.

How it works
Promise.race can select a deadline result. Clear its timer after settlement. Without cooperative cancellation, the losing operation may continue and produce a remote side effect.

Where the model stops
This helper bounds the returned wait only. Production calls should propagate a deadline and use cancellation where supported.

Make one change
Replace the never-resolving operation with one that completes after the deadline. Record that it still runs, then design an AbortSignal-aware alternative and a total request time budget.

Mental model: Leaving a long queue does not necessarily cancel the order already being prepared.

Boundary: This helper bounds the returned wait only. Production calls should propagate a deadline and use cancellation where supported.

Worked example: import assert from 'node:assert/strict';
async function deadline(work,ms){let timer;try{return await Promise.race([work,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Deadline')),ms)})])}finally{clearTimeout(timer)}}
assert.equal(await deadline(Promise.resolve('ok'),100),'ok');
await assert.rejects(deadline(new Promise(()=>{}),5),/Deadline/);
console.log('PASS: immediate success and bounded wait');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/timeouts. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Replace the never-resolving operation with one that completes after the deadline. Record that it still runs, then design an AbortSignal-aware alternative and a total request time budget.

Terminal folder: course-labs/advanced/timeouts

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Promise.race can select a deadline result. Clear its timer after settlement. Without cooperative cancellation, the losing operation may continue and produce a remote side effect.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/timeouts. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The reference resolves success and rejects the timed-out wait. Your observation distinguishes a stopped wait from cancelled work.

Build your change

Replace the never-resolving operation with one that completes after the deadline. Record that it still runs, then design an AbortSignal-aware alternative and a total request time budget.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The reference resolves success and rejects the timed-out wait. Your observation distinguishes a stopped wait from cancelled work.

Break, repair and explain

Deliberately violate this boundary: This helper bounds the returned wait only. Production calls should propagate a deadline and use cancellation where supported. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The reference resolves success and rejects the timed-out wait. Your observation distinguishes a stopped wait from cancelled work.

Troubleshoot: My result does not match Timeouts: stop waiting within a budget: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Promise.race can select a deadline result. Clear its timer after settlement. Without cooperative cancellation, the losing operation may continue and produce a remote side effect. Then inspect this limit: This helper bounds the returned wait only. Production calls should propagate a deadline and use cancellation where supported. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/timeouts/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Timeouts: stop waiting within a budget line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Leaving a long queue does not necessarily cancel the order already being prepared.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Does Promise.race cancel the losing Promise? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This helper bounds the returned wait only. Production calls should propagate a deadline and use cancellation where supported. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does Promise.race cancel the losing Promise?

Interview: Does Promise.race cancel the losing Promise? Defend your answer using your actual lab result and this boundary: This helper bounds the returned wait only. Production calls should propagate a deadline and use cancellation where supported.

Quiz: Does Promise.race cancel the losing Promise?

Yes.

Only if it contains a timer.

No.

Reference: No. — Promises do not have automatic cancellation semantics. The underlying API must support cancellation and observe the signal.

Sources:

Node.js: timers: https://nodejs.org/api/timers.html

### Retries: retry only eligible bounded work

Retries can recover a transient read failure or amplify an outage. Retry only known eligible failures, cap attempts and respect the remaining deadline. Writes need explicit repeat-safety.

How it works
This deterministic loop stops on success, stops immediately for permanent failures and caps transient attempts. Real backoff needs jitter, a maximum delay and cancellation within a total budget.

Where the model stops
The example deliberately has no sleep and is a retry decision test, not a production retry implementation.

Make one change
Add an exhaustion case and verify the exact attempt count. Write a timing table for exponential backoff plus jitter within a 2-second total budget; do not retry a non-idempotent write by default.

Mental model: A retry is another visitor at the same busy service desk, not free capacity.

Boundary: The example deliberately has no sleep and is a retry decision test, not a production retry implementation.

Worked example: import assert from 'node:assert/strict';
async function retry(work,max){for(let attempt=1;attempt<=max;attempt++){try{return await work()}catch(e){if(!e.transient||attempt===max)throw e}}}
let calls=0;
assert.equal(await retry(async()=>{if(++calls<3)throw {transient:true};return 'ok'},3),'ok');assert.equal(calls,3);
let bad=0;await assert.rejects(retry(async()=>{bad++;throw new Error('Invalid')},3),/Invalid/);assert.equal(bad,1);
console.log('PASS: bounded transient retry and no permanent retry');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/retry-policy. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add an exhaustion case and verify the exact attempt count. Write a timing table for exponential backoff plus jitter within a 2-second total budget; do not retry a non-idempotent write by default.

Terminal folder: course-labs/advanced/retry-policy

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. This deterministic loop stops on success, stops immediately for permanent failures and caps transient attempts. Real backoff needs jitter, a maximum delay and cancellation within a total budget.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/retry-policy. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Transient failure succeeds on attempt 3; a permanent failure is called once. Exhaustion respects your cap.

Build your change

Add an exhaustion case and verify the exact attempt count. Write a timing table for exponential backoff plus jitter within a 2-second total budget; do not retry a non-idempotent write by default.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Transient failure succeeds on attempt 3; a permanent failure is called once. Exhaustion respects your cap.

Break, repair and explain

Deliberately violate this boundary: The example deliberately has no sleep and is a retry decision test, not a production retry implementation. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Transient failure succeeds on attempt 3; a permanent failure is called once. Exhaustion respects your cap.

Troubleshoot: My result does not match Retries: retry only eligible bounded work: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: This deterministic loop stops on success, stops immediately for permanent failures and caps transient attempts. Real backoff needs jitter, a maximum delay and cancellation within a total budget. Then inspect this limit: The example deliberately has no sleep and is a retry decision test, not a production retry implementation. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/retry-policy/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Retries: retry only eligible bounded work line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A retry is another visitor at the same busy service desk, not free capacity.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Which request is safest to retry by default? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The example deliberately has no sleep and is a retry decision test, not a production retry implementation. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which request is safest to retry by default?

Interview: Which request is safest to retry by default? Defend your answer using your actual lab result and this boundary: The example deliberately has no sleep and is a retry decision test, not a production retry implementation.

Quiz: Which request is safest to retry by default?

Any payment write after an unknown timeout.

A repeat-safe read with a transient failure and remaining budget.

Every validation error forever.

Reference: A repeat-safe read with a transient failure and remaining budget. — Retry safety depends on semantics, failure class and budget. More retries can increase load and duplicate side effects.

Sources:

MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### Outbox: store intent beside the state change

A service can commit a database write and fail before publishing its event. A transactional outbox stores the event intent in the same transaction so a worker can publish it later.

How it works
The SQLite example creates a task and an outbox row together. A worker would read unsent rows and publish them, then mark delivery. A crash between publication and marking can cause a duplicate.

Where the model stops
An outbox provides durable intent with at-least-once delivery patterns, not automatic exactly-once effects at the consumer.

Make one change
Inject an exception between the two inserts and verify neither row commits. Design consumer deduplication using event_id, then describe a crash after publishing but before marking sent.

Mental model: The ledger and its outgoing-mail slip are filed in the same envelope.

Boundary: An outbox provides durable intent with at-least-once delivery patterns, not automatic exactly-once effects at the consumer.

Worked example: import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.executescript('create table tasks(id integer primary key,title text); create table outbox(event_id text primary key,task_id integer);')
 with con:
  con.execute('insert into tasks values(?,?)',(1,'Read'))
  con.execute('insert into outbox values(?,?)',('event-1',1))
 assert con.execute('select count(*) from tasks').fetchone()[0]==1
 assert con.execute('select event_id from outbox').fetchone()[0]=='event-1'
 print('PASS: task and event intent committed together')
finally:
 con.close()


Setup: Download and extract backend.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/outbox. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python sqlite3 / SQLite

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Inject an exception between the two inserts and verify neither row commits. Design consumer deduplication using event_id, then describe a crash after publishing but before marking sent.

Terminal folder: course-labs/advanced/outbox

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The SQLite example creates a task and an outbox row together. A worker would read unsent rows and publish them, then mark delivery. A crash between publication and marking can cause a duplicate.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/outbox. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Both rows commit normally; neither commits in your injected-failure case. Your delivery design explicitly handles duplicate events.

Build your change

Inject an exception between the two inserts and verify neither row commits. Design consumer deduplication using event_id, then describe a crash after publishing but before marking sent.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Both rows commit normally; neither commits in your injected-failure case. Your delivery design explicitly handles duplicate events.

Break, repair and explain

Deliberately violate this boundary: An outbox provides durable intent with at-least-once delivery patterns, not automatic exactly-once effects at the consumer. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Both rows commit normally; neither commits in your injected-failure case. Your delivery design explicitly handles duplicate events.

Troubleshoot: My result does not match Outbox: store intent beside the state change: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The SQLite example creates a task and an outbox row together. A worker would read unsent rows and publish them, then mark delivery. A crash between publication and marking can cause a duplicate. Then inspect this limit: An outbox provides durable intent with at-least-once delivery patterns, not automatic exactly-once effects at the consumer. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/outbox/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Outbox: store intent beside the state change line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The ledger and its outgoing-mail slip are filed in the same envelope.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Why must an outbox consumer still consider duplicates? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An outbox provides durable intent with at-least-once delivery patterns, not automatic exactly-once effects at the consumer. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why must an outbox consumer still consider duplicates?

Interview: Why must an outbox consumer still consider duplicates? Defend your answer using your actual lab result and this boundary: An outbox provides durable intent with at-least-once delivery patterns, not automatic exactly-once effects at the consumer.

Quiz: Why must an outbox consumer still consider duplicates?

A publisher can crash after send and before recording delivery.

SQL always deletes ids.

An outbox forbids transactions.

Reference: A publisher can crash after send and before recording delivery. — The external send and local mark are separate effects. Deduplication and idempotent consumers handle replay.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Queues: reject excess work intentionally

An unbounded in-memory queue turns overload into growing memory use and long waiting times. A capacity limit forces an explicit overload policy: reject, defer or shed lower-priority work.

How it works
Check capacity before enqueueing. Treat queued and in-flight work separately in a real worker. Record rejected work and queue age, not only request success counts.

Where the model stops
This synchronous array is a decision model, not a durable broker. Process failure loses queued data.

Make one change
Add a maximum job age with an injected clock. Define what happens to expired jobs and how the caller learns of rejection. Compare a durable broker with this process-local queue.

Mental model: A waiting room has a limited number of seats and a visible full sign.

Boundary: This synchronous array is a decision model, not a durable broker. Process failure loses queued data.

Worked example: import assert from 'node:assert/strict';
const queue=[];const capacity=2;
function offer(job){if(queue.length>=capacity)return false;queue.push(job);return true}
assert.equal(offer('a'),true);assert.equal(offer('b'),true);assert.equal(offer('c'),false);
assert.equal(queue.shift(),'a');assert.equal(offer('d'),true);assert.deepEqual(queue,['b','d']);
console.log('PASS: reject overload and accept after capacity returns');


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/bounded-queue. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a maximum job age with an injected clock. Define what happens to expired jobs and how the caller learns of rejection. Compare a durable broker with this process-local queue.

Terminal folder: course-labs/advanced/bounded-queue

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Check capacity before enqueueing. Treat queued and in-flight work separately in a real worker. Record rejected work and queue age, not only request success counts.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/bounded-queue. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The third job is rejected and capacity returns after a dequeue. Your expiry policy avoids processing indefinitely stale work.

Build your change

Add a maximum job age with an injected clock. Define what happens to expired jobs and how the caller learns of rejection. Compare a durable broker with this process-local queue.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The third job is rejected and capacity returns after a dequeue. Your expiry policy avoids processing indefinitely stale work.

Break, repair and explain

Deliberately violate this boundary: This synchronous array is a decision model, not a durable broker. Process failure loses queued data. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The third job is rejected and capacity returns after a dequeue. Your expiry policy avoids processing indefinitely stale work.

Troubleshoot: My result does not match Queues: reject excess work intentionally: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Check capacity before enqueueing. Treat queued and in-flight work separately in a real worker. Record rejected work and queue age, not only request success counts. Then inspect this limit: This synchronous array is a decision model, not a durable broker. Process failure loses queued data. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/bounded-queue/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Queues: reject excess work intentionally line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A waiting room has a limited number of seats and a visible full sign.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Why is a capacity bound useful? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This synchronous array is a decision model, not a durable broker. Process failure loses queued data. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why is a capacity bound useful?

Interview: Why is a capacity bound useful? Defend your answer using your actual lab result and this boundary: This synchronous array is a decision model, not a durable broker. Process failure loses queued data.

Quiz: Why is a capacity bound useful?

It guarantees every request is served.

It makes the broker durable.

It limits local backlog and exposes overload deliberately.

Reference: It limits local backlog and exposes overload deliberately. — A bound limits one resource and forces a policy decision. It does not guarantee throughput or durability.

Sources:

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### Observability: define useful service indicators

Logs describe events, metrics summarise measurements and traces connect work across boundaries. Start with a user outcome: successful requests within a latency threshold. Separate reliability from raw traffic volume.

How it works
Count all eligible requests in the denominator. Treat failed requests as bad even when fast. Define the measurement window and exclusions before interpreting a percentage.

Where the model stops
This four-request calculation is a teaching example, not an SLO recommendation or production telemetry pipeline.

Make one change
Add an empty measurement window and decide how to display no data without claiming 100% success. Specify a request-id log and one trace boundary without recording secrets or high-cardinality user ids in metric labels.

Mental model: A dashboard is an instrument panel; first decide which journey the instruments describe.

Boundary: This four-request calculation is a teaching example, not an SLO recommendation or production telemetry pipeline.

Worked example: import assert from 'node:assert/strict';
const requests=[{ok:true,ms:50},{ok:true,ms:90},{ok:false,ms:20},{ok:true,ms:250}];
const good=requests.filter(r=>r.ok&&r.ms<=100).length;
const indicator=good/requests.length;
assert.equal(indicator,0.5);
console.log('Good within threshold: '+good+'/'+requests.length);


Setup: Download and extract backend.zip. Node.js 22+ (supported LTS recommended). No npm package is required. Run node --version to check the runtime. Open a terminal in course-labs/advanced/service-indicators. The supplied reference file is exercise.mjs. Read it before running node exercise.mjs. Keep a copy before editing.

Tools for this exercise: Node.js

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add an empty measurement window and decide how to display no data without claiming 100% success. Specify a request-id log and one trace boundary without recording secrets or high-cardinality user ids in metric labels.

Terminal folder: course-labs/advanced/service-indicators

```
node exercise.mjs
```

Predict before running

Read exercise.mjs. Write the expected output and identify the state changed by this example. Count all eligible requests in the denominator. Treat failed requests as bad even when fast. Define the measurement window and exclusions before interpreting a percentage.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/service-indicators. This checks the reference behaviour only.

```
node exercise.mjs
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Two of four requests meet the combined rule. Your no-data state is distinct from both success and failure.

Build your change

Add an empty measurement window and decide how to display no data without claiming 100% success. Specify a request-id log and one trace boundary without recording secrets or high-cardinality user ids in metric labels.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Two of four requests meet the combined rule. Your no-data state is distinct from both success and failure.

Break, repair and explain

Deliberately violate this boundary: This four-request calculation is a teaching example, not an SLO recommendation or production telemetry pipeline. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Two of four requests meet the combined rule. Your no-data state is distinct from both success and failure.

Troubleshoot: My result does not match Observability: define useful service indicators: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Count all eligible requests in the denominator. Treat failed requests as bad even when fast. Define the measurement window and exclusions before interpreting a percentage. Then inspect this limit: This four-request calculation is a teaching example, not an SLO recommendation or production telemetry pipeline. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/service-indicators/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Observability: define useful service indicators line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A dashboard is an instrument panel; first decide which journey the instruments describe.

seeker: Prepare a coursework example for Backend Engineer. Answer this interview question before revealing the rubric: Should a fast failed request count as good in this success-and-latency indicator? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This four-request calculation is a teaching example, not an SLO recommendation or production telemetry pipeline. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Should a fast failed request count as good in this success-and-latency indicator?

Interview: Should a fast failed request count as good in this success-and-latency indicator? Defend your answer using your actual lab result and this boundary: This four-request calculation is a teaching example, not an SLO recommendation or production telemetry pipeline.

Quiz: Should a fast failed request count as good in this success-and-latency indicator?

Yes, it was fast.

No, both conditions must hold.

Only during an outage.

Reference: No, both conditions must hold. — The indicator describes a successful user outcome within a threshold. Fast errors do not meet that outcome.

Sources:

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### State and recovery

State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. In this role, work through: Key k1/title A twice gives one task; k1/title B is rejected. The practical workshop develops this into: Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Role application: A numbered claim ticket can retrieve the same parcel without ordering another one.

Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict.

Worked example: Key k1/title A twice gives one task; k1/title B is rejected.

Shared foundation example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Backend Engineer: Key k1/title A twice gives one task; k1/title B is rejected.

Predict the worked case

Read this case without running a tool: Key k1/title A twice gives one task; k1/title B is rejected. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state and recovery.

Connect the concept to the role

Apply this rule: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database also fails; persistence needs backups and tested recovery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state and recovery to this case: Key k1/title A twice gives one task; k1/title B is rejected. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Key k1/title A twice gives one task; k1/title B is rejected. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for State and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state and recovery. Use the glossary below, then write your prediction for: Key k1/title A twice gives one task; k1/title B is rejected. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain state and recovery using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state and recovery to a system or workflow you know. Explain state and recovery using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Name two things required before calling this service production ready.

Interview: Explain state and recovery using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops.

Quiz: After the Idempotent creation rehearsal, check this foundation: A successful operation exists only in process memory. The process restarts. What can you promise?

The success response guarantees recovery after restart.

A retry will always reconstruct the original state.

Nothing about retention without a persistence and recovery design.

Reference: Nothing about retention without a persistence and recovery design. — An acknowledgment is not a storage guarantee. Identify the persistence boundary and verify restoration.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Idempotent creation

Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict. In this role, work through: Key k1/title A twice gives one task; k1/title B is rejected. The practical workshop develops this into: Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

Mental model: A numbered claim ticket can retrieve the same parcel without ordering another one.

Boundary: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.

Worked example: Key k1/title A twice gives one task; k1/title B is rejected.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Backend Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Key k1/title A twice gives one task; k1/title B is rejected. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

```
node app.mjs test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Exactly one task for two identical retries; a conflict response for changed content.

Role workshop · debug and verify

If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save idempotency tests and a durable-storage design note. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Exactly one task for two identical retries; a conflict response for changed content.

Expected: Exactly one task for two identical retries; a conflict response for changed content.

Troubleshoot: The role exercise differs from the prediction: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: idempotency tests and a durable-storage design note; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent creation. Use the glossary below, then write your prediction for: Key k1/title A twice gives one task; k1/title B is rejected. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain idempotent creation using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent creation to a system or workflow you know. Explain idempotent creation using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.

Interview: Explain idempotent creation using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Key k1/title A twice gives one task; k1/title B is rejected.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Exactly one task for two identical retries; a conflict response for changed content.

Reference: Exactly one task for two identical retries; a conflict response for changed content. — Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict. Exactly one task for two identical retries; a conflict response for changed content.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
