# Backend Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in Backend Engineer: Use the concept to complete this role exercise: Document GET and POST request/response examples

HTTP resource contracts: A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier.

### Request and response

A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. In this role, work through: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. The practical workshop develops this into: Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Role application: A library catalog number stays attached to a book when the shelf order changes.

A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier.

Worked example: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

Shared foundation example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Backend Engineer: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

Predict the worked case

Read this case without running a tool: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in request and response.

Connect the concept to the role

Apply this rule: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Networks can time out; sending an order does not prove it was fulfilled.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies request and response to this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Request and response; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request and response. Use the glossary below, then write your prediction for: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain request and response using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request and response to a system or workflow you know. Explain request and response using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Draw the request and response for adding one task.

Interview: Explain request and response using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops.

Quiz: After the HTTP resource contracts rehearsal, check this foundation: A request returns HTTP 404. Which boundary has evidence of working?

An HTTP server returned a response; inspect the route next.

The request never reached any HTTP server.

The server has confirmed that the resource exists.

Reference: An HTTP server returned a response; inspect the route next. — 404 is an HTTP response, not a transport timeout. It does not prove which component generated it or that the business operation succeeded.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### HTTP resource contracts

A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier. In this role, work through: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. The practical workshop develops this into: Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

Mental model: A library catalog number stays attached to a book when the shelf order changes.

Boundary: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.

Worked example: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Backend Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use curl or DevTools against app.mjs for those three requests. Save the bodies and confirm failed requests do not change GET /api/tasks. Write an API contract table including content type and ID type.

```
node app.mjs
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One successful record and zero records from the two failures.

Role workshop · debug and verify

If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save api-contract.md and three reproducible requests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One successful record and zero records from the two failures.

Expected: One successful record and zero records from the two failures.

Troubleshoot: The role exercise differs from the prediction: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: api-contract.md and three reproducible requests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with http resource contracts. Use the glossary below, then write your prediction for: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain http resource contracts using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate http resource contracts to a system or workflow you know. Explain http resource contracts using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If malformed JSON crashes the process, move parsing into the handled validation boundary and rerun the success case afterward.

Interview: Explain http resource contracts using this case: POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? POST a valid title gives 201; malformed JSON gives 400; an unknown path gives 404.

One successful record and zero records from the two failures.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: One successful record and zero records from the two failures. — A resource contract includes methods, paths, status codes and validation behavior. IDs identify records; their position in a displayed array is not a reliable public identifier. One successful record and zero records from the two failures.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in Backend Engineer: Use the concept to complete this role exercise: Specify pagination and stable identifiers for a task API

Cursor pagination: A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy.

### Validation at a boundary

Check input before storing or using it. Client checks help people; the server must also enforce the rule. In this role, work through: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. The practical workshop develops this into: Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Role application: A bookmark names the last item read instead of counting pages in a changing binder.

A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy.

Worked example: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Shared foundation example: A blank title receives 400 and does not change task count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Backend Engineer: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Predict the worked case

Read this case without running a tool: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in validation at a boundary.

Connect the concept to the role

Apply this rule: Check input before storing or using it. Client checks help people; the server must also enforce the rule. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid input can still be unauthorized; validation is not access control.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies validation at a boundary to this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Validation at a boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with validation at a boundary. Use the glossary below, then write your prediction for: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain validation at a boundary using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate validation at a boundary to a system or workflow you know. Explain validation at a boundary using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Explain validation at a boundary using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops.

Quiz: After the Cursor pagination rehearsal, check this foundation: A browser rejects a blank field. A second client calls the API directly. Where must the same business rule be enforced?

Only in the browser to avoid duplicate logic.

At the server boundary before state changes.

Only after storing the input, in the dashboard.

Reference: At the server boundary before state changes. — Client checks improve feedback; the server must protect its contract for every caller.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Cursor pagination

A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy. In this role, work through: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. The practical workshop develops this into: Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

Mental model: A bookmark names the last item read instead of counting pages in a changing binder.

Boundary: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.

Worked example: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Backend Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extend GET with after and limit. Sort by immutable ID, reject nonnumeric or excessive limits and return nextCursor. Test an empty final page and an insertion between page requests. State whether you guarantee a snapshot.

```
node app.mjs test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Role workshop · debug and verify

Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save pagination tests, request examples and consistency contract. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Expected: Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Troubleshoot: The role exercise differs from the prediction: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: pagination tests, request examples and consistency contract; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cursor pagination. Use the glossary below, then write your prediction for: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain cursor pagination using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cursor pagination to a system or workflow you know. Explain cursor pagination using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Repeated pages usually mean the filter includes the cursor item instead of selecting IDs greater than it.

Interview: Explain cursor pagination using this case: IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5]. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? IDs 1 through 5 with limit 2 produce [1,2], [3,4], [5].

Ignore the failing case and keep only the successful screenshot.

Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Treat any successful command as proof that all business and access rules passed.

Reference: Each original ID appears once in the unchanged fixture; malformed limit receives 400. — A page boundary should use stable ordering. Offset pagination can skip or repeat records when preceding rows change; a cursor encodes where to continue under a documented ordering policy. Each original ID appears once in the unchanged fixture; malformed limit receives 400.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in Backend Engineer: Use the concept to complete this role exercise: Design idempotent creation, rate limits and recovery tests

Idempotent creation: Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict.

### State and recovery

State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. In this role, work through: Key k1/title A twice gives one task; k1/title B is rejected. The practical workshop develops this into: Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Role application: A numbered claim ticket can retrieve the same parcel without ordering another one.

Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict.

Worked example: Key k1/title A twice gives one task; k1/title B is rejected.

Shared foundation example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Backend Engineer: Key k1/title A twice gives one task; k1/title B is rejected.

Predict the worked case

Read this case without running a tool: Key k1/title A twice gives one task; k1/title B is rejected. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state and recovery.

Connect the concept to the role

Apply this rule: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database also fails; persistence needs backups and tested recovery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state and recovery to this case: Key k1/title A twice gives one task; k1/title B is rejected. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Key k1/title A twice gives one task; k1/title B is rejected. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for State and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state and recovery. Use the glossary below, then write your prediction for: Key k1/title A twice gives one task; k1/title B is rejected. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain state and recovery using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state and recovery to a system or workflow you know. Explain state and recovery using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Name two things required before calling this service production ready.

Interview: Explain state and recovery using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops.

Quiz: After the Idempotent creation rehearsal, check this foundation: A successful operation exists only in process memory. The process restarts. What can you promise?

The success response guarantees recovery after restart.

A retry will always reconstruct the original state.

Nothing about retention without a persistence and recovery design.

Reference: Nothing about retention without a persistence and recovery design. — An acknowledgment is not a storage guarantee. Identify the persistence boundary and verify restoration.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

### Idempotent creation

Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict. In this role, work through: Key k1/title A twice gives one task; k1/title B is rejected. The practical workshop develops this into: Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

Mental model: A numbered claim ticket can retrieve the same parcel without ordering another one.

Boundary: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.

Worked example: Key k1/title A twice gives one task; k1/title B is rejected.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Node.js HTTP and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Backend Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Key k1/title A twice gives one task; k1/title B is rejected. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add an Idempotency-Key map to the local service. Store the normalized request and result atomically within this single-process exercise. Test duplicate and conflicting requests and document why a production database must enforce uniqueness.

```
node app.mjs test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Exactly one task for two identical retries; a conflict response for changed content.

Role workshop · debug and verify

If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save idempotency tests and a durable-storage design note. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Exactly one task for two identical retries; a conflict response for changed content.

Expected: Exactly one task for two identical retries; a conflict response for changed content.

Troubleshoot: The role exercise differs from the prediction: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: idempotency tests and a durable-storage design note; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent creation. Use the glossary below, then write your prediction for: Key k1/title A twice gives one task; k1/title B is rejected. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Backend Engineer role interview. Explain idempotent creation using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent creation to a system or workflow you know. Explain idempotent creation using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If two requests create records, inspect the check-and-write boundary; a distributed system needs a transaction or unique constraint.

Interview: Explain idempotent creation using this case: Key k1/title A twice gives one task; k1/title B is rejected. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Key k1/title A twice gives one task; k1/title B is rejected.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Exactly one task for two identical retries; a conflict response for changed content.

Reference: Exactly one task for two identical retries; a conflict response for changed content. — Retries can occur after a server commits but before the client sees the response. An idempotency key must be associated with both the request identity and its result; a reused key with a changed payload is a conflict. Exactly one task for two identical retries; a conflict response for changed content.

Sources:

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
