import assert from 'node:assert/strict';
const queue=[];const capacity=2;
function offer(job){if(queue.length>=capacity)return false;queue.push(job);return true}
assert.equal(offer('a'),true);assert.equal(offer('b'),true);assert.equal(offer('c'),false);
assert.equal(queue.shift(),'a');assert.equal(offer('d'),true);assert.deepEqual(queue,['b','d']);
console.log('PASS: reject overload and accept after capacity returns');
