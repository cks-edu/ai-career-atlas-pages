import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.executescript('create table tasks(id integer primary key,title text); create table outbox(event_id text primary key,task_id integer);')
 with con:
  con.execute('insert into tasks values(?,?)',(1,'Read'))
  con.execute('insert into outbox values(?,?)',('event-1',1))
 assert con.execute('select count(*) from tasks').fetchone()[0]==1
 assert con.execute('select event_id from outbox').fetchone()[0]=='event-1'
 print('PASS: task and event intent committed together')
finally:
 con.close()
