import assert from 'node:assert/strict';
const requests=[{ok:true,ms:50},{ok:true,ms:90},{ok:false,ms:20},{ok:true,ms:250}];
const good=requests.filter(r=>r.ok&&r.ms<=100).length;
const indicator=good/requests.length;
assert.equal(indicator,0.5);
console.log('Good within threshold: '+good+'/'+requests.length);
