import assert from 'node:assert/strict';
async function retry(work,max){for(let attempt=1;attempt<=max;attempt++){try{return await work()}catch(e){if(!e.transient||attempt===max)throw e}}}
let calls=0;
assert.equal(await retry(async()=>{if(++calls<3)throw {transient:true};return 'ok'},3),'ok');assert.equal(calls,3);
let bad=0;await assert.rejects(retry(async()=>{bad++;throw new Error('Invalid')},3),/Invalid/);assert.equal(bad,1);
console.log('PASS: bounded transient retry and no permanent retry');
