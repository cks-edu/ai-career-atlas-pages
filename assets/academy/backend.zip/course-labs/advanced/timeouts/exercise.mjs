import assert from 'node:assert/strict';
async function deadline(work,ms){let timer;try{return await Promise.race([work,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Deadline')),ms)})])}finally{clearTimeout(timer)}}
assert.equal(await deadline(Promise.resolve('ok'),100),'ok');
await assert.rejects(deadline(new Promise(()=>{}),5),/Deadline/);
console.log('PASS: immediate success and bounded wait');
