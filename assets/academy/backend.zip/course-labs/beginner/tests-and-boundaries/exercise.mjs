import assert from 'node:assert/strict';
const allowed=size=>Number.isInteger(size)&&size>=1&&size<=100;
for(const [value,want] of [[0,false],[1,true],[100,true],[101,false],[1.5,false],['1',false]]) assert.equal(allowed(value),want,String(value));
console.log('PASS: lower/upper boundaries, fractional and string inputs');
