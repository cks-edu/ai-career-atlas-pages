import assert from 'node:assert/strict';
const tasks=new Map([[1,{id:1,title:'Read'}]]);
function read(id){return tasks.has(id)?{status:200,body:tasks.get(id)}:{status:404,body:{error:'Task not found'}};}
assert.equal(read(1).status,200);
assert.equal(read(2).status,404);
console.log(JSON.stringify(read(2)));
