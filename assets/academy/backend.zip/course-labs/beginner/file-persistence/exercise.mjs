import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os'; import {join} from 'node:path';
import assert from 'node:assert/strict';
const dir=await mkdtemp(join(tmpdir(),'skillbadi-backend-'));
try {
 const path=join(dir,'tasks.json'); const tasks=[{id:1,title:'Read'}];
 await writeFile(path,JSON.stringify(tasks));
 assert.deepEqual(JSON.parse(await readFile(path,'utf8')),tasks);
 console.log('PASS: file round trip');
}finally{await rm(dir,{recursive:true,force:true})}
