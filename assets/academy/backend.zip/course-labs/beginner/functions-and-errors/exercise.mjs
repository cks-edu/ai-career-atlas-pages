import assert from 'node:assert/strict';
function title(value) {
 if(typeof value !== 'string') throw new TypeError('Expected text');
 const clean=value.trim(); if(clean.length<1 || clean.length>80) throw new Error('Length 1 to 80');
 return clean;
}
assert.equal(title(' Read '),'Read');
assert.throws(()=>title(null),TypeError);
assert.throws(()=>title('x'.repeat(81)),/Length/);
console.log('PASS: clean text, wrong type, length boundary');
