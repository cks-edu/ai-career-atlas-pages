import assert from 'node:assert/strict';
function parse(text){
 let value; try{value=JSON.parse(text)}catch{return {ok:false,error:'Invalid JSON'}}
 if(!value || Array.isArray(value) || typeof value.title!=='string' || !value.title.trim()) return {ok:false,error:'Title required'};
 return {ok:true,title:value.title.trim()};
}
assert.equal(parse('{').error,'Invalid JSON');
assert.equal(parse('null').error,'Title required');
assert.deepEqual(parse('{"title":" Read "}'),{ok:true,title:'Read'});
console.log('PASS: syntax and schema are separate checks');
