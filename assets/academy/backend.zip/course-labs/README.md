# Backend Engineer — core lessons

Learn input rules, HTTP outcomes, persistence and testing before transactions, repeat-safe writes, timeouts, queues and observability. The reference code deliberately separates a pure policy model from a real I/O check.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A task service with bounded input, explicit errors, data integrity, retry policy and observed failure evidence.
