import assert from 'node:assert/strict';
const usage=new Map();
function allow(user,now){const window=Math.floor(now/1000);const old=usage.get(user);const n=old?.window===window?old.count:0;if(n>=2)return false;usage.set(user,{window,count:n+1});return true}
assert.equal(allow('a',0),true);assert.equal(allow('a',1),true);assert.equal(allow('a',2),false);
assert.equal(allow('b',2),true);assert.equal(allow('a',1000),true);
console.log('PASS: limit, caller isolation and next window');
