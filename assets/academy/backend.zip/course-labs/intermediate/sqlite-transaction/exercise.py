import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.execute('create table accounts(id integer primary key, balance integer check(balance >= 0))')
 con.executemany('insert into accounts values(?,?)',[(1,100),(2,50)])
 con.commit()
 try:
  with con:
   con.execute('update accounts set balance=balance-200 where id=1')
   con.execute('update accounts set balance=balance+200 where id=2')
 except sqlite3.IntegrityError:
  pass
 assert con.execute('select balance from accounts order by id').fetchall()==[(100,),(50,)]
 print('PASS: failed transfer leaves both committed balances unchanged')
finally:
 con.close()
