import sqlite3
con=sqlite3.connect(':memory:')
try:
 con.execute('create table tasks(title text)')
 attack="x'); drop table tasks; --"
 con.execute('insert into tasks(title) values(?)',(attack,))
 assert con.execute('select title from tasks').fetchone()[0]==attack
 assert con.execute('select count(*) from tasks').fetchone()[0]==1
 print('PASS: SQL-looking input stored as literal data')
finally:
 con.close()
