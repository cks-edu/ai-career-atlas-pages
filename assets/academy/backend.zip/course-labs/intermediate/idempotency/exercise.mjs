import assert from 'node:assert/strict';
const seen=new Map();let writes=0;
function create(key,title){
 if(seen.has(key)){const old=seen.get(key);if(old.title!==title)throw new Error('Key conflict');return old.result}
 const result={id:++writes,title};seen.set(key,{title,result});return result;
}
assert.deepEqual(create('a','Read'),create('a','Read'));
assert.equal(writes,1);assert.throws(()=>create('a','Other'),/conflict/);
console.log('PASS: duplicate returns original; mismatched replay conflicts');
