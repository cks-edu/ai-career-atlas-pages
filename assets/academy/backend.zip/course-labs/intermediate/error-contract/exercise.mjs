import assert from 'node:assert/strict';
function publicError(error,requestId){
 return error.code==='INVALID_TITLE'?{status:422,body:{code:error.code,requestId}}:{status:500,body:{code:'INTERNAL',requestId}};
}
const r=publicError(new Error('password=secret'),'req-7');
assert.equal(r.status,500);assert.equal(JSON.stringify(r).includes('secret'),false);
assert.equal(publicError({code:'INVALID_TITLE'},'req-8').status,422);
console.log('PASS: classified error and public redaction');
