# AI query contract and semantic-layer ADR

Project: Governed metrics for AI analytics
Status: blank work product — not completed evidence

## Purpose and audience
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.

## Required content
Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

## Failure evidence
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
