# Reconciliation fixtures

Project: Governed metrics for AI analytics
Status: blank work product — not completed evidence

## Purpose and audience
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.

## Required content
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

## Failure evidence
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
