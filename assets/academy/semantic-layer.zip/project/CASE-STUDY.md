# Governed metrics for AI analytics

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

## Limitations and next iteration
Add a governed natural-language mapping with explicit clarification for ambiguous metric names.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
