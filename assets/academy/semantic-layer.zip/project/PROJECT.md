# Governed metrics for AI analytics

Career: Semantic-layer engineering for AI analytics
Reviewed: 2026-10-22

Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.

## Prerequisites
SQL, dimensional modeling and metric definitions.

## Included starter versus your implementation
DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Metric definitions and tested SQL/dbt models — artifact-1.md
2. Reconciliation fixtures — artifact-2.md
3. AI query contract and semantic-layer ADR — artifact-3.md

## Troubleshooting
- Missing CSV: run from the extracted folder.
- Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
- Wrong totals: check units, duplicate joins and whether failures are included.

## Extension
Add a governed natural-language mapping with explicit clarification for ambiguous metric names.

## Primary learning resources
- DuckDB: https://duckdb.org/docs/stable/clients/python/overview — Open source · local; CSV ingestion, SQL transforms and reproducible analysis.
- dbt: https://docs.getdbt.com/docs/introduction — Open source Core · commercial cloud optional; Versioned transformations, lineage and data tests.
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
