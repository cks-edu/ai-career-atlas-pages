## advanced — Governed AI queries

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Governed AI queries
Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning.
Mental model: A translator uses an agreed dictionary and asks when a word has two meanings.
Boundary: SQL syntax validity does not prove semantic correctness or authorization.
Worked example: For active customers, ask which activity window applies or use the documented default and disclose it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Governed metrics for AI analytics
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Recall: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. Identify one observation that would contradict your claim.

### Terms
Governed AI queries: Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning.
API: Application programming interface: the agreed way one program requests work or data from another.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.
Add a governed natural-language mapping with explicit clarification for ambiguous metric names.
Deliverables: Metric definitions and tested SQL/dbt models; Reconciliation fixtures; AI query contract and semantic-layer ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A reviewer must reproduce one result and identify which capabilities you implemented. Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

### Interview
Explain your advanced solution for Semantic-layer engineering for AI analytics. Use this scenario: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Review: Start with the task and permitted scope. Explain governed ai queries: Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning. Show the input and observed output, then address Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Metric definitions and tested SQL/dbt models; Reconciliation fixtures; AI query contract and semantic-layer ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

