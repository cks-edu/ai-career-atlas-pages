# SAMPLE — Metric contract and reconciliation worksheet
Role: Semantic-layer engineering for AI analytics
Case: Revenue doubles after a join
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The toy semantic model permits no duplicate contribution of an order to the revenue metric.

## Evidence table
| Record | duplicate_contributions (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three queries inflate revenue through a grain-mismatched join.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Define grain and join keys explicitly and aggregate at the correct business level.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in semantic-layer engineering for ai analytics.
Before release: Compare reference SQL totals and edge cases for dates, refunds and repeated line items.

## Design choice and trade-off
Define metric semantics before natural-language access; restrict queries to tested governed models.
An apparently fluent analytics answer can still be wrong when the underlying metric definition is inconsistent.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Governed metrics catalog: Two dashboards return the same result for the same question.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
