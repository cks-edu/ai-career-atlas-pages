## beginner — Metric definitions and grain

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Metric definitions and grain
Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL.
Mental model: Two cooks cannot compare recipes if one cup means a different volume.
Boundary: A metric name alone rarely captures all business rules.
Worked example: Revenue per order differs from revenue per line item; state the grain before joining order and item tables.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Revenue doubles after a join
The toy semantic model permits no duplicate contribution of an order to the revenue metric. Three queries inflate revenue through a grain-mismatched join. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level.
Recall: Compare reference SQL totals and edge cases for dates, refunds and repeated line items. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Metric definitions and grain: Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A semantic layer gives business measures consistent definitions. Different definitions can produce different correct-looking answers.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use three fictional records: A logged in but studied nothing; B completed a lesson this month; C completed a lesson last year.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

3. Try step 2
Calculate active learners under “logged in this month” and “completed a lesson this month”, stating any missing login information.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

4. Try step 3
Write one chosen definition with time window, event and time-zone convention.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

5. Explain and check your result
The definition fixes the meaning of “active”; unknown login data is not silently counted as activity or inactivity. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A metric definition and a table explaining which records qualify or remain unknown. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The toy semantic model permits no duplicate contribution of an order to the revenue metric. Apply this toy-case rule manually: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three queries inflate revenue through a grain-mismatched join. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Semantic-layer engineering for AI analytics.
Use three fictional records: A logged in but studied nothing; B completed a lesson this month; C completed a lesson last year.
Calculate active learners under “logged in this month” and “completed a lesson this month”, stating any missing login information.
Write one chosen definition with time window, event and time-zone convention.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A metric definition and a table explaining which records qualify or remain unknown. Include beginner-worksheet.md and your completed Metric contract and reconciliation worksheet.
Check: The definition fixes the meaning of “active”; unknown login data is not silently counted as activity or inactivity.

### Interview
Explain your beginner solution for Semantic-layer engineering for AI analytics. Use this scenario: The toy semantic model permits no duplicate contribution of an order to the revenue metric.
Review: Start with the task and permitted scope. Explain metric definitions and grain: Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL. Show the input and observed output, then address Define grain and join keys explicitly and aggregate at the correct business level. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A metric definition and a table explaining which records qualify or remain unknown. Include beginner-worksheet.md and your completed Metric contract and reconciliation worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

