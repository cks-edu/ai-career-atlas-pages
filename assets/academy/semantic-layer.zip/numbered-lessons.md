# Semantic-layer engineering for AI analytics — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Metric definitions and grain: Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Metric definitions and grain

Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL. In this role, work through: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Two cooks cannot compare recipes if one cup means a different volume.

Boundary: A metric name alone rarely captures all business rules.

Worked example: Revenue per order differs from revenue per line item; state the grain before joining order and item tables.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); dbt (Open source Core · commercial cloud optional); FastAPI (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Semantic-layer engineering for AI analytics: Revenue per order differs from revenue per line item; state the grain before joining order and item tables.

Predict the worked case

Read this case without running a tool: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in metric definitions and grain.

Connect the concept to the role

Apply this rule: Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A metric name alone rarely captures all business rules.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies metric definitions and grain to this case: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Metric definitions and grain; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with metric definitions and grain. Use the glossary below, then write your prediction for: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Semantic-layer engineering for AI analytics role interview. Explain metric definitions and grain using this case: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate metric definitions and grain to a system or workflow you know. Explain metric definitions and grain using this case: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain metric definitions and grain using this case: Revenue per order differs from revenue per line item; state the grain before joining order and item tables. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Revenue per order differs from revenue per line item; state the grain before joining order and item tables.

Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL. — Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL. A metric name alone rarely captures all business rules.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

dbt: https://docs.getdbt.com/docs/introduction

FastAPI: https://fastapi.tiangolo.com/tutorial/

dbt: https://docs.getdbt.com/docs/introduction

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

### Diagnose: Revenue doubles after a join

The toy semantic model permits no duplicate contribution of an order to the revenue metric. Three queries inflate revenue through a grain-mismatched join. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Two cooks cannot compare recipes if one cup means a different volume.

Revenue per order differs from revenue per line item; state the grain before joining order and item tables.

Worked example: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); dbt (Open source Core · commercial cloud optional); FastAPI (Open source · local)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The toy semantic model permits no duplicate contribution of an order to the revenue metric. Three queries inflate revenue through a grain-mismatched join. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The toy semantic model permits no duplicate contribution of an order to the revenue metric. Apply this toy-case rule manually: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A semantic layer gives business measures consistent definitions. Different definitions can produce different correct-looking answers.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use three fictional records: A logged in but studied nothing; B completed a lesson this month; C completed a lesson last year.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

Preparation · Try step 2

Calculate active learners under “logged in this month” and “completed a lesson this month”, stating any missing login information.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

Preparation · Try step 3

Write one chosen definition with time window, event and time-zone convention.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

Preparation · Explain and check your result

The definition fixes the meaning of “active”; unknown login data is not silently counted as activity or inactivity. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A metric definition and a table explaining which records qualify or remain unknown. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The toy semantic model permits no duplicate contribution of an order to the revenue metric. Apply this toy-case rule manually: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three queries inflate revenue through a grain-mismatched join. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three queries inflate revenue through a grain-mismatched join. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: revenue doubles after a join. Use the glossary below, then write your prediction for: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Semantic-layer engineering for AI analytics role interview. Explain diagnose: revenue doubles after a join using this case: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: revenue doubles after a join to a system or workflow you know. Explain diagnose: revenue doubles after a join using this case: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Compare reference SQL totals and edge cases for dates, refunds and repeated line items. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: revenue doubles after a join using this case: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level. State the evidence, one alternative and where the mental model stops.

Quiz: Revenue doubles after a join: The toy semantic model permits no duplicate contribution of an order to the revenue metric.

Change the acceptance rule after seeing an inconvenient result.

Define grain and join keys explicitly and aggregate at the correct business level.

Omit failed cases and report only the successful demonstrations.

Reference: Define grain and join keys explicitly and aggregate at the correct business level. — Define grain and join keys explicitly and aggregate at the correct business level. Compare reference SQL totals and edge cases for dates, refunds and repeated line items.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

dbt: https://docs.getdbt.com/docs/introduction

FastAPI: https://fastapi.tiangolo.com/tutorial/

dbt: https://docs.getdbt.com/docs/introduction

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, dimensional modeling and metric definitions.

Terms:

Join correctness: Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Join correctness

Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries. In this role, work through: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Combining two guest lists can accidentally count one person twice.

Boundary: Passing a small example does not prove every production relationship is clean.

Worked example: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, dimensional modeling and metric definitions.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); dbt (Open source Core · commercial cloud optional); FastAPI (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Semantic-layer engineering for AI analytics: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing.

Predict the worked case

Read this case without running a tool: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in join correctness.

Connect the concept to the role

Apply this rule: Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Passing a small example does not prove every production relationship is clean.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies join correctness to this case: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Join correctness; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with join correctness. Use the glossary below, then write your prediction for: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Semantic-layer engineering for AI analytics role interview. Explain join correctness using this case: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate join correctness to a system or workflow you know. Explain join correctness using this case: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain join correctness using this case: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing.

Treat a passing starter as proof of the whole role workflow.

Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries.

Ignore the failure because the tool produced an output.

Reference: Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries. — Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries. Passing a small example does not prove every production relationship is clean.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

dbt: https://docs.getdbt.com/docs/introduction

FastAPI: https://fastapi.tiangolo.com/tutorial/

dbt: https://docs.getdbt.com/docs/introduction

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

### Integrate: Governed metrics for AI analytics

Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests. In this role, work through: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: Combining two guest lists can accidentally count one person twice.

One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing.

Worked example: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); dbt (Open source Core · commercial cloud optional); FastAPI (Open source · local)

Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The toy semantic model permits no duplicate contribution of an order to the revenue metric. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Metric definitions and tested SQL/dbt models; Reconciliation fixtures. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: governed metrics for ai analytics. Use the glossary below, then write your prediction for: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Semantic-layer engineering for AI analytics role interview. Explain integrate: governed metrics for ai analytics using this case: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: governed metrics for ai analytics to a system or workflow you know. Explain integrate: governed metrics for ai analytics using this case: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. Identify one observation that would contradict your claim.

Interview: Explain integrate: governed metrics for ai analytics using this case: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Governed metrics for AI analytics at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

Reference: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. — Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

dbt: https://docs.getdbt.com/docs/introduction

FastAPI: https://fastapi.tiangolo.com/tutorial/

dbt: https://docs.getdbt.com/docs/introduction

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Governed AI queries: Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning.

API: Application programming interface: the agreed way one program requests work or data from another.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Governed AI queries

Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning. In this role, work through: For active customers, ask which activity window applies or use the documented default and disclose it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A translator uses an agreed dictionary and asks when a word has two meanings.

Boundary: SQL syntax validity does not prove semantic correctness or authorization.

Worked example: For active customers, ask which activity window applies or use the documented default and disclose it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); dbt (Open source Core · commercial cloud optional); FastAPI (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Semantic-layer engineering for AI analytics: For active customers, ask which activity window applies or use the documented default and disclose it.

Predict the worked case

Read this case without running a tool: For active customers, ask which activity window applies or use the documented default and disclose it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in governed ai queries.

Connect the concept to the role

Apply this rule: Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: SQL syntax validity does not prove semantic correctness or authorization.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies governed ai queries to this case: For active customers, ask which activity window applies or use the documented default and disclose it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For active customers, ask which activity window applies or use the documented default and disclose it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Governed AI queries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with governed ai queries. Use the glossary below, then write your prediction for: For active customers, ask which activity window applies or use the documented default and disclose it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Semantic-layer engineering for AI analytics role interview. Explain governed ai queries using this case: For active customers, ask which activity window applies or use the documented default and disclose it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate governed ai queries to a system or workflow you know. Explain governed ai queries using this case: For active customers, ask which activity window applies or use the documented default and disclose it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain governed ai queries using this case: For active customers, ask which activity window applies or use the documented default and disclose it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For active customers, ask which activity window applies or use the documented default and disclose it.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning.

Reference: Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning. — Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning. SQL syntax validity does not prove semantic correctness or authorization.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

dbt: https://docs.getdbt.com/docs/introduction

FastAPI: https://fastapi.tiangolo.com/tutorial/

dbt: https://docs.getdbt.com/docs/introduction

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

### Defend: Governed metrics for AI analytics

Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters. In this role, work through: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A translator uses an agreed dictionary and asks when a word has two meanings.

For active customers, ask which activity window applies or use the documented default and disclose it.

Worked example: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); dbt (Open source Core · commercial cloud optional); FastAPI (Open source · local)

Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A reviewer must reproduce one result and identify which capabilities you implemented. Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Metric definitions and tested SQL/dbt models; Reconciliation fixtures; AI query contract and semantic-layer ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: governed metrics for ai analytics. Use the glossary below, then write your prediction for: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Semantic-layer engineering for AI analytics role interview. Explain defend: governed metrics for ai analytics using this case: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: governed metrics for ai analytics to a system or workflow you know. Explain defend: governed metrics for ai analytics using this case: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. Identify one observation that would contradict your claim.

Interview: Explain defend: governed metrics for ai analytics using this case: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Governed metrics for AI analytics at this level?

Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated. — Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated. Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

dbt: https://docs.getdbt.com/docs/introduction

FastAPI: https://fastapi.tiangolo.com/tutorial/

dbt: https://docs.getdbt.com/docs/introduction

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
