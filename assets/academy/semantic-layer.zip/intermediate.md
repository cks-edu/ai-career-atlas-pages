## intermediate — Join correctness

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, dimensional modeling and metric definitions.

### Join correctness
Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries.
Mental model: Combining two guest lists can accidentally count one person twice.
Boundary: Passing a small example does not prove every production relationship is clean.
Worked example: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Governed metrics for AI analytics
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Recall: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. Identify one observation that would contradict your claim.

### Terms
Join correctness: Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The toy semantic model permits no duplicate contribution of an order to the revenue metric. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.
Deliverables: Metric definitions and tested SQL/dbt models; Reconciliation fixtures. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Semantic-layer engineering for AI analytics. Use this scenario: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Review: Start with the task and permitted scope. Explain join correctness: Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries. Show the input and observed output, then address Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Metric definitions and tested SQL/dbt models; Reconciliation fixtures. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

