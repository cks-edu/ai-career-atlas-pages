# Semantic-layer engineering for AI analytics

AI Engineering · Beginner → Intermediate → Advanced

Start with Metric definitions and grain. A semantic layer gives business measures consistent definitions. Different definitions can produce different correct-looking answers. Then try Define “active learner”. The three levels build toward Governed metrics for AI analytics. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Metric definitions and grain

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Metric definitions and grain
Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL.
Mental model: Two cooks cannot compare recipes if one cup means a different volume.
Boundary: A metric name alone rarely captures all business rules.
Worked example: Revenue per order differs from revenue per line item; state the grain before joining order and item tables.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Revenue doubles after a join
The toy semantic model permits no duplicate contribution of an order to the revenue metric. Three queries inflate revenue through a grain-mismatched join. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Define grain and join keys explicitly and aggregate at the correct business level.
Recall: Compare reference SQL totals and edge cases for dates, refunds and repeated line items. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Metric definitions and grain: Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A semantic layer gives business measures consistent definitions. Different definitions can produce different correct-looking answers.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use three fictional records: A logged in but studied nothing; B completed a lesson this month; C completed a lesson last year.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

3. Try step 2
Calculate active learners under “logged in this month” and “completed a lesson this month”, stating any missing login information.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

4. Try step 3
Write one chosen definition with time window, event and time-zone convention.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A metric definition and a table explaining which records qualify or remain unknown.

5. Explain and check your result
The definition fixes the meaning of “active”; unknown login data is not silently counted as activity or inactivity. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A metric definition and a table explaining which records qualify or remain unknown. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The toy semantic model permits no duplicate contribution of an order to the revenue metric. Apply this toy-case rule manually: Review when duplicate_contributions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three queries inflate revenue through a grain-mismatched join. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Semantic-layer engineering for AI analytics.
Use three fictional records: A logged in but studied nothing; B completed a lesson this month; C completed a lesson last year.
Calculate active learners under “logged in this month” and “completed a lesson this month”, stating any missing login information.
Write one chosen definition with time window, event and time-zone convention.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A metric definition and a table explaining which records qualify or remain unknown. Include beginner-worksheet.md and your completed Metric contract and reconciliation worksheet.
Check: The definition fixes the meaning of “active”; unknown login data is not silently counted as activity or inactivity.

### Interview
Explain your beginner solution for Semantic-layer engineering for AI analytics. Use this scenario: The toy semantic model permits no duplicate contribution of an order to the revenue metric.
Review: Start with the task and permitted scope. Explain metric definitions and grain: Define what each measure counts, its unit, filters and row grain. An AI query interface needs stable business meaning before it can produce useful SQL. Show the input and observed output, then address Define grain and join keys explicitly and aggregate at the correct business level. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A metric definition and a table explaining which records qualify or remain unknown. Include beginner-worksheet.md and your completed Metric contract and reconciliation worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Join correctness

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, dimensional modeling and metric definitions.

### Join correctness
Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries.
Mental model: Combining two guest lists can accidentally count one person twice.
Boundary: Passing a small example does not prove every production relationship is clean.
Worked example: One order with three items repeats the order total three times after a join; aggregate at the correct grain before summing.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Governed metrics for AI analytics
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Recall: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. Identify one observation that would contradict your claim.

### Terms
Join correctness: Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The toy semantic model permits no duplicate contribution of an order to the revenue metric. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.
Deliverables: Metric definitions and tested SQL/dbt models; Reconciliation fixtures. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Semantic-layer engineering for AI analytics. Use this scenario: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Review: Start with the task and permitted scope. Explain join correctness: Model relationships and test whether joins multiply or lose records. Validate totals against a small hand-calculated example before exposing metrics to natural-language queries. Show the input and observed output, then address Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Metric definitions and tested SQL/dbt models; Reconciliation fixtures. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Governed AI queries

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Governed AI queries
Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning.
Mental model: A translator uses an agreed dictionary and asks when a word has two meanings.
Boundary: SQL syntax validity does not prove semantic correctness or authorization.
Worked example: For active customers, ask which activity window applies or use the documented default and disclose it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Governed metrics for AI analytics
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Recall: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. Identify one observation that would contradict your claim.

### Terms
Governed AI queries: Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning.
API: Application programming interface: the agreed way one program requests work or data from another.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a semantic layer that prevents an assistant from inventing inconsistent business metrics.
Create fictional orders, refunds and customers with dates and currencies. Define gross sales, net sales and active customers with explicit grain and time semantics.
Use DuckDB to stage tables and implement metric SQL with named dimensions. Write tests for duplicate joins, refunds, missing exchange rates and time boundaries.
Create a dbt project using a compatible adapter or retain the local SQL reference. Document lineage and metric definitions alongside the tests.
Expose allowlisted metric queries through an API instead of executing arbitrary model SQL. Validate dimensions, date ranges and tenant filters.
Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer.
Add a governed natural-language mapping with explicit clarification for ambiguous metric names.
Deliverables: Metric definitions and tested SQL/dbt models; Reconciliation fixtures; AI query contract and semantic-layer ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A reviewer must reproduce one result and identify which capabilities you implemented. Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.

### Interview
Explain your advanced solution for Semantic-layer engineering for AI analytics. Use this scenario: Ask for revenue while a join duplicates orders and a refund crosses the reporting boundary. The tests must catch the discrepancy before a narrative is generated.
Review: Start with the task and permitted scope. Explain governed ai queries: Constrain generated queries to approved metrics, permissions and resource limits. Explain metric definitions and ambiguous requests rather than inventing a meaning. Show the input and observed output, then address Reconcile each metric to a small hand-calculated ledger. Report unsupported questions and definition ambiguities rather than fabricating an answer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Metric definitions and tested SQL/dbt models; Reconciliation fixtures; AI query contract and semantic-layer ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

dbt — Open source Core · commercial cloud optional
Versioned transformations, lineage and data tests.
Alternative: Versioned SQL plus tests for a small project; SQLMesh (open source) offers another transformation workflow.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
dbt: https://docs.getdbt.com/docs/introduction
FastAPI: https://fastapi.tiangolo.com/tutorial/
dbt: https://docs.getdbt.com/docs/introduction
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
