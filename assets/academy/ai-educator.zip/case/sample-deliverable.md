# SAMPLE — Tested lesson and learner-observation log
Role: AI educator / technical writer / developer advocate
Case: The tutorial works only for its author
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The learning pilot flags any hidden setup dependency discovered by a new learner.

## Evidence table
| Record | hidden_prerequisites (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three tutorial runs depend on unstated setup, so the published steps are not reproducible.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai educator / technical writer / developer advocate.
Before release: Ask a new learner to follow the revised instructions from a clean starting point.

## Design choice and trade-off
Teach toward an observable task; verify examples and document limitations.
Concise tutorials are useful only if they do not omit the steps learners need to reproduce the result.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI fundamentals workshop: Assessment measures understanding rather than memorized terminology.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
