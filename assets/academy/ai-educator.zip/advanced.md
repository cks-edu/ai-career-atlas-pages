## advanced — Assessment and revision

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Assessment and revision
Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved.
Mental model: A driving test asks the learner to navigate, not only name car parts.
Boundary: A self-check or quiz score is not professional certification.
Worked example: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Tested AI learning module and documentation site
Publish a learning module that helps a defined audience complete and verify a practical AI task. Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Recall: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. Identify one observation that would contradict your claim.

### Terms
Assessment and revision: Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Publish a learning module that helps a defined audience complete and verify a practical AI task. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Publish a learning module that helps a defined audience complete and verify a practical AI task.
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.
A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.
Add an accessible video with transcript and test whether it helps the target audience complete the same task.
Deliverables: Published lesson and exercise assets; Assessment rubric and worked answer; Pilot report and revision history. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A reviewer must reproduce one result and identify which capabilities you implemented. A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

### Interview
Explain your advanced solution for AI educator / technical writer / developer advocate. Use this scenario: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Review: Start with the task and permitted scope. Explain assessment and revision: Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved. Show the input and observed output, then address Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Published lesson and exercise assets; Assessment rubric and worked answer; Pilot report and revision history. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

