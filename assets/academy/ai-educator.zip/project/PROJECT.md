# Tested AI learning module and documentation site

Career: AI educator / technical writer / developer advocate
Reviewed: 2026-10-22

Publish a learning module that helps a defined audience complete and verify a practical AI task.

## Prerequisites
Audience expertise and verified explanations; developer advocacy and technical tutorials usually require coding.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Published lesson and exercise assets — artifact-1.md
2. Assessment rubric and worked answer — artifact-2.md
3. Pilot report and revision history — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Add an accessible video with transcript and test whether it helps the target audience complete the same task.

## Primary learning resources
- LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/ — Open source · no account needed; Edit reports, workshop decks and export PDF deliverables.
- GitHub Actions: https://docs.github.com/en/actions — Commercial hosted service · usage limits; CI checks and reviewable build artifacts; paid usage may apply.
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
