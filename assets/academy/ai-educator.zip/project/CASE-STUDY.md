# Tested AI learning module and documentation site

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Publish a learning module that helps a defined audience complete and verify a practical AI task.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

## Limitations and next iteration
Add an accessible video with transcript and test whether it helps the target audience complete the same task.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
