# AI educator / technical writer / developer advocate — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Audience and prerequisites: Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Audience and prerequisites

Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack. In this role, work through: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A staircase needs a reachable first step and visible landings.

Boundary: A profile label such as student does not reveal every learner's knowledge.

Worked example: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); GitHub Actions (Commercial hosted service · usage limits); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI educator / technical writer / developer advocate: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract.

Predict the worked case

Read this case without running a tool: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in audience and prerequisites.

Connect the concept to the role

Apply this rule: Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A profile label such as student does not reveal every learner's knowledge.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies audience and prerequisites to this case: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Audience and prerequisites; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with audience and prerequisites. Use the glossary below, then write your prediction for: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI educator / technical writer / developer advocate role interview. Explain audience and prerequisites using this case: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate audience and prerequisites to a system or workflow you know. Explain audience and prerequisites using this case: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain audience and prerequisites using this case: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract.

Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack. — Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack. A profile label such as student does not reveal every learner's knowledge.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

GitHub Actions: https://docs.github.com/en/actions

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

GitHub Actions: https://docs.github.com/en/actions

### Diagnose: The tutorial works only for its author

The learning pilot flags any hidden setup dependency discovered by a new learner. Three tutorial runs depend on unstated setup, so the published steps are not reproducible. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A staircase needs a reachable first step and visible landings.

A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract.

Worked example: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); GitHub Actions (Commercial hosted service · usage limits); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The learning pilot flags any hidden setup dependency discovered by a new learner. Three tutorial runs depend on unstated setup, so the published steps are not reproducible. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The learning pilot flags any hidden setup dependency discovered by a new learner. Apply this toy-case rule manually: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A learning objective describes something a learner can do. Check understanding with an example, not just “Does that make sense?”

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Choose the idea “AI-generated answers can be wrong.” Write what a beginner should be able to do after the lesson.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

Preparation · Try step 2

Create a fictional answer with a visible error and show how to compare it with a supplied fact.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

Preparation · Try step 3

Write one practice question, an answer explanation and a hint that does not give away the answer.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

Preparation · Explain and check your result

The practice tests verification behavior; the lesson does not imply that fluent wording or a citation guarantees truth. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A mini-lesson with objective, example, question, hint and answer. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The learning pilot flags any hidden setup dependency discovered by a new learner. Apply this toy-case rule manually: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three tutorial runs depend on unstated setup, so the published steps are not reproducible. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three tutorial runs depend on unstated setup, so the published steps are not reproducible. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the tutorial works only for its author. Use the glossary below, then write your prediction for: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI educator / technical writer / developer advocate role interview. Explain diagnose: the tutorial works only for its author using this case: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the tutorial works only for its author to a system or workflow you know. Explain diagnose: the tutorial works only for its author using this case: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Ask a new learner to follow the revised instructions from a clean starting point. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the tutorial works only for its author using this case: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. State the evidence, one alternative and where the mental model stops.

Quiz: The tutorial works only for its author: The learning pilot flags any hidden setup dependency discovered by a new learner.

Change the acceptance rule after seeing an inconvenient result.

Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch.

Omit failed cases and report only the successful demonstrations.

Reference: Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. — Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. Ask a new learner to follow the revised instructions from a clean starting point.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

GitHub Actions: https://docs.github.com/en/actions

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

GitHub Actions: https://docs.github.com/en/actions

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audience expertise and verified explanations; developer advocacy and technical tutorials usually require coding.

Terms:

Instructional verification: Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Instructional verification

Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors. In this role, work through: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A recipe author cooks the recipe before publishing it.

Boundary: One environment test cannot guarantee every operating system or version.

Worked example: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audience expertise and verified explanations; developer advocacy and technical tutorials usually require coding.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); GitHub Actions (Commercial hosted service · usage limits); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI educator / technical writer / developer advocate: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message.

Predict the worked case

Read this case without running a tool: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in instructional verification.

Connect the concept to the role

Apply this rule: Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: One environment test cannot guarantee every operating system or version.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies instructional verification to this case: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Instructional verification; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with instructional verification. Use the glossary below, then write your prediction for: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI educator / technical writer / developer advocate role interview. Explain instructional verification using this case: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate instructional verification to a system or workflow you know. Explain instructional verification using this case: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain instructional verification using this case: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message.

Treat a passing starter as proof of the whole role workflow.

Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors.

Ignore the failure because the tool produced an output.

Reference: Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors. — Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors. One environment test cannot guarantee every operating system or version.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

GitHub Actions: https://docs.github.com/en/actions

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

GitHub Actions: https://docs.github.com/en/actions

### Integrate: Tested AI learning module and documentation site

Publish a learning module that helps a defined audience complete and verify a practical AI task. Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment. In this role, work through: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A recipe author cooks the recipe before publishing it.

Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message.

Worked example: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); GitHub Actions (Commercial hosted service · usage limits); LibreOffice Calc (Open source · no account needed)

Publish a learning module that helps a defined audience complete and verify a practical AI task. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Publish a learning module that helps a defined audience complete and verify a practical AI task.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The learning pilot flags any hidden setup dependency discovered by a new learner. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Published lesson and exercise assets; Assessment rubric and worked answer. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: tested ai learning module and documentation site. Use the glossary below, then write your prediction for: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI educator / technical writer / developer advocate role interview. Explain integrate: tested ai learning module and documentation site using this case: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: tested ai learning module and documentation site to a system or workflow you know. Explain integrate: tested ai learning module and documentation site using this case: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. Identify one observation that would contradict your claim.

Interview: Explain integrate: tested ai learning module and documentation site using this case: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Tested AI learning module and documentation site at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.

Reference: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. — Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

GitHub Actions: https://docs.github.com/en/actions

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

GitHub Actions: https://docs.github.com/en/actions

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Assessment and revision: Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Assessment and revision

Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved. In this role, work through: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A driving test asks the learner to navigate, not only name car parts.

Boundary: A self-check or quiz score is not professional certification.

Worked example: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); GitHub Actions (Commercial hosted service · usage limits); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI educator / technical writer / developer advocate: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning.

Predict the worked case

Read this case without running a tool: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in assessment and revision.

Connect the concept to the role

Apply this rule: Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A self-check or quiz score is not professional certification.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies assessment and revision to this case: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Assessment and revision; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with assessment and revision. Use the glossary below, then write your prediction for: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI educator / technical writer / developer advocate role interview. Explain assessment and revision using this case: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate assessment and revision to a system or workflow you know. Explain assessment and revision using this case: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain assessment and revision using this case: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved.

Reference: Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved. — Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved. A self-check or quiz score is not professional certification.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

GitHub Actions: https://docs.github.com/en/actions

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

GitHub Actions: https://docs.github.com/en/actions

### Defend: Tested AI learning module and documentation site

Publish a learning module that helps a defined audience complete and verify a practical AI task. Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence. In this role, work through: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A driving test asks the learner to navigate, not only name car parts.

A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning.

Worked example: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); GitHub Actions (Commercial hosted service · usage limits); LibreOffice Calc (Open source · no account needed)

Publish a learning module that helps a defined audience complete and verify a practical AI task. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Publish a learning module that helps a defined audience complete and verify a practical AI task.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A reviewer must reproduce one result and identify which capabilities you implemented. A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Published lesson and exercise assets; Assessment rubric and worked answer; Pilot report and revision history. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: tested ai learning module and documentation site. Use the glossary below, then write your prediction for: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI educator / technical writer / developer advocate role interview. Explain defend: tested ai learning module and documentation site using this case: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: tested ai learning module and documentation site to a system or workflow you know. Explain defend: tested ai learning module and documentation site using this case: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. Identify one observation that would contradict your claim.

Interview: Explain defend: tested ai learning module and documentation site using this case: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Tested AI learning module and documentation site at this level?

A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method. — A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method. Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

GitHub Actions: https://docs.github.com/en/actions

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

GitHub Actions: https://docs.github.com/en/actions
