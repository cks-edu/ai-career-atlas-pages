## beginner — Audience and prerequisites

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Audience and prerequisites
Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack.
Mental model: A staircase needs a reachable first step and visible landings.
Boundary: A profile label such as student does not reveal every learner's knowledge.
Worked example: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The tutorial works only for its author
The learning pilot flags any hidden setup dependency discovered by a new learner. Three tutorial runs depend on unstated setup, so the published steps are not reproducible. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch.
Recall: Ask a new learner to follow the revised instructions from a clean starting point. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Audience and prerequisites: Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A learning objective describes something a learner can do. Check understanding with an example, not just “Does that make sense?”
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose the idea “AI-generated answers can be wrong.” Write what a beginner should be able to do after the lesson.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

3. Try step 2
Create a fictional answer with a visible error and show how to compare it with a supplied fact.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

4. Try step 3
Write one practice question, an answer explanation and a hint that does not give away the answer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

5. Explain and check your result
The practice tests verification behavior; the lesson does not imply that fluent wording or a citation guarantees truth. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A mini-lesson with objective, example, question, hint and answer. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The learning pilot flags any hidden setup dependency discovered by a new learner. Apply this toy-case rule manually: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three tutorial runs depend on unstated setup, so the published steps are not reproducible. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI educator / technical writer / developer advocate.
Choose the idea “AI-generated answers can be wrong.” Write what a beginner should be able to do after the lesson.
Create a fictional answer with a visible error and show how to compare it with a supplied fact.
Write one practice question, an answer explanation and a hint that does not give away the answer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A mini-lesson with objective, example, question, hint and answer. Include beginner-worksheet.md and your completed Tested lesson and learner-observation log.
Check: The practice tests verification behavior; the lesson does not imply that fluent wording or a citation guarantees truth.

### Interview
Explain your beginner solution for AI educator / technical writer / developer advocate. Use this scenario: The learning pilot flags any hidden setup dependency discovered by a new learner.
Review: Start with the task and permitted scope. Explain audience and prerequisites: Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack. Show the input and observed output, then address Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A mini-lesson with objective, example, question, hint and answer. Include beginner-worksheet.md and your completed Tested lesson and learner-observation log.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

