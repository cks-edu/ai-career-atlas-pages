## intermediate — Instructional verification

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audience expertise and verified explanations; developer advocacy and technical tutorials usually require coding.

### Instructional verification
Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors.
Mental model: A recipe author cooks the recipe before publishing it.
Boundary: One environment test cannot guarantee every operating system or version.
Worked example: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Tested AI learning module and documentation site
Publish a learning module that helps a defined audience complete and verify a practical AI task. Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Recall: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. Identify one observation that would contradict your claim.

### Terms
Instructional verification: Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Publish a learning module that helps a defined audience complete and verify a practical AI task. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The learning pilot flags any hidden setup dependency discovered by a new learner. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Publish a learning module that helps a defined audience complete and verify a practical AI task.
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.
Deliverables: Published lesson and exercise assets; Assessment rubric and worked answer. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI educator / technical writer / developer advocate. Use this scenario: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Review: Start with the task and permitted scope. Explain instructional verification: Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors. Show the input and observed output, then address Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Published lesson and exercise assets; Assessment rubric and worked answer. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

