# AI educator / technical writer / developer advocate

AI Engineering · Beginner → Intermediate → Advanced

Start with Audience and prerequisites. A learning objective describes something a learner can do. Check understanding with an example, not just “Does that make sense?” Then try Design a five-minute mini-lesson. The three levels build toward Tested AI learning module and documentation site. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Audience and prerequisites

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Audience and prerequisites
Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack.
Mental model: A staircase needs a reachable first step and visible landings.
Boundary: A profile label such as student does not reveal every learner's knowledge.
Worked example: A new learner labels five example outputs before learning precision and recall; an experienced engineer can begin with the evaluation contract.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The tutorial works only for its author
The learning pilot flags any hidden setup dependency discovered by a new learner. Three tutorial runs depend on unstated setup, so the published steps are not reproducible. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch.
Recall: Ask a new learner to follow the revised instructions from a clean starting point. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Audience and prerequisites: Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A learning objective describes something a learner can do. Check understanding with an example, not just “Does that make sense?”
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose the idea “AI-generated answers can be wrong.” Write what a beginner should be able to do after the lesson.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

3. Try step 2
Create a fictional answer with a visible error and show how to compare it with a supplied fact.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

4. Try step 3
Write one practice question, an answer explanation and a hint that does not give away the answer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A mini-lesson with objective, example, question, hint and answer.

5. Explain and check your result
The practice tests verification behavior; the lesson does not imply that fluent wording or a citation guarantees truth. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A mini-lesson with objective, example, question, hint and answer. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The learning pilot flags any hidden setup dependency discovered by a new learner. Apply this toy-case rule manually: Review when hidden_prerequisites >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three tutorial runs depend on unstated setup, so the published steps are not reproducible. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI educator / technical writer / developer advocate.
Choose the idea “AI-generated answers can be wrong.” Write what a beginner should be able to do after the lesson.
Create a fictional answer with a visible error and show how to compare it with a supplied fact.
Write one practice question, an answer explanation and a hint that does not give away the answer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A mini-lesson with objective, example, question, hint and answer. Include beginner-worksheet.md and your completed Tested lesson and learner-observation log.
Check: The practice tests verification behavior; the lesson does not imply that fluent wording or a citation guarantees truth.

### Interview
Explain your beginner solution for AI educator / technical writer / developer advocate. Use this scenario: The learning pilot flags any hidden setup dependency discovered by a new learner.
Review: Start with the task and permitted scope. Explain audience and prerequisites: Identify what learners already know, what they should be able to do and which terms need explanation. Design a small first success before introducing a large tool stack. Show the input and observed output, then address Make prerequisites, versions and expected outputs explicit and add a troubleshooting branch. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A mini-lesson with objective, example, question, hint and answer. Include beginner-worksheet.md and your completed Tested lesson and learner-observation log.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Instructional verification

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audience expertise and verified explanations; developer advocacy and technical tutorials usually require coding.

### Instructional verification
Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors.
Mental model: A recipe author cooks the recipe before publishing it.
Boundary: One environment test cannot guarantee every operating system or version.
Worked example: Run a local example from a fresh folder, record its output and explain how a missing dependency changes the error message.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Tested AI learning module and documentation site
Publish a learning module that helps a defined audience complete and verify a practical AI task. Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Recall: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. Identify one observation that would contradict your claim.

### Terms
Instructional verification: Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Publish a learning module that helps a defined audience complete and verify a practical AI task. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The learning pilot flags any hidden setup dependency discovered by a new learner. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Publish a learning module that helps a defined audience complete and verify a practical AI task.
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.
Deliverables: Published lesson and exercise assets; Assessment rubric and worked answer. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI educator / technical writer / developer advocate. Use this scenario: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Review: Start with the task and permitted scope. Explain instructional verification: Check commands, outputs and source claims in the supported environment. Explain why steps matter and provide recovery guidance for predictable errors. Show the input and observed output, then address Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Published lesson and exercise assets; Assessment rubric and worked answer. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Assessment and revision

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Assessment and revision
Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved.
Mental model: A driving test asks the learner to navigate, not only name car parts.
Boundary: A self-check or quiz score is not professional certification.
Worked example: A learner explains why a cited answer can still be wrong, then fixes a source-selection case and records the reasoning.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Tested AI learning module and documentation site
Publish a learning module that helps a defined audience complete and verify a practical AI task. Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Recall: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. Identify one observation that would contradict your claim.

### Terms
Assessment and revision: Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Publish a learning module that helps a defined audience complete and verify a practical AI task. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Publish a learning module that helps a defined audience complete and verify a practical AI task.
Choose a concrete task such as checking generated summaries against sources. Define prerequisites and write three measurable learning objectives.
Create a lesson with an explanation, worked example, guided exercise and independent assessment. Include deliberately flawed outputs and an answer rationale.
Build a small documentation site or PDF workbook with navigation, alt text and copyable examples. Run every command you include and record the tested environment.
Pilot with consenting learners or a labeled solo rehearsal. Observe where they get stuck, revise the lesson and maintain a change log tied to evidence.
A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning.
Add an accessible video with transcript and test whether it helps the target audience complete the same task.
Deliverables: Published lesson and exercise assets; Assessment rubric and worked answer; Pilot report and revision history. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A reviewer must reproduce one result and identify which capabilities you implemented. A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.

### Interview
Explain your advanced solution for AI educator / technical writer / developer advocate. Use this scenario: A learner copies the example and passes without understanding. Add a transfer task with changed constraints and require an explanation of the verification method.
Review: Start with the task and permitted scope. Explain assessment and revision: Use tasks that reveal understanding rather than recall of tool names. Analyze misconceptions, revise the lesson and preserve evidence of what improved. Show the input and observed output, then address Report task completion, critical-error detection and usability findings. Page views and satisfaction are secondary signals, not proof of learning. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Published lesson and exercise assets; Assessment rubric and worked answer; Pilot report and revision history. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
GitHub Actions: https://docs.github.com/en/actions
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Google Technical Writing: https://developers.google.com/tech-writing
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
GitHub Actions: https://docs.github.com/en/actions
