# UX Engineer / Interaction Designer

Software Engineering

Start with interaction states and affordances. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward UX/accessibility report and before/after evidence.

## beginner

Prototype the task form in HTML and sketch four states. Use clear labels, inline errors and a visible recovery action; test keyboard-only submission. Record where focus remains after failure and successful recovery.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Observable behavior
A test compares a defined observation with an expected result for a chosen input.
Mental model: A recipe with a taste check rather than a photograph of ingredients.
Limit: Passing examples do not prove every possible input works.
Example: An empty task must not be added and the error must be understandable.
Recall: Write a test case with input, action and expected observation.

### Interaction states and affordances
An interaction design must cover empty, loading, success and failure states. Labels should explain actions and outcomes without requiring users to know implementation terms.
Mental model: A door handle should suggest how to open the door.
Limit: If users cannot tell whether work was saved, separate draft, pending and confirmed states.
Example: After a failed save, the title remains available for correction rather than disappearing.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If users cannot tell whether work was saved, separate draft, pending and confirmed states.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
After a failed save, the title remains available for correction rather than disappearing. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Prototype the task form in HTML and sketch four states. Use clear labels, inline errors and a visible recovery action; test keyboard-only submission. Record where focus remains after failure and successful recovery.
Expected: A complete state flow with no dead-end error state.

6. Role workshop · debug and verify
If users cannot tell whether work was saved, separate draft, pending and confirmed states. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save interactive prototype and state map. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A complete state flow with no dead-end error state.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Interaction states and affordances: If users cannot tell whether work was saved, separate draft, pending and confirmed states.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: interactive prototype and state map
A complete state flow with no dead-end error state.

Interview: Work through this UX Engineer / Interaction Designer case: After a failed save, the title remains available for correction rather than disappearing. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An interaction design must cover empty, loading, success and failure states. Labels should explain actions and outcomes without requiring users to know implementation terms. Expected evidence: A complete state flow with no dead-end error state. Diagnosis: If users cannot tell whether work was saved, separate draft, pending and confirmed states. State the limits of the mental model: A door handle should suggest how to open the door.

Resume: Built interactive prototype and state map using HTML prototypes and accessibility tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Write a neutral task script, run a permitted session or clearly labeled self-walkthrough and record observations separately from interpretations. Propose one change linked to a specific problem.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Test boundaries
Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.
Mental model: Check a component, then an assembled bicycle, then a ride.
Limit: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.
Example: Validate title alone, then HTTP request, then keyboard submission in the browser.
Recall: Which layer should identify whether a failure is parsing or rendering?

### Usability observations
A usability session observes a task, not whether a participant praises the design. Record behavior, hesitation and errors without leading the participant to the intended answer.
Mental model: Watch someone find a room before explaining where the signs point.
Limit: A self-test cannot establish broad usability; state participant and sampling limits.
Example: Ask a participant to add and correct a task without naming the controls.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A self-test cannot establish broad usability; state participant and sampling limits.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Ask a participant to add and correct a task without naming the controls. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a neutral task script, run a permitted session or clearly labeled self-walkthrough and record observations separately from interpretations. Propose one change linked to a specific problem.
Expected: Evidence distinguishes observed actions from designer assumptions.

6. Role workshop · debug and verify
A self-test cannot establish broad usability; state participant and sampling limits. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save session script, notes and revised prototype. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Evidence distinguishes observed actions from designer assumptions.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Usability observations: A self-test cannot establish broad usability; state participant and sampling limits.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: session script, notes and revised prototype
Evidence distinguishes observed actions from designer assumptions.

Interview: Work through this UX Engineer / Interaction Designer case: Ask a participant to add and correct a task without naming the controls. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A usability session observes a task, not whether a participant praises the design. Record behavior, hesitation and errors without leading the participant to the intended answer. Expected evidence: Evidence distinguishes observed actions from designer assumptions. Diagnosis: A self-test cannot establish broad usability; state participant and sampling limits. State the limits of the mental model: Watch someone find a room before explaining where the signs point.

Resume: Built session script, notes and revised prototype using HTML prototypes and accessibility tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Test the prototype at narrow width and large zoom, run an accessibility check and manually retest the complete task. Create a prioritized issue list with acceptance criteria.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Risk-based release
Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.
Mental model: Inspect brakes before polishing the paint.
Limit: Risk ranking is judgment informed by users, not an excuse to skip known defects.
Example: Test invalid input, double submission, keyboard focus and server restart; record results.
Recall: What evidence would make you hold a release despite a high pass count?

### Inclusive design validation
Design quality includes keyboard, zoom, assistive technology and understandable recovery. Prioritize barriers by task impact and retest after changing the interface.
Mental model: A building is usable only when people with different needs can reach its essential rooms.
Limit: Automated checks do not judge whether instructions make sense; review wording with the task.
Example: Large text should not hide the save action or truncate the error explanation.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Automated checks do not judge whether instructions make sense; review wording with the task.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Large text should not hide the save action or truncate the error explanation. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Test the prototype at narrow width and large zoom, run an accessibility check and manually retest the complete task. Create a prioritized issue list with acceptance criteria.
Expected: Every fixed issue has a reproducible retest and remaining gaps are visible.

6. Role workshop · debug and verify
Automated checks do not judge whether instructions make sense; review wording with the task. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save UX/accessibility report and before/after evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Every fixed issue has a reproducible retest and remaining gaps are visible.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Inclusive design validation: Automated checks do not judge whether instructions make sense; review wording with the task.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: UX/accessibility report and before/after evidence
Every fixed issue has a reproducible retest and remaining gaps are visible.

Interview: Work through this UX Engineer / Interaction Designer case: Large text should not hide the save action or truncate the error explanation. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Design quality includes keyboard, zoom, assistive technology and understandable recovery. Prioritize barriers by task impact and retest after changing the interface. Expected evidence: Every fixed issue has a reproducible retest and remaining gaps are visible. Diagnosis: Automated checks do not judge whether instructions make sense; review wording with the task. State the limits of the mental model: A building is usable only when people with different needs can reach its essential rooms.

Resume: Built UX/accessibility report and before/after evidence using HTML prototypes and accessibility tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
Playwright: installation and first tests: https://playwright.dev/docs/intro
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
