# UX Engineer / Interaction Designer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Interaction states and affordances

An interaction design must cover empty, loading, success and failure states. Labels should explain actions and outcomes without requiring users to know implementation terms.
Mental model: A door handle should suggest how to open the door.
Case: After a failed save, the title remains available for correction rather than disappearing.
Task: Prototype the task form in HTML and sketch four states. Use clear labels, inline errors and a visible recovery action; test keyboard-only submission. Record where focus remains after failure and successful recovery.
Acceptance: A complete state flow with no dead-end error state.
Troubleshooting: If users cannot tell whether work was saved, separate draft, pending and confirmed states.
Deliverable: interactive prototype and state map

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Usability observations

A usability session observes a task, not whether a participant praises the design. Record behavior, hesitation and errors without leading the participant to the intended answer.
Mental model: Watch someone find a room before explaining where the signs point.
Case: Ask a participant to add and correct a task without naming the controls.
Task: Write a neutral task script, run a permitted session or clearly labeled self-walkthrough and record observations separately from interpretations. Propose one change linked to a specific problem.
Acceptance: Evidence distinguishes observed actions from designer assumptions.
Troubleshooting: A self-test cannot establish broad usability; state participant and sampling limits.
Deliverable: session script, notes and revised prototype

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Inclusive design validation

Design quality includes keyboard, zoom, assistive technology and understandable recovery. Prioritize barriers by task impact and retest after changing the interface.
Mental model: A building is usable only when people with different needs can reach its essential rooms.
Case: Large text should not hide the save action or truncate the error explanation.
Task: Test the prototype at narrow width and large zoom, run an accessibility check and manually retest the complete task. Create a prioritized issue list with acceptance criteria.
Acceptance: Every fixed issue has a reproducible retest and remaining gaps are visible.
Troubleshooting: Automated checks do not judge whether instructions make sense; review wording with the task.
Deliverable: UX/accessibility report and before/after evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
