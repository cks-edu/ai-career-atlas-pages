# Data / BI Analyst

Software Engineering

Start with population and missing data. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward executive analysis brief, chart and reproducible calculation.

## beginner

Build a small spreadsheet or SQL table, compute observed count, missing count and mean, then write the population and exclusion rule below the chart. Keep the original blank cell visible for review.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Population and missing data
An average describes the selected population, not automatically all users. Count missing values and exclusions alongside the metric before making a recommendation.
Mental model: A survey of people in one room cannot silently represent the whole city.
Limit: If blanks become zeros during import, check data types and the missing-value policy before analysis.
Example: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If blanks become zeros during import, check data types and the missing-value policy before analysis.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Build a small spreadsheet or SQL table, compute observed count, missing count and mean, then write the population and exclusion rule below the chart. Keep the original blank cell visible for review.
Expected: Mean 15, observed count 2 and missing count 1 are all visible.

6. Role workshop · debug and verify
If blanks become zeros during import, check data types and the missing-value policy before analysis. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save analysis worksheet with a data dictionary. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Mean 15, observed count 2 and missing count 1 are all visible.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Population and missing data: If blanks become zeros during import, check data types and the missing-value policy before analysis.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: analysis worksheet with a data dictionary
Mean 15, observed count 2 and missing count 1 are all visible.

Interview: Work through this Data / BI Analyst case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An average describes the selected population, not automatically all users. Count missing values and exclusions alongside the metric before making a recommendation. Expected evidence: Mean 15, observed count 2 and missing count 1 are all visible. Diagnosis: If blanks become zeros during import, check data types and the missing-value policy before analysis. State the limits of the mental model: A survey of people in one room cannot silently represent the whole city.

Resume: Built analysis worksheet with a data dictionary using SQL and a spreadsheet; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create orders and customers fixtures, deliberately duplicate a customer key and compare row counts and sums before/after the join. Correct the model or deduplicate using an explicit rule.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Reconciliation and joins
Before charting combined data, verify join keys and cardinality. A many-to-many join can multiply totals without obvious errors in the charting tool.
Mental model: Matching two guest lists by first name can pair one person with several strangers.
Limit: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative.
Example: Two orders for customer C join to one customer record; duplicate customer C would double the total.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Two orders for customer C join to one customer record; duplicate customer C would double the total. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create orders and customers fixtures, deliberately duplicate a customer key and compare row counts and sums before/after the join. Correct the model or deduplicate using an explicit rule.
Expected: The defect is detected; corrected joined revenue equals source revenue.

6. Role workshop · debug and verify
Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save join audit and reconciled chart dataset. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The defect is detected; corrected joined revenue equals source revenue.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Reconciliation and joins: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: join audit and reconciled chart dataset
The defect is detected; corrected joined revenue equals source revenue.

Interview: Work through this Data / BI Analyst case: Two orders for customer C join to one customer record; duplicate customer C would double the total. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Before charting combined data, verify join keys and cardinality. A many-to-many join can multiply totals without obvious errors in the charting tool. Expected evidence: The defect is detected; corrected joined revenue equals source revenue. Diagnosis: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative. State the limits of the mental model: Matching two guest lists by first name can pair one person with several strangers.

Resume: Built join audit and reconciled chart dataset using SQL and a spreadsheet; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write a one-page recommendation with population, sample sizes, alternative explanations and a proposed comparison experiment. Add a privacy-safe aggregate chart and a monitoring threshold.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Decision communication and uncertainty
A dashboard should connect an observation to a bounded decision, with uncertainty and guardrail metrics. Correlation and a before/after change do not alone establish causation.
Mental model: A weather report supports a decision but does not control the weather.
Limit: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it.
Example: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a one-page recommendation with population, sample sizes, alternative explanations and a proposed comparison experiment. Add a privacy-safe aggregate chart and a monitoring threshold.
Expected: The recommendation separates observed facts, interpretation and next evidence needed.

6. Role workshop · debug and verify
A confident causal headline from a small uncontrolled sample overstates the evidence; revise it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save executive analysis brief, chart and reproducible calculation. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The recommendation separates observed facts, interpretation and next evidence needed.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Decision communication and uncertainty: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: executive analysis brief, chart and reproducible calculation
The recommendation separates observed facts, interpretation and next evidence needed.

Interview: Work through this Data / BI Analyst case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A dashboard should connect an observation to a bounded decision, with uncertainty and guardrail metrics. Correlation and a before/after change do not alone establish causation. Expected evidence: The recommendation separates observed facts, interpretation and next evidence needed. Diagnosis: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it. State the limits of the mental model: A weather report supports a decision but does not control the weather.

Resume: Built executive analysis brief, chart and reproducible calculation using SQL and a spreadsheet; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
