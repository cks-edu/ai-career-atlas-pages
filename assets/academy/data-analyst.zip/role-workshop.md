# Data / BI Analyst — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Population and missing data

An average describes the selected population, not automatically all users. Count missing values and exclusions alongside the metric before making a recommendation.
Mental model: A survey of people in one room cannot silently represent the whole city.
Case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three.
Task: Build a small spreadsheet or SQL table, compute observed count, missing count and mean, then write the population and exclusion rule below the chart. Keep the original blank cell visible for review.
Acceptance: Mean 15, observed count 2 and missing count 1 are all visible.
Troubleshooting: If blanks become zeros during import, check data types and the missing-value policy before analysis.
Deliverable: analysis worksheet with a data dictionary

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Reconciliation and joins

Before charting combined data, verify join keys and cardinality. A many-to-many join can multiply totals without obvious errors in the charting tool.
Mental model: Matching two guest lists by first name can pair one person with several strangers.
Case: Two orders for customer C join to one customer record; duplicate customer C would double the total.
Task: Create orders and customers fixtures, deliberately duplicate a customer key and compare row counts and sums before/after the join. Correct the model or deduplicate using an explicit rule.
Acceptance: The defect is detected; corrected joined revenue equals source revenue.
Troubleshooting: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative.
Deliverable: join audit and reconciled chart dataset

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Decision communication and uncertainty

A dashboard should connect an observation to a bounded decision, with uncertainty and guardrail metrics. Correlation and a before/after change do not alone establish causation.
Mental model: A weather report supports a decision but does not control the weather.
Case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement.
Task: Write a one-page recommendation with population, sample sizes, alternative explanations and a proposed comparison experiment. Add a privacy-safe aggregate chart and a monitoring threshold.
Acceptance: The recommendation separates observed facts, interpretation and next evidence needed.
Troubleshooting: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it.
Deliverable: executive analysis brief, chart and reproducible calculation

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
