# Data / BI Analyst — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Data / BI Analyst: Use the concept to complete this role exercise: Calculate the accepted-order total and explain rejected rows

Population and missing data: An average describes the selected population, not automatically all users. Count missing values and exclusions alongside the metric before making a recommendation.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. The practical workshop develops this into: Build a small spreadsheet or SQL table, compute observed count, missing count and mean, then write the population and exclusion rule below the chart. Keep the original blank cell visible for review.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: A survey of people in one room cannot silently represent the whole city.

An average describes the selected population, not automatically all users. Count missing values and exclusions alongside the metric before making a recommendation.

Worked example: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: SQL and a spreadsheet (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Data / BI Analyst: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three.

Predict the worked case

Read this case without running a tool: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data / BI Analyst role interview. Explain keys and constraints using this case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. State the evidence, one alternative and where the mental model stops.

Quiz: After the Population and missing data rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Population and missing data

An average describes the selected population, not automatically all users. Count missing values and exclusions alongside the metric before making a recommendation. In this role, work through: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. The practical workshop develops this into: Build a small spreadsheet or SQL table, compute observed count, missing count and mean, then write the population and exclusion rule below the chart. Keep the original blank cell visible for review.

Mental model: A survey of people in one room cannot silently represent the whole city.

Boundary: If blanks become zeros during import, check data types and the missing-value policy before analysis.

Worked example: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQL and a spreadsheet (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Data / BI Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Build a small spreadsheet or SQL table, compute observed count, missing count and mean, then write the population and exclusion rule below the chart. Keep the original blank cell visible for review.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Build a small spreadsheet or SQL table, compute observed count, missing count and mean, then write the population and exclusion rule below the chart. Keep the original blank cell visible for review.

Expected: Mean 15, observed count 2 and missing count 1 are all visible.

Role workshop · debug and verify

If blanks become zeros during import, check data types and the missing-value policy before analysis. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save analysis worksheet with a data dictionary. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Mean 15, observed count 2 and missing count 1 are all visible.

Expected: Mean 15, observed count 2 and missing count 1 are all visible.

Troubleshoot: The role exercise differs from the prediction: If blanks become zeros during import, check data types and the missing-value policy before analysis.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: analysis worksheet with a data dictionary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with population and missing data. Use the glossary below, then write your prediction for: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data / BI Analyst role interview. Explain population and missing data using this case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate population and missing data to a system or workflow you know. Explain population and missing data using this case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If blanks become zeros during import, check data types and the missing-value policy before analysis.

Interview: Explain population and missing data using this case: Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Values 10,20,NULL have an observed mean of 15 over two values, not 10 over three.

Mean 15, observed count 2 and missing count 1 are all visible.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Mean 15, observed count 2 and missing count 1 are all visible. — An average describes the selected population, not automatically all users. Count missing values and exclusions alongside the metric before making a recommendation. Mean 15, observed count 2 and missing count 1 are all visible.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Data / BI Analyst: Use the concept to complete this role exercise: Reconcile a summary against source records

Reconciliation and joins: Before charting combined data, verify join keys and cardinality. A many-to-many join can multiply totals without obvious errors in the charting tool.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: Two orders for customer C join to one customer record; duplicate customer C would double the total. The practical workshop develops this into: Create orders and customers fixtures, deliberately duplicate a customer key and compare row counts and sums before/after the join. Correct the model or deduplicate using an explicit rule.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: Matching two guest lists by first name can pair one person with several strangers.

Before charting combined data, verify join keys and cardinality. A many-to-many join can multiply totals without obvious errors in the charting tool.

Worked example: Two orders for customer C join to one customer record; duplicate customer C would double the total.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: SQL and a spreadsheet (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Data / BI Analyst: Two orders for customer C join to one customer record; duplicate customer C would double the total.

Predict the worked case

Read this case without running a tool: Two orders for customer C join to one customer record; duplicate customer C would double the total. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: Two orders for customer C join to one customer record; duplicate customer C would double the total. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two orders for customer C join to one customer record; duplicate customer C would double the total. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: Two orders for customer C join to one customer record; duplicate customer C would double the total. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data / BI Analyst role interview. Explain idempotent processing using this case: Two orders for customer C join to one customer record; duplicate customer C would double the total. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: Two orders for customer C join to one customer record; duplicate customer C would double the total. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: Two orders for customer C join to one customer record; duplicate customer C would double the total. State the evidence, one alternative and where the mental model stops.

Quiz: After the Reconciliation and joins rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Reconciliation and joins

Before charting combined data, verify join keys and cardinality. A many-to-many join can multiply totals without obvious errors in the charting tool. In this role, work through: Two orders for customer C join to one customer record; duplicate customer C would double the total. The practical workshop develops this into: Create orders and customers fixtures, deliberately duplicate a customer key and compare row counts and sums before/after the join. Correct the model or deduplicate using an explicit rule.

Mental model: Matching two guest lists by first name can pair one person with several strangers.

Boundary: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative.

Worked example: Two orders for customer C join to one customer record; duplicate customer C would double the total.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQL and a spreadsheet (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Data / BI Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create orders and customers fixtures, deliberately duplicate a customer key and compare row counts and sums before/after the join. Correct the model or deduplicate using an explicit rule.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Two orders for customer C join to one customer record; duplicate customer C would double the total. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create orders and customers fixtures, deliberately duplicate a customer key and compare row counts and sums before/after the join. Correct the model or deduplicate using an explicit rule.

Expected: The defect is detected; corrected joined revenue equals source revenue.

Role workshop · debug and verify

Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save join audit and reconciled chart dataset. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The defect is detected; corrected joined revenue equals source revenue.

Expected: The defect is detected; corrected joined revenue equals source revenue.

Troubleshoot: The role exercise differs from the prediction: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: join audit and reconciled chart dataset; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with reconciliation and joins. Use the glossary below, then write your prediction for: Two orders for customer C join to one customer record; duplicate customer C would double the total. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data / BI Analyst role interview. Explain reconciliation and joins using this case: Two orders for customer C join to one customer record; duplicate customer C would double the total. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate reconciliation and joins to a system or workflow you know. Explain reconciliation and joins using this case: Two orders for customer C join to one customer record; duplicate customer C would double the total. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not use DISTINCT blindly to hide multiplication; decide which record is authoritative.

Interview: Explain reconciliation and joins using this case: Two orders for customer C join to one customer record; duplicate customer C would double the total. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Two orders for customer C join to one customer record; duplicate customer C would double the total.

Ignore the failing case and keep only the successful screenshot.

The defect is detected; corrected joined revenue equals source revenue.

Treat any successful command as proof that all business and access rules passed.

Reference: The defect is detected; corrected joined revenue equals source revenue. — Before charting combined data, verify join keys and cardinality. A many-to-many join can multiply totals without obvious errors in the charting tool. The defect is detected; corrected joined revenue equals source revenue.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Data / BI Analyst: Use the concept to complete this role exercise: Publish a dashboard specification with missing-data and privacy limitations

Decision communication and uncertainty: A dashboard should connect an observation to a bounded decision, with uncertainty and guardrail metrics. Correlation and a before/after change do not alone establish causation.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. The practical workshop develops this into: Write a one-page recommendation with population, sample sizes, alternative explanations and a proposed comparison experiment. Add a privacy-safe aggregate chart and a monitoring threshold.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: A weather report supports a decision but does not control the weather.

A dashboard should connect an observation to a bounded decision, with uncertainty and guardrail metrics. Correlation and a before/after change do not alone establish causation.

Worked example: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: SQL and a spreadsheet (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Data / BI Analyst: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement.

Predict the worked case

Read this case without running a tool: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data / BI Analyst role interview. Explain transaction and recovery using this case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. State the evidence, one alternative and where the mental model stops.

Quiz: After the Decision communication and uncertainty rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Decision communication and uncertainty

A dashboard should connect an observation to a bounded decision, with uncertainty and guardrail metrics. Correlation and a before/after change do not alone establish causation. In this role, work through: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. The practical workshop develops this into: Write a one-page recommendation with population, sample sizes, alternative explanations and a proposed comparison experiment. Add a privacy-safe aggregate chart and a monitoring threshold.

Mental model: A weather report supports a decision but does not control the weather.

Boundary: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it.

Worked example: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQL and a spreadsheet (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Data / BI Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a one-page recommendation with population, sample sizes, alternative explanations and a proposed comparison experiment. Add a privacy-safe aggregate chart and a monitoring threshold.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a one-page recommendation with population, sample sizes, alternative explanations and a proposed comparison experiment. Add a privacy-safe aggregate chart and a monitoring threshold.

Expected: The recommendation separates observed facts, interpretation and next evidence needed.

Role workshop · debug and verify

A confident causal headline from a small uncontrolled sample overstates the evidence; revise it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save executive analysis brief, chart and reproducible calculation. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The recommendation separates observed facts, interpretation and next evidence needed.

Expected: The recommendation separates observed facts, interpretation and next evidence needed.

Troubleshoot: The role exercise differs from the prediction: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: executive analysis brief, chart and reproducible calculation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with decision communication and uncertainty. Use the glossary below, then write your prediction for: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data / BI Analyst role interview. Explain decision communication and uncertainty using this case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate decision communication and uncertainty to a system or workflow you know. Explain decision communication and uncertainty using this case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A confident causal headline from a small uncontrolled sample overstates the evidence; revise it.

Interview: Explain decision communication and uncertainty using this case: Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Conversion rises from 20/100 to 24/100; this small change alone does not prove a feature caused improvement.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

The recommendation separates observed facts, interpretation and next evidence needed.

Reference: The recommendation separates observed facts, interpretation and next evidence needed. — A dashboard should connect an observation to a bounded decision, with uncertainty and guardrail metrics. Correlation and a before/after change do not alone establish causation. The recommendation separates observed facts, interpretation and next evidence needed.

Sources:

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
