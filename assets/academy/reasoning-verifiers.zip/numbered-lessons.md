# Reasoning Models, Test-Time Compute & Verifiers — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## intermediate

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

test-time compute: Computation spent during inference rather than training.

deadline: The latest acceptable completion time for an operation.

router: A policy selecting a processing path from explicit inputs.

SLM: Small language model; size alone does not establish fitness for a task.

verifier: Code or a reviewed process checking a declared property.

least privilege: Grant only the operations and data needed for the task.

reasoning summary: An explicitly supplied public summary, not a raw hidden-reasoning transcript.

observable evidence: Inputs, tool actions and results that can actually be inspected.

### Test-time compute and reasoning budgets

Some models spend additional inference work before answering. That can help certain tasks, but more computation is not a correctness guarantee. Give the task a total deadline and a supported model-specific budget; stop or defer when there is insufficient room.

Reserve generation time after the supplied reasoning allowance. A request fits only when both are nonnegative finite measurements and their total stays inside the deadline. This is a policy model, not a mapping from milliseconds to reasoning tokens.

Different providers expose different budget controls and may account for hidden reasoning tokens differently. A client cannot enforce a hard remote deadline merely by writing it in a prompt.

Mental model: Task → model-specific reasoning allowance → generation → deadline. Picture the boundary as a checked gate between stages.

Boundary: Different providers expose different budget controls and may account for hidden reasoning tokens differently. A client cannot enforce a hard remote deadline merely by writing it in a prompt.

Worked example: function reasoningFits(reasonMs, outputMs, deadlineMs) {
  return [reasonMs,outputMs,deadlineMs].every(n=>Number.isFinite(n) && n>=0) && reasonMs + outputMs <= deadlineMs;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract reasoning-verifiers.zip, install Node.js LTS, then open production-ai/06-01-reasoning-budget.

Tools for this exercise: JavaScript · local isolated workbench; JSON Schema, Model provider API as documented optional extensions

Course tool and framework map: JSON Schema (Open standard · local validators); Model provider API (Commercial / model dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement reasoningFits and compare two declared budgets on a synthetic latency worksheet. Keep observed accuracy separate from an assumed benefit.

Terminal folder: production-ai/06-01-reasoning-budget

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Reserve generation time after the supplied reasoning allowance. A request fits only when both are nonnegative finite measurements and their total stays inside the deadline. This is a policy model, not a mapping from milliseconds to reasoning tokens.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement reasoningFits and compare two declared budgets on a synthetic latency worksheet. Keep observed accuracy separate from an assumed benefit.

Expected: A reserved answer fits

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Combined allowance obeys the boundary; Invalid measurements fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A reserved answer fits; Combined allowance obeys the boundary; Invalid measurements fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Bound the allowance and leave output/transport headroom. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/06-01-reasoning-budget/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Task → model-specific reasoning allowance → generation → deadline. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does a larger reasoning budget guarantee a correct answer? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Extra compute cannot extend a synchronous service’s deadline. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does a larger reasoning budget guarantee a correct answer?

Interview: Does a larger reasoning budget guarantee a correct answer? Explain the decision, a failing case and a production limitation.

Quiz: Does a larger reasoning budget guarantee a correct answer?

Yes, if it is expensive.

No; validate results and measure the trade-off on relevant cases.

Yes, if its explanation is long.

Reference: No; validate results and measure the trade-off on relevant cases. — Additional inference work is a resource choice. Its value must be established by task-specific evaluation.

Sources:

Qwen Team: Qwen3 thinking modes and inference budgets (2025 example): https://qwenlm.github.io/blog/qwen3/

Hugging Face: LLM inference concepts: https://huggingface.co/docs/transformers/llm_tutorial

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Route by measured task needs, not impressive labels

A small fast model may handle routine requests; harder tasks may justify a more capable model and a verifier. A complexity router is itself a policy that can make mistakes. Use explicit task signals and evaluate wrong-route cases, rather than asking a model to self-certify its difficulty.

This deterministic router sends known complex tasks to a deeper route only when enough latency allowance remains. Unknown task types go to review. The budget thresholds are fictional worksheet inputs, not vendor benchmarks.

A task label is a weak proxy for difficulty. Audit quality and latency by task slice; protect private data regardless of the selected route.

Mental model: Task classification → latency/data policy → fast, deep or review route. Picture the boundary as a checked gate between stages.

Boundary: A task label is a weak proxy for difficulty. Audit quality and latency by task slice; protect private data regardless of the selected route.

Worked example: function chooseModel(kind, remainingMs) {
  if (!Number.isFinite(remainingMs) || remainingMs <= 0) return 'defer';
  if (kind === 'simple') return 'fast';
  if (kind === 'complex') return remainingMs >= 1000 ? 'deep' : 'defer';
  return 'review';
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract reasoning-verifiers.zip, install Node.js LTS, then open production-ai/06-02-complexity-router.

Tools for this exercise: JavaScript · local isolated workbench; JSON Schema, Model provider API as documented optional extensions

Course tool and framework map: JSON Schema (Open standard · local validators); Model provider API (Commercial / model dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement chooseModel. Add a privacy flag in a separate extension and produce a table of wrong-route cases to evaluate.

Terminal folder: production-ai/06-02-complexity-router

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This deterministic router sends known complex tasks to a deeper route only when enough latency allowance remains. Unknown task types go to review. The budget thresholds are fictional worksheet inputs, not vendor benchmarks.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement chooseModel. Add a privacy flag in a separate extension and produce a table of wrong-route cases to evaluate.

Expected: Routine work stays fast

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Complex work needs time; Unknown and invalid work are explicit

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Routine work stays fast; Complex work needs time; Unknown and invalid work are explicit. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Route known simple work fast; defer when deep work cannot fit. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/06-02-complexity-router/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Task classification → latency/data policy → fast, deep or review route. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A complex task cannot fit the request deadline. What is a defensible route? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: An unknown task must not silently receive an assumed-safe route. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A complex task cannot fit the request deadline. What is a defensible route?

Interview: A complex task cannot fit the request deadline. What is a defensible route? Explain the decision, a failing case and a production limitation.

Quiz: A complex task cannot fit the request deadline. What is a defensible route?

Run deep reasoning and hide the timeout.

Pretend the fast result has been verified.

Defer or use an explicitly evaluated alternative.

Reference: Defer or use an explicitly evaluated alternative. — Routing must respect both the task’s quality requirement and the service boundary. A timeout is not a successful answer.

Sources:

Hugging Face: LLM inference concepts: https://huggingface.co/docs/transformers/llm_tutorial

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### Generate → execute → verify with a narrow contract

Generated SQL and JSON are untrusted proposals. A deterministic verifier can test a narrow contract before anything is executed. Start with a constrained query object rather than pretending a regular expression can safely validate arbitrary SQL.

The fixture accepts only a read-only lookup object with exact fields table and limit. It permits one reviewed table and an integer limit from 1 to 50. A real SQL service should use parameterized queries, least-privilege credentials and a database-aware parser.

Schema validity does not prove the query answers the user’s question. This exercise intentionally does not execute SQL or arbitrary model-generated code.

Mental model: Generated query object → schema → table/limit allowlist → parameterized executor. Picture the boundary as a checked gate between stages.

Boundary: Schema validity does not prove the query answers the user’s question. This exercise intentionally does not execute SQL or arbitrary model-generated code.

Worked example: function verifyQuery(q) {
  return !!q && !Array.isArray(q) && Object.keys(q).sort().join(',') === 'limit,table' &&
    q.table === 'public_docs' && Number.isSafeInteger(q.limit) && q.limit >= 1 && q.limit <= 50;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract reasoning-verifiers.zip, install Node.js LTS, then open production-ai/06-03-deterministic-verifier.

Tools for this exercise: JavaScript · local isolated workbench; JSON Schema, Model provider API as documented optional extensions

Course tool and framework map: JSON Schema (Open standard · local validators); Model provider API (Commercial / model dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement verifyQuery. Write the exact parameterized template a real backend would use and keep database execution separate from this policy test.

Terminal folder: production-ai/06-03-deterministic-verifier

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture accepts only a read-only lookup object with exact fields table and limit. It permits one reviewed table and an integer limit from 1 to 50. A real SQL service should use parameterized queries, least-privilege credentials and a database-aware parser.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement verifyQuery. Write the exact parameterized template a real backend would use and keep database execution separate from this policy test.

Expected: The narrow read contract passes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Private tables and extra commands fail; Unbounded, fractional and malformed inputs fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: The narrow read contract passes; Private tables and extra commands fail; Unbounded, fractional and malformed inputs fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Allow only a narrow read contract and bounded result size. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/06-03-deterministic-verifier/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Generated query object → schema → table/limit allowlist → parameterized executor. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Is a keyword regex enough to make arbitrary model-generated SQL safe? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: No generated string becomes executable SQL here. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Is a keyword regex enough to make arbitrary model-generated SQL safe?

Interview: Is a keyword regex enough to make arbitrary model-generated SQL safe? Explain the decision, a failing case and a production limitation.

Quiz: Is a keyword regex enough to make arbitrary model-generated SQL safe?

No; use a narrow contract and database-enforced least privilege.

Yes, if it removes DELETE.

Yes, if the model says read-only.

Reference: No; use a narrow contract and database-enforced least privilege. — String patterns miss syntax and semantic edge cases. Reduce the allowed surface and enforce data permissions at execution.

Sources:

JSON Schema: object validation: https://json-schema.org/understanding-json-schema/reference/object

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Thought summaries are not hidden reasoning transcripts

A user needs useful progress and a clear result, not a fabricated stream of a model’s private reasoning. If the provider offers an approved reasoning summary, label it as a summary. Otherwise report application stages such as validating evidence or waiting for the model.

The fixture exposes only application status and an explicitly provided public summary. Unknown fields, including a raw hidden-reasoning field, are never copied into the UI result. This does not request or reconstruct private chain-of-thought.

A summary is not an audit trail or proof of correctness. Verify outcomes using observable inputs, actions and tests.

Mental model: Application stage → optional public summary → user-facing status. Picture the boundary as a checked gate between stages.

Boundary: A summary is not an audit trail or proof of correctness. Verify outcomes using observable inputs, actions and tests.

Worked example: function publicProgress(event) {
  const statuses = {waiting:'Waiting for model.',verifying:'Checking the result.',done:'Result ready.'};
  return {status:Object.hasOwn(statuses,event.stage) ? statuses[event.stage] : 'Working.',summary:typeof event.publicSummary === 'string' ? event.publicSummary : ''};
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract reasoning-verifiers.zip, install Node.js LTS, then open production-ai/06-04-reasoning-status.

Tools for this exercise: JavaScript · local isolated workbench; JSON Schema, Model provider API as documented optional extensions

Course tool and framework map: JSON Schema (Open standard · local validators); Model provider API (Commercial / model dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement publicProgress and include an unknown field test. Sketch waiting, verifying, failed and done states for a real interface.

Terminal folder: production-ai/06-04-reasoning-status

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture exposes only application status and an explicitly provided public summary. Unknown fields, including a raw hidden-reasoning field, are never copied into the UI result. This does not request or reconstruct private chain-of-thought.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement publicProgress and include an unknown field test. Sketch waiting, verifying, failed and done states for a real interface.

Expected: Application status is clear

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: A supplied public summary is exposed; Internal or malformed fields stay out

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Application status is clear; A supplied public summary is exposed; Internal or malformed fields stay out. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Expose allowlisted status and a labeled public summary only. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/06-04-reasoning-status/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Application stage → optional public summary → user-facing status. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. What should an interface show when no public reasoning summary is provided? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Private internal reasoning is not application evidence. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: What should an interface show when no public reasoning summary is provided?

Interview: What should an interface show when no public reasoning summary is provided? Explain the decision, a failing case and a production limitation.

Quiz: What should an interface show when no public reasoning summary is provided?

A made-up thought transcript.

Actual application status, without inventing internal reasoning.

A claim that the answer has been proven.

Reference: Actual application status, without inventing internal reasoning. — Report observable progress. Neither a long explanation nor a summary substitutes for result verification.

Sources:

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
