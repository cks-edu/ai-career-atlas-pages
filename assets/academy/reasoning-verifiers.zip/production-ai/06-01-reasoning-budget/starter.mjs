function reasoningFits(reasonMs,outputMs,deadlineMs) { return reasonMs <= deadlineMs; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(reasoningFits(100,50,200));
console.log("PASS: A reserved answer fits");
}
{
assert(reasoningFits(150,50,200)); assert(!reasoningFits(151,50,200));
console.log("PASS: Combined allowance obeys the boundary");
}
{
assert(!reasoningFits(NaN,50,200)); assert(!reasoningFits(-1,50,200));
console.log("PASS: Invalid measurements fail");
}
