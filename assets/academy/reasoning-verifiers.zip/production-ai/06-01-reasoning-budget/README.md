# Test-time compute and reasoning budgets

Some models spend additional inference work before answering. That can help certain tasks, but more computation is not a correctness guarantee. Give the task a total deadline and a supported model-specific budget; stop or defer when there is insufficient room.

Reserve generation time after the supplied reasoning allowance. A request fits only when both are nonnegative finite measurements and their total stays inside the deadline. This is a policy model, not a mapping from milliseconds to reasoning tokens.

Task: Implement reasoningFits and compare two declared budgets on a synthetic latency worksheet. Keep observed accuracy separate from an assumed benefit.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Task → model-specific reasoning allowance → generation → deadline.
State: Reasoning and output allowances share the request budget.
Boundary: Extra compute cannot extend a synchronous service’s deadline.
Failure: The model consumes all available time before returning any answer.
Control: Bound the allowance and leave output/transport headroom.
Observability: Measure actual reasoning usage, latency and verifier outcomes.
Blast radius: All requests waiting behind long-running work.
Trade-off: Extra work may help difficult cases but raises latency and cost.

Limit: Different providers expose different budget controls and may account for hidden reasoning tokens differently. A client cannot enforce a hard remote deadline merely by writing it in a prompt.

Sources:
https://qwenlm.github.io/blog/qwen3/
https://huggingface.co/docs/transformers/llm_tutorial
https://opentelemetry.io/docs/concepts/observability-primer/
https://www.nist.gov/itl/ai-risk-management-framework
