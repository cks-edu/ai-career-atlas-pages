# Generate → execute → verify with a narrow contract

Generated SQL and JSON are untrusted proposals. A deterministic verifier can test a narrow contract before anything is executed. Start with a constrained query object rather than pretending a regular expression can safely validate arbitrary SQL.

The fixture accepts only a read-only lookup object with exact fields table and limit. It permits one reviewed table and an integer limit from 1 to 50. A real SQL service should use parameterized queries, least-privilege credentials and a database-aware parser.

Task: Implement verifyQuery. Write the exact parameterized template a real backend would use and keep database execution separate from this policy test.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Generated query object → schema → table/limit allowlist → parameterized executor.
State: The query is data until checks pass.
Boundary: No generated string becomes executable SQL here.
Failure: A broad or malformed query exposes too many records.
Control: Allow only a narrow read contract and bounded result size.
Observability: Log verifier rejection categories and query template ID.
Blast radius: The data available to the executor’s credential.
Trade-off: A constrained language limits flexibility but simplifies enforcement.

Limit: Schema validity does not prove the query answers the user’s question. This exercise intentionally does not execute SQL or arbitrary model-generated code.

Sources:
https://json-schema.org/understanding-json-schema/reference/object
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
