function verifyQuery(q) { return !!q; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(verifyQuery({table:'public_docs',limit:10}));
console.log("PASS: The narrow read contract passes");
}
{
assert(!verifyQuery({table:'payroll',limit:10})); assert(!verifyQuery({table:'public_docs',limit:10,sql:'DROP TABLE docs'}));
console.log("PASS: Private tables and extra commands fail");
}
{
assert(!verifyQuery({table:'public_docs',limit:51})); assert(!verifyQuery({table:'public_docs',limit:1.5})); assert(!verifyQuery(null));
console.log("PASS: Unbounded, fractional and malformed inputs fail");
}
