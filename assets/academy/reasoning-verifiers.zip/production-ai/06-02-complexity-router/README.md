# Route by measured task needs, not impressive labels

A small fast model may handle routine requests; harder tasks may justify a more capable model and a verifier. A complexity router is itself a policy that can make mistakes. Use explicit task signals and evaluate wrong-route cases, rather than asking a model to self-certify its difficulty.

This deterministic router sends known complex tasks to a deeper route only when enough latency allowance remains. Unknown task types go to review. The budget thresholds are fictional worksheet inputs, not vendor benchmarks.

Task: Implement chooseModel. Add a privacy flag in a separate extension and produce a table of wrong-route cases to evaluate.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Task classification → latency/data policy → fast, deep or review route.
State: Task kind and remaining time determine the proposal.
Boundary: An unknown task must not silently receive an assumed-safe route.
Failure: A complex task is placed on a slow synchronous checkout path.
Control: Route known simple work fast; defer when deep work cannot fit.
Observability: Record routing reason, actual latency and verifier result.
Blast radius: The endpoint depending on the router’s decision.
Trade-off: Fast routing lowers latency but can reduce quality on misclassified cases.

Limit: A task label is a weak proxy for difficulty. Audit quality and latency by task slice; protect private data regardless of the selected route.

Sources:
https://huggingface.co/docs/transformers/llm_tutorial
https://opentelemetry.io/docs/concepts/observability-primer/
