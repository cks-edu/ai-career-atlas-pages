function chooseModel(kind,remainingMs) { return "deep"; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(chooseModel('simple',100)==='fast');
console.log("PASS: Routine work stays fast");
}
{
assert(chooseModel('complex',1000)==='deep'); assert(chooseModel('complex',999)==='defer');
console.log("PASS: Complex work needs time");
}
{
assert(chooseModel('unknown',1000)==='review'); assert(chooseModel('simple',NaN)==='defer');
console.log("PASS: Unknown and invalid work are explicit");
}
