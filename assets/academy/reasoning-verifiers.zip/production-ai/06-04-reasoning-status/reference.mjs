function publicProgress(event) {
  const statuses = {waiting:'Waiting for model.',verifying:'Checking the result.',done:'Result ready.'};
  return {status:Object.hasOwn(statuses,event.stage) ? statuses[event.stage] : 'Working.',summary:typeof event.publicSummary === 'string' ? event.publicSummary : ''};
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(publicProgress({stage:'verifying'}).status==='Checking the result.');
console.log("PASS: Application status is clear");
}
{
assert(publicProgress({stage:'waiting',publicSummary:'Comparing permitted sources.'}).summary==='Comparing permitted sources.');
console.log("PASS: A supplied public summary is exposed");
}
{
const r=publicProgress({stage:'waiting',hiddenReasoning:'private',publicSummary:4}); assert(!('hiddenReasoning' in r) && r.summary==='');
console.log("PASS: Internal or malformed fields stay out");
}
