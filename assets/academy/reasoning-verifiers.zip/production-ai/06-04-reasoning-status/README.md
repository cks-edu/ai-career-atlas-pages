# Thought summaries are not hidden reasoning transcripts

A user needs useful progress and a clear result, not a fabricated stream of a model’s private reasoning. If the provider offers an approved reasoning summary, label it as a summary. Otherwise report application stages such as validating evidence or waiting for the model.

The fixture exposes only application status and an explicitly provided public summary. Unknown fields, including a raw hidden-reasoning field, are never copied into the UI result. This does not request or reconstruct private chain-of-thought.

Task: Implement publicProgress and include an unknown field test. Sketch waiting, verifying, failed and done states for a real interface.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Application stage → optional public summary → user-facing status.
State: Only approved summary and state fields cross to the UI.
Boundary: Private internal reasoning is not application evidence.
Failure: A UI fabricates a detailed thought transcript while waiting.
Control: Expose allowlisted status and a labeled public summary only.
Observability: Record stage timestamps and actual tool/verifier outcomes.
Blast radius: The displayed explanation and any exported trace.
Trade-off: Concise status is honest and usable but reveals less internal detail.

Limit: A summary is not an audit trail or proof of correctness. Verify outcomes using observable inputs, actions and tests.

Sources:
https://opentelemetry.io/docs/concepts/observability-primer/
https://www.nist.gov/itl/ai-risk-management-framework
