# Performance report with regressions and limits

Project: Correctness-first GPU kernel benchmark
Status: blank work product — not completed evidence

## Purpose and audience
Implement and benchmark a GPU operation while preserving numerical and boundary correctness.

## Required content
Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.

## Failure evidence
Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
