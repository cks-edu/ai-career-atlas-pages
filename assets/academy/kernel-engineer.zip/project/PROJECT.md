# Correctness-first GPU kernel benchmark

Career: ML compiler / GPU kernel engineer
Reviewed: 2026-10-22

Implement and benchmark a GPU operation while preserving numerical and boundary correctness.

## Prerequisites
Computer architecture, parallel programming, numerical methods and low-level debugging.

## Included starter versus your implementation
A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Kernel source and correctness suite — artifact-1.md
2. Benchmark harness and hardware manifest — artifact-2.md
3. Performance report with regressions and limits — artifact-3.md

## Troubleshooting
- CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
- OOM: reduce batch/context size and inspect live allocations.
- Unstable timings: warm up, synchronize and isolate other workloads.

## Extension
Add one fusion or layout optimization and explain the memory-access trade-off.

## Primary learning resources
- Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html — Open source · supported GPU; GPU kernel correctness and performance methodology.
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.
- NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html — Vendor software · NVIDIA hardware; Driver, device-plugin and GPU scheduling prerequisites.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
