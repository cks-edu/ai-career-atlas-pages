# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Kernel source and correctness suite.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
