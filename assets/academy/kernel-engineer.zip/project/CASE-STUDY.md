# Correctness-first GPU kernel benchmark

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Implement and benchmark a GPU operation while preserving numerical and boundary correctness.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

## Limitations and next iteration
Add one fusion or layout optimization and explain the memory-access trade-off.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
