## intermediate — Tail masks and numerical correctness

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Computer architecture, parallel programming, numerical methods and low-level debugging.

### Tail masks and numerical correctness
Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block.
Mental model: The final bus may be partly empty; do not count nonexistent passengers.
Boundary: A passing shape does not prove correctness for other strides or dtypes.
Worked example: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Correctness-first GPU kernel benchmark
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Recall: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. Identify one observation that would contradict your claim.

### Terms
Tail masks and numerical correctness: Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The numerical contract flags absolute error above 0.001 against the reference implementation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Implement and benchmark a GPU operation while preserving numerical and boundary correctness.
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.
Deliverables: Kernel source and correctness suite; Benchmark harness and hardware manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for ML compiler / GPU kernel engineer. Use this scenario: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Review: Start with the task and permitted scope. Explain tail masks and numerical correctness: Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block. Show the input and observed output, then address Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Kernel source and correctness suite; Benchmark harness and hardware manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

