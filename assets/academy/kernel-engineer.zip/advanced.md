## advanced — Fair kernel benchmarks

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Fair kernel benchmarks
Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions.
Mental model: Time the race itself rather than one runner's shoe-fitting session.
Boundary: A faster microbenchmark may not improve an application dominated by other operations.
Worked example: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Correctness-first GPU kernel benchmark
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Recall: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. Identify one observation that would contradict your claim.

### Terms
Fair kernel benchmarks: Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Implement and benchmark a GPU operation while preserving numerical and boundary correctness.
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.
Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.
Add one fusion or layout optimization and explain the memory-access trade-off.
Deliverables: Kernel source and correctness suite; Benchmark harness and hardware manifest; Performance report with regressions and limits. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A reviewer must reproduce one result and identify which capabilities you implemented. Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

### Interview
Explain your advanced solution for ML compiler / GPU kernel engineer. Use this scenario: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Review: Start with the task and permitted scope. Explain fair kernel benchmarks: Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions. Show the input and observed output, then address Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Kernel source and correctness suite; Benchmark harness and hardware manifest; Performance report with regressions and limits. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

