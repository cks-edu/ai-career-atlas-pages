# ML compiler / GPU kernel engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Threads, blocks and memory. A GPU kernel is a small function run across many data elements. Correctness and memory access must be understood before performance tuning. Then try Map a parallel vector addition. The three levels build toward Correctness-first GPU kernel benchmark. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Threads, blocks and memory

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Threads, blocks and memory
A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing.
Mental model: Many workers share storage rooms with different distances and capacities.
Boundary: A CPU tensor example does not validate GPU scheduling or memory behavior.
Worked example: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The fast kernel changes the answer
The numerical contract flags absolute error above 0.001 against the reference implementation. Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again.
Recall: Run correctness across irregular shapes and extreme values before synchronized timing tests. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Threads, blocks and memory: A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A GPU kernel is a small function run across many data elements. Correctness and memory access must be understood before performance tuning.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Take A = [1, 2, 3, 4] and B = [10, 20, 30, 40]. Number positions from 0 to 3 and assign one output position to each of four workers.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

3. Try step 2
Record which inputs each worker reads and which output it writes.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

4. Try step 3
Add a fifth worker and specify a bounds check so it does not access index 4.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

5. Explain and check your result
The output is [11, 22, 33, 44]; each valid index has one writer and the extra worker performs no array access. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A worker-to-index table and a bounds-check rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The numerical contract flags absolute error above 0.001 against the reference implementation. Apply this toy-case rule manually: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to ML compiler / GPU kernel engineer.
Take A = [1, 2, 3, 4] and B = [10, 20, 30, 40]. Number positions from 0 to 3 and assign one output position to each of four workers.
Record which inputs each worker reads and which output it writes.
Add a fifth worker and specify a bounds check so it does not access index 4.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A worker-to-index table and a bounds-check rule. Include beginner-worksheet.md and your completed Numerical correctness and performance matrix.
Check: The output is [11, 22, 33, 44]; each valid index has one writer and the extra worker performs no array access.

### Interview
Explain your beginner solution for ML compiler / GPU kernel engineer. Use this scenario: The numerical contract flags absolute error above 0.001 against the reference implementation.
Review: Start with the task and permitted scope. Explain threads, blocks and memory: A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing. Show the input and observed output, then address Inspect accumulation precision and edge shapes before benchmarking the candidate again. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A worker-to-index table and a bounds-check rule. Include beginner-worksheet.md and your completed Numerical correctness and performance matrix.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Tail masks and numerical correctness

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Computer architecture, parallel programming, numerical methods and low-level debugging.

### Tail masks and numerical correctness
Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block.
Mental model: The final bus may be partly empty; do not count nonexistent passengers.
Boundary: A passing shape does not prove correctness for other strides or dtypes.
Worked example: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Correctness-first GPU kernel benchmark
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Recall: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. Identify one observation that would contradict your claim.

### Terms
Tail masks and numerical correctness: Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The numerical contract flags absolute error above 0.001 against the reference implementation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Implement and benchmark a GPU operation while preserving numerical and boundary correctness.
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.
Deliverables: Kernel source and correctness suite; Benchmark harness and hardware manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for ML compiler / GPU kernel engineer. Use this scenario: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Review: Start with the task and permitted scope. Explain tail masks and numerical correctness: Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block. Show the input and observed output, then address Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Kernel source and correctness suite; Benchmark harness and hardware manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Fair kernel benchmarks

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Fair kernel benchmarks
Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions.
Mental model: Time the race itself rather than one runner's shoe-fitting session.
Boundary: A faster microbenchmark may not improve an application dominated by other operations.
Worked example: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Correctness-first GPU kernel benchmark
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Recall: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. Identify one observation that would contradict your claim.

### Terms
Fair kernel benchmarks: Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Implement and benchmark a GPU operation while preserving numerical and boundary correctness. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Implement and benchmark a GPU operation while preserving numerical and boundary correctness.
Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.
Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.
Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.
Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.
Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.
Add one fusion or layout optimization and explain the memory-access trade-off.
Deliverables: Kernel source and correctness suite; Benchmark harness and hardware manifest; Performance report with regressions and limits. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A reviewer must reproduce one result and identify which capabilities you implemented. Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

### Interview
Explain your advanced solution for ML compiler / GPU kernel engineer. Use this scenario: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.
Review: Start with the task and permitted scope. Explain fair kernel benchmarks: Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions. Show the input and observed output, then address Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Kernel source and correctness suite; Benchmark harness and hardware manifest; Performance report with regressions and limits. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Triton kernel tutorial — Open source · supported GPU
GPU kernel correctness and performance methodology.
Alternative: CUDA C++ for compatible NVIDIA hardware; vendor toolchain terms and portability differ from the Triton compiler.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NVIDIA GPU Operator — Vendor software · NVIDIA hardware
Driver, device-plugin and GPU scheduling prerequisites.
Alternative: AMD ROCm is an alternative hardware/software ecosystem, not a drop-in NVIDIA GPU Operator replacement; validate framework and device support.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html
NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html
Triton language: https://triton-lang.org/main/index.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
