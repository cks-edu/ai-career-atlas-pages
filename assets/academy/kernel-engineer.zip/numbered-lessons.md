# ML compiler / GPU kernel engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Threads, blocks and memory: A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

tensor: A multidimensional array of values with a shape and data type.

### Threads, blocks and memory

A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing. In this role, work through: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Many workers share storage rooms with different distances and capacities.

Boundary: A CPU tensor example does not validate GPU scheduling or memory behavior.

Worked example: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Triton kernel tutorial (Open source · supported GPU); PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ML compiler / GPU kernel engineer: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum.

Predict the worked case

Read this case without running a tool: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in threads, blocks and memory.

Connect the concept to the role

Apply this rule: A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A CPU tensor example does not validate GPU scheduling or memory behavior.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies threads, blocks and memory to this case: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Threads, blocks and memory; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threads, blocks and memory. Use the glossary below, then write your prediction for: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ML compiler / GPU kernel engineer role interview. Explain threads, blocks and memory using this case: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threads, blocks and memory to a system or workflow you know. Explain threads, blocks and memory using this case: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain threads, blocks and memory using this case: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Vector addition assigns output indices to workers; each valid index reads two values and writes one sum.

A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing. — A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing. A CPU tensor example does not validate GPU scheduling or memory behavior.

Sources:

Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Triton language: https://triton-lang.org/main/index.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Diagnose: The fast kernel changes the answer

The numerical contract flags absolute error above 0.001 against the reference implementation. Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Many workers share storage rooms with different distances and capacities.

Vector addition assigns output indices to workers; each valid index reads two values and writes one sum.

Worked example: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Triton kernel tutorial (Open source · supported GPU); PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The numerical contract flags absolute error above 0.001 against the reference implementation. Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The numerical contract flags absolute error above 0.001 against the reference implementation. Apply this toy-case rule manually: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A GPU kernel is a small function run across many data elements. Correctness and memory access must be understood before performance tuning.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Take A = [1, 2, 3, 4] and B = [10, 20, 30, 40]. Number positions from 0 to 3 and assign one output position to each of four workers.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

Preparation · Try step 2

Record which inputs each worker reads and which output it writes.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

Preparation · Try step 3

Add a fifth worker and specify a bounds check so it does not access index 4.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

Preparation · Explain and check your result

The output is [11, 22, 33, 44]; each valid index has one writer and the extra worker performs no array access. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A worker-to-index table and a bounds-check rule. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The numerical contract flags absolute error above 0.001 against the reference implementation. Apply this toy-case rule manually: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the fast kernel changes the answer. Use the glossary below, then write your prediction for: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ML compiler / GPU kernel engineer role interview. Explain diagnose: the fast kernel changes the answer using this case: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the fast kernel changes the answer to a system or workflow you know. Explain diagnose: the fast kernel changes the answer using this case: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Run correctness across irregular shapes and extreme values before synchronized timing tests. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the fast kernel changes the answer using this case: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again. State the evidence, one alternative and where the mental model stops.

Quiz: The fast kernel changes the answer: The numerical contract flags absolute error above 0.001 against the reference implementation.

Change the acceptance rule after seeing an inconvenient result.

Inspect accumulation precision and edge shapes before benchmarking the candidate again.

Omit failed cases and report only the successful demonstrations.

Reference: Inspect accumulation precision and edge shapes before benchmarking the candidate again. — Inspect accumulation precision and edge shapes before benchmarking the candidate again. Run correctness across irregular shapes and extreme values before synchronized timing tests.

Sources:

Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Triton language: https://triton-lang.org/main/index.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Computer architecture, parallel programming, numerical methods and low-level debugging.

Terms:

Tail masks and numerical correctness: Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

tensor: A multidimensional array of values with a shape and data type.

### Tail masks and numerical correctness

Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block. In this role, work through: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: The final bus may be partly empty; do not count nonexistent passengers.

Boundary: A passing shape does not prove correctness for other strides or dtypes.

Worked example: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Computer architecture, parallel programming, numerical methods and low-level debugging.

Tools for this exercise: Document or text editor

Course tool and framework map: Triton kernel tutorial (Open source · supported GPU); PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ML compiler / GPU kernel engineer: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses.

Predict the worked case

Read this case without running a tool: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in tail masks and numerical correctness.

Connect the concept to the role

Apply this rule: Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A passing shape does not prove correctness for other strides or dtypes.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies tail masks and numerical correctness to this case: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Tail masks and numerical correctness; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with tail masks and numerical correctness. Use the glossary below, then write your prediction for: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ML compiler / GPU kernel engineer role interview. Explain tail masks and numerical correctness using this case: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate tail masks and numerical correctness to a system or workflow you know. Explain tail masks and numerical correctness using this case: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain tail masks and numerical correctness using this case: For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses.

Treat a passing starter as proof of the whole role workflow.

Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block.

Ignore the failure because the tool produced an output.

Reference: Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block. — Guard accesses outside valid ranges and compare against a trusted reference using suitable tolerances. Include sizes that do not fill a complete block. A passing shape does not prove correctness for other strides or dtypes.

Sources:

Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Triton language: https://triton-lang.org/main/index.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Integrate: Correctness-first GPU kernel benchmark

Implement and benchmark a GPU operation while preserving numerical and boundary correctness. Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances. In this role, work through: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: The final bus may be partly empty; do not count nonexistent passengers.

For 130 elements with blocks of 128, only two positions in the final block are valid; mask the other accesses.

Worked example: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Triton kernel tutorial (Open source · supported GPU); PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware)

Implement and benchmark a GPU operation while preserving numerical and boundary correctness. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Implement and benchmark a GPU operation while preserving numerical and boundary correctness.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The numerical contract flags absolute error above 0.001 against the reference implementation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-intermediate-2.md: Kernel source and correctness suite; Benchmark harness and hardware manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: correctness-first gpu kernel benchmark. Use the glossary below, then write your prediction for: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ML compiler / GPU kernel engineer role interview. Explain integrate: correctness-first gpu kernel benchmark using this case: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: correctness-first gpu kernel benchmark to a system or workflow you know. Explain integrate: correctness-first gpu kernel benchmark using this case: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. Identify one observation that would contradict your claim.

Interview: Explain integrate: correctness-first gpu kernel benchmark using this case: Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Correctness-first GPU kernel benchmark at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.

Reference: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. — Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.

Sources:

Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Triton language: https://triton-lang.org/main/index.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Fair kernel benchmarks: Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

tensor: A multidimensional array of values with a shape and data type.

### Fair kernel benchmarks

Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions. In this role, work through: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Time the race itself rather than one runner's shoe-fitting session.

Boundary: A faster microbenchmark may not improve an application dominated by other operations.

Worked example: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Triton kernel tutorial (Open source · supported GPU); PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ML compiler / GPU kernel engineer: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column.

Predict the worked case

Read this case without running a tool: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in fair kernel benchmarks.

Connect the concept to the role

Apply this rule: Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A faster microbenchmark may not improve an application dominated by other operations.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies fair kernel benchmarks to this case: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Fair kernel benchmarks; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with fair kernel benchmarks. Use the glossary below, then write your prediction for: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ML compiler / GPU kernel engineer role interview. Explain fair kernel benchmarks using this case: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate fair kernel benchmarks to a system or workflow you know. Explain fair kernel benchmarks using this case: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain fair kernel benchmarks using this case: Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions.

Reference: Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions. — Warm up compilation, synchronize asynchronous work and compare like-for-like inputs. Report errors and performance across several shapes, including regressions. A faster microbenchmark may not improve an application dominated by other operations.

Sources:

Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Triton language: https://triton-lang.org/main/index.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Defend: Correctness-first GPU kernel benchmark

Implement and benchmark a GPU operation while preserving numerical and boundary correctness. Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth. In this role, work through: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: Time the race itself rather than one runner's shoe-fitting session.

Measure repeated steady-state executions of both reference and candidate, keeping compilation timing in a separate column.

Worked example: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Triton kernel tutorial (Open source · supported GPU); PyTorch (Open source · hardware dependent); NVIDIA GPU Operator (Vendor software · NVIDIA hardware)

Implement and benchmark a GPU operation while preserving numerical and boundary correctness. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Implement and benchmark a GPU operation while preserving numerical and boundary correctness.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Use a compatible Triton GPU environment. Start with vector addition, then choose a bounded fused operation; keep a PyTorch reference and record supported dtypes/shapes.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run tensor_probe.py and the official Triton vector-add tutorial. Write your own kernel file with masks for partial blocks and explicit output allocation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Test empty/small inputs, non-multiple block sizes, several dtypes and documented stride assumptions. Compare against the reference using justified tolerances.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Benchmark warmed-up repeated runs with synchronization and several shapes. Separate compilation from execution and record peak memory plus effective bandwidth.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. A reviewer must reproduce one result and identify which capabilities you implemented. Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-advanced-2.md: Kernel source and correctness suite; Benchmark harness and hardware manifest; Performance report with regressions and limits. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: correctness-first gpu kernel benchmark. Use the glossary below, then write your prediction for: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ML compiler / GPU kernel engineer role interview. Explain defend: correctness-first gpu kernel benchmark using this case: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: correctness-first gpu kernel benchmark to a system or workflow you know. Explain defend: correctness-first gpu kernel benchmark using this case: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side. Identify one observation that would contradict your claim.

Interview: Explain defend: correctness-first gpu kernel benchmark using this case: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Correctness-first GPU kernel benchmark at this level?

Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups. — Disable the tail mask in a test copy and show a boundary failure; restore it and rerun all correctness cases before publishing speedups. Report maximum absolute/relative error and speed ratio by shape. Never generalize a single favorable shape or include reference startup overhead in only one side.

Sources:

Triton kernel tutorial: https://triton-lang.org/main/getting-started/tutorials/01-vector-add.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

NVIDIA GPU Operator: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/getting-started.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

Triton language: https://triton-lang.org/main/index.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
