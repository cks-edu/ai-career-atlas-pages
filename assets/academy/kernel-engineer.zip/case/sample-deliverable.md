# SAMPLE — Numerical correctness and performance matrix
Role: ML compiler / GPU kernel engineer
Case: The fast kernel changes the answer
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The numerical contract flags absolute error above 0.001 against the reference implementation.

## Evidence table
| Record | absolute_error (absolute units) | Decision |
|---|---:|---|
| case-1 | 0.0001 | within_demo_bound |
| case-2 | 0.001 | within_demo_bound |
| case-3 | 0.002 | review |
| case-4 | 0.01 | review |
| case-5 | 0.0005 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Inspect accumulation precision and edge shapes before benchmarking the candidate again.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ml compiler / gpu kernel engineer.
Before release: Run correctness across irregular shapes and extreme values before synchronized timing tests.

## Design choice and trade-off
Validate semantics before optimization; benchmark warmup and synchronization consistently.
Reduced precision may improve throughput but must respect task-specific error tolerance.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Fused tensor operator: Report regressions and hardware/software versions.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
