## beginner — Threads, blocks and memory

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Threads, blocks and memory
A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing.
Mental model: Many workers share storage rooms with different distances and capacities.
Boundary: A CPU tensor example does not validate GPU scheduling or memory behavior.
Worked example: Vector addition assigns output indices to workers; each valid index reads two values and writes one sum.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The fast kernel changes the answer
The numerical contract flags absolute error above 0.001 against the reference implementation. Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Inspect accumulation precision and edge shapes before benchmarking the candidate again.
Recall: Run correctness across irregular shapes and extreme values before synchronized timing tests. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Threads, blocks and memory: A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A GPU kernel is a small function run across many data elements. Correctness and memory access must be understood before performance tuning.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Take A = [1, 2, 3, 4] and B = [10, 20, 30, 40]. Number positions from 0 to 3 and assign one output position to each of four workers.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

3. Try step 2
Record which inputs each worker reads and which output it writes.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

4. Try step 3
Add a fifth worker and specify a bounds check so it does not access index 4.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worker-to-index table and a bounds-check rule.

5. Explain and check your result
The output is [11, 22, 33, 44]; each valid index has one writer and the extra worker performs no array access. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A worker-to-index table and a bounds-check rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The numerical contract flags absolute error above 0.001 against the reference implementation. Apply this toy-case rule manually: Review when absolute_error > 0.001 (absolute units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two optimized cases violate the declared numerical tolerance; speed alone cannot justify the kernel. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to ML compiler / GPU kernel engineer.
Take A = [1, 2, 3, 4] and B = [10, 20, 30, 40]. Number positions from 0 to 3 and assign one output position to each of four workers.
Record which inputs each worker reads and which output it writes.
Add a fifth worker and specify a bounds check so it does not access index 4.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A worker-to-index table and a bounds-check rule. Include beginner-worksheet.md and your completed Numerical correctness and performance matrix.
Check: The output is [11, 22, 33, 44]; each valid index has one writer and the extra worker performs no array access.

### Interview
Explain your beginner solution for ML compiler / GPU kernel engineer. Use this scenario: The numerical contract flags absolute error above 0.001 against the reference implementation.
Review: Start with the task and permitted scope. Explain threads, blocks and memory: A GPU kernel maps parallel work to hardware and moves data through a memory hierarchy. Begin with a reference operation and explicit shapes before optimizing. Show the input and observed output, then address Inspect accumulation precision and edge shapes before benchmarking the candidate again. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A worker-to-index table and a bounds-check rule. Include beginner-worksheet.md and your completed Numerical correctness and performance matrix.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

