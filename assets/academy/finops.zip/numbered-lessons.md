# AI FinOps / capacity engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Cost per useful outcome: Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Cost per useful outcome

Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow. In this role, work through: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Compare the cost of completed deliveries, not just fuel per kilometer.

Boundary: State what is included; local electricity, people and hardware are not automatically zero.

Worked example: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); FinOps for AI (Public framework); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI FinOps / capacity engineer: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs.

Predict the worked case

Read this case without running a tool: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in cost per useful outcome.

Connect the concept to the role

Apply this rule: Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: State what is included; local electricity, people and hardware are not automatically zero.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies cost per useful outcome to this case: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Cost per useful outcome; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cost per useful outcome. Use the glossary below, then write your prediction for: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI FinOps / capacity engineer role interview. Explain cost per useful outcome using this case: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cost per useful outcome to a system or workflow you know. Explain cost per useful outcome using this case: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain cost per useful outcome using this case: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs.

Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow. — Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow. State what is included; local electricity, people and hardware are not automatically zero.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Diagnose: Cheap tokens, expensive outcomes

The trial budget caps cost per accepted task at 0.10 synthetic currency units. Two routes exceed the outcome budget after retries and rejected outputs are included. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Compare the cost of completed deliveries, not just fuel per kilometer.

A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs.

Worked example: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); FinOps for AI (Public framework); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The trial budget caps cost per accepted task at 0.10 synthetic currency units. Two routes exceed the outcome budget after retries and rejected outputs are included. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial budget caps cost per accepted task at 0.10 synthetic currency units. Apply this toy-case rule manually: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Cost per successful task includes failed attempts and other costs. A cheap individual request may still produce an expensive useful result.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Option A costs 10 units for 100 attempts with 50 accepted results. Option B costs 12 units for 100 attempts with 80 accepted results.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

Preparation · Try step 2

Divide each total cost by accepted results.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

Preparation · Try step 3

Add a note listing costs not included, such as staff review and storage.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

Preparation · Explain and check your result

A costs 0.20 units per accepted result and B costs 0.15; the cheaper attempt is not the cheaper accepted result. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A two-row spreadsheet or handwritten cost comparison. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial budget caps cost per accepted task at 0.10 synthetic currency units. Apply this toy-case rule manually: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two routes exceed the outcome budget after retries and rejected outputs are included. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two routes exceed the outcome budget after retries and rejected outputs are included. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: cheap tokens, expensive outcomes. Use the glossary below, then write your prediction for: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI FinOps / capacity engineer role interview. Explain diagnose: cheap tokens, expensive outcomes using this case: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: cheap tokens, expensive outcomes to a system or workflow you know. Explain diagnose: cheap tokens, expensive outcomes using this case: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Reconcile total spend and accepted outcomes using the same reporting window. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: cheap tokens, expensive outcomes using this case: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes. State the evidence, one alternative and where the mental model stops.

Quiz: Cheap tokens, expensive outcomes: The trial budget caps cost per accepted task at 0.10 synthetic currency units.

Change the acceptance rule after seeing an inconvenient result.

Allocate retries and review overhead before comparing model routes.

Omit failed cases and report only the successful demonstrations.

Reference: Allocate retries and review overhead before comparing model routes. — Allocate retries and review overhead before comparing model routes. Reconcile total spend and accepted outcomes using the same reporting window.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn cloud billing, SQL/Python analysis, tagging and allocation, plus inference workload metrics. FinOps work is collaborative; the most useful skills include explaining assumptions and checking total cost, not just optimizing token prices.

Terms:

Usage allocation: Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Usage allocation

Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible. In this role, work through: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A shared electricity bill needs meters or an explicit allocation rule.

Boundary: Allocation is an accounting policy, not proof of which team caused every shared cost.

Worked example: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn cloud billing, SQL/Python analysis, tagging and allocation, plus inference workload metrics. FinOps work is collaborative; the most useful skills include explaining assumptions and checking total cost, not just optimizing token prices.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); FinOps for AI (Public framework); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI FinOps / capacity engineer: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently.

Predict the worked case

Read this case without running a tool: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in usage allocation.

Connect the concept to the role

Apply this rule: Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Allocation is an accounting policy, not proof of which team caused every shared cost.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies usage allocation to this case: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Usage allocation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with usage allocation. Use the glossary below, then write your prediction for: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI FinOps / capacity engineer role interview. Explain usage allocation using this case: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate usage allocation to a system or workflow you know. Explain usage allocation using this case: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain usage allocation using this case: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently.

Treat a passing starter as proof of the whole role workflow.

Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible.

Ignore the failure because the tool produced an output.

Reference: Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible. — Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible. Allocation is an accounting policy, not proof of which team caused every shared cost.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Integrate: AI usage attribution and budget simulator

Build a transparent cost ledger and compare routing decisions against a quality floor. Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals. In this role, work through: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A shared electricity bill needs meters or an explicit allocation rule.

A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently.

Worked example: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); FinOps for AI (Public framework); LibreOffice Calc (Open source · no account needed)

Build a transparent cost ledger and compare routing decisions against a quality floor. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a transparent cost ledger and compare routing decisions against a quality floor.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The trial budget caps cost per accepted task at 0.10 synthetic currency units. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Usage/rate schema and SQL views; Showback workbook and reconciliation tests. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: ai usage attribution and budget simulator. Use the glossary below, then write your prediction for: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI FinOps / capacity engineer role interview. Explain integrate: ai usage attribution and budget simulator using this case: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: ai usage attribution and budget simulator to a system or workflow you know. Explain integrate: ai usage attribution and budget simulator using this case: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. Identify one observation that would contradict your claim.

Interview: Explain integrate: ai usage attribution and budget simulator using this case: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI usage attribution and budget simulator at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.

Reference: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. — Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Quality-constrained optimization: Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Quality-constrained optimization

Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison. In this role, work through: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A cheaper delivery method is useful only if parcels arrive intact and on time.

Boundary: Optimization results depend on the measured workload and changing prices.

Worked example: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); FinOps for AI (Public framework); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI FinOps / capacity engineer: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it.

Predict the worked case

Read this case without running a tool: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in quality-constrained optimization.

Connect the concept to the role

Apply this rule: Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Optimization results depend on the measured workload and changing prices.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies quality-constrained optimization to this case: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Quality-constrained optimization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with quality-constrained optimization. Use the glossary below, then write your prediction for: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI FinOps / capacity engineer role interview. Explain quality-constrained optimization using this case: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate quality-constrained optimization to a system or workflow you know. Explain quality-constrained optimization using this case: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain quality-constrained optimization using this case: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison.

Reference: Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison. — Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison. Optimization results depend on the measured workload and changing prices.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Defend: AI usage attribution and budget simulator

Build a transparent cost ledger and compare routing decisions against a quality floor. Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks. In this role, work through: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A cheaper delivery method is useful only if parcels arrive intact and on time.

A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it.

Worked example: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); FinOps for AI (Public framework); LibreOffice Calc (Open source · no account needed)

Build a transparent cost ledger and compare routing decisions against a quality floor. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a transparent cost ledger and compare routing decisions against a quality floor.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A reviewer must reproduce one result and identify which capabilities you implemented. Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Usage/rate schema and SQL views; Showback workbook and reconciliation tests; Budget policy and routing decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: ai usage attribution and budget simulator. Use the glossary below, then write your prediction for: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI FinOps / capacity engineer role interview. Explain defend: ai usage attribution and budget simulator using this case: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: ai usage attribution and budget simulator to a system or workflow you know. Explain defend: ai usage attribution and budget simulator using this case: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. Identify one observation that would contradict your claim.

Interview: Explain defend: ai usage attribution and budget simulator using this case: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI usage attribution and budget simulator at this level?

Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy. — Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy. Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Prometheus: https://prometheus.io/docs/introduction/overview/
