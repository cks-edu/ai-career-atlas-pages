## advanced — Quality-constrained optimization

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Quality-constrained optimization
Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison.
Mental model: A cheaper delivery method is useful only if parcels arrive intact and on time.
Boundary: Optimization results depend on the measured workload and changing prices.
Worked example: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI usage attribution and budget simulator
Build a transparent cost ledger and compare routing decisions against a quality floor. Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Recall: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. Identify one observation that would contradict your claim.

### Terms
Quality-constrained optimization: Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a transparent cost ledger and compare routing decisions against a quality floor. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a transparent cost ledger and compare routing decisions against a quality floor.
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks.
Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.
Import a sanitized real billing export with permission and explain discounts, commitments and shared costs.
Deliverables: Usage/rate schema and SQL views; Showback workbook and reconciliation tests; Budget policy and routing decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A reviewer must reproduce one result and identify which capabilities you implemented. Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

### Interview
Explain your advanced solution for AI FinOps / capacity engineer. Use this scenario: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Review: Start with the task and permitted scope. Explain quality-constrained optimization: Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison. Show the input and observed output, then address Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Usage/rate schema and SQL views; Showback workbook and reconciliation tests; Budget policy and routing decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

