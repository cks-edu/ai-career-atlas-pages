# SAMPLE — Reconciled AI unit-cost ledger
Role: AI FinOps / capacity engineer
Case: Cheap tokens, expensive outcomes
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The trial budget caps cost per accepted task at 0.10 synthetic currency units.

## Evidence table
| Record | cost_per_accepted (synthetic units) | Decision |
|---|---:|---|
| case-1 | 0.04 | within_demo_bound |
| case-2 | 0.1 | within_demo_bound |
| case-3 | 0.11 | review |
| case-4 | 0.25 | review |
| case-5 | 0.08 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two routes exceed the outcome budget after retries and rejected outputs are included.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Allocate retries and review overhead before comparing model routes.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai finops / capacity engineer.
Before release: Reconcile total spend and accepted outcomes using the same reporting window.

## Design choice and trade-off
Measure cost per accepted outcome with quality constraints; disclose shared-cost allocation.
A cheaper model can cost more per useful result if errors and review increase.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Reconcile AI cost per successful outcome: Reconcile every request cost, including failures and unknown owners. Publish the outcome definition and denominator. Keep illustrative numbers clearly separate from actual provider bills and rates.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
