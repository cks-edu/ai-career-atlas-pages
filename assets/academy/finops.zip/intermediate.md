## intermediate — Usage allocation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn cloud billing, SQL/Python analysis, tagging and allocation, plus inference workload metrics. FinOps work is collaborative; the most useful skills include explaining assumptions and checking total cost, not just optimizing token prices.

### Usage allocation
Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible.
Mental model: A shared electricity bill needs meters or an explicit allocation rule.
Boundary: Allocation is an accounting policy, not proof of which team caused every shared cost.
Worked example: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI usage attribution and budget simulator
Build a transparent cost ledger and compare routing decisions against a quality floor. Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Recall: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. Identify one observation that would contradict your claim.

### Terms
Usage allocation: Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a transparent cost ledger and compare routing decisions against a quality floor. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The trial budget caps cost per accepted task at 0.10 synthetic currency units. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a transparent cost ledger and compare routing decisions against a quality floor.
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.
Deliverables: Usage/rate schema and SQL views; Showback workbook and reconciliation tests. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI FinOps / capacity engineer. Use this scenario: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Review: Start with the task and permitted scope. Explain usage allocation: Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible. Show the input and observed output, then address Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Usage/rate schema and SQL views; Showback workbook and reconciliation tests. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

