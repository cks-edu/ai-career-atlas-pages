## beginner — Cost per useful outcome

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Cost per useful outcome
Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow.
Mental model: Compare the cost of completed deliveries, not just fuel per kilometer.
Boundary: State what is included; local electricity, people and hardware are not automatically zero.
Worked example: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Cheap tokens, expensive outcomes
The trial budget caps cost per accepted task at 0.10 synthetic currency units. Two routes exceed the outcome budget after retries and rejected outputs are included. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes.
Recall: Reconcile total spend and accepted outcomes using the same reporting window. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Cost per useful outcome: Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Cost per successful task includes failed attempts and other costs. A cheap individual request may still produce an expensive useful result.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Option A costs 10 units for 100 attempts with 50 accepted results. Option B costs 12 units for 100 attempts with 80 accepted results.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

3. Try step 2
Divide each total cost by accepted results.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

4. Try step 3
Add a note listing costs not included, such as staff review and storage.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

5. Explain and check your result
A costs 0.20 units per accepted result and B costs 0.15; the cheaper attempt is not the cheaper accepted result. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A two-row spreadsheet or handwritten cost comparison. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial budget caps cost per accepted task at 0.10 synthetic currency units. Apply this toy-case rule manually: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two routes exceed the outcome budget after retries and rejected outputs are included. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI FinOps / capacity engineer.
Option A costs 10 units for 100 attempts with 50 accepted results. Option B costs 12 units for 100 attempts with 80 accepted results.
Divide each total cost by accepted results.
Add a note listing costs not included, such as staff review and storage.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A two-row spreadsheet or handwritten cost comparison. Include beginner-worksheet.md and your completed Reconciled AI unit-cost ledger.
Check: A costs 0.20 units per accepted result and B costs 0.15; the cheaper attempt is not the cheaper accepted result.

### Interview
Explain your beginner solution for AI FinOps / capacity engineer. Use this scenario: The trial budget caps cost per accepted task at 0.10 synthetic currency units.
Review: Start with the task and permitted scope. Explain cost per useful outcome: Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow. Show the input and observed output, then address Allocate retries and review overhead before comparing model routes. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A two-row spreadsheet or handwritten cost comparison. Include beginner-worksheet.md and your completed Reconciled AI unit-cost ledger.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

