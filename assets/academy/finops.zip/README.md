# AI FinOps / capacity engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Cost per useful outcome. Cost per successful task includes failed attempts and other costs. A cheap individual request may still produce an expensive useful result. Then try Compare two fictional service options. The three levels build toward AI usage attribution and budget simulator. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Cost per useful outcome

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Cost per useful outcome
Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow.
Mental model: Compare the cost of completed deliveries, not just fuel per kilometer.
Boundary: State what is included; local electricity, people and hardware are not automatically zero.
Worked example: A run costs 12 units and produces 8 accepted results: 1.5 units per accepted result, before any separately excluded costs.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Cheap tokens, expensive outcomes
The trial budget caps cost per accepted task at 0.10 synthetic currency units. Two routes exceed the outcome budget after retries and rejected outputs are included. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Allocate retries and review overhead before comparing model routes.
Recall: Reconcile total spend and accepted outcomes using the same reporting window. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Cost per useful outcome: Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Cost per successful task includes failed attempts and other costs. A cheap individual request may still produce an expensive useful result.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Option A costs 10 units for 100 attempts with 50 accepted results. Option B costs 12 units for 100 attempts with 80 accepted results.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

3. Try step 2
Divide each total cost by accepted results.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

4. Try step 3
Add a note listing costs not included, such as staff review and storage.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-row spreadsheet or handwritten cost comparison.

5. Explain and check your result
A costs 0.20 units per accepted result and B costs 0.15; the cheaper attempt is not the cheaper accepted result. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A two-row spreadsheet or handwritten cost comparison. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial budget caps cost per accepted task at 0.10 synthetic currency units. Apply this toy-case rule manually: Review when cost_per_accepted > 0.1 (synthetic units). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two routes exceed the outcome budget after retries and rejected outputs are included. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI FinOps / capacity engineer.
Option A costs 10 units for 100 attempts with 50 accepted results. Option B costs 12 units for 100 attempts with 80 accepted results.
Divide each total cost by accepted results.
Add a note listing costs not included, such as staff review and storage.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A two-row spreadsheet or handwritten cost comparison. Include beginner-worksheet.md and your completed Reconciled AI unit-cost ledger.
Check: A costs 0.20 units per accepted result and B costs 0.15; the cheaper attempt is not the cheaper accepted result.

### Interview
Explain your beginner solution for AI FinOps / capacity engineer. Use this scenario: The trial budget caps cost per accepted task at 0.10 synthetic currency units.
Review: Start with the task and permitted scope. Explain cost per useful outcome: Measure total attributed cost against accepted task results, including failures and retries. A lower token price can still produce a more expensive successful workflow. Show the input and observed output, then address Allocate retries and review overhead before comparing model routes. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A two-row spreadsheet or handwritten cost comparison. Include beginner-worksheet.md and your completed Reconciled AI unit-cost ledger.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Usage allocation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn cloud billing, SQL/Python analysis, tagging and allocation, plus inference workload metrics. FinOps work is collaborative; the most useful skills include explaining assumptions and checking total cost, not just optimizing token prices.

### Usage allocation
Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible.
Mental model: A shared electricity bill needs meters or an explicit allocation rule.
Boundary: Allocation is an accounting policy, not proof of which team caused every shared cost.
Worked example: A daily total is 100 units; attributed rows sum to 92. Report 8 unallocated rather than distributing it silently.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI usage attribution and budget simulator
Build a transparent cost ledger and compare routing decisions against a quality floor. Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Recall: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. Identify one observation that would contradict your claim.

### Terms
Usage allocation: Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a transparent cost ledger and compare routing decisions against a quality floor. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The trial budget caps cost per accepted task at 0.10 synthetic currency units. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a transparent cost ledger and compare routing decisions against a quality floor.
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.
Deliverables: Usage/rate schema and SQL views; Showback workbook and reconciliation tests. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI FinOps / capacity engineer. Use this scenario: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Review: Start with the task and permitted scope. Explain usage allocation: Attach team, workload and environment identifiers to usage records. Reconcile totals before assigning costs and keep unallocated amounts visible. Show the input and observed output, then address Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Usage/rate schema and SQL views; Showback workbook and reconciliation tests. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Quality-constrained optimization

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Quality-constrained optimization
Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison.
Mental model: A cheaper delivery method is useful only if parcels arrive intact and on time.
Boundary: Optimization results depend on the measured workload and changing prices.
Worked example: A smaller model saves 30% on inference but doubles manual review; calculate the complete workflow before recommending it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI usage attribution and budget simulator
Build a transparent cost ledger and compare routing decisions against a quality floor. Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Recall: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. Identify one observation that would contradict your claim.

### Terms
Quality-constrained optimization: Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a transparent cost ledger and compare routing decisions against a quality floor. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a transparent cost ledger and compare routing decisions against a quality floor.
Expand usage.csv to 200 synthetic requests with tenant, model, input/output units, retry count and success. Create a separate dated rate table using real published prices or explicitly fictional prices.
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.
Implement a budget reservation simulation with reserve, reconcile and release states. Compare two model-routing policies using quality labels on the same tasks.
Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.
Import a sanitized real billing export with permission and explain discounts, commitments and shared costs.
Deliverables: Usage/rate schema and SQL views; Showback workbook and reconciliation tests; Budget policy and routing decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A reviewer must reproduce one result and identify which capabilities you implemented. Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

### Interview
Explain your advanced solution for AI FinOps / capacity engineer. Use this scenario: Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.
Review: Start with the task and permitted scope. Explain quality-constrained optimization: Compare savings only among configurations that meet the agreed task-quality and latency bounds. Include fallback and review effort in the comparison. Show the input and observed output, then address Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Usage/rate schema and SQL views; Showback workbook and reconciliation tests; Budget policy and routing decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

FinOps for AI — Public framework
Cost attribution, unit economics and capacity decisions.
Alternative: A documented cost-allocation workbook can implement a small practice; commercial cloud cost tools are optional and need validated data.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
FinOps for AI: https://www.finops.org/framework/technology-categories/ai/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
Prometheus: https://prometheus.io/docs/introduction/overview/
