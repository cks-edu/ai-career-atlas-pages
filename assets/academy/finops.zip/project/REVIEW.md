# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Usage/rate schema and SQL views.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
