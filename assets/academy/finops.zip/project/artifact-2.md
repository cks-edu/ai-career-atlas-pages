# Showback workbook and reconciliation tests

Project: AI usage attribution and budget simulator
Status: blank work product — not completed evidence

## Purpose and audience
Build a transparent cost ledger and compare routing decisions against a quality floor.

## Required content
Create tenant showback views and a reconciliation report that separates estimates, provider billing and shared overhead. Add failed/retried requests to consumption totals.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.

## Failure evidence
Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
