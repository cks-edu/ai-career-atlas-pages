# AI usage attribution and budget simulator

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a transparent cost ledger and compare routing decisions against a quality floor.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

## Limitations and next iteration
Import a sanitized real billing export with permission and explain discounts, commitments and shared costs.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
