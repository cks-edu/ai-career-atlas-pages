# Usage/rate schema and SQL views

Project: AI usage attribution and budget simulator
Status: blank work product — not completed evidence

## Purpose and audience
Build a transparent cost ledger and compare routing decisions against a quality floor.

## Required content
Use DuckDB to join usage to versioned rates. Keep currency, unit size and effective dates explicit; reject missing prices instead of treating them as free.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report cost per successful task, unattributed spend, reconciliation difference and quality loss. Never compare models only by cost per token.

## Failure evidence
Replay a request ID and introduce delayed usage records. Prove you do not double-charge and show the maximum budget overshoot allowed by your chosen policy.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
