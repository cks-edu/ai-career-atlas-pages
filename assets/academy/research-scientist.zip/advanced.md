## advanced — Scientific contribution and scope

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Scientific contribution and scope
Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt.
Mental model: A map includes both surveyed territory and blank regions.
Boundary: A course reproduction is not automatically a novel or peer-reviewed contribution.
Worked example: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Pre-registered ablation and replication study
Investigate a narrow research question with baselines, ablations and a transparent negative-result path. Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Recall: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. Identify one observation that would contradict your claim.

### Terms
Scientific contribution and scope: Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Investigate a narrow research question with baselines, ablations and a transparent negative-result path. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Investigate a narrow research question with baselines, ablations and a transparent negative-result path.
Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.
Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.
Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.
Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix.
Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.
Invite an independent reviewer to rerun one central figure and record discrepancies.
Deliverables: Protocol and experiment code; Ablation/replication tables with raw runs; Research report and reproducibility appendix. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A reviewer must reproduce one result and identify which capabilities you implemented. Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

### Interview
Explain your advanced solution for AI research scientist. Use this scenario: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Review: Start with the task and permitted scope. Explain scientific contribution and scope: Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt. Show the input and observed output, then address Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Protocol and experiment code; Ablation/replication tables with raw runs; Research report and reproducibility appendix. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

