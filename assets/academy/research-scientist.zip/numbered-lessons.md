# AI research scientist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Falsifiable hypotheses: A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

### Falsifiable hypotheses

A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable. In this role, work through: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A detective considers evidence that could clear the suspect as well as implicate them.

Boundary: Novelty requires careful literature review, not only a different implementation.

Worked example: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI research scientist: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim.

Predict the worked case

Read this case without running a tool: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in falsifiable hypotheses.

Connect the concept to the role

Apply this rule: A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Novelty requires careful literature review, not only a different implementation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies falsifiable hypotheses to this case: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Falsifiable hypotheses; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with falsifiable hypotheses. Use the glossary below, then write your prediction for: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research scientist role interview. Explain falsifiable hypotheses using this case: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate falsifiable hypotheses to a system or workflow you know. Explain falsifiable hypotheses using this case: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain falsifiable hypotheses using this case: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim.

A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable. — A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable. Novelty requires careful literature review, not only a different implementation.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Google Research careers: https://research.google/careers/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

### Diagnose: Only winning seeds are in the paper

The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Three result summaries omit planned trials, so the reported evidence is selectively presented. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A detective considers evidence that could clear the suspect as well as implicate them.

Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim.

Worked example: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Three result summaries omit planned trials, so the reported evidence is selectively presented. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Apply this toy-case rule manually: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A research question should identify something not yet established. Separate a claim, supporting evidence and an unanswered question.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use this fictional claim: “Method A scored 82% and method B scored 80% on one test set.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

Preparation · Try step 2

List what is unknown: sample size, repeated runs, test construction and whether the difference is meaningful.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

Preparation · Try step 3

Write one follow-up research question and the evidence needed to answer it.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

Preparation · Explain and check your result

You do not infer a reliable or general improvement from two percentages alone. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A claim/evidence/unknowns table and a follow-up question. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Apply this toy-case rule manually: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three result summaries omit planned trials, so the reported evidence is selectively presented. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three result summaries omit planned trials, so the reported evidence is selectively presented. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: only winning seeds are in the paper. Use the glossary below, then write your prediction for: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research scientist role interview. Explain diagnose: only winning seeds are in the paper using this case: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: only winning seeds are in the paper to a system or workflow you know. Explain diagnose: only winning seeds are in the paper using this case: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report effect sizes, variability, negative results and deviations from the original plan. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: only winning seeds are in the paper using this case: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results. State the evidence, one alternative and where the mental model stops.

Quiz: Only winning seeds are in the paper: The study plan requires reporting every planned seed, including failed or unfavorable outcomes.

Change the acceptance rule after seeing an inconvenient result.

Restore the full trial ledger and revise the claim to match the complete results.

Omit failed cases and report only the successful demonstrations.

Reference: Restore the full trial ledger and revise the claim to match the complete results. — Restore the full trial ledger and revise the claim to match the complete results. Report effect sizes, variability, negative results and deviations from the original plan.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Google Research careers: https://research.google/careers/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Deep mathematical and experimental expertise; many roles expect a PhD or equivalent original research record.

Terms:

Study design and uncertainty: Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

ablation: An experiment removing or changing a component to investigate its contribution.

### Study design and uncertainty

Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness. In this role, work through: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Plan the race rules before seeing who is ahead.

Boundary: Multiple comparisons and selective reporting can create misleading apparent gains.

Worked example: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Deep mathematical and experimental expertise; many roles expect a PhD or equivalent original research record.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI research scientist: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score.

Predict the worked case

Read this case without running a tool: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in study design and uncertainty.

Connect the concept to the role

Apply this rule: Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Multiple comparisons and selective reporting can create misleading apparent gains.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies study design and uncertainty to this case: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Study design and uncertainty; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with study design and uncertainty. Use the glossary below, then write your prediction for: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research scientist role interview. Explain study design and uncertainty using this case: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate study design and uncertainty to a system or workflow you know. Explain study design and uncertainty using this case: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain study design and uncertainty using this case: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score.

Treat a passing starter as proof of the whole role workflow.

Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness.

Ignore the failure because the tool produced an output.

Reference: Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness. — Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness. Multiple comparisons and selective reporting can create misleading apparent gains.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Google Research careers: https://research.google/careers/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

### Integrate: Pre-registered ablation and replication study

Investigate a narrow research question with baselines, ablations and a transparent negative-result path. Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements. In this role, work through: Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: Plan the race rules before seeing who is ahead.

Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score.

Worked example: Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Investigate a narrow research question with baselines, ablations and a transparent negative-result path. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Investigate a narrow research question with baselines, ablations and a transparent negative-result path.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-intermediate-2.md: Protocol and experiment code; Ablation/replication tables with raw runs. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: pre-registered ablation and replication study. Use the glossary below, then write your prediction for: Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research scientist role interview. Explain integrate: pre-registered ablation and replication study using this case: Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: pre-registered ablation and replication study to a system or workflow you know. Explain integrate: pre-registered ablation and replication study using this case: Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. Identify one observation that would contradict your claim.

Interview: Explain integrate: pre-registered ablation and replication study using this case: Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Pre-registered ablation and replication study at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.

Reference: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. — Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Google Research careers: https://research.google/careers/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Scientific contribution and scope: Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

ablation: An experiment removing or changing a component to investigate its contribution.

### Scientific contribution and scope

Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt. In this role, work through: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A map includes both surveyed territory and blank regions.

Boundary: A course reproduction is not automatically a novel or peer-reviewed contribution.

Worked example: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI research scientist: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority.

Predict the worked case

Read this case without running a tool: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in scientific contribution and scope.

Connect the concept to the role

Apply this rule: Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A course reproduction is not automatically a novel or peer-reviewed contribution.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies scientific contribution and scope to this case: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Scientific contribution and scope; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with scientific contribution and scope. Use the glossary below, then write your prediction for: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research scientist role interview. Explain scientific contribution and scope using this case: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate scientific contribution and scope to a system or workflow you know. Explain scientific contribution and scope using this case: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain scientific contribution and scope using this case: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt.

Reference: Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt. — Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt. A course reproduction is not automatically a novel or peer-reviewed contribution.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Google Research careers: https://research.google/careers/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

### Defend: Pre-registered ablation and replication study

Investigate a narrow research question with baselines, ablations and a transparent negative-result path. Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix. In this role, work through: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A map includes both surveyed territory and blank regions.

A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority.

Worked example: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Investigate a narrow research question with baselines, ablations and a transparent negative-result path. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Investigate a narrow research question with baselines, ablations and a transparent negative-result path.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A reviewer must reproduce one result and identify which capabilities you implemented. Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-advanced-2.md: Protocol and experiment code; Ablation/replication tables with raw runs; Research report and reproducibility appendix. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: pre-registered ablation and replication study. Use the glossary below, then write your prediction for: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research scientist role interview. Explain defend: pre-registered ablation and replication study using this case: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: pre-registered ablation and replication study to a system or workflow you know. Explain defend: pre-registered ablation and replication study using this case: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. Identify one observation that would contradict your claim.

Interview: Explain defend: pre-registered ablation and replication study using this case: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Pre-registered ablation and replication study at this level?

Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result. — Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result. Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Google Research careers: https://research.google/careers/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/
