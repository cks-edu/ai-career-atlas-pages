# AI research scientist

AI Engineering · Beginner → Intermediate → Advanced

Start with Falsifiable hypotheses. A research question should identify something not yet established. Separate a claim, supporting evidence and an unanswered question. Then try Practice reading evidence. The three levels build toward Pre-registered ablation and replication study. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Falsifiable hypotheses

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Falsifiable hypotheses
A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable.
Mental model: A detective considers evidence that could clear the suspect as well as implicate them.
Boundary: Novelty requires careful literature review, not only a different implementation.
Worked example: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Only winning seeds are in the paper
The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Three result summaries omit planned trials, so the reported evidence is selectively presented. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results.
Recall: Report effect sizes, variability, negative results and deviations from the original plan. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Falsifiable hypotheses: A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A research question should identify something not yet established. Separate a claim, supporting evidence and an unanswered question.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use this fictional claim: “Method A scored 82% and method B scored 80% on one test set.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

3. Try step 2
List what is unknown: sample size, repeated runs, test construction and whether the difference is meaningful.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

4. Try step 3
Write one follow-up research question and the evidence needed to answer it.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

5. Explain and check your result
You do not infer a reliable or general improvement from two percentages alone. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A claim/evidence/unknowns table and a follow-up question. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Apply this toy-case rule manually: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three result summaries omit planned trials, so the reported evidence is selectively presented. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI research scientist.
Use this fictional claim: “Method A scored 82% and method B scored 80% on one test set.”
List what is unknown: sample size, repeated runs, test construction and whether the difference is meaningful.
Write one follow-up research question and the evidence needed to answer it.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A claim/evidence/unknowns table and a follow-up question. Include beginner-worksheet.md and your completed Reproducible research note and claim-evidence table.
Check: You do not infer a reliable or general improvement from two percentages alone.

### Interview
Explain your beginner solution for AI research scientist. Use this scenario: The study plan requires reporting every planned seed, including failed or unfavorable outcomes.
Review: Start with the task and permitted scope. Explain falsifiable hypotheses: A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable. Show the input and observed output, then address Restore the full trial ledger and revise the claim to match the complete results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A claim/evidence/unknowns table and a follow-up question. Include beginner-worksheet.md and your completed Reproducible research note and claim-evidence table.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Study design and uncertainty

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Deep mathematical and experimental expertise; many roles expect a PhD or equivalent original research record.

### Study design and uncertainty
Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness.
Mental model: Plan the race rules before seeing who is ahead.
Boundary: Multiple comparisons and selective reporting can create misleading apparent gains.
Worked example: Repeat the comparison across declared seeds and datasets, retaining a run that failed rather than presenting only the best score.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Pre-registered ablation and replication study
Investigate a narrow research question with baselines, ablations and a transparent negative-result path. Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.
Recall: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. Identify one observation that would contradict your claim.

### Terms
Study design and uncertainty: Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Investigate a narrow research question with baselines, ablations and a transparent negative-result path. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Investigate a narrow research question with baselines, ablations and a transparent negative-result path.
Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.
Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.
Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.
Deliverables: Protocol and experiment code; Ablation/replication tables with raw runs. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI research scientist. Use this scenario: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Review: Start with the task and permitted scope. Explain study design and uncertainty: Choose data splits, comparisons and analysis before inspecting final results. Report variation and negative results so the reader can judge robustness. Show the input and observed output, then address Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Protocol and experiment code; Ablation/replication tables with raw runs. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Scientific contribution and scope

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Scientific contribution and scope
Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt.
Mental model: A map includes both surveyed territory and blank regions.
Boundary: A course reproduction is not automatically a novel or peer-reviewed contribution.
Worked example: A method wins on one synthetic task; describe that boundary and propose a test on a different distribution before claiming general superiority.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Pre-registered ablation and replication study
Investigate a narrow research question with baselines, ablations and a transparent negative-result path. Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Recall: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. Identify one observation that would contradict your claim.

### Terms
Scientific contribution and scope: Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Investigate a narrow research question with baselines, ablations and a transparent negative-result path. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Investigate a narrow research question with baselines, ablations and a transparent negative-result path.
Choose a small public dataset and a falsifiable claim. Write a dated protocol with hypothesis, metrics, split strategy, compute budget and stopping rule before experimentation.
Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.
Run multiple seeds and at least two ablations that isolate the proposed mechanism. Preserve all outcomes, including failures and non-improvements.
Replicate on a second dataset or split regime. Write a short paper-style report with related work, method, results, limitations and a reproducibility appendix.
Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.
Invite an independent reviewer to rerun one central figure and record discrepancies.
Deliverables: Protocol and experiment code; Ablation/replication tables with raw runs; Research report and reproducibility appendix. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A reviewer must reproduce one result and identify which capabilities you implemented. Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

### Interview
Explain your advanced solution for AI research scientist. Use this scenario: Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.
Review: Start with the task and permitted scope. Explain scientific contribution and scope: Connect empirical findings to the stated hypothesis and discuss competing explanations. Publish enough method and artifact detail for an independent attempt. Show the input and observed output, then address Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Protocol and experiment code; Ablation/replication tables with raw runs; Research report and reproducibility appendix. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
Google Research careers: https://research.google/careers/
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
MLflow: https://mlflow.org/docs/latest/
