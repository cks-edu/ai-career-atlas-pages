# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Protocol and experiment code.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
