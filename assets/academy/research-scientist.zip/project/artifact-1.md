# Protocol and experiment code

Project: Pre-registered ablation and replication study
Status: blank work product — not completed evidence

## Purpose and audience
Investigate a narrow research question with baselines, ablations and a transparent negative-result path.

## Required content
Run the baseline starter and implement the proposed change as a separately configurable component. Keep preprocessing and tuning budgets comparable.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.

## Failure evidence
Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
