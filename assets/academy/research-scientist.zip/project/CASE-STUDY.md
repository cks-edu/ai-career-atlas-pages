# Pre-registered ablation and replication study

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Investigate a narrow research question with baselines, ablations and a transparent negative-result path.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report effect sizes and uncertainty, compute and protocol deviations. Do not present exploratory post-hoc findings as preregistered confirmation.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Remove the supposedly critical component and test whether the claimed benefit remains. Investigate alternative explanations instead of hiding the result.

## Limitations and next iteration
Invite an independent reviewer to rerun one central figure and record discrepancies.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
