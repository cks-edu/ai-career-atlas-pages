# SAMPLE — Reproducible research note and claim-evidence table
Role: AI research scientist
Case: Only winning seeds are in the paper
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The study plan requires reporting every planned seed, including failed or unfavorable outcomes.

## Evidence table
| Record | omitted_seeds (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 3 | review |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three result summaries omit planned trials, so the reported evidence is selectively presented.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Restore the full trial ledger and revise the claim to match the complete results.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai research scientist.
Before release: Report effect sizes, variability, negative results and deviations from the original plan.

## Design choice and trade-off
Make hypotheses falsifiable and comparisons fair; separate exploratory results from confirmatory claims.
A narrower, defensible claim is more valuable than an impressive result dependent on selective reporting.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Focused research proposal: Proposal explains novelty and a falsification criterion.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
