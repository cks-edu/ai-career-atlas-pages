## beginner — Falsifiable hypotheses

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Falsifiable hypotheses
A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable.
Mental model: A detective considers evidence that could clear the suspect as well as implicate them.
Boundary: Novelty requires careful literature review, not only a different implementation.
Worked example: Predict that a method improves a defined metric under low-data conditions, then state the split and result that would reject that claim.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Only winning seeds are in the paper
The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Three result summaries omit planned trials, so the reported evidence is selectively presented. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Restore the full trial ledger and revise the claim to match the complete results.
Recall: Report effect sizes, variability, negative results and deviations from the original plan. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Falsifiable hypotheses: A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A research question should identify something not yet established. Separate a claim, supporting evidence and an unanswered question.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use this fictional claim: “Method A scored 82% and method B scored 80% on one test set.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

3. Try step 2
List what is unknown: sample size, repeated runs, test construction and whether the difference is meaningful.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

4. Try step 3
Write one follow-up research question and the evidence needed to answer it.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A claim/evidence/unknowns table and a follow-up question.

5. Explain and check your result
You do not infer a reliable or general improvement from two percentages alone. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A claim/evidence/unknowns table and a follow-up question. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The study plan requires reporting every planned seed, including failed or unfavorable outcomes. Apply this toy-case rule manually: Review when omitted_seeds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three result summaries omit planned trials, so the reported evidence is selectively presented. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI research scientist.
Use this fictional claim: “Method A scored 82% and method B scored 80% on one test set.”
List what is unknown: sample size, repeated runs, test construction and whether the difference is meaningful.
Write one follow-up research question and the evidence needed to answer it.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A claim/evidence/unknowns table and a follow-up question. Include beginner-worksheet.md and your completed Reproducible research note and claim-evidence table.
Check: You do not infer a reliable or general improvement from two percentages alone.

### Interview
Explain your beginner solution for AI research scientist. Use this scenario: The study plan requires reporting every planned seed, including failed or unfavorable outcomes.
Review: Start with the task and permitted scope. Explain falsifiable hypotheses: A research claim should specify what evidence would contradict it. Begin with literature, assumptions and a baseline that makes the contribution testable. Show the input and observed output, then address Restore the full trial ledger and revise the claim to match the complete results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A claim/evidence/unknowns table and a follow-up question. Include beginner-worksheet.md and your completed Reproducible research note and claim-evidence table.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

