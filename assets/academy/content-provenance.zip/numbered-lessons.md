# AI content provenance & authenticity — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Provenance versus truth: Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Provenance versus truth

Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true. In this role, work through: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A signed receipt proves who issued the receipt, not whether the purchased item is good.

Boundary: Missing credentials do not by themselves prove an asset is fake.

Worked example: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: C2PA Tool (Open source · trust credentials separate); Blender (Open source · local); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI content provenance & authenticity: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate.

Predict the worked case

Read this case without running a tool: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in provenance versus truth.

Connect the concept to the role

Apply this rule: Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Missing credentials do not by themselves prove an asset is fake.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies provenance versus truth to this case: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Provenance versus truth; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with provenance versus truth. Use the glossary below, then write your prediction for: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI content provenance & authenticity role interview. Explain provenance versus truth using this case: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate provenance versus truth to a system or workflow you know. Explain provenance versus truth using this case: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain provenance versus truth using this case: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate.

Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true. — Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true. Missing credentials do not by themselves prove an asset is fake.

Sources:

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Blender: https://docs.blender.org/manual/en/latest/

Python: https://docs.python.org/3/library/venv.html

C2PA specifications: https://spec.c2pa.org/specifications/

Blender manual: https://docs.blender.org/manual/en/latest/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

### Diagnose: The asset changed after signing

The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Three assets no longer match their recorded binding; the UI must not present them as verified. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A signed receipt proves who issued the receipt, not whether the purchased item is good.

An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate.

Worked example: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: C2PA Tool (Open source · trust credentials separate); Blender (Open source · local); Python (Open source · local)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Three assets no longer match their recorded binding; the UI must not present them as verified. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Apply this toy-case rule manually: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Provenance describes where content came from and how it changed. A valid signature can support integrity and signer identity without proving the content is factually true.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine a signed image record stating that Alex created an image and later cropped it. The image caption claims it shows an event yesterday.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

Preparation · Try step 2

Make columns for recorded history, integrity/signature checks and factual claims needing other evidence.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

Preparation · Try step 3

Write what the record could support if validated and what it cannot establish about the caption.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

Preparation · Explain and check your result

The caption’s truth is not inferred from the signature; record validation and real-world fact checking remain separate. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An evidence table and a cautious provenance statement. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Apply this toy-case rule manually: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three assets no longer match their recorded binding; the UI must not present them as verified. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three assets no longer match their recorded binding; the UI must not present them as verified. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the asset changed after signing. Use the glossary below, then write your prediction for: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI content provenance & authenticity role interview. Explain diagnose: the asset changed after signing using this case: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the asset changed after signing to a system or workflow you know. Explain diagnose: the asset changed after signing using this case: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test altered files, stripped metadata and unknown signers with the selected specification. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the asset changed after signing using this case: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context. State the evidence, one alternative and where the mental model stops.

Quiz: The asset changed after signing: The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state.

Change the acceptance rule after seeing an inconvenient result.

Display valid, invalid and unknown provenance distinctly and retain trust-chain context.

Omit failed cases and report only the successful demonstrations.

Reference: Display valid, invalid and unknown provenance distinctly and retain trust-chain context. — Display valid, invalid and unknown provenance distinctly and retain trust-chain context. Test altered files, stripped metadata and unknown signers with the selected specification.

Sources:

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Blender: https://docs.blender.org/manual/en/latest/

Python: https://docs.python.org/3/library/venv.html

C2PA specifications: https://spec.c2pa.org/specifications/

Blender manual: https://docs.blender.org/manual/en/latest/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Metadata, signatures and media workflows; implementation roles require coding and security review.

Terms:

Manifests and integrity checks: Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

CLI: Command-line interface: a program operated by commands in a terminal.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Manifests and integrity checks

Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions. In this role, work through: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A tamper-evident envelope and the sender's identity are separate checks.

Boundary: Trust policies and supported formats differ between implementations.

Worked example: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Metadata, signatures and media workflows; implementation roles require coding and security review.

Tools for this exercise: Document or text editor

Course tool and framework map: C2PA Tool (Open source · trust credentials separate); Blender (Open source · local); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI content provenance & authenticity: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid.

Predict the worked case

Read this case without running a tool: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in manifests and integrity checks.

Connect the concept to the role

Apply this rule: Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Trust policies and supported formats differ between implementations.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies manifests and integrity checks to this case: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Manifests and integrity checks; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with manifests and integrity checks. Use the glossary below, then write your prediction for: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI content provenance & authenticity role interview. Explain manifests and integrity checks using this case: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate manifests and integrity checks to a system or workflow you know. Explain manifests and integrity checks using this case: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain manifests and integrity checks using this case: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid.

Treat a passing starter as proof of the whole role workflow.

Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions.

Ignore the failure because the tool produced an output.

Reference: Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions. — Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions. Trust policies and supported formats differ between implementations.

Sources:

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Blender: https://docs.blender.org/manual/en/latest/

Python: https://docs.python.org/3/library/venv.html

C2PA specifications: https://spec.c2pa.org/specifications/

Blender manual: https://docs.blender.org/manual/en/latest/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

### Integrate: Media provenance verification workflow

Build a verification workflow that distinguishes provenance evidence from content truth. Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable. In this role, work through: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A tamper-evident envelope and the sender's identity are separate checks.

Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid.

Worked example: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: C2PA Tool (Open source · trust credentials separate); Blender (Open source · local); Python (Open source · local)

Build a verification workflow that distinguishes provenance evidence from content truth. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a verification workflow that distinguishes provenance evidence from content truth.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

Prepare the project inputs

Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Asset/manifests and verification logs; Reviewer decision worksheet. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: media provenance verification workflow. Use the glossary below, then write your prediction for: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI content provenance & authenticity role interview. Explain integrate: media provenance verification workflow using this case: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: media provenance verification workflow to a system or workflow you know. Explain integrate: media provenance verification workflow using this case: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. Identify one observation that would contradict your claim.

Interview: Explain integrate: media provenance verification workflow using this case: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Media provenance verification workflow at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.

Reference: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. — Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.

Sources:

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Blender: https://docs.blender.org/manual/en/latest/

Python: https://docs.python.org/3/library/venv.html

C2PA specifications: https://spec.c2pa.org/specifications/

Blender manual: https://docs.blender.org/manual/en/latest/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Provenance workflow continuity: Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

CLI: Command-line interface: a program operated by commands in a terminal.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Provenance workflow continuity

Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient. In this role, work through: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A chain-of-custody log must survive each handoff to remain useful.

Boundary: A complete technical history still requires contextual and editorial judgment.

Worked example: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: C2PA Tool (Open source · trust credentials separate); Blender (Open source · local); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI content provenance & authenticity: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity.

Predict the worked case

Read this case without running a tool: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in provenance workflow continuity.

Connect the concept to the role

Apply this rule: Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A complete technical history still requires contextual and editorial judgment.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies provenance workflow continuity to this case: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Provenance workflow continuity; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with provenance workflow continuity. Use the glossary below, then write your prediction for: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI content provenance & authenticity role interview. Explain provenance workflow continuity using this case: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate provenance workflow continuity to a system or workflow you know. Explain provenance workflow continuity using this case: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain provenance workflow continuity using this case: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient.

Reference: Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient. — Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient. A complete technical history still requires contextual and editorial judgment.

Sources:

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Blender: https://docs.blender.org/manual/en/latest/

Python: https://docs.python.org/3/library/venv.html

C2PA specifications: https://spec.c2pa.org/specifications/

Blender manual: https://docs.blender.org/manual/en/latest/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

### Defend: Media provenance verification workflow

Build a verification workflow that distinguishes provenance evidence from content truth. Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo. In this role, work through: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A chain-of-custody log must survive each handoff to remain useful.

Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity.

Worked example: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: C2PA Tool (Open source · trust credentials separate); Blender (Open source · local); Python (Open source · local)

Build a verification workflow that distinguishes provenance evidence from content truth. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a verification workflow that distinguishes provenance evidence from content truth.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

Prepare the project inputs

Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A reviewer must reproduce one result and identify which capabilities you implemented. Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Asset/manifests and verification logs; Reviewer decision worksheet; Provenance case study with limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: media provenance verification workflow. Use the glossary below, then write your prediction for: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI content provenance & authenticity role interview. Explain defend: media provenance verification workflow using this case: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: media provenance verification workflow to a system or workflow you know. Explain defend: media provenance verification workflow using this case: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. Identify one observation that would contradict your claim.

Interview: Explain defend: media provenance verification workflow using this case: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Media provenance verification workflow at this level?

Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials. — Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials. Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.

Sources:

C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/

Blender: https://docs.blender.org/manual/en/latest/

Python: https://docs.python.org/3/library/venv.html

C2PA specifications: https://spec.c2pa.org/specifications/

Blender manual: https://docs.blender.org/manual/en/latest/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/
