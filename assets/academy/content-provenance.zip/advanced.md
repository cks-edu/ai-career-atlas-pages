## advanced — Provenance workflow continuity

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Provenance workflow continuity
Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient.
Mental model: A chain-of-custody log must survive each handoff to remain useful.
Boundary: A complete technical history still requires contextual and editorial judgment.
Worked example: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Media provenance verification workflow
Build a verification workflow that distinguishes provenance evidence from content truth. Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Recall: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. Identify one observation that would contradict your claim.

### Terms
Provenance workflow continuity: Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
CLI: Command-line interface: a program operated by commands in a terminal.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a verification workflow that distinguishes provenance evidence from content truth. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

2. Prepare the project inputs
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a verification workflow that distinguishes provenance evidence from content truth.
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.
Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.
Add a chain of edits and compare tools’ handling of ingredients, trust and unsupported assertions.
Deliverables: Asset/manifests and verification logs; Reviewer decision worksheet; Provenance case study with limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A reviewer must reproduce one result and identify which capabilities you implemented. Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

### Interview
Explain your advanced solution for AI content provenance & authenticity. Use this scenario: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Review: Start with the task and permitted scope. Explain provenance workflow continuity: Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient. Show the input and observed output, then address Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Asset/manifests and verification logs; Reviewer decision worksheet; Provenance case study with limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

