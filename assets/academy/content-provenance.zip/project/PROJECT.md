# Media provenance verification workflow

Career: AI content provenance & authenticity
Reviewed: 2026-10-22

Build a verification workflow that distinguishes provenance evidence from content truth.

## Prerequisites
Metadata, signatures and media workflows; implementation roles require coding and security review.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```

## Portfolio deliverables
1. Asset/manifests and verification logs — artifact-1.md
2. Reviewer decision worksheet — artifact-2.md
3. Provenance case study with limitations — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Add a chain of edits and compare tools’ handling of ingredients, trust and unsupported assertions.

## Primary learning resources
- C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/ — Open source · trust credentials separate; Read provenance manifests; integrity does not establish truth or rights.
- Blender: https://docs.blender.org/manual/en/latest/ — Open source · local; Storyboarding, editing and compositing; version-specific UI may vary.
- Python: https://docs.python.org/3/library/venv.html — Open source · local; Isolated environments and reproducible scripts.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
