# Reviewer decision worksheet

Project: Media provenance verification workflow
Status: blank work product — not completed evidence

## Purpose and audience
Build a verification workflow that distinguishes provenance evidence from content truth.

## Required content
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.

## Failure evidence
Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
