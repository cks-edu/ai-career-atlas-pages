# Media provenance verification workflow

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a verification workflow that distinguishes provenance evidence from content truth.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

## Limitations and next iteration
Add a chain of edits and compare tools’ handling of ingredients, trust and unsupported assertions.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
