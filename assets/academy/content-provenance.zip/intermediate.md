## intermediate — Manifests and integrity checks

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Metadata, signatures and media workflows; implementation roles require coding and security review.

### Manifests and integrity checks
Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions.
Mental model: A tamper-evident envelope and the sender's identity are separate checks.
Boundary: Trust policies and supported formats differ between implementations.
Worked example: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Media provenance verification workflow
Build a verification workflow that distinguishes provenance evidence from content truth. Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Recall: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. Identify one observation that would contradict your claim.

### Terms
Manifests and integrity checks: Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
CLI: Command-line interface: a program operated by commands in a terminal.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a verification workflow that distinguishes provenance evidence from content truth. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

2. Prepare the project inputs
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a verification workflow that distinguishes provenance evidence from content truth.
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.
Deliverables: Asset/manifests and verification logs; Reviewer decision worksheet. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI content provenance & authenticity. Use this scenario: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Review: Start with the task and permitted scope. Explain manifests and integrity checks: Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions. Show the input and observed output, then address Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Asset/manifests and verification logs; Reviewer decision worksheet. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

