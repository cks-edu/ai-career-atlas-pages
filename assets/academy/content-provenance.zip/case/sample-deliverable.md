# SAMPLE — Provenance inspection report and status-language guide
Role: AI content provenance & authenticity
Case: The asset changed after signing
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state.

## Evidence table
| Record | binding_failures (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three assets no longer match their recorded binding; the UI must not present them as verified.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Display valid, invalid and unknown provenance distinctly and retain trust-chain context.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai content provenance & authenticity.
Before release: Test altered files, stripped metadata and unknown signers with the selected specification.

## Design choice and trade-off
Separate provenance integrity from factual truth; preserve ingredient and transformation history.
Valid credentials can describe a fabricated scene; provenance supports origin review, not truth certification.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Media provenance inspector: UI distinguishes unknown provenance from detected tampering.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
