# AI content provenance & authenticity

AI Engineering · Beginner → Intermediate → Advanced

Start with Provenance versus truth. Provenance describes where content came from and how it changed. A valid signature can support integrity and signer identity without proving the content is factually true. Then try Separate three kinds of evidence. The three levels build toward Media provenance verification workflow. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Provenance versus truth

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Provenance versus truth
Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true.
Mental model: A signed receipt proves who issued the receipt, not whether the purchased item is good.
Boundary: Missing credentials do not by themselves prove an asset is fake.
Worked example: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The asset changed after signing
The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Three assets no longer match their recorded binding; the UI must not present them as verified. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context.
Recall: Test altered files, stripped metadata and unknown signers with the selected specification. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Provenance versus truth: Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Provenance describes where content came from and how it changed. A valid signature can support integrity and signer identity without proving the content is factually true.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a signed image record stating that Alex created an image and later cropped it. The image caption claims it shows an event yesterday.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

3. Try step 2
Make columns for recorded history, integrity/signature checks and factual claims needing other evidence.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

4. Try step 3
Write what the record could support if validated and what it cannot establish about the caption.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

5. Explain and check your result
The caption’s truth is not inferred from the signature; record validation and real-world fact checking remain separate. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An evidence table and a cautious provenance statement. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Apply this toy-case rule manually: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three assets no longer match their recorded binding; the UI must not present them as verified. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI content provenance & authenticity.
Imagine a signed image record stating that Alex created an image and later cropped it. The image caption claims it shows an event yesterday.
Make columns for recorded history, integrity/signature checks and factual claims needing other evidence.
Write what the record could support if validated and what it cannot establish about the caption.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An evidence table and a cautious provenance statement. Include beginner-worksheet.md and your completed Provenance inspection report and status-language guide.
Check: The caption’s truth is not inferred from the signature; record validation and real-world fact checking remain separate.

### Interview
Explain your beginner solution for AI content provenance & authenticity. Use this scenario: The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state.
Review: Start with the task and permitted scope. Explain provenance versus truth: Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true. Show the input and observed output, then address Display valid, invalid and unknown provenance distinctly and retain trust-chain context. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An evidence table and a cautious provenance statement. Include beginner-worksheet.md and your completed Provenance inspection report and status-language guide.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Manifests and integrity checks

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Metadata, signatures and media workflows; implementation roles require coding and security review.

### Manifests and integrity checks
Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions.
Mental model: A tamper-evident envelope and the sender's identity are separate checks.
Boundary: Trust policies and supported formats differ between implementations.
Worked example: Modify a copy of a signed asset and inspect the verifier's binding result rather than assuming the metadata alone remains valid.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Media provenance verification workflow
Build a verification workflow that distinguishes provenance evidence from content truth. Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Recall: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. Identify one observation that would contradict your claim.

### Terms
Manifests and integrity checks: Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
CLI: Command-line interface: a program operated by commands in a terminal.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a verification workflow that distinguishes provenance evidence from content truth. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

2. Prepare the project inputs
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a verification workflow that distinguishes provenance evidence from content truth.
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.
Deliverables: Asset/manifests and verification logs; Reviewer decision worksheet. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI content provenance & authenticity. Use this scenario: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Review: Start with the task and permitted scope. Explain manifests and integrity checks: Inspect the manifest, asset binding and trust information using an appropriate verifier. Distinguish valid structure, intact binding and trusted signer decisions. Show the input and observed output, then address Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Asset/manifests and verification logs; Reviewer decision worksheet. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Provenance workflow continuity

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Provenance workflow continuity
Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient.
Mental model: A chain-of-custody log must survive each handoff to remain useful.
Boundary: A complete technical history still requires contextual and editorial judgment.
Worked example: Export an edited asset through two tools and compare credential availability; document any lost history rather than silently claiming continuity.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Media provenance verification workflow
Build a verification workflow that distinguishes provenance evidence from content truth. Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Recall: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. Identify one observation that would contradict your claim.

### Terms
Provenance workflow continuity: Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
CLI: Command-line interface: a program operated by commands in a terminal.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a verification workflow that distinguishes provenance evidence from content truth. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An asset ledger and original SVG storyboard frame are included.

2. Prepare the project inputs
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing c2patool and obtaining a permitted sample:
c2patool -V
c2patool signed-sample.jpg > provenance-report.json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a verification workflow that distinguishes provenance evidence from content truth.
Create your own image and edited derivative. Record source hashes and editing steps; obtain a separate known signed sample from an official C2PA example source.
Install the maintained Content Authenticity CLI from its official repository and inspect the signed sample with c2patool. Save the manifest and validation output; record tool version.
Compare the original, edited derivative and an unsigned export. Document ingredient links, signature status and what is absent or unverifiable.
Create a reviewer worksheet and a simple report that explains evidence without labeling unsigned media as fake or signed media as true. Use test certificates only for a clearly labeled signing demo.
Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights.
Add a chain of edits and compare tools’ handling of ingredients, trust and unsupported assertions.
Deliverables: Asset/manifests and verification logs; Reviewer decision worksheet; Provenance case study with limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A reviewer must reproduce one result and identify which capabilities you implemented. Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.

### Interview
Explain your advanced solution for AI content provenance & authenticity. Use this scenario: Modify a signed file and compare validation results, then strip metadata in a separate copy. Distinguish tampered assertions from absent credentials.
Review: Start with the task and permitted scope. Explain provenance workflow continuity: Track ingredients and editing steps through export and distribution. Test whether transformations preserve or remove credentials and explain gaps to the recipient. Show the input and observed output, then address Report verification outcomes and evidence gaps. A valid signature establishes an assertion’s integrity and signer context, not factual truth or legal rights. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Asset/manifests and verification logs; Reviewer decision worksheet; Provenance case study with limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
C2PA Tool — Open source · trust credentials separate
Read provenance manifests; integrity does not establish truth or rights.
Alternative: Another C2PA-compatible verifier can inspect credentials; an unsigned checksum checks integrity only and does not provide signer provenance.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Blender — Open source · local
Storyboarding, editing and compositing; version-specific UI may vary.
Alternative: Autodesk Maya (commercial) or other licensed media tools; ensure editable exports and asset rights travel with the work.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Python — Open source · local
Isolated environments and reproducible scripts.
Alternative: A spreadsheet for manual evidence exercises, or another supported programming language for implementation; reproduce the same acceptance checks.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
C2PA Tool: https://opensource.contentauthenticity.org/docs/sdk-repos/c2patool/
Blender: https://docs.blender.org/manual/en/latest/
Python: https://docs.python.org/3/library/venv.html
C2PA specifications: https://spec.c2pa.org/specifications/
Blender manual: https://docs.blender.org/manual/en/latest/
OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/
