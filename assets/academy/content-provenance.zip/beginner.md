## beginner — Provenance versus truth

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Provenance versus truth
Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true.
Mental model: A signed receipt proves who issued the receipt, not whether the purchased item is good.
Boundary: Missing credentials do not by themselves prove an asset is fake.
Worked example: An image has a valid credential showing an edit; the credential does not prove the scene was unstaged or the caption accurate.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The asset changed after signing
The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Three assets no longer match their recorded binding; the UI must not present them as verified. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Display valid, invalid and unknown provenance distinctly and retain trust-chain context.
Recall: Test altered files, stripped metadata and unknown signers with the selected specification. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Provenance versus truth: Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
C2PA: A standard for recording and verifying content provenance. Credentials do not establish factual truth.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Provenance describes where content came from and how it changed. A valid signature can support integrity and signer identity without proving the content is factually true.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a signed image record stating that Alex created an image and later cropped it. The image caption claims it shows an event yesterday.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

3. Try step 2
Make columns for recorded history, integrity/signature checks and factual claims needing other evidence.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

4. Try step 3
Write what the record could support if validated and what it cannot establish about the caption.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An evidence table and a cautious provenance statement.

5. Explain and check your result
The caption’s truth is not inferred from the signature; record validation and real-world fact checking remain separate. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An evidence table and a cautious provenance statement. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state. Apply this toy-case rule manually: Review when binding_failures >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three assets no longer match their recorded binding; the UI must not present them as verified. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI content provenance & authenticity.
Imagine a signed image record stating that Alex created an image and later cropped it. The image caption claims it shows an event yesterday.
Make columns for recorded history, integrity/signature checks and factual claims needing other evidence.
Write what the record could support if validated and what it cannot establish about the caption.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An evidence table and a cautious provenance statement. Include beginner-worksheet.md and your completed Provenance inspection report and status-language guide.
Check: The caption’s truth is not inferred from the signature; record validation and real-world fact checking remain separate.

### Interview
Explain your beginner solution for AI content provenance & authenticity. Use this scenario: The provenance viewer must flag any asset-binding validation failure; missing credentials are a separate unknown state.
Review: Start with the task and permitted scope. Explain provenance versus truth: Provenance describes an asset's recorded origin and edits. Authenticity checks can support that history without proving that the depicted event or claim is true. Show the input and observed output, then address Display valid, invalid and unknown provenance distinctly and retain trust-chain context. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An evidence table and a cautious provenance statement. Include beginner-worksheet.md and your completed Provenance inspection report and status-language guide.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

