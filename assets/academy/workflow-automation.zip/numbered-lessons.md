# AI workflow automation engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Process boundaries: Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

idempotent: Repeating the same identified operation has the same intended effect as doing it once.

### Process boundaries

Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution. In this role, work through: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Draw the delivery route and its checkpoints before buying a van.

Boundary: A documented process may still differ from what people actually do.

Worked example: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI workflow automation engineer: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment.

Predict the worked case

Read this case without running a tool: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in process boundaries.

Connect the concept to the role

Apply this rule: Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A documented process may still differ from what people actually do.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies process boundaries to this case: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Process boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with process boundaries. Use the glossary below, then write your prediction for: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI workflow automation engineer role interview. Explain process boundaries using this case: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate process boundaries to a system or workflow you know. Explain process boundaries using this case: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain process boundaries using this case: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment.

Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution. — Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution. A documented process may still differ from what people actually do.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

diagrams.net: https://www.drawio.com/docs/getting-started/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Diagnose: Invoices bypass approval

The simulated ledger must contain zero unapproved writes; no real payments are involved. Three workflow runs reach the ledger without a recorded approval. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Draw the delivery route and its checkpoints before buying a van.

A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment.

Worked example: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing); diagrams.net (Open source editor · browser/desktop)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The simulated ledger must contain zero unapproved writes; no real payments are involved. Three workflow runs reach the ledger without a recorded approval. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated ledger must contain zero unapproved writes; no real payments are involved. Apply this toy-case rule manually: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Automation connects steps in a process. Start by understanding exceptions and actions that cannot easily be undone.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Write the steps from a request arriving to a room being confirmed. Use fictional requests for an available room, a full room and a missing date.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

Preparation · Try step 2

For each step, record the person responsible, information needed and possible failure.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

Preparation · Try step 3

Mark the confirmation step as needing a checked room/date; add a clarification route for incomplete requests.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

Preparation · Explain and check your result

An incomplete request cannot silently become a confirmed booking; each exception has an owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A process table covering three requests and their outcomes. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated ledger must contain zero unapproved writes; no real payments are involved. Apply this toy-case rule manually: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three workflow runs reach the ledger without a recorded approval. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three workflow runs reach the ledger without a recorded approval. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: invoices bypass approval. Use the glossary below, then write your prediction for: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI workflow automation engineer role interview. Explain diagnose: invoices bypass approval using this case: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: invoices bypass approval to a system or workflow you know. Explain diagnose: invoices bypass approval using this case: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Reject missing, denied and stale approvals; approved retries must remain idempotent. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: invoices bypass approval using this case: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence. State the evidence, one alternative and where the mental model stops.

Quiz: Invoices bypass approval: The simulated ledger must contain zero unapproved writes; no real payments are involved.

Change the acceptance rule after seeing an inconvenient result.

Enforce an approval state before the connector action; do not rely on a generated approval sentence.

Omit failed cases and report only the successful demonstrations.

Reference: Enforce an approval state before the connector action; do not rely on a generated approval sentence. — Enforce an approval state before the connector action; do not rely on a generated approval sentence. Reject missing, denied and stale approvals; approved retries must remain idempotent.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

diagrams.net: https://www.drawio.com/docs/getting-started/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Process mapping, APIs or connectors, data access and exception handling; coding varies with integration depth.

Terms:

Duplicate-safe integration: Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Duplicate-safe integration

Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction. In this role, work through: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A numbered receipt prevents the same purchase being entered twice.

Boundary: The receiving service must enforce the same identity rule for reliable protection.

Worked example: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Process mapping, APIs or connectors, data access and exception handling; coding varies with integration depth.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI workflow automation engineer: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log.

Predict the worked case

Read this case without running a tool: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in duplicate-safe integration.

Connect the concept to the role

Apply this rule: Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: The receiving service must enforce the same identity rule for reliable protection.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies duplicate-safe integration to this case: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Duplicate-safe integration; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with duplicate-safe integration. Use the glossary below, then write your prediction for: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI workflow automation engineer role interview. Explain duplicate-safe integration using this case: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate duplicate-safe integration to a system or workflow you know. Explain duplicate-safe integration using this case: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain duplicate-safe integration using this case: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log.

Treat a passing starter as proof of the whole role workflow.

Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction.

Ignore the failure because the tool produced an output.

Reference: Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction. — Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction. The receiving service must enforce the same identity rule for reliable protection.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

diagrams.net: https://www.drawio.com/docs/getting-started/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Integrate: Human-approved invoice exception workflow

Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation. In this role, work through: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A numbered receipt prevents the same purchase being entered twice.

Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log.

Worked example: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing); diagrams.net (Open source editor · browser/desktop)

Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The simulated ledger must contain zero unapproved writes; no real payments are involved. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: As-is/to-be process map; Flow export or labeled manual simulation with ledger. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: human-approved invoice exception workflow. Use the glossary below, then write your prediction for: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI workflow automation engineer role interview. Explain integrate: human-approved invoice exception workflow using this case: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: human-approved invoice exception workflow to a system or workflow you know. Explain integrate: human-approved invoice exception workflow using this case: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. Identify one observation that would contradict your claim.

Interview: Explain integrate: human-approved invoice exception workflow using this case: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Human-approved invoice exception workflow at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.

Reference: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. — Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

diagrams.net: https://www.drawio.com/docs/getting-started/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Exception ownership: Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

### Exception ownership

Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard. In this role, work through: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A returned parcel needs a named person to resolve its address.

Boundary: A paper walkthrough proves the proposed process, not a live connector's reliability.

Worked example: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI workflow automation engineer: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair.

Predict the worked case

Read this case without running a tool: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in exception ownership.

Connect the concept to the role

Apply this rule: Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A paper walkthrough proves the proposed process, not a live connector's reliability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies exception ownership to this case: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Exception ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with exception ownership. Use the glossary below, then write your prediction for: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI workflow automation engineer role interview. Explain exception ownership using this case: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate exception ownership to a system or workflow you know. Explain exception ownership using this case: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain exception ownership using this case: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard.

Reference: Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard. — Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard. A paper walkthrough proves the proposed process, not a live connector's reliability.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

diagrams.net: https://www.drawio.com/docs/getting-started/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Defend: Human-approved invoice exception workflow

Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner. In this role, work through: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A returned parcel needs a named person to resolve its address.

Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair.

Worked example: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Calc (Open source · no account needed); Power Automate (Commercial · account and connector licensing); diagrams.net (Open source editor · browser/desktop)

Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A reviewer must reproduce one result and identify which capabilities you implemented. Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: As-is/to-be process map; Flow export or labeled manual simulation with ledger; UAT script and exception handling guide. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: human-approved invoice exception workflow. Use the glossary below, then write your prediction for: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI workflow automation engineer role interview. Explain defend: human-approved invoice exception workflow using this case: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: human-approved invoice exception workflow to a system or workflow you know. Explain defend: human-approved invoice exception workflow using this case: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. Identify one observation that would contradict your claim.

Interview: Explain defend: human-approved invoice exception workflow using this case: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Human-approved invoice exception workflow at this level?

Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request. — Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request. Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Power Automate: https://learn.microsoft.com/en-us/power-automate/

diagrams.net: https://www.drawio.com/docs/getting-started/

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
