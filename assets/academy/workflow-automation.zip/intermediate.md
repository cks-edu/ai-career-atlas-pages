## intermediate — Duplicate-safe integration

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Process mapping, APIs or connectors, data access and exception handling; coding varies with integration depth.

### Duplicate-safe integration
Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction.
Mental model: A numbered receipt prevents the same purchase being entered twice.
Boundary: The receiving service must enforce the same identity rule for reliable protection.
Worked example: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Human-approved invoice exception workflow
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Recall: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. Identify one observation that would contradict your claim.

### Terms
Duplicate-safe integration: Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The simulated ledger must contain zero unapproved writes; no real payments are involved. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.
Deliverables: As-is/to-be process map; Flow export or labeled manual simulation with ledger. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI workflow automation engineer. Use this scenario: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Review: Start with the task and permitted scope. Explain duplicate-safe integration: Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction. Show the input and observed output, then address Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [As-is/to-be process map; Flow export or labeled manual simulation with ledger. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

