## advanced — Exception ownership

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Exception ownership
Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard.
Mental model: A returned parcel needs a named person to resolve its address.
Boundary: A paper walkthrough proves the proposed process, not a live connector's reliability.
Worked example: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Human-approved invoice exception workflow
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Recall: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. Identify one observation that would contradict your claim.

### Terms
Exception ownership: Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.
Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.
Add an OCR extraction step and require a reviewer to confirm low-confidence fields before the approval flow.
Deliverables: As-is/to-be process map; Flow export or labeled manual simulation with ledger; UAT script and exception handling guide. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A reviewer must reproduce one result and identify which capabilities you implemented. Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

### Interview
Explain your advanced solution for AI workflow automation engineer. Use this scenario: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Review: Start with the task and permitted scope. Explain exception ownership: Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard. Show the input and observed output, then address Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [As-is/to-be process map; Flow export or labeled manual simulation with ledger; UAT script and exception handling guide. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

