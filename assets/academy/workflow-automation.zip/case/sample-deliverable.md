# SAMPLE — Workflow map and exception-handling checklist
Role: AI workflow automation engineer
Case: Invoices bypass approval
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The simulated ledger must contain zero unapproved writes; no real payments are involved.

## Evidence table
| Record | unapproved_writes (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three workflow runs reach the ledger without a recorded approval.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Enforce an approval state before the connector action; do not rely on a generated approval sentence.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai workflow automation engineer.
Before release: Reject missing, denied and stale approvals; approved retries must remain idempotent.

## Design choice and trade-off
Separate extraction, approval and write permissions; route exceptions to an accountable reviewer.
Human review adds delay but bounds high-impact mistakes; automate preparation before automating commitment.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Invoice intake workflow: Duplicates are detected and no payment is executed.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
