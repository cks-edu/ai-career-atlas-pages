## beginner — Process boundaries

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Process boundaries
Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution.
Mental model: Draw the delivery route and its checkpoints before buying a van.
Boundary: A documented process may still differ from what people actually do.
Worked example: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Invoices bypass approval
The simulated ledger must contain zero unapproved writes; no real payments are involved. Three workflow runs reach the ledger without a recorded approval. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence.
Recall: Reject missing, denied and stale approvals; approved retries must remain idempotent. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Process boundaries: Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
idempotent: Repeating the same identified operation has the same intended effect as doing it once.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Automation connects steps in a process. Start by understanding exceptions and actions that cannot easily be undone.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Write the steps from a request arriving to a room being confirmed. Use fictional requests for an available room, a full room and a missing date.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

3. Try step 2
For each step, record the person responsible, information needed and possible failure.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

4. Try step 3
Mark the confirmation step as needing a checked room/date; add a clarification route for incomplete requests.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

5. Explain and check your result
An incomplete request cannot silently become a confirmed booking; each exception has an owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A process table covering three requests and their outcomes. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated ledger must contain zero unapproved writes; no real payments are involved. Apply this toy-case rule manually: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three workflow runs reach the ledger without a recorded approval. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI workflow automation engineer.
Write the steps from a request arriving to a room being confirmed. Use fictional requests for an available room, a full room and a missing date.
For each step, record the person responsible, information needed and possible failure.
Mark the confirmation step as needing a checked room/date; add a clarification route for incomplete requests.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A process table covering three requests and their outcomes. Include beginner-worksheet.md and your completed Workflow map and exception-handling checklist.
Check: An incomplete request cannot silently become a confirmed booking; each exception has an owner.

### Interview
Explain your beginner solution for AI workflow automation engineer. Use this scenario: The simulated ledger must contain zero unapproved writes; no real payments are involved.
Review: Start with the task and permitted scope. Explain process boundaries: Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution. Show the input and observed output, then address Enforce an approval state before the connector action; do not rely on a generated approval sentence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A process table covering three requests and their outcomes. Include beginner-worksheet.md and your completed Workflow map and exception-handling checklist.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

