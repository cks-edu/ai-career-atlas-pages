# AI workflow automation engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Process boundaries. Automation connects steps in a process. Start by understanding exceptions and actions that cannot easily be undone. Then try Map a request for a study-room booking. The three levels build toward Human-approved invoice exception workflow. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Process boundaries

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Process boundaries
Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution.
Mental model: Draw the delivery route and its checkpoints before buying a van.
Boundary: A documented process may still differ from what people actually do.
Worked example: A new invoice can trigger extraction, but a missing supplier ID routes to a person rather than automatic payment.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Invoices bypass approval
The simulated ledger must contain zero unapproved writes; no real payments are involved. Three workflow runs reach the ledger without a recorded approval. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Enforce an approval state before the connector action; do not rely on a generated approval sentence.
Recall: Reject missing, denied and stale approvals; approved retries must remain idempotent. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Process boundaries: Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
idempotent: Repeating the same identified operation has the same intended effect as doing it once.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Automation connects steps in a process. Start by understanding exceptions and actions that cannot easily be undone.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Write the steps from a request arriving to a room being confirmed. Use fictional requests for an available room, a full room and a missing date.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

3. Try step 2
For each step, record the person responsible, information needed and possible failure.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

4. Try step 3
Mark the confirmation step as needing a checked room/date; add a clarification route for incomplete requests.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A process table covering three requests and their outcomes.

5. Explain and check your result
An incomplete request cannot silently become a confirmed booking; each exception has an owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A process table covering three requests and their outcomes. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated ledger must contain zero unapproved writes; no real payments are involved. Apply this toy-case rule manually: Review when unapproved_writes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three workflow runs reach the ledger without a recorded approval. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI workflow automation engineer.
Write the steps from a request arriving to a room being confirmed. Use fictional requests for an available room, a full room and a missing date.
For each step, record the person responsible, information needed and possible failure.
Mark the confirmation step as needing a checked room/date; add a clarification route for incomplete requests.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A process table covering three requests and their outcomes. Include beginner-worksheet.md and your completed Workflow map and exception-handling checklist.
Check: An incomplete request cannot silently become a confirmed booking; each exception has an owner.

### Interview
Explain your beginner solution for AI workflow automation engineer. Use this scenario: The simulated ledger must contain zero unapproved writes; no real payments are involved.
Review: Start with the task and permitted scope. Explain process boundaries: Describe the trigger, inputs, owner and finished outcome before choosing an automation tool. Identify exceptions that require judgment and keep those outside unattended execution. Show the input and observed output, then address Enforce an approval state before the connector action; do not rely on a generated approval sentence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A process table covering three requests and their outcomes. Include beginner-worksheet.md and your completed Workflow map and exception-handling checklist.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Duplicate-safe integration

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Process mapping, APIs or connectors, data access and exception handling; coding varies with integration depth.

### Duplicate-safe integration
Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction.
Mental model: A numbered receipt prevents the same purchase being entered twice.
Boundary: The receiving service must enforce the same identity rule for reliable protection.
Worked example: Two identical invoice events with ID INV-7 result in one proposed payment and a duplicate-event log.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Human-approved invoice exception workflow
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Recall: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. Identify one observation that would contradict your claim.

### Terms
Duplicate-safe integration: Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The simulated ledger must contain zero unapproved writes; no real payments are involved. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.
Deliverables: As-is/to-be process map; Flow export or labeled manual simulation with ledger. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI workflow automation engineer. Use this scenario: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Review: Start with the task and permitted scope. Explain duplicate-safe integration: Connect systems using stable business identifiers and record attempted, completed and failed transfers. Repeating a trigger should not create another business transaction. Show the input and observed output, then address Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [As-is/to-be process map; Flow export or labeled manual simulation with ledger. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Exception ownership

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Exception ownership
Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard.
Mental model: A returned parcel needs a named person to resolve its address.
Boundary: A paper walkthrough proves the proposed process, not a live connector's reliability.
Worked example: Simulate an expired connector credential; pause delivery, notify the fictional owner and replay only unprocessed records after repair.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Human-approved invoice exception workflow
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Recall: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. Identify one observation that would contradict your claim.

### Terms
Exception ownership: Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
OCR: Optical character recognition: extracting text from images; layout, small print and unusual fonts can cause errors.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.
Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.
Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.
Add an OCR extraction step and require a reviewer to confirm low-confidence fields before the approval flow.
Deliverables: As-is/to-be process map; Flow export or labeled manual simulation with ledger; UAT script and exception handling guide. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A reviewer must reproduce one result and identify which capabilities you implemented. Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

### Interview
Explain your advanced solution for AI workflow automation engineer. Use this scenario: Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.
Review: Start with the task and permitted scope. Explain exception ownership: Give each failure queue an owner, response expectation and replay procedure. A workflow is incomplete if failed work is merely hidden in an automation dashboard. Show the input and observed output, then address Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [As-is/to-be process map; Flow export or labeled manual simulation with ledger; UAT script and exception handling guide. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Power Automate — Commercial · account and connector licensing
Test approval workflows; use a labeled manual simulation if access is unavailable.
Alternative: Node-RED (open source) or a manually executed checklist; connector availability and operating responsibility differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Power Automate: https://learn.microsoft.com/en-us/power-automate/
diagrams.net: https://www.drawio.com/docs/getting-started/
Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
