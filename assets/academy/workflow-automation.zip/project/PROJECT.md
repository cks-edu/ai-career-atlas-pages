# Human-approved invoice exception workflow

Career: AI workflow automation engineer
Reviewed: 2026-10-22

Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.

## Prerequisites
Process mapping, APIs or connectors, data access and exception handling; coding varies with integration depth.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create 25 fictional invoices in Calc with invoice ID, supplier, amount, purchase-order match and owner. Include five duplicates and four missing purchase orders; no actual payments are made.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Draw the current and proposed process in diagrams.net with swimlanes for requester, finance reviewer and system. Mark every decision and handoff.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
In Power Automate create a manually triggered test flow that reads a test table, creates an approval for exceptions and writes the decision to a separate ledger. Use only a test account; connector licenses vary. If unavailable, perform the exact state transitions in Calc and label the result a manual simulation.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. As-is/to-be process map — artifact-1.md
2. Flow export or labeled manual simulation with ledger — artifact-2.md
3. UAT script and exception handling guide — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Add an OCR extraction step and require a reviewer to confirm low-confidence fields before the approval flow.

## Primary learning resources
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.
- Power Automate: https://learn.microsoft.com/en-us/power-automate/ — Commercial · account and connector licensing; Test approval workflows; use a labeled manual simulation if access is unavailable.
- diagrams.net: https://www.drawio.com/docs/getting-started/ — Open source editor · browser/desktop; Architecture diagrams, process maps and trust boundaries.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
