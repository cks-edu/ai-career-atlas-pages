# UAT script and exception handling guide

Project: Human-approved invoice exception workflow
Status: blank work product — not completed evidence

## Purpose and audience
Design and demonstrate an invoice exception workflow with approvals, duplicate handling and a clear audit trail.

## Required content
Store invoice ID plus supplier as a deduplication key. Add explicit pending, approved, rejected and expired states; route timeouts to a named fictional owner.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Measure touches per invoice, duplicate suppression and time in each state. Use observed test-flow timings or clearly labeled simulated timings; do not invent realized savings.

## Failure evidence
Resubmit a previously approved invoice, then leave another approval unanswered. Show a single ledger entry for the duplicate and an escalation path for the expired request.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
