# Observability Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Apply desired state in Observability Engineer: Use the concept to complete this role exercise: Define a user-visible signal with a clear unit and population

Metrics, logs and traces: Metrics summarize measurements, logs record events and traces connect operations across a request. Use each signal for a question instead of copying all data into every backend.

### Desired state

A controller compares the current system with a declared target and works to reconcile the difference. In this role, work through: A request ID connects an error log to the slow operation that produced it. The practical workshop develops this into: Define a synthetic request schema with timestamp, route, status and duration. Create one metric definition, one structured log and a trace sketch for a failed request.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Role application: A dashboard shows traffic volume, a diary records events and a parcel tracker follows one journey.

Metrics summarize measurements, logs record events and traces connect operations across a request. Use each signal for a question instead of copying all data into every backend.

Worked example: A request ID connects an error log to the slow operation that produced it.

Shared foundation example: One replica means the controller tries to keep one Pod running.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenTelemetry, Prometheus and Grafana (Open source cores); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Observability Engineer: A request ID connects an error log to the slow operation that produced it.

Predict the worked case

Read this case without running a tool: A request ID connects an error log to the slow operation that produced it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in desired state.

Connect the concept to the role

Apply this rule: A controller compares the current system with a declared target and works to reconcile the difference. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: It cannot fix every cause: a missing image or insufficient resources still needs action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies desired state to this case: A request ID connects an error log to the slow operation that produced it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A request ID connects an error log to the slow operation that produced it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Desired state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with desired state. Use the glossary below, then write your prediction for: A request ID connects an error log to the slow operation that produced it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Observability Engineer role interview. Explain desired state using this case: A request ID connects an error log to the slow operation that produced it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate desired state to a system or workflow you know. Explain desired state using this case: A request ID connects an error log to the slow operation that produced it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired state using this case: A request ID connects an error log to the slow operation that produced it. State the evidence, one alternative and where the mental model stops.

Quiz: After the Metrics, logs and traces rehearsal, check this foundation: A controller is told to run two replicas, but only one is ready. What does the declared target mean?

The controller attempts reconciliation; it is not a guarantee that both are healthy now.

Two healthy replicas must already exist.

The current replica count becomes the new desired target automatically.

Reference: The controller attempts reconciliation; it is not a guarantee that both are healthy now. — Desired and observed state differ during convergence or failure. Inspect readiness, events and constraints.

Sources:

OpenTelemetry: signals: https://opentelemetry.io/docs/concepts/signals/

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

### Metrics, logs and traces

Metrics summarize measurements, logs record events and traces connect operations across a request. Use each signal for a question instead of copying all data into every backend. In this role, work through: A request ID connects an error log to the slow operation that produced it. The practical workshop develops this into: Define a synthetic request schema with timestamp, route, status and duration. Create one metric definition, one structured log and a trace sketch for a failed request.

Mental model: A dashboard shows traffic volume, a diary records events and a parcel tracker follows one journey.

Boundary: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk.

Worked example: A request ID connects an error log to the slow operation that produced it.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenTelemetry, Prometheus and Grafana (Open source cores); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Observability Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Define a synthetic request schema with timestamp, route, status and duration. Create one metric definition, one structured log and a trace sketch for a failed request.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

A request ID connects an error log to the slow operation that produced it. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Define a synthetic request schema with timestamp, route, status and duration. Create one metric definition, one structured log and a trace sketch for a failed request.

Expected: Each signal answers a distinct diagnostic question without sensitive payloads.

Role workshop · debug and verify

A user ID as an unrestricted metric label can create excessive cardinality and privacy risk. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save telemetry schema and signal map. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Each signal answers a distinct diagnostic question without sensitive payloads.

Expected: Each signal answers a distinct diagnostic question without sensitive payloads.

Troubleshoot: The role exercise differs from the prediction: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-beginner-2.md: telemetry schema and signal map; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with metrics, logs and traces. Use the glossary below, then write your prediction for: A request ID connects an error log to the slow operation that produced it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Observability Engineer role interview. Explain metrics, logs and traces using this case: A request ID connects an error log to the slow operation that produced it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate metrics, logs and traces to a system or workflow you know. Explain metrics, logs and traces using this case: A request ID connects an error log to the slow operation that produced it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk.

Interview: Explain metrics, logs and traces using this case: A request ID connects an error log to the slow operation that produced it. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A request ID connects an error log to the slow operation that produced it.

Each signal answers a distinct diagnostic question without sensitive payloads.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Each signal answers a distinct diagnostic question without sensitive payloads. — Metrics summarize measurements, logs record events and traces connect operations across a request. Use each signal for a question instead of copying all data into every backend. Each signal answers a distinct diagnostic question without sensitive payloads.

Sources:

OpenTelemetry: signals: https://opentelemetry.io/docs/concepts/signals/

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Apply readiness and routing in Observability Engineer: Use the concept to complete this role exercise: Correlate logs, metrics and traces without recording secrets

Cardinality and correlation: Metric labels create series combinations; unbounded identifiers can make telemetry expensive and hard to use. Correlation needs consistent context propagation, not just similarly named fields.

### Readiness and routing

Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. In this role, work through: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. The practical workshop develops this into: Compare series counts for two routes and three statuses versus 1000 unique request IDs. Add a shared trace ID to synthetic logs and identify a broken propagation hop.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Role application: An index with one drawer per unique parcel can grow without bound.

Metric labels create series combinations; unbounded identifiers can make telemetry expensive and hard to use. Correlation needs consistent context propagation, not just similarly named fields.

Worked example: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not.

Shared foundation example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenTelemetry, Prometheus and Grafana (Open source cores); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Observability Engineer: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not.

Predict the worked case

Read this case without running a tool: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and routing.

Connect the concept to the role

Apply this rule: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A health endpoint can be too shallow; it must reflect the service contract.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and routing to this case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Readiness and routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and routing. Use the glossary below, then write your prediction for: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Observability Engineer role interview. Explain readiness and routing using this case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and routing to a system or workflow you know. Explain readiness and routing using this case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Explain readiness and routing using this case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. State the evidence, one alternative and where the mental model stops.

Quiz: After the Cardinality and correlation rehearsal, check this foundation: A process listens on 8080. A Service accepts 80. Which target port should route to that listener?

80 because the Service port must equal the application port.

8080, matching the actual application listener.

443 because readiness always implies TLS.

Reference: 8080, matching the actual application listener. — Service and target ports can differ. Readiness must also reflect whether the workload can serve traffic.

Sources:

OpenTelemetry: signals: https://opentelemetry.io/docs/concepts/signals/

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

### Cardinality and correlation

Metric labels create series combinations; unbounded identifiers can make telemetry expensive and hard to use. Correlation needs consistent context propagation, not just similarly named fields. In this role, work through: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. The practical workshop develops this into: Compare series counts for two routes and three statuses versus 1000 unique request IDs. Add a shared trace ID to synthetic logs and identify a broken propagation hop.

Mental model: An index with one drawer per unique parcel can grow without bound.

Boundary: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces.

Worked example: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenTelemetry, Prometheus and Grafana (Open source cores); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Observability Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Compare series counts for two routes and three statuses versus 1000 unique request IDs. Add a shared trace ID to synthetic logs and identify a broken propagation hop.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Compare series counts for two routes and three statuses versus 1000 unique request IDs. Add a shared trace ID to synthetic logs and identify a broken propagation hop.

Expected: A bounded label design and a repaired correlation example.

Role workshop · debug and verify

Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save cardinality budget and correlation tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A bounded label design and a repaired correlation example.

Expected: A bounded label design and a repaired correlation example.

Troubleshoot: The role exercise differs from the prediction: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-intermediate-2.md: cardinality budget and correlation tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cardinality and correlation. Use the glossary below, then write your prediction for: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Observability Engineer role interview. Explain cardinality and correlation using this case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cardinality and correlation to a system or workflow you know. Explain cardinality and correlation using this case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces.

Interview: Explain cardinality and correlation using this case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Labeling latency by route template is bounded; labeling by raw URL with order IDs is not.

Ignore the failing case and keep only the successful screenshot.

A bounded label design and a repaired correlation example.

Treat any successful command as proof that all business and access rules passed.

Reference: A bounded label design and a repaired correlation example. — Metric labels create series combinations; unbounded identifiers can make telemetry expensive and hard to use. Correlation needs consistent context propagation, not just similarly named fields. A bounded label design and a repaired correlation example.

Sources:

OpenTelemetry: signals: https://opentelemetry.io/docs/concepts/signals/

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Apply rollback and service objectives in Observability Engineer: Use the concept to complete this role exercise: Design low-noise alerts, cardinality limits and telemetry failure handling

Telemetry pipeline failure: Collectors and backends can drop or delay data. Monitor ingestion health, queue pressure and export errors so missing telemetry does not masquerade as a healthy service.

### Rollback and service objectives

A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. In this role, work through: Zero errors during an exporter outage does not mean zero application errors. The practical workshop develops this into: Create a failure tabletop with backend unavailability, bounded queues and recovery. Define drop counters, alerting and retention trade-offs, then test a local collector if available using official setup.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Role application: A weather station must report when its sensor wire is disconnected.

Collectors and backends can drop or delay data. Monitor ingestion health, queue pressure and export errors so missing telemetry does not masquerade as a healthy service.

Worked example: Zero errors during an exporter outage does not mean zero application errors.

Shared foundation example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenTelemetry, Prometheus and Grafana (Open source cores); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Observability Engineer: Zero errors during an exporter outage does not mean zero application errors.

Predict the worked case

Read this case without running a tool: Zero errors during an exporter outage does not mean zero application errors. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in rollback and service objectives.

Connect the concept to the role

Apply this rule: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback may not undo database changes; release safety includes schema compatibility.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies rollback and service objectives to this case: Zero errors during an exporter outage does not mean zero application errors. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Zero errors during an exporter outage does not mean zero application errors. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Rollback and service objectives; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and service objectives. Use the glossary below, then write your prediction for: Zero errors during an exporter outage does not mean zero application errors. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Observability Engineer role interview. Explain rollback and service objectives using this case: Zero errors during an exporter outage does not mean zero application errors. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and service objectives to a system or workflow you know. Explain rollback and service objectives using this case: Zero errors during an exporter outage does not mean zero application errors. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks must pass after undoing a bad image?

Interview: Explain rollback and service objectives using this case: Zero errors during an exporter outage does not mean zero application errors. State the evidence, one alternative and where the mental model stops.

Quiz: After the Telemetry pipeline failure rehearsal, check this foundation: A rollout undo completes. What additional evidence establishes user recovery?

The deployment command exited zero, so no more checks are needed.

The old image tag exists in the registry.

A representative user operation succeeds and dependent state remains compatible.

Reference: A representative user operation succeeds and dependent state remains compatible. — Control-plane convergence does not verify the business path or reverse external state changes.

Sources:

OpenTelemetry: signals: https://opentelemetry.io/docs/concepts/signals/

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

### Telemetry pipeline failure

Collectors and backends can drop or delay data. Monitor ingestion health, queue pressure and export errors so missing telemetry does not masquerade as a healthy service. In this role, work through: Zero errors during an exporter outage does not mean zero application errors. The practical workshop develops this into: Create a failure tabletop with backend unavailability, bounded queues and recovery. Define drop counters, alerting and retention trade-offs, then test a local collector if available using official setup.

Mental model: A weather station must report when its sensor wire is disconnected.

Boundary: Unlimited buffering can exhaust the application host; set and test resource bounds.

Worked example: Zero errors during an exporter outage does not mean zero application errors.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenTelemetry, Prometheus and Grafana (Open source cores); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Observability Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a failure tabletop with backend unavailability, bounded queues and recovery. Define drop counters, alerting and retention trade-offs, then test a local collector if available using official setup.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Rehearse a failed release

Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

Role workshop · predict

Zero errors during an exporter outage does not mean zero application errors. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a failure tabletop with backend unavailability, bounded queues and recovery. Define drop counters, alerting and retention trade-offs, then test a local collector if available using official setup.

Expected: A diagnostic plan that distinguishes application health from telemetry health.

Role workshop · debug and verify

Unlimited buffering can exhaust the application host; set and test resource bounds. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save observability pipeline runbook and loss/recovery analysis. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A diagnostic plan that distinguishes application health from telemetry health.

Expected: A diagnostic plan that distinguishes application health from telemetry health.

Troubleshoot: The role exercise differs from the prediction: Unlimited buffering can exhaust the application host; set and test resource bounds.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-advanced-2.md: observability pipeline runbook and loss/recovery analysis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with telemetry pipeline failure. Use the glossary below, then write your prediction for: Zero errors during an exporter outage does not mean zero application errors. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Observability Engineer role interview. Explain telemetry pipeline failure using this case: Zero errors during an exporter outage does not mean zero application errors. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate telemetry pipeline failure to a system or workflow you know. Explain telemetry pipeline failure using this case: Zero errors during an exporter outage does not mean zero application errors. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Unlimited buffering can exhaust the application host; set and test resource bounds.

Interview: Explain telemetry pipeline failure using this case: Zero errors during an exporter outage does not mean zero application errors. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Zero errors during an exporter outage does not mean zero application errors.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A diagnostic plan that distinguishes application health from telemetry health.

Reference: A diagnostic plan that distinguishes application health from telemetry health. — Collectors and backends can drop or delay data. Monitor ingestion health, queue pressure and export errors so missing telemetry does not masquerade as a healthy service. A diagnostic plan that distinguishes application health from telemetry health.

Sources:

OpenTelemetry: signals: https://opentelemetry.io/docs/concepts/signals/

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/
