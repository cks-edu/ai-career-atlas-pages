# Observability Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Metrics, logs and traces

Metrics summarize measurements, logs record events and traces connect operations across a request. Use each signal for a question instead of copying all data into every backend.
Mental model: A dashboard shows traffic volume, a diary records events and a parcel tracker follows one journey.
Case: A request ID connects an error log to the slow operation that produced it.
Task: Define a synthetic request schema with timestamp, route, status and duration. Create one metric definition, one structured log and a trace sketch for a failed request.
Acceptance: Each signal answers a distinct diagnostic question without sensitive payloads.
Troubleshooting: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk.
Deliverable: telemetry schema and signal map

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Cardinality and correlation

Metric labels create series combinations; unbounded identifiers can make telemetry expensive and hard to use. Correlation needs consistent context propagation, not just similarly named fields.
Mental model: An index with one drawer per unique parcel can grow without bound.
Case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not.
Task: Compare series counts for two routes and three statuses versus 1000 unique request IDs. Add a shared trace ID to synthetic logs and identify a broken propagation hop.
Acceptance: A bounded label design and a repaired correlation example.
Troubleshooting: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces.
Deliverable: cardinality budget and correlation tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Telemetry pipeline failure

Collectors and backends can drop or delay data. Monitor ingestion health, queue pressure and export errors so missing telemetry does not masquerade as a healthy service.
Mental model: A weather station must report when its sensor wire is disconnected.
Case: Zero errors during an exporter outage does not mean zero application errors.
Task: Create a failure tabletop with backend unavailability, bounded queues and recovery. Define drop counters, alerting and retention trade-offs, then test a local collector if available using official setup.
Acceptance: A diagnostic plan that distinguishes application health from telemetry health.
Troubleshooting: Unlimited buffering can exhaust the application host; set and test resource bounds.
Deliverable: observability pipeline runbook and loss/recovery analysis

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
