# Observability Engineer

Software Engineering

Begin with desired state. Define a user-visible signal with a clear unit and population. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Define a user-visible signal with a clear unit and population

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Apply desired state in Observability Engineer
Use the concept to complete this role exercise: Define a user-visible signal with a clear unit and population
Mental model: A thermostat compares actual temperature with the set point.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: One replica means the controller tries to keep one Pod running. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course
kubectl --context kind-atlas-course create namespace atlas-lab
kubectl --context kind-atlas-course apply -f deployment.yaml
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Apply the role exercise
Define a user-visible signal with a clear unit and population
Expected: Save architecture, diagnostic or CI evidence with the actual environment and untested parts clearly identified.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course. This deletes that local learning cluster and its lab data only.

Portfolio: observability-engineer-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Define a user-visible signal with a clear unit and population? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A controller compares the current system with a declared target and works to reconcile the difference. For this role, explicitly address: Define a user-visible signal with a clear unit and population.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Correlate logs, metrics and traces without recording secrets

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Apply readiness and routing in Observability Engineer
Use the concept to complete this role exercise: Correlate logs, metrics and traces without recording secrets
Mental model: A shop can have lights on but still be closed to customers.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course
kubectl --context kind-atlas-course create namespace atlas-lab
kubectl --context kind-atlas-course apply -f deployment.yaml
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Apply the role exercise
Correlate logs, metrics and traces without recording secrets
Expected: Save architecture, diagnostic or CI evidence with the actual environment and untested parts clearly identified.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course. This deletes that local learning cluster and its lab data only.

Portfolio: observability-engineer-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Correlate logs, metrics and traces without recording secrets? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. For this role, explicitly address: Correlate logs, metrics and traces without recording secrets.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Design low-noise alerts, cardinality limits and telemetry failure handling

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Apply rollback and service objectives in Observability Engineer
Use the concept to complete this role exercise: Design low-noise alerts, cardinality limits and telemetry failure handling
Mental model: A reversible road detour with traffic counters at both ends.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course
kubectl --context kind-atlas-course create namespace atlas-lab
kubectl --context kind-atlas-course apply -f deployment.yaml
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --context kind-atlas-course -n atlas-lab get pods
kubectl --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Apply the role exercise
Design low-noise alerts, cardinality limits and telemetry failure handling
Expected: Save architecture, diagnostic or CI evidence with the actual environment and untested parts clearly identified.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course. This deletes that local learning cluster and its lab data only.

Portfolio: observability-engineer-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Design low-noise alerts, cardinality limits and telemetry failure handling? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. For this role, explicitly address: Design low-noise alerts, cardinality limits and telemetry failure handling.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Google SRE book: https://sre.google/sre-book/table-of-contents/
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
