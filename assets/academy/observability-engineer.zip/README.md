# Observability Engineer

Software Engineering

Start with metrics, logs and traces. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward observability pipeline runbook and loss/recovery analysis.

## beginner

Define a synthetic request schema with timestamp, route, status and duration. Create one metric definition, one structured log and a trace sketch for a failed request.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Metrics, logs and traces
Metrics summarize measurements, logs record events and traces connect operations across a request. Use each signal for a question instead of copying all data into every backend.
Mental model: A dashboard shows traffic volume, a diary records events and a parcel tracker follows one journey.
Limit: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk.
Example: A request ID connects an error log to the slow operation that produced it.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
A request ID connects an error log to the slow operation that produced it. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Define a synthetic request schema with timestamp, route, status and duration. Create one metric definition, one structured log and a trace sketch for a failed request.
Expected: Each signal answers a distinct diagnostic question without sensitive payloads.

6. Role workshop · debug and verify
A user ID as an unrestricted metric label can create excessive cardinality and privacy risk. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save telemetry schema and signal map. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Each signal answers a distinct diagnostic question without sensitive payloads.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Metrics, logs and traces: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: telemetry schema and signal map
Each signal answers a distinct diagnostic question without sensitive payloads.

Interview: Work through this Observability Engineer case: A request ID connects an error log to the slow operation that produced it. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Metrics summarize measurements, logs record events and traces connect operations across a request. Use each signal for a question instead of copying all data into every backend. Expected evidence: Each signal answers a distinct diagnostic question without sensitive payloads. Diagnosis: A user ID as an unrestricted metric label can create excessive cardinality and privacy risk. State the limits of the mental model: A dashboard shows traffic volume, a diary records events and a parcel tracker follows one journey.

Resume: Built telemetry schema and signal map using OpenTelemetry, Prometheus and Grafana; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Compare series counts for two routes and three statuses versus 1000 unique request IDs. Add a shared trace ID to synthetic logs and identify a broken propagation hop.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Cardinality and correlation
Metric labels create series combinations; unbounded identifiers can make telemetry expensive and hard to use. Correlation needs consistent context propagation, not just similarly named fields.
Mental model: An index with one drawer per unique parcel can grow without bound.
Limit: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces.
Example: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Compare series counts for two routes and three statuses versus 1000 unique request IDs. Add a shared trace ID to synthetic logs and identify a broken propagation hop.
Expected: A bounded label design and a repaired correlation example.

6. Role workshop · debug and verify
Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save cardinality budget and correlation tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A bounded label design and a repaired correlation example.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cardinality and correlation: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: cardinality budget and correlation tests
A bounded label design and a repaired correlation example.

Interview: Work through this Observability Engineer case: Labeling latency by route template is bounded; labeling by raw URL with order IDs is not. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Metric labels create series combinations; unbounded identifiers can make telemetry expensive and hard to use. Correlation needs consistent context propagation, not just similarly named fields. Expected evidence: A bounded label design and a repaired correlation example. Diagnosis: Dropping all context fixes cost by destroying usefulness; keep high-cardinality detail in appropriate logs/traces. State the limits of the mental model: An index with one drawer per unique parcel can grow without bound.

Resume: Built cardinality budget and correlation tests using OpenTelemetry, Prometheus and Grafana; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create a failure tabletop with backend unavailability, bounded queues and recovery. Define drop counters, alerting and retention trade-offs, then test a local collector if available using official setup.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Telemetry pipeline failure
Collectors and backends can drop or delay data. Monitor ingestion health, queue pressure and export errors so missing telemetry does not masquerade as a healthy service.
Mental model: A weather station must report when its sensor wire is disconnected.
Limit: Unlimited buffering can exhaust the application host; set and test resource bounds.
Example: Zero errors during an exporter outage does not mean zero application errors.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Unlimited buffering can exhaust the application host; set and test resource bounds.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
Zero errors during an exporter outage does not mean zero application errors. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a failure tabletop with backend unavailability, bounded queues and recovery. Define drop counters, alerting and retention trade-offs, then test a local collector if available using official setup.
Expected: A diagnostic plan that distinguishes application health from telemetry health.

6. Role workshop · debug and verify
Unlimited buffering can exhaust the application host; set and test resource bounds. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save observability pipeline runbook and loss/recovery analysis. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A diagnostic plan that distinguishes application health from telemetry health.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Telemetry pipeline failure: Unlimited buffering can exhaust the application host; set and test resource bounds.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: observability pipeline runbook and loss/recovery analysis
A diagnostic plan that distinguishes application health from telemetry health.

Interview: Work through this Observability Engineer case: Zero errors during an exporter outage does not mean zero application errors. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Collectors and backends can drop or delay data. Monitor ingestion health, queue pressure and export errors so missing telemetry does not masquerade as a healthy service. Expected evidence: A diagnostic plan that distinguishes application health from telemetry health. Diagnosis: Unlimited buffering can exhaust the application host; set and test resource bounds. State the limits of the mental model: A weather station must report when its sensor wire is disconnected.

Resume: Built observability pipeline runbook and loss/recovery analysis using OpenTelemetry, Prometheus and Grafana; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Google SRE book: https://sre.google/sre-book/table-of-contents/
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
OpenTelemetry: signals: https://opentelemetry.io/docs/concepts/signals/
