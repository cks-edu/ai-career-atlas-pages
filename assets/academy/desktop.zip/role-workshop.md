# Desktop Application Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Keyboard-first desktop interaction

Desktop users expect tab navigation, visible focus and predictable shortcuts. A window resize should rearrange content without hiding the current task or losing input.
Mental model: A desk should keep its tools reachable when the workspace gets smaller.
Case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft.
Task: Create the Flutter desktop sample on a supported OS. Add a task screen, define focus order and test keyboard-only entry at narrow and wide window sizes.
Acceptance: Every action is reachable and focus is visible; resizing preserves the draft.
Troubleshooting: If a shortcut fires while typing, scope its handler to the intended control or mode.
Deliverable: keyboard map and resize evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
File storage boundaries

Desktop file access needs explicit locations and error handling. Never assume the installation directory is writable; separate app data from exported user files.
Mental model: The office archive and the customer's take-home copy belong in different places.
Case: A denied export must leave the previous file intact and explain the failure.
Task: Add local persistence using a supported application-data location, then implement an explicit export action. Test canceling the dialog, choosing an unwritable path and reopening a valid export.
Acceptance: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.
Troubleshooting: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported.
Deliverable: storage design and export failure cases

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Updates and migration recovery

Desktop updates may change local data formats. Version the schema, back up before conversion and test both upgraded and failed-migration behavior.
Mental model: Renovate the archive only after keeping a recoverable copy of the old filing system.
Case: Version 1 task data without priority migrates to version 2 with a default.
Task: Create v1, valid-v2 and corrupted fixtures. Implement a migration on copies, verify IDs/counts and refuse unknown versions with a recovery message. Document signing and installer requirements for the chosen OS.
Acceptance: Valid upgrade preserves records; corruption does not overwrite the source file.
Troubleshooting: An installer success is not a migration test; verify the actual existing-user data path.
Deliverable: migration fixtures and an OS-specific release runbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
