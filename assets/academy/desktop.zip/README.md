# Desktop Application Developer

Software Engineering

Begin with ui state. Create a desktop task window and verify keyboard navigation. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Create a desktop task window and verify keyboard navigation

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app.

### UI state
The visible interface is a projection of state. User actions update state and trigger a new view.
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: Rendering frameworks differ; re-rendering does not automatically persist data.
Example: Adding one task changes count from zero to one.
Recall: Which state must survive app restart?

### Apply ui state in Desktop Application Developer
Use the concept to complete this role exercise: Create a desktop task window and verify keyboard navigation
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Adding one task changes count from zero to one. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start the native template
Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Apply this level’s extension
Create a desktop task window and verify keyboard navigation
Expected: Record each row of checklist.md with input, expected result, observed result and evidence.

4. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: desktop-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Create a desktop task window and verify keyboard navigation? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: The visible interface is a projection of state. User actions update state and trigger a new view. For this role, explicitly address: Create a desktop task window and verify keyboard navigation.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Persist window state and tasks across restart

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app.

### Local persistence and offline work
Save data explicitly and show whether it is local, queued or synchronized.
Mental model: An outbox keeps letters until the courier is available.
Limit: Local storage can be removed or unavailable; it is not cloud backup.
Example: Create a task offline, restart and verify it remains marked unsent.
Recall: Why must the user see a queued status?

### Apply local persistence and offline work in Desktop Application Developer
Use the concept to complete this role exercise: Persist window state and tasks across restart
Mental model: An outbox keeps letters until the courier is available.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Create a task offline, restart and verify it remains marked unsent. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start the native template
Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Apply this level’s extension
Persist window state and tasks across restart
Expected: Record each row of checklist.md with input, expected result, observed result and evidence.

4. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: desktop-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Persist window state and tasks across restart? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Save data explicitly and show whether it is local, queued or synchronized. For this role, explicitly address: Persist window state and tasks across restart.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Document installer, update, signing and file-permission requirements

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app.

### Lifecycle and synchronization
Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: A bookmark cannot decide how to merge two different edits.
Example: Retry the same task ID after reconnecting and verify one remote record.
Recall: What happens if two devices change the same title offline?

### Apply lifecycle and synchronization in Desktop Application Developer
Use the concept to complete this role exercise: Document installer, update, signing and file-permission requirements
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Retry the same task ID after reconnecting and verify one remote record. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start the native template
Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Apply this level’s extension
Document installer, update, signing and file-permission requirements
Expected: Record each row of checklist.md with input, expected result, observed result and evidence.

4. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: desktop-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Document installer, update, signing and file-permission requirements? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. For this role, explicitly address: Document installer, update, signing and file-permission requirements.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Flutter learning pathway: https://docs.flutter.dev/learn
Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course
Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
