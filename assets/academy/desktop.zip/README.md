# Desktop Application Developer

Software Engineering

Start with keyboard-first desktop interaction. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward migration fixtures and an OS-specific release runbook.

## beginner

Create the Flutter desktop sample on a supported OS. Add a task screen, define focus order and test keyboard-only entry at narrow and wide window sizes.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### UI state
The visible interface is a projection of state. User actions update state and trigger a new view.
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: Rendering frameworks differ; re-rendering does not automatically persist data.
Example: Adding one task changes count from zero to one.
Recall: Which state must survive app restart?

### Keyboard-first desktop interaction
Desktop users expect tab navigation, visible focus and predictable shortcuts. A window resize should rearrange content without hiding the current task or losing input.
Mental model: A desk should keep its tools reachable when the workspace gets smaller.
Limit: If a shortcut fires while typing, scope its handler to the intended control or mode.
Example: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If a shortcut fires while typing, scope its handler to the intended control or mode.

1. Start the native template
Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create the Flutter desktop sample on a supported OS. Add a task screen, define focus order and test keyboard-only entry at narrow and wide window sizes.
```
flutter devices
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Every action is reachable and focus is visible; resizing preserves the draft.

6. Role workshop · debug and verify
If a shortcut fires while typing, scope its handler to the intended control or mode. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save keyboard map and resize evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Every action is reachable and focus is visible; resizing preserves the draft.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Keyboard-first desktop interaction: If a shortcut fires while typing, scope its handler to the intended control or mode.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: keyboard map and resize evidence
Every action is reachable and focus is visible; resizing preserves the draft.

Interview: Work through this Desktop Application Developer case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Desktop users expect tab navigation, visible focus and predictable shortcuts. A window resize should rearrange content without hiding the current task or losing input. Expected evidence: Every action is reachable and focus is visible; resizing preserves the draft. Diagnosis: If a shortcut fires while typing, scope its handler to the intended control or mode. State the limits of the mental model: A desk should keep its tools reachable when the workspace gets smaller.

Resume: Built keyboard map and resize evidence using Flutter desktop; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add local persistence using a supported application-data location, then implement an explicit export action. Test canceling the dialog, choosing an unwritable path and reopening a valid export.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Local persistence and offline work
Save data explicitly and show whether it is local, queued or synchronized.
Mental model: An outbox keeps letters until the courier is available.
Limit: Local storage can be removed or unavailable; it is not cloud backup.
Example: Create a task offline, restart and verify it remains marked unsent.
Recall: Why must the user see a queued status?

### File storage boundaries
Desktop file access needs explicit locations and error handling. Never assume the installation directory is writable; separate app data from exported user files.
Mental model: The office archive and the customer's take-home copy belong in different places.
Limit: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported.
Example: A denied export must leave the previous file intact and explain the failure.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported.

1. Start the native template
Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
A denied export must leave the previous file intact and explain the failure. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add local persistence using a supported application-data location, then implement an explicit export action. Test canceling the dialog, choosing an unwritable path and reopening a valid export.
```
flutter test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

6. Role workshop · debug and verify
A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save storage design and export failure cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
File storage boundaries: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: storage design and export failure cases
Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

Interview: Work through this Desktop Application Developer case: A denied export must leave the previous file intact and explain the failure. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Desktop file access needs explicit locations and error handling. Never assume the installation directory is writable; separate app data from exported user files. Expected evidence: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back. Diagnosis: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported. State the limits of the mental model: The office archive and the customer's take-home copy belong in different places.

Resume: Built storage design and export failure cases using Flutter desktop; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create v1, valid-v2 and corrupted fixtures. Implement a migration on copies, verify IDs/counts and refuse unknown versions with a recovery message. Document signing and installer requirements for the chosen OS.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Lifecycle and synchronization
Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: A bookmark cannot decide how to merge two different edits.
Example: Retry the same task ID after reconnecting and verify one remote record.
Recall: What happens if two devices change the same title offline?

### Updates and migration recovery
Desktop updates may change local data formats. Version the schema, back up before conversion and test both upgraded and failed-migration behavior.
Mental model: Renovate the archive only after keeping a recoverable copy of the old filing system.
Limit: An installer success is not a migration test; verify the actual existing-user data path.
Example: Version 1 task data without priority migrates to version 2 with a default.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An installer success is not a migration test; verify the actual existing-user data path.

1. Start the native template
Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Version 1 task data without priority migrates to version 2 with a default. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create v1, valid-v2 and corrupted fixtures. Implement a migration on copies, verify IDs/counts and refuse unknown versions with a recovery message. Document signing and installer requirements for the chosen OS.
```
flutter test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Valid upgrade preserves records; corruption does not overwrite the source file.

6. Role workshop · debug and verify
An installer success is not a migration test; verify the actual existing-user data path. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save migration fixtures and an OS-specific release runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Valid upgrade preserves records; corruption does not overwrite the source file.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Updates and migration recovery: An installer success is not a migration test; verify the actual existing-user data path.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: migration fixtures and an OS-specific release runbook
Valid upgrade preserves records; corruption does not overwrite the source file.

Interview: Work through this Desktop Application Developer case: Version 1 task data without priority migrates to version 2 with a default. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Desktop updates may change local data formats. Version the schema, back up before conversion and test both upgraded and failed-migration behavior. Expected evidence: Valid upgrade preserves records; corruption does not overwrite the source file. Diagnosis: An installer success is not a migration test; verify the actual existing-user data path. State the limits of the mental model: Renovate the archive only after keeping a recoverable copy of the old filing system.

Resume: Built migration fixtures and an OS-specific release runbook using Flutter desktop; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Flutter learning pathway: https://docs.flutter.dev/learn
Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course
Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
