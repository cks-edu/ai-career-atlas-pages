# Desktop Application Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

UI state: The visible interface is a projection of state. User actions update state and trigger a new view.

Apply ui state in Desktop Application Developer: Use the concept to complete this role exercise: Create a desktop task window and verify keyboard navigation

Keyboard-first desktop interaction: Desktop users expect tab navigation, visible focus and predictable shortcuts. A window resize should rearrange content without hiding the current task or losing input.

### UI state

The visible interface is a projection of state. User actions update state and trigger a new view. In this role, work through: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. The practical workshop develops this into: Create the Flutter desktop sample on a supported OS. Add a task screen, define focus order and test keyboard-only entry at narrow and wide window sizes.

Mental model: A scoreboard reflects the current score rather than owning the game rules.

Boundary: Rendering frameworks differ; re-rendering does not automatically persist data.

Role application: A desk should keep its tools reachable when the workspace gets smaller.

Desktop users expect tab navigation, visible focus and predictable shortcuts. A window resize should rearrange content without hiding the current task or losing input.

Worked example: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft.

Shared foundation example: Adding one task changes count from zero to one.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Flutter desktop (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Desktop Application Developer: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft.

Predict the worked case

Read this case without running a tool: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in ui state.

Connect the concept to the role

Apply this rule: The visible interface is a projection of state. User actions update state and trigger a new view. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Rendering frameworks differ; re-rendering does not automatically persist data.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies ui state to this case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for UI state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ui state. Use the glossary below, then write your prediction for: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Desktop Application Developer role interview. Explain ui state using this case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ui state to a system or workflow you know. Explain ui state using this case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which state must survive app restart?

Interview: Explain ui state using this case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. State the evidence, one alternative and where the mental model stops.

Quiz: After the Keyboard-first desktop interaction rehearsal, check this foundation: A screen shows an old count after the underlying list changes. What should you inspect first?

How the view derives from state and receives change notifications.

Whether a screenshot contains the desired count.

Whether an unrelated server restart changes the display.

Reference: How the view derives from state and receives change notifications. — Trace the action, state update and rendered projection before adding a second conflicting source of truth.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

### Keyboard-first desktop interaction

Desktop users expect tab navigation, visible focus and predictable shortcuts. A window resize should rearrange content without hiding the current task or losing input. In this role, work through: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. The practical workshop develops this into: Create the Flutter desktop sample on a supported OS. Add a task screen, define focus order and test keyboard-only entry at narrow and wide window sizes.

Mental model: A desk should keep its tools reachable when the workspace gets smaller.

Boundary: If a shortcut fires while typing, scope its handler to the intended control or mode.

Worked example: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Flutter desktop (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Desktop Application Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create the Flutter desktop sample on a supported OS. Add a task screen, define focus order and test keyboard-only entry at narrow and wide window sizes.

Start the native template

Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.

```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create the Flutter desktop sample on a supported OS. Add a task screen, define focus order and test keyboard-only entry at narrow and wide window sizes.

```
flutter devices
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Every action is reachable and focus is visible; resizing preserves the draft.

Role workshop · debug and verify

If a shortcut fires while typing, scope its handler to the intended control or mode. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save keyboard map and resize evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Every action is reachable and focus is visible; resizing preserves the draft.

Expected: Every action is reachable and focus is visible; resizing preserves the draft.

Troubleshoot: The role exercise differs from the prediction: If a shortcut fires while typing, scope its handler to the intended control or mode.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-beginner-2.md: keyboard map and resize evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keyboard-first desktop interaction. Use the glossary below, then write your prediction for: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Desktop Application Developer role interview. Explain keyboard-first desktop interaction using this case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keyboard-first desktop interaction to a system or workflow you know. Explain keyboard-first desktop interaction using this case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If a shortcut fires while typing, scope its handler to the intended control or mode.

Interview: Explain keyboard-first desktop interaction using this case: Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Tab reaches input, Add and task actions; Escape dismisses a temporary dialog without deleting a draft.

Every action is reachable and focus is visible; resizing preserves the draft.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Every action is reachable and focus is visible; resizing preserves the draft. — Desktop users expect tab navigation, visible focus and predictable shortcuts. A window resize should rearrange content without hiding the current task or losing input. Every action is reachable and focus is visible; resizing preserves the draft.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Local persistence and offline work: Save data explicitly and show whether it is local, queued or synchronized.

Apply local persistence and offline work in Desktop Application Developer: Use the concept to complete this role exercise: Persist window state and tasks across restart

File storage boundaries: Desktop file access needs explicit locations and error handling. Never assume the installation directory is writable; separate app data from exported user files.

### Local persistence and offline work

Save data explicitly and show whether it is local, queued or synchronized. In this role, work through: A denied export must leave the previous file intact and explain the failure. The practical workshop develops this into: Add local persistence using a supported application-data location, then implement an explicit export action. Test canceling the dialog, choosing an unwritable path and reopening a valid export.

Mental model: An outbox keeps letters until the courier is available.

Boundary: Local storage can be removed or unavailable; it is not cloud backup.

Role application: The office archive and the customer's take-home copy belong in different places.

Desktop file access needs explicit locations and error handling. Never assume the installation directory is writable; separate app data from exported user files.

Worked example: A denied export must leave the previous file intact and explain the failure.

Shared foundation example: Create a task offline, restart and verify it remains marked unsent.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Flutter desktop (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Desktop Application Developer: A denied export must leave the previous file intact and explain the failure.

Predict the worked case

Read this case without running a tool: A denied export must leave the previous file intact and explain the failure. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in local persistence and offline work.

Connect the concept to the role

Apply this rule: Save data explicitly and show whether it is local, queued or synchronized. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Local storage can be removed or unavailable; it is not cloud backup.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies local persistence and offline work to this case: A denied export must leave the previous file intact and explain the failure. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A denied export must leave the previous file intact and explain the failure. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Local persistence and offline work; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with local persistence and offline work. Use the glossary below, then write your prediction for: A denied export must leave the previous file intact and explain the failure. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Desktop Application Developer role interview. Explain local persistence and offline work using this case: A denied export must leave the previous file intact and explain the failure. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate local persistence and offline work to a system or workflow you know. Explain local persistence and offline work using this case: A denied export must leave the previous file intact and explain the failure. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the user see a queued status?

Interview: Explain local persistence and offline work using this case: A denied export must leave the previous file intact and explain the failure. State the evidence, one alternative and where the mental model stops.

Quiz: After the File storage boundaries rehearsal, check this foundation: A record is saved locally while offline. Which status is justified before server acknowledgment?

Synchronized because it survives local restart.

Saved locally / pending synchronization.

Rejected because offline work cannot be stored.

Reference: Saved locally / pending synchronization. — Local durability and remote acknowledgment are different states. Communicate them separately.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

### File storage boundaries

Desktop file access needs explicit locations and error handling. Never assume the installation directory is writable; separate app data from exported user files. In this role, work through: A denied export must leave the previous file intact and explain the failure. The practical workshop develops this into: Add local persistence using a supported application-data location, then implement an explicit export action. Test canceling the dialog, choosing an unwritable path and reopening a valid export.

Mental model: The office archive and the customer's take-home copy belong in different places.

Boundary: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported.

Worked example: A denied export must leave the previous file intact and explain the failure.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Flutter desktop (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Desktop Application Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add local persistence using a supported application-data location, then implement an explicit export action. Test canceling the dialog, choosing an unwritable path and reopening a valid export.

Start the native template

Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.

```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

A denied export must leave the previous file intact and explain the failure. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add local persistence using a supported application-data location, then implement an explicit export action. Test canceling the dialog, choosing an unwritable path and reopening a valid export.

```
flutter test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

Role workshop · debug and verify

A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save storage design and export failure cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

Expected: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

Troubleshoot: The role exercise differs from the prediction: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-intermediate-2.md: storage design and export failure cases; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with file storage boundaries. Use the glossary below, then write your prediction for: A denied export must leave the previous file intact and explain the failure. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Desktop Application Developer role interview. Explain file storage boundaries using this case: A denied export must leave the previous file intact and explain the failure. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate file storage boundaries to a system or workflow you know. Explain file storage boundaries using this case: A denied export must leave the previous file intact and explain the failure. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A half-written file suggests direct overwrite; consider writing a temporary file and replacing only after success where supported.

Interview: Explain file storage boundaries using this case: A denied export must leave the previous file intact and explain the failure. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A denied export must leave the previous file intact and explain the failure.

Ignore the failing case and keep only the successful screenshot.

Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

Treat any successful command as proof that all business and access rules passed.

Reference: Cancel changes nothing; failed writes preserve prior data; a valid export can be read back. — Desktop file access needs explicit locations and error handling. Never assume the installation directory is writable; separate app data from exported user files. Cancel changes nothing; failed writes preserve prior data; a valid export can be read back.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Lifecycle and synchronization: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.

Apply lifecycle and synchronization in Desktop Application Developer: Use the concept to complete this role exercise: Document installer, update, signing and file-permission requirements

Updates and migration recovery: Desktop updates may change local data formats. Version the schema, back up before conversion and test both upgraded and failed-migration behavior.

### Lifecycle and synchronization

Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. In this role, work through: Version 1 task data without priority migrates to version 2 with a default. The practical workshop develops this into: Create v1, valid-v2 and corrupted fixtures. Implement a migration on copies, verify IDs/counts and refuse unknown versions with a recovery message. Document signing and installer requirements for the chosen OS.

Mental model: A bookmark preserves your place when a reading session is interrupted.

Boundary: A bookmark cannot decide how to merge two different edits.

Role application: Renovate the archive only after keeping a recoverable copy of the old filing system.

Desktop updates may change local data formats. Version the schema, back up before conversion and test both upgraded and failed-migration behavior.

Worked example: Version 1 task data without priority migrates to version 2 with a default.

Shared foundation example: Retry the same task ID after reconnecting and verify one remote record.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Flutter desktop (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Desktop Application Developer: Version 1 task data without priority migrates to version 2 with a default.

Predict the worked case

Read this case without running a tool: Version 1 task data without priority migrates to version 2 with a default. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in lifecycle and synchronization.

Connect the concept to the role

Apply this rule: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A bookmark cannot decide how to merge two different edits.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies lifecycle and synchronization to this case: Version 1 task data without priority migrates to version 2 with a default. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Version 1 task data without priority migrates to version 2 with a default. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Lifecycle and synchronization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with lifecycle and synchronization. Use the glossary below, then write your prediction for: Version 1 task data without priority migrates to version 2 with a default. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Desktop Application Developer role interview. Explain lifecycle and synchronization using this case: Version 1 task data without priority migrates to version 2 with a default. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate lifecycle and synchronization to a system or workflow you know. Explain lifecycle and synchronization using this case: Version 1 task data without priority migrates to version 2 with a default. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens if two devices change the same title offline?

Interview: Explain lifecycle and synchronization using this case: Version 1 task data without priority migrates to version 2 with a default. State the evidence, one alternative and where the mental model stops.

Quiz: After the Updates and migration recovery rehearsal, check this foundation: An app reconnects after an interrupted upload. Which retry behavior avoids creating a new logical record?

Generate a new record ID on every attempt.

Delete local state before checking the response.

Reuse the stable record ID and apply an explicit conflict policy.

Reference: Reuse the stable record ID and apply an explicit conflict policy. — Stable identity helps replay; concurrent edits still need a deliberate resolution strategy.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

### Updates and migration recovery

Desktop updates may change local data formats. Version the schema, back up before conversion and test both upgraded and failed-migration behavior. In this role, work through: Version 1 task data without priority migrates to version 2 with a default. The practical workshop develops this into: Create v1, valid-v2 and corrupted fixtures. Implement a migration on copies, verify IDs/counts and refuse unknown versions with a recovery message. Document signing and installer requirements for the chosen OS.

Mental model: Renovate the archive only after keeping a recoverable copy of the old filing system.

Boundary: An installer success is not a migration test; verify the actual existing-user data path.

Worked example: Version 1 task data without priority migrates to version 2 with a default.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Flutter desktop (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Desktop Application Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create v1, valid-v2 and corrupted fixtures. Implement a migration on copies, verify IDs/counts and refuse unknown versions with a recovery message. Document signing and installer requirements for the chosen OS.

Start the native template

Create the Flutter scaffold. Select your supported desktop target from flutter devices, then run flutter run -d with that listed device identifier.

```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter devices
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

Version 1 task data without priority migrates to version 2 with a default. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create v1, valid-v2 and corrupted fixtures. Implement a migration on copies, verify IDs/counts and refuse unknown versions with a recovery message. Document signing and installer requirements for the chosen OS.

```
flutter test
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Valid upgrade preserves records; corruption does not overwrite the source file.

Role workshop · debug and verify

An installer success is not a migration test; verify the actual existing-user data path. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save migration fixtures and an OS-specific release runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Valid upgrade preserves records; corruption does not overwrite the source file.

Expected: Valid upgrade preserves records; corruption does not overwrite the source file.

Troubleshoot: The role exercise differs from the prediction: An installer success is not a migration test; verify the actual existing-user data path.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-advanced-2.md: migration fixtures and an OS-specific release runbook; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with updates and migration recovery. Use the glossary below, then write your prediction for: Version 1 task data without priority migrates to version 2 with a default. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Desktop Application Developer role interview. Explain updates and migration recovery using this case: Version 1 task data without priority migrates to version 2 with a default. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate updates and migration recovery to a system or workflow you know. Explain updates and migration recovery using this case: Version 1 task data without priority migrates to version 2 with a default. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: An installer success is not a migration test; verify the actual existing-user data path.

Interview: Explain updates and migration recovery using this case: Version 1 task data without priority migrates to version 2 with a default. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Version 1 task data without priority migrates to version 2 with a default.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Valid upgrade preserves records; corruption does not overwrite the source file.

Reference: Valid upgrade preserves records; corruption does not overwrite the source file. — Desktop updates may change local data formats. Version the schema, back up before conversion and test both upgraded and failed-migration behavior. Valid upgrade preserves records; corruption does not overwrite the source file.

Sources:

Flutter learning pathway: https://docs.flutter.dev/learn

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
