# RPA / Business Automation Developer

Software Engineering

Start with deterministic automation boundaries. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward RPA operations runbook and release checklist.

## beginner

Create a local spreadsheet fixture and a UiPath Academy workflow that reads rows and validates required fields before any UI action. Record accepted and rejected IDs.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Deterministic automation boundaries
RPA repeats UI or application operations but needs stable inputs and selectors. Separate business decisions from screen navigation and avoid real credentials in learning fixtures.
Mental model: A robot follows labeled stations; moving the labels can confuse it.
Limit: Image-coordinate clicks are fragile; prefer supported selectors and observable application state.
Example: A synthetic invoice list contains valid, blank and duplicate invoice IDs.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Image-coordinate clicks are fragile; prefer supported selectors and observable application state.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A synthetic invoice list contains valid, blank and duplicate invoice IDs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a local spreadsheet fixture and a UiPath Academy workflow that reads rows and validates required fields before any UI action. Record accepted and rejected IDs.
Expected: Invalid rows are logged without crashing the batch.

6. Role workshop · debug and verify
Image-coordinate clicks are fragile; prefer supported selectors and observable application state. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save RPA input contract and validation workflow. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Invalid rows are logged without crashing the batch.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Deterministic automation boundaries: Image-coordinate clicks are fragile; prefer supported selectors and observable application state.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: RPA input contract and validation workflow
Invalid rows are logged without crashing the batch.

Interview: Work through this RPA / Business Automation Developer case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: RPA repeats UI or application operations but needs stable inputs and selectors. Separate business decisions from screen navigation and avoid real credentials in learning fixtures. Expected evidence: Invalid rows are logged without crashing the batch. Diagnosis: Image-coordinate clicks are fragile; prefer supported selectors and observable application state. State the limits of the mental model: A robot follows labeled stations; moving the labels can confuse it.

Resume: Built RPA input contract and validation workflow using UiPath Studio and Orchestrator; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Build a fake submit step with a stable invoice key, inject a timeout and check for prior completion before retry. Route invalid amounts to a human exception queue.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Retries and business exceptions
Retry transient technical failures differently from invalid business data. Repeating a payment or submission without checking identity can duplicate effects.
Mental model: Try opening a temporarily stuck door again; do not repeatedly submit the same purchase.
Limit: Blind retry of a non-idempotent action can duplicate work.
Example: A timeout after invoice submission may mean the invoice was already accepted.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Blind retry of a non-idempotent action can duplicate work.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A timeout after invoice submission may mean the invoice was already accepted. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Build a fake submit step with a stable invoice key, inject a timeout and check for prior completion before retry. Route invalid amounts to a human exception queue.
Expected: One recorded submission per invoice and separate technical/business failure paths.

6. Role workshop · debug and verify
Blind retry of a non-idempotent action can duplicate work. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save retry workflow and exception cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One recorded submission per invoice and separate technical/business failure paths.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Retries and business exceptions: Blind retry of a non-idempotent action can duplicate work.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: retry workflow and exception cases
One recorded submission per invoice and separate technical/business failure paths.

Interview: Work through this RPA / Business Automation Developer case: A timeout after invoice submission may mean the invoice was already accepted. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Retry transient technical failures differently from invalid business data. Repeating a payment or submission without checking identity can duplicate effects. Expected evidence: One recorded submission per invoice and separate technical/business failure paths. Diagnosis: Blind retry of a non-idempotent action can duplicate work. State the limits of the mental model: Try opening a temporarily stuck door again; do not repeatedly submit the same purchase.

Resume: Built retry workflow and exception cases using UiPath Studio and Orchestrator; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write an operations plan with approved credential storage, least privilege, retry limits and ownership. Rehearse synthetic credential failure without using live accounts and define recovery verification.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Credential and unattended operations
Unattended automation needs controlled identity, secret storage, scheduling and monitoring. A successful desktop demo does not establish a secure production robot.
Mental model: An overnight worker needs an authorized badge and an incident contact.
Limit: Do not embed passwords in spreadsheet cells to simplify a demo.
Example: A rotated credential must produce a controlled alert rather than endless failed logins.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not embed passwords in spreadsheet cells to simplify a demo.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A rotated credential must produce a controlled alert rather than endless failed logins. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write an operations plan with approved credential storage, least privilege, retry limits and ownership. Rehearse synthetic credential failure without using live accounts and define recovery verification.
Expected: A bounded failure and explicit handoff; no secrets in logs or source.

6. Role workshop · debug and verify
Do not embed passwords in spreadsheet cells to simplify a demo. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save RPA operations runbook and release checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A bounded failure and explicit handoff; no secrets in logs or source.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Credential and unattended operations: Do not embed passwords in spreadsheet cells to simplify a demo.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: RPA operations runbook and release checklist
A bounded failure and explicit handoff; no secrets in logs or source.

Interview: Work through this RPA / Business Automation Developer case: A rotated credential must produce a controlled alert rather than endless failed logins. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Unattended automation needs controlled identity, secret storage, scheduling and monitoring. A successful desktop demo does not establish a secure production robot. Expected evidence: A bounded failure and explicit handoff; no secrets in logs or source. Diagnosis: Do not embed passwords in spreadsheet cells to simplify a demo. State the limits of the mental model: An overnight worker needs an authorized badge and an incident contact.

Resume: Built RPA operations runbook and release checklist using UiPath Studio and Orchestrator; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
UiPath Academy: https://academy.uipath.com/
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
