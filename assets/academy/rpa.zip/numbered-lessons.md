# RPA / Business Automation Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Apply acceptance criteria in RPA / Business Automation Developer: Use the concept to complete this role exercise: Describe a synthetic invoice-to-register automation with validation

Deterministic automation boundaries: RPA repeats UI or application operations but needs stable inputs and selectors. Separate business decisions from screen navigation and avoid real credentials in learning fixtures.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: A synthetic invoice list contains valid, blank and duplicate invoice IDs. The practical workshop develops this into: Create a local spreadsheet fixture and a UiPath Academy workflow that reads rows and validates required fields before any UI action. Record accepted and rejected IDs.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A robot follows labeled stations; moving the labels can confuse it.

RPA repeats UI or application operations but needs stable inputs and selectors. Separate business decisions from screen navigation and avoid real credentials in learning fixtures.

Worked example: A synthetic invoice list contains valid, blank and duplicate invoice IDs.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: UiPath Studio and Orchestrator (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RPA / Business Automation Developer: A synthetic invoice list contains valid, blank and duplicate invoice IDs.

Predict the worked case

Read this case without running a tool: A synthetic invoice list contains valid, blank and duplicate invoice IDs. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: A synthetic invoice list contains valid, blank and duplicate invoice IDs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RPA / Business Automation Developer role interview. Explain acceptance criteria using this case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. State the evidence, one alternative and where the mental model stops.

Quiz: After the Deterministic automation boundaries rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

UiPath Academy: https://academy.uipath.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Deterministic automation boundaries

RPA repeats UI or application operations but needs stable inputs and selectors. Separate business decisions from screen navigation and avoid real credentials in learning fixtures. In this role, work through: A synthetic invoice list contains valid, blank and duplicate invoice IDs. The practical workshop develops this into: Create a local spreadsheet fixture and a UiPath Academy workflow that reads rows and validates required fields before any UI action. Record accepted and rejected IDs.

Mental model: A robot follows labeled stations; moving the labels can confuse it.

Boundary: Image-coordinate clicks are fragile; prefer supported selectors and observable application state.

Worked example: A synthetic invoice list contains valid, blank and duplicate invoice IDs.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: UiPath Studio and Orchestrator (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required RPA / Business Automation Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a local spreadsheet fixture and a UiPath Academy workflow that reads rows and validates required fields before any UI action. Record accepted and rejected IDs.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A synthetic invoice list contains valid, blank and duplicate invoice IDs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a local spreadsheet fixture and a UiPath Academy workflow that reads rows and validates required fields before any UI action. Record accepted and rejected IDs.

Expected: Invalid rows are logged without crashing the batch.

Role workshop · debug and verify

Image-coordinate clicks are fragile; prefer supported selectors and observable application state. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save RPA input contract and validation workflow. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Invalid rows are logged without crashing the batch.

Expected: Invalid rows are logged without crashing the batch.

Troubleshoot: The role exercise differs from the prediction: Image-coordinate clicks are fragile; prefer supported selectors and observable application state.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: RPA input contract and validation workflow; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with deterministic automation boundaries. Use the glossary below, then write your prediction for: A synthetic invoice list contains valid, blank and duplicate invoice IDs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RPA / Business Automation Developer role interview. Explain deterministic automation boundaries using this case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate deterministic automation boundaries to a system or workflow you know. Explain deterministic automation boundaries using this case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Image-coordinate clicks are fragile; prefer supported selectors and observable application state.

Interview: Explain deterministic automation boundaries using this case: A synthetic invoice list contains valid, blank and duplicate invoice IDs. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A synthetic invoice list contains valid, blank and duplicate invoice IDs.

Invalid rows are logged without crashing the batch.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Invalid rows are logged without crashing the batch. — RPA repeats UI or application operations but needs stable inputs and selectors. Separate business decisions from screen navigation and avoid real credentials in learning fixtures. Invalid rows are logged without crashing the batch.

Sources:

UiPath Academy: https://academy.uipath.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Apply traceability in RPA / Business Automation Developer: Use the concept to complete this role exercise: Separate recoverable application errors from business exceptions

Retries and business exceptions: Retry transient technical failures differently from invalid business data. Repeating a payment or submission without checking identity can duplicate effects.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: A timeout after invoice submission may mean the invoice was already accepted. The practical workshop develops this into: Build a fake submit step with a stable invoice key, inject a timeout and check for prior completion before retry. Route invalid amounts to a human exception queue.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: Try opening a temporarily stuck door again; do not repeatedly submit the same purchase.

Retry transient technical failures differently from invalid business data. Repeating a payment or submission without checking identity can duplicate effects.

Worked example: A timeout after invoice submission may mean the invoice was already accepted.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: UiPath Studio and Orchestrator (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RPA / Business Automation Developer: A timeout after invoice submission may mean the invoice was already accepted.

Predict the worked case

Read this case without running a tool: A timeout after invoice submission may mean the invoice was already accepted. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: A timeout after invoice submission may mean the invoice was already accepted. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A timeout after invoice submission may mean the invoice was already accepted. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: A timeout after invoice submission may mean the invoice was already accepted. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RPA / Business Automation Developer role interview. Explain traceability using this case: A timeout after invoice submission may mean the invoice was already accepted. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: A timeout after invoice submission may mean the invoice was already accepted. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: A timeout after invoice submission may mean the invoice was already accepted. State the evidence, one alternative and where the mental model stops.

Quiz: After the Retries and business exceptions rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

UiPath Academy: https://academy.uipath.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Retries and business exceptions

Retry transient technical failures differently from invalid business data. Repeating a payment or submission without checking identity can duplicate effects. In this role, work through: A timeout after invoice submission may mean the invoice was already accepted. The practical workshop develops this into: Build a fake submit step with a stable invoice key, inject a timeout and check for prior completion before retry. Route invalid amounts to a human exception queue.

Mental model: Try opening a temporarily stuck door again; do not repeatedly submit the same purchase.

Boundary: Blind retry of a non-idempotent action can duplicate work.

Worked example: A timeout after invoice submission may mean the invoice was already accepted.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: UiPath Studio and Orchestrator (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required RPA / Business Automation Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Build a fake submit step with a stable invoice key, inject a timeout and check for prior completion before retry. Route invalid amounts to a human exception queue.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A timeout after invoice submission may mean the invoice was already accepted. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Build a fake submit step with a stable invoice key, inject a timeout and check for prior completion before retry. Route invalid amounts to a human exception queue.

Expected: One recorded submission per invoice and separate technical/business failure paths.

Role workshop · debug and verify

Blind retry of a non-idempotent action can duplicate work. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save retry workflow and exception cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One recorded submission per invoice and separate technical/business failure paths.

Expected: One recorded submission per invoice and separate technical/business failure paths.

Troubleshoot: The role exercise differs from the prediction: Blind retry of a non-idempotent action can duplicate work.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: retry workflow and exception cases; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with retries and business exceptions. Use the glossary below, then write your prediction for: A timeout after invoice submission may mean the invoice was already accepted. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RPA / Business Automation Developer role interview. Explain retries and business exceptions using this case: A timeout after invoice submission may mean the invoice was already accepted. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate retries and business exceptions to a system or workflow you know. Explain retries and business exceptions using this case: A timeout after invoice submission may mean the invoice was already accepted. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Blind retry of a non-idempotent action can duplicate work.

Interview: Explain retries and business exceptions using this case: A timeout after invoice submission may mean the invoice was already accepted. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A timeout after invoice submission may mean the invoice was already accepted.

Ignore the failing case and keep only the successful screenshot.

One recorded submission per invoice and separate technical/business failure paths.

Treat any successful command as proof that all business and access rules passed.

Reference: One recorded submission per invoice and separate technical/business failure paths. — Retry transient technical failures differently from invalid business data. Repeating a payment or submission without checking identity can duplicate effects. One recorded submission per invoice and separate technical/business failure paths.

Sources:

UiPath Academy: https://academy.uipath.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Apply release decision and ownership in RPA / Business Automation Developer: Use the concept to complete this role exercise: Design queue retries, credential handling, human review and monitoring

Credential and unattended operations: Unattended automation needs controlled identity, secret storage, scheduling and monitoring. A successful desktop demo does not establish a secure production robot.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: A rotated credential must produce a controlled alert rather than endless failed logins. The practical workshop develops this into: Write an operations plan with approved credential storage, least privilege, retry limits and ownership. Rehearse synthetic credential failure without using live accounts and define recovery verification.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: An overnight worker needs an authorized badge and an incident contact.

Unattended automation needs controlled identity, secret storage, scheduling and monitoring. A successful desktop demo does not establish a secure production robot.

Worked example: A rotated credential must produce a controlled alert rather than endless failed logins.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: UiPath Studio and Orchestrator (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RPA / Business Automation Developer: A rotated credential must produce a controlled alert rather than endless failed logins.

Predict the worked case

Read this case without running a tool: A rotated credential must produce a controlled alert rather than endless failed logins. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: A rotated credential must produce a controlled alert rather than endless failed logins. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A rotated credential must produce a controlled alert rather than endless failed logins. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: A rotated credential must produce a controlled alert rather than endless failed logins. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RPA / Business Automation Developer role interview. Explain release decision and ownership using this case: A rotated credential must produce a controlled alert rather than endless failed logins. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: A rotated credential must produce a controlled alert rather than endless failed logins. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: A rotated credential must produce a controlled alert rather than endless failed logins. State the evidence, one alternative and where the mental model stops.

Quiz: After the Credential and unattended operations rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

UiPath Academy: https://academy.uipath.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Credential and unattended operations

Unattended automation needs controlled identity, secret storage, scheduling and monitoring. A successful desktop demo does not establish a secure production robot. In this role, work through: A rotated credential must produce a controlled alert rather than endless failed logins. The practical workshop develops this into: Write an operations plan with approved credential storage, least privilege, retry limits and ownership. Rehearse synthetic credential failure without using live accounts and define recovery verification.

Mental model: An overnight worker needs an authorized badge and an incident contact.

Boundary: Do not embed passwords in spreadsheet cells to simplify a demo.

Worked example: A rotated credential must produce a controlled alert rather than endless failed logins.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: UiPath Studio and Orchestrator (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required RPA / Business Automation Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write an operations plan with approved credential storage, least privilege, retry limits and ownership. Rehearse synthetic credential failure without using live accounts and define recovery verification.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A rotated credential must produce a controlled alert rather than endless failed logins. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write an operations plan with approved credential storage, least privilege, retry limits and ownership. Rehearse synthetic credential failure without using live accounts and define recovery verification.

Expected: A bounded failure and explicit handoff; no secrets in logs or source.

Role workshop · debug and verify

Do not embed passwords in spreadsheet cells to simplify a demo. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save RPA operations runbook and release checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A bounded failure and explicit handoff; no secrets in logs or source.

Expected: A bounded failure and explicit handoff; no secrets in logs or source.

Troubleshoot: The role exercise differs from the prediction: Do not embed passwords in spreadsheet cells to simplify a demo.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: RPA operations runbook and release checklist; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with credential and unattended operations. Use the glossary below, then write your prediction for: A rotated credential must produce a controlled alert rather than endless failed logins. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RPA / Business Automation Developer role interview. Explain credential and unattended operations using this case: A rotated credential must produce a controlled alert rather than endless failed logins. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate credential and unattended operations to a system or workflow you know. Explain credential and unattended operations using this case: A rotated credential must produce a controlled alert rather than endless failed logins. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not embed passwords in spreadsheet cells to simplify a demo.

Interview: Explain credential and unattended operations using this case: A rotated credential must produce a controlled alert rather than endless failed logins. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A rotated credential must produce a controlled alert rather than endless failed logins.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A bounded failure and explicit handoff; no secrets in logs or source.

Reference: A bounded failure and explicit handoff; no secrets in logs or source. — Unattended automation needs controlled identity, secret storage, scheduling and monitoring. A successful desktop demo does not establish a secure production robot. A bounded failure and explicit handoff; no secrets in logs or source.

Sources:

UiPath Academy: https://academy.uipath.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys
