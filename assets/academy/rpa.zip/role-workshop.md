# RPA / Business Automation Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Deterministic automation boundaries

RPA repeats UI or application operations but needs stable inputs and selectors. Separate business decisions from screen navigation and avoid real credentials in learning fixtures.
Mental model: A robot follows labeled stations; moving the labels can confuse it.
Case: A synthetic invoice list contains valid, blank and duplicate invoice IDs.
Task: Create a local spreadsheet fixture and a UiPath Academy workflow that reads rows and validates required fields before any UI action. Record accepted and rejected IDs.
Acceptance: Invalid rows are logged without crashing the batch.
Troubleshooting: Image-coordinate clicks are fragile; prefer supported selectors and observable application state.
Deliverable: RPA input contract and validation workflow

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Retries and business exceptions

Retry transient technical failures differently from invalid business data. Repeating a payment or submission without checking identity can duplicate effects.
Mental model: Try opening a temporarily stuck door again; do not repeatedly submit the same purchase.
Case: A timeout after invoice submission may mean the invoice was already accepted.
Task: Build a fake submit step with a stable invoice key, inject a timeout and check for prior completion before retry. Route invalid amounts to a human exception queue.
Acceptance: One recorded submission per invoice and separate technical/business failure paths.
Troubleshooting: Blind retry of a non-idempotent action can duplicate work.
Deliverable: retry workflow and exception cases

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Credential and unattended operations

Unattended automation needs controlled identity, secret storage, scheduling and monitoring. A successful desktop demo does not establish a secure production robot.
Mental model: An overnight worker needs an authorized badge and an incident contact.
Case: A rotated credential must produce a controlled alert rather than endless failed logins.
Task: Write an operations plan with approved credential storage, least privilege, retry limits and ownership. Rehearse synthetic credential failure without using live accounts and define recovery verification.
Acceptance: A bounded failure and explicit handoff; no secrets in logs or source.
Troubleshooting: Do not embed passwords in spreadsheet cells to simplify a demo.
Deliverable: RPA operations runbook and release checklist

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
