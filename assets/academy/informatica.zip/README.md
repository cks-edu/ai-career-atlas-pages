# Informatica Data Integration Developer

Software Engineering

Begin with keys and constraints. Map source columns to target columns with type and rejection rules. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Map source columns to target columns with type and rejection rules

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. For the Informatica extension, use an authorized learning environment. If the documentation portal is unavailable, the official course overview explains training scope; its R37 edition is not a claim about the current interface.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Mapping and transformation
A mapping describes how source records become target records through explicit transformation rules.
Mental model: A sorting line labels, checks and directs parcels to the correct destination.
Limit: A visual mapping still needs data contracts and tests; icons do not establish correctness.
Example: Map order_id and amount, reject negative amounts and retain a rejection reason.
Recall: Where should a type conversion failure be recorded?

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Map source columns to target columns with type and rejection rules
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: informatica-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Map source columns to target columns with type and rejection rules? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. For this role, explicitly address: Map source columns to target columns with type and rejection rules.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Design a mapping task with incremental watermark and reconciliation counts

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. For the Informatica extension, use an authorized learning environment. If the documentation portal is unavailable, the official course overview explains training scope; its R37 edition is not a claim about the current interface.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Runtime and watermark
An integration runtime executes the mapping. An incremental watermark records how far processing has progressed.
Mental model: The worker runs the sorting line; a bookmark marks the last processed page.
Limit: Advancing the bookmark before successful output can lose data; late corrections need a policy.
Example: Store the last successful update timestamp only after reconciliation succeeds.
Recall: How would you handle two rows with the same update timestamp?

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Design a mapping task with incremental watermark and reconciliation counts
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: informatica-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Design a mapping task with incremental watermark and reconciliation counts? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Repeating the same operation should have the same intended effect as applying it once. For this role, explicitly address: Design a mapping task with incremental watermark and reconciliation counts.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Plan replay, schema change, failed-agent recovery and environment promotion

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. For the Informatica extension, use an authorized learning environment. If the documentation portal is unavailable, the official course overview explains training scope; its R37 edition is not a claim about the current interface.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Task orchestration and recovery
Dependencies, retries and environment parameters turn mappings into an operational pipeline. Preserve evidence of each run.
Mental model: A production schedule coordinates machines and records which batch reached each station.
Limit: Blind retries can duplicate effects; idempotence must be designed.
Example: Pause after a target failure, identify accepted rows, then replay using stable keys.
Recall: Which values should be environment parameters instead of hardcoded mapping values?

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Plan replay, schema change, failed-agent recovery and environment promotion
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: informatica-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Plan replay, schema change, failed-agent recovery and environment promotion? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. For this role, explicitly address: Plan replay, schema change, failed-agent recovery and environment promotion.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html
