# Informatica Data Integration Developer

Software Engineering

Start with mapping, typing and rejection paths. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward CDI failure/replay report and environment promotion runbook.

## beginner

Run beginner, inspect Decimal conversion and rejection reasons, then draw Source → validation/expression → valid target and reject target. Map each branch to the CDI tools available in your authorized environment.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Mapping, typing and rejection paths
A CDI mapping connects source, transformations and target. Define field types and rejection routes before arranging transformations. The local Python model teaches the contract; it is not an Informatica runtime or connector test.
Mental model: A sorting line needs labels, inspection rules and a reject bin as well as a conveyor.
Limit: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons.
Example: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons.

1. Inspect the business fixture
Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run beginner, inspect Decimal conversion and rejection reasons, then draw Source → validation/expression → valid target and reject target. Map each branch to the CDI tools available in your authorized environment.
```
python3 enterprise_lab.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py beginner --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Create an authorized CDI mapping
In a permitted IDMC organization, confirm connector entitlement and an approved runtime environment. Create a mapping from a synthetic source to a disposable target, map order ID/amount and route invalid amounts to a reject output. Keep the contract independent of connector-specific expression syntax; use that connector’s current documentation.
Expected: Source, accepted, duplicate and rejected counts reconcile. No real production connection or agent is reconfigured.

6. Assemble the portfolio evidence
Create mapping specification and accepted/rejected outputs. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: mapping specification and accepted/rejected outputs
5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

Interview: Work through this Informatica Data Integration Developer case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A CDI mapping connects source, transformations and target. Define field types and rejection routes before arranging transformations. The local Python model teaches the contract; it is not an Informatica runtime or connector test. Expected evidence: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30. Diagnosis: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons. State the limits of the mental model: A sorting line needs labels, inspection rules and a reject bin as well as a conveyor.

Resume: Built mapping specification and accepted/rejected outputs using Informatica IDMC Cloud Data Integration and Secure Agent; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run intermediate, inspect versioned upsert and checkpoint order. In authorized CDI create a mapping task, choose the approved runtime, bind parameters and inspect source/target configuration before running a synthetic batch.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Mapping tasks and commit watermarks
A mapping task supplies runtime configuration to execute a mapping. An incremental checkpoint must advance only after successful target work and reconciliation; late-arriving corrections need an additional policy.
Mental model: The bookmark moves only after the page has actually been read and checked.
Limit: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement.
Example: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement.

1. Inspect the business fixture
A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run intermediate, inspect versioned upsert and checkpoint order. In authorized CDI create a mapping task, choose the approved runtime, bind parameters and inspect source/target configuration before running a synthetic batch.
```
python3 enterprise_lab.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Three target orders totaling 37 and watermark 3 in the local model.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py intermediate --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Bind and run a mapping task
The linked April 2025 Tasks guide describes New → Tasks → Mapping Task; confirm labels in your current environment, choose the mapping and review source, target, input parameters and runtime options. Configure the intended filter/window explicitly. Run the synthetic delta and inspect task results and target values; record runtime and connector versions.
Expected: Expected local contract is total 37 and three orders; any connector-specific difference is investigated and documented.

6. Assemble the portfolio evidence
Create parameterized mapping-task workbook and incremental tests. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Three target orders totaling 37 and watermark 3 in the local model.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: parameterized mapping-task workbook and incremental tests
Three target orders totaling 37 and watermark 3 in the local model.

Interview: Work through this Informatica Data Integration Developer case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A mapping task supplies runtime configuration to execute a mapping. An incremental checkpoint must advance only after successful target work and reconciliation; late-arriving corrections need an additional policy. Expected evidence: Three target orders totaling 37 and watermark 3 in the local model. Diagnosis: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement. State the limits of the mental model: The bookmark moves only after the page has actually been read and checked.

Resume: Built parameterized mapping-task workbook and incremental tests using Informatica IDMC Cloud Data Integration and Secure Agent; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run advanced, use --broken to advance the watermark before the failed commit, and investigate the failing assertion. Restore commit ordering and write an IDMC taskflow recovery/promotion plan with actual connector guarantees marked for verification.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Failure recovery and environment promotion
An agent or target failure can leave partial work unless the connector/transaction policy prevents it. Preserve run identifiers, rejected records and checkpoints; promote mappings with environment-specific connections reviewed separately.
Mental model: A failed conveyor needs both a batch ledger and a safe restart point.
Limit: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects.
Example: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects.

1. Inspect the business fixture
An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run advanced, use --broken to advance the watermark before the failed commit, and investigate the failing assertion. Restore commit ordering and write an IDMC taskflow recovery/promotion plan with actual connector guarantees marked for verification.
```
python3 enterprise_lab.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Rollback preserves the baseline; replay produces the corrected target without double counting.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py advanced --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Recover and promote safely
In a test connection, simulate a safe target-unavailable condition without disrupting a shared agent. Inspect run/error logs, reconcile partial target writes and restore connectivity. Replay by stable business key; review connection/parameter substitutions before promotion.
Expected: The replay matches the intended target and checkpoint policy; the runbook states whether the connector supports atomic rollback or requires compensating reconciliation.

6. Assemble the portfolio evidence
Create CDI failure/replay report and environment promotion runbook. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Rollback preserves the baseline; replay produces the corrected target without double counting.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: CDI failure/replay report and environment promotion runbook
Rollback preserves the baseline; replay produces the corrected target without double counting.

Interview: Work through this Informatica Data Integration Developer case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An agent or target failure can leave partial work unless the connector/transaction policy prevents it. Preserve run identifiers, rejected records and checkpoints; promote mappings with environment-specific connections reviewed separately. Expected evidence: Rollback preserves the baseline; replay produces the corrected target without double counting. Diagnosis: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects. State the limits of the mental model: A failed conveyor needs both a batch ledger and a safe restart point.

Resume: Built CDI failure/replay report and environment promotion runbook using Informatica IDMC Cloud Data Integration and Secure Agent; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html
Informatica CDI Tasks guide (April 2025 edition; portal access may be required): https://docs.informatica.com/content/dam/source/GUID-0/GUID-0E9D5DC7-01A2-4D15-816E-3F3515FF9D2D/62/en/CDI_April2025_Tasks_en.pdf
Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html
