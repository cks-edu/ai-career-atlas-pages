# Informatica Data Integration Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Mapping and transformation: A mapping describes how source records become target records through explicit transformation rules.

CDI: Cloud Data Integration, a service in Informatica IDMC.

Secure Agent: Informatica runtime software used for supported integration tasks; requirements depend on the connector and runtime option.

Watermark: A saved processing boundary. It must reflect successfully completed work and does not automatically capture deletes or late corrections.

Mapping, typing and rejection paths: A CDI mapping connects source, transformations and target. Define field types and rejection routes before arranging transformations. The local Python model teaches the contract; it is not an Informatica runtime or connector test.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. The practical workshop develops this into: Run beginner, inspect Decimal conversion and rejection reasons, then draw Source → validation/expression → valid target and reject target. Map each branch to the CDI tools available in your authorized environment.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: A sorting line needs labels, inspection rules and a reject bin as well as a conveyor.

A CDI mapping connects source, transformations and target. Define field types and rejection routes before arranging transformations. The local Python model teaches the contract; it is not an Informatica runtime or connector test.

Worked example: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Informatica IDMC Cloud Data Integration and Secure Agent (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Informatica Data Integration Developer: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows.

Predict the worked case

Read this case without running a tool: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Informatica Data Integration Developer role interview. Explain keys and constraints using this case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. State the evidence, one alternative and where the mental model stops.

Quiz: After the Mapping, typing and rejection paths rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Informatica CDI Tasks guide (April 2025 edition; portal access may be required): https://docs.informatica.com/content/dam/source/GUID-0/GUID-0E9D5DC7-01A2-4D15-816E-3F3515FF9D2D/62/en/CDI_April2025_Tasks_en.pdf

Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html

Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html

### Mapping, typing and rejection paths

A CDI mapping connects source, transformations and target. Define field types and rejection routes before arranging transformations. The local Python model teaches the contract; it is not an Informatica runtime or connector test. In this role, work through: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. The practical workshop develops this into: Run beginner, inspect Decimal conversion and rejection reasons, then draw Source → validation/expression → valid target and reject target. Map each branch to the CDI tools available in your authorized environment.

Mental model: A sorting line needs labels, inspection rules and a reject bin as well as a conveyor.

Boundary: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons.

Worked example: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Informatica IDMC Cloud Data Integration and Secure Agent (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run beginner, inspect Decimal conversion and rejection reasons, then draw Source → validation/expression → valid target and reject target. Map each branch to the CDI tools available in your authorized environment.

Inspect the business fixture

Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run beginner, inspect Decimal conversion and rejection reasons, then draw Source → validation/expression → valid target and reject target. Map each branch to the CDI tools available in your authorized environment.

```
python3 enterprise_lab.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py beginner --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Create an authorized CDI mapping

In a permitted IDMC organization, confirm connector entitlement and an approved runtime environment. Create a mapping from a synthetic source to a disposable target, map order ID/amount and route invalid amounts to a reject output. Keep the contract independent of connector-specific expression syntax; use that connector’s current documentation.

Expected: Source, accepted, duplicate and rejected counts reconcile. No real production connection or agent is reconfigured.

Assemble the portfolio evidence

Create mapping specification and accepted/rejected outputs. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

Expected: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

Troubleshoot: The role exercise differs from the prediction: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-beginner-2.md: mapping specification and accepted/rejected outputs; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with mapping, typing and rejection paths. Use the glossary below, then write your prediction for: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Informatica Data Integration Developer role interview. Explain mapping, typing and rejection paths using this case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate mapping, typing and rejection paths to a system or workflow you know. Explain mapping, typing and rejection paths using this case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons.

Interview: Explain mapping, typing and rejection paths using this case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows.

5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30. — A CDI mapping connects source, transformations and target. Define field types and rejection routes before arranging transformations. The local Python model teaches the contract; it is not an Informatica runtime or connector test. 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.

Sources:

Informatica CDI Tasks guide (April 2025 edition; portal access may be required): https://docs.informatica.com/content/dam/source/GUID-0/GUID-0E9D5DC7-01A2-4D15-816E-3F3515FF9D2D/62/en/CDI_April2025_Tasks_en.pdf

Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html

Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Runtime and watermark: An integration runtime executes the mapping. An incremental watermark records how far processing has progressed.

CDI: Cloud Data Integration, a service in Informatica IDMC.

Secure Agent: Informatica runtime software used for supported integration tasks; requirements depend on the connector and runtime option.

Watermark: A saved processing boundary. It must reflect successfully completed work and does not automatically capture deletes or late corrections.

Mapping tasks and commit watermarks: A mapping task supplies runtime configuration to execute a mapping. An incremental checkpoint must advance only after successful target work and reconciliation; late-arriving corrections need an additional policy.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. The practical workshop develops this into: Run intermediate, inspect versioned upsert and checkpoint order. In authorized CDI create a mapping task, choose the approved runtime, bind parameters and inspect source/target configuration before running a synthetic batch.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: The bookmark moves only after the page has actually been read and checked.

A mapping task supplies runtime configuration to execute a mapping. An incremental checkpoint must advance only after successful target work and reconciliation; late-arriving corrections need an additional policy.

Worked example: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Informatica IDMC Cloud Data Integration and Secure Agent (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Informatica Data Integration Developer: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success.

Predict the worked case

Read this case without running a tool: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Informatica Data Integration Developer role interview. Explain idempotent processing using this case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. State the evidence, one alternative and where the mental model stops.

Quiz: After the Mapping tasks and commit watermarks rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Informatica CDI Tasks guide (April 2025 edition; portal access may be required): https://docs.informatica.com/content/dam/source/GUID-0/GUID-0E9D5DC7-01A2-4D15-816E-3F3515FF9D2D/62/en/CDI_April2025_Tasks_en.pdf

Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html

Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html

### Mapping tasks and commit watermarks

A mapping task supplies runtime configuration to execute a mapping. An incremental checkpoint must advance only after successful target work and reconciliation; late-arriving corrections need an additional policy. In this role, work through: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. The practical workshop develops this into: Run intermediate, inspect versioned upsert and checkpoint order. In authorized CDI create a mapping task, choose the approved runtime, bind parameters and inspect source/target configuration before running a synthetic batch.

Mental model: The bookmark moves only after the page has actually been read and checked.

Boundary: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement.

Worked example: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Informatica IDMC Cloud Data Integration and Secure Agent (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run intermediate, inspect versioned upsert and checkpoint order. In authorized CDI create a mapping task, choose the approved runtime, bind parameters and inspect source/target configuration before running a synthetic batch.

Inspect the business fixture

A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run intermediate, inspect versioned upsert and checkpoint order. In authorized CDI create a mapping task, choose the approved runtime, bind parameters and inspect source/target configuration before running a synthetic batch.

```
python3 enterprise_lab.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Three target orders totaling 37 and watermark 3 in the local model.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py intermediate --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Bind and run a mapping task

The linked April 2025 Tasks guide describes New → Tasks → Mapping Task; confirm labels in your current environment, choose the mapping and review source, target, input parameters and runtime options. Configure the intended filter/window explicitly. Run the synthetic delta and inspect task results and target values; record runtime and connector versions.

Expected: Expected local contract is total 37 and three orders; any connector-specific difference is investigated and documented.

Assemble the portfolio evidence

Create parameterized mapping-task workbook and incremental tests. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Three target orders totaling 37 and watermark 3 in the local model.

Expected: Three target orders totaling 37 and watermark 3 in the local model.

Troubleshoot: The role exercise differs from the prediction: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-intermediate-2.md: parameterized mapping-task workbook and incremental tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with mapping tasks and commit watermarks. Use the glossary below, then write your prediction for: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Informatica Data Integration Developer role interview. Explain mapping tasks and commit watermarks using this case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate mapping tasks and commit watermarks to a system or workflow you know. Explain mapping tasks and commit watermarks using this case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement.

Interview: Explain mapping tasks and commit watermarks using this case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success.

Ignore the failing case and keep only the successful screenshot.

Three target orders totaling 37 and watermark 3 in the local model.

Treat any successful command as proof that all business and access rules passed.

Reference: Three target orders totaling 37 and watermark 3 in the local model. — A mapping task supplies runtime configuration to execute a mapping. An incremental checkpoint must advance only after successful target work and reconciliation; late-arriving corrections need an additional policy. Three target orders totaling 37 and watermark 3 in the local model.

Sources:

Informatica CDI Tasks guide (April 2025 edition; portal access may be required): https://docs.informatica.com/content/dam/source/GUID-0/GUID-0E9D5DC7-01A2-4D15-816E-3F3515FF9D2D/62/en/CDI_April2025_Tasks_en.pdf

Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html

Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Task orchestration and recovery: Dependencies, retries and environment parameters turn mappings into an operational pipeline. Preserve evidence of each run.

CDI: Cloud Data Integration, a service in Informatica IDMC.

Secure Agent: Informatica runtime software used for supported integration tasks; requirements depend on the connector and runtime option.

Watermark: A saved processing boundary. It must reflect successfully completed work and does not automatically capture deletes or late corrections.

Failure recovery and environment promotion: An agent or target failure can leave partial work unless the connector/transaction policy prevents it. Preserve run identifiers, rejected records and checkpoints; promote mappings with environment-specific connections reviewed separately.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. The practical workshop develops this into: Run advanced, use --broken to advance the watermark before the failed commit, and investigate the failing assertion. Restore commit ordering and write an IDMC taskflow recovery/promotion plan with actual connector guarantees marked for verification.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: A failed conveyor needs both a batch ledger and a safe restart point.

An agent or target failure can leave partial work unless the connector/transaction policy prevents it. Preserve run identifiers, rejected records and checkpoints; promote mappings with environment-specific connections reviewed separately.

Worked example: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Informatica IDMC Cloud Data Integration and Secure Agent (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Informatica Data Integration Developer: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3.

Predict the worked case

Read this case without running a tool: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Informatica Data Integration Developer role interview. Explain transaction and recovery using this case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. State the evidence, one alternative and where the mental model stops.

Quiz: After the Failure recovery and environment promotion rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Informatica CDI Tasks guide (April 2025 edition; portal access may be required): https://docs.informatica.com/content/dam/source/GUID-0/GUID-0E9D5DC7-01A2-4D15-816E-3F3515FF9D2D/62/en/CDI_April2025_Tasks_en.pdf

Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html

Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html

### Failure recovery and environment promotion

An agent or target failure can leave partial work unless the connector/transaction policy prevents it. Preserve run identifiers, rejected records and checkpoints; promote mappings with environment-specific connections reviewed separately. In this role, work through: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. The practical workshop develops this into: Run advanced, use --broken to advance the watermark before the failed commit, and investigate the failing assertion. Restore commit ordering and write an IDMC taskflow recovery/promotion plan with actual connector guarantees marked for verification.

Mental model: A failed conveyor needs both a batch ledger and a safe restart point.

Boundary: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects.

Worked example: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Informatica IDMC Cloud Data Integration and Secure Agent (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run advanced, use --broken to advance the watermark before the failed commit, and investigate the failing assertion. Restore commit ordering and write an IDMC taskflow recovery/promotion plan with actual connector guarantees marked for verification.

Inspect the business fixture

An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run advanced, use --broken to advance the watermark before the failed commit, and investigate the failing assertion. Restore commit ordering and write an IDMC taskflow recovery/promotion plan with actual connector guarantees marked for verification.

```
python3 enterprise_lab.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Rollback preserves the baseline; replay produces the corrected target without double counting.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py advanced --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Recover and promote safely

In a test connection, simulate a safe target-unavailable condition without disrupting a shared agent. Inspect run/error logs, reconcile partial target writes and restore connectivity. Replay by stable business key; review connection/parameter substitutions before promotion.

Expected: The replay matches the intended target and checkpoint policy; the runbook states whether the connector supports atomic rollback or requires compensating reconciliation.

Assemble the portfolio evidence

Create CDI failure/replay report and environment promotion runbook. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Rollback preserves the baseline; replay produces the corrected target without double counting.

Expected: Rollback preserves the baseline; replay produces the corrected target without double counting.

Troubleshoot: The role exercise differs from the prediction: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-advanced-2.md: CDI failure/replay report and environment promotion runbook; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure recovery and environment promotion. Use the glossary below, then write your prediction for: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Informatica Data Integration Developer role interview. Explain failure recovery and environment promotion using this case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure recovery and environment promotion to a system or workflow you know. Explain failure recovery and environment promotion using this case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects.

Interview: Explain failure recovery and environment promotion using this case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Rollback preserves the baseline; replay produces the corrected target without double counting.

Reference: Rollback preserves the baseline; replay produces the corrected target without double counting. — An agent or target failure can leave partial work unless the connector/transaction policy prevents it. Preserve run identifiers, rejected records and checkpoints; promote mappings with environment-specific connections reviewed separately. Rollback preserves the baseline; replay produces the corrected target without double counting.

Sources:

Informatica CDI Tasks guide (April 2025 edition; portal access may be required): https://docs.informatica.com/content/dam/source/GUID-0/GUID-0E9D5DC7-01A2-4D15-816E-3F3515FF9D2D/62/en/CDI_April2025_Tasks_en.pdf

Informatica University: CDI course overview (R37 edition; check current training access): https://now.informatica.com/IICS-Cloud-Data-Integration-Services-R37-onDemand.html

Informatica Cloud Data Integration documentation: https://docs.informatica.com/integration-cloud/cloud-data-integration/current-version.html
