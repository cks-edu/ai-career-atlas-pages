# Informatica Data Integration Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Mapping, typing and rejection paths

A CDI mapping connects source, transformations and target. Define field types and rejection routes before arranging transformations. The local Python model teaches the contract; it is not an Informatica runtime or connector test.
Mental model: A sorting line needs labels, inspection rules and a reject bin as well as a conveyor.
Case: Rows a=10,b=20,a=10,c=-5,d=ten yield two accepted unique orders, one duplicate and two rejected rows.
Task: Run beginner, inspect Decimal conversion and rejection reasons, then draw Source → validation/expression → valid target and reject target. Map each branch to the CDI tools available in your authorized environment.
Acceptance: 5 input = 2 accepted + 1 duplicate + 2 rejected; accepted total 30.
Troubleshooting: A filter that simply discards invalid rows loses reconciliation evidence; retain identifiers and reasons.
Deliverable: mapping specification and accepted/rejected outputs

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Mapping tasks and commit watermarks

A mapping task supplies runtime configuration to execute a mapping. An incremental checkpoint must advance only after successful target work and reconciliation; late-arriving corrections need an additional policy.
Mental model: The bookmark moves only after the page has actually been read and checked.
Case: A correction changes a from 10 to 12 and adds e=5, producing total 37; watermark moves from 1 to 3 after success.
Task: Run intermediate, inspect versioned upsert and checkpoint order. In authorized CDI create a mapping task, choose the approved runtime, bind parameters and inspect source/target configuration before running a synthetic batch.
Acceptance: Three target orders totaling 37 and watermark 3 in the local model.
Troubleshooting: A valid-looking task can still have an unset parameter; inspect every task binding and connector requirement.
Deliverable: parameterized mapping-task workbook and incremental tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Failure recovery and environment promotion

An agent or target failure can leave partial work unless the connector/transaction policy prevents it. Preserve run identifiers, rejected records and checkpoints; promote mappings with environment-specific connections reviewed separately.
Mental model: A failed conveyor needs both a batch ledger and a safe restart point.
Case: An injected target failure leaves the baseline target total 30 and watermark 1; repaired replay reaches total 37 and watermark 3.
Task: Run advanced, use --broken to advance the watermark before the failed commit, and investigate the failing assertion. Restore commit ordering and write an IDMC taskflow recovery/promotion plan with actual connector guarantees marked for verification.
Acceptance: Rollback preserves the baseline; replay produces the corrected target without double counting.
Troubleshooting: Do not claim every Informatica connector gives one atomic transaction; verify its documented behavior and reconcile partial effects.
Deliverable: CDI failure/replay report and environment promotion runbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
