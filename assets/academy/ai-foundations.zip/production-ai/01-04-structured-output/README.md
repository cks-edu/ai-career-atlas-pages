# Valid JSON is only the first check

A model may return valid JSON with the wrong fields or an unsupported claim. First parse the text, then validate its shape and permitted values. Only after those checks should you examine factual support. In this task the response must contain exactly answer and sourceId.

Use an exact field set, check types, and require the source ID to exist in the permitted evidence set. Unknown keys and unknown source IDs are rejected. This proves structural and membership checks, not the truth of the answer.

Task: Implement validAnswer. Save one valid case and three rejection cases, then write a claim that has a real source ID but lacks support.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Generated text → JSON parser → schema → permitted source check.
State: Parsed answer and source ID remain untrusted until checked.
Boundary: Syntax, schema and factual support are different boundaries.
Failure: A valid JSON object cites an invented document.
Control: Require exact keys, text types and a permitted source ID.
Observability: Count parse, schema and support failures separately.
Blast radius: The current answer; publishing unchecked outputs increases reach.
Trade-off: A strict schema simplifies integration but cannot establish truth.

Limit: A citation can exist while failing to support the sentence. A human or task-specific evidence check still has to compare the claim with the source.

Sources:
https://json-schema.org/understanding-json-schema/reference/object
https://www.nist.gov/itl/ai-risk-management-framework
