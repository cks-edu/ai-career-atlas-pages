function validAnswer(text, allowedSources) {
  try {
    const a = JSON.parse(text);
    return !!a && !Array.isArray(a) && Object.keys(a).sort().join(',') === 'answer,sourceId' &&
      typeof a.answer === 'string' && a.answer.trim().length > 0 &&
      typeof a.sourceId === 'string' && allowedSources.includes(a.sourceId);
  } catch { return false; }
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(validAnswer('{"answer":"Check the lesson","sourceId":"s1"}',['s1']));
console.log("PASS: A supported-shaped answer is admitted");
}
{
assert(!validAnswer('{"answer":"Yes","sourceId":"invented"}',['s1'])); assert(!validAnswer('{"answer":"Yes","sourceId":"s1","admin":true}',['s1']));
console.log("PASS: Unknown sources and extra fields are denied");
}
{
assert(!validAnswer('oops',['s1'])); assert(!validAnswer('null',['s1'])); assert(!validAnswer('{"answer":1,"sourceId":"s1"}',['s1']));
console.log("PASS: Malformed and wrong-type responses fail");
}
