# A model proposes; your application decides

An LLM predicts tokens from its input. A fluent answer is not permission to update an account, nor proof that a claim is true. Treat the model’s output as a proposal. Your application checks the request, permitted action and result before it changes anything.

Follow one request through input → model proposal → validator → action. The validator is ordinary code with an explicit allowlist. Reject an unknown operation before calling a tool. In the sandbox you implement that validator without contacting a model.

Task: Implement allowProposal. Trace a valid read and a forbidden delete; add an unknown operation test.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: User input → proposed action → policy check → tool.
State: A proposal carries operation and account; the principal holds allowed operations.
Boundary: Model text cannot expand the caller’s permissions.
Failure: A delete request is proposed by a read-only assistant.
Control: Reject unknown or unauthorized actions before dispatch.
Observability: Record the operation, policy decision and request ID without private payloads.
Blast radius: The one request; shared credentials would widen the impact.
Trade-off: Explicit policies constrain flexibility but make side effects reviewable.

Limit: An allowlisted action still needs authenticated user and resource checks. This synthetic validator is not an identity provider.

Sources:
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
https://huggingface.co/docs/transformers/llm_tutorial
