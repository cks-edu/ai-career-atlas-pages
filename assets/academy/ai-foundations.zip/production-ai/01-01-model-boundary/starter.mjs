function allowProposal(proposal, allowed) {
  return true; // Replace with the permission check.
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(allowProposal({operation:'read'},['read']) === true);
console.log("PASS: A permitted read succeeds");
}
{
assert(allowProposal({operation:'delete'},['read']) === false);
console.log("PASS: A proposed delete is denied");
}
{
assert(allowProposal(null,['read']) === false); assert(allowProposal({},['read']) === false);
console.log("PASS: Missing input is rejected");
}
