function evidenceIds(hits, tenant, threshold) {
  return hits.map(h => h.id); // Apply permission and score filters first.
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(JSON.stringify(evidenceIds([{id:'a',tenant:'t1',score:.9}], 't1',.7)) === '["a"]');
console.log("PASS: Permitted relevant evidence is retained");
}
{
assert(evidenceIds([{id:'private',tenant:'t2',score:1}], 't1',.7).length === 0);
console.log("PASS: Another tenant is excluded");
}
{
assert(evidenceIds([{id:'a',tenant:'t1',score:.2},{id:'b',tenant:'t1',score:NaN}], 't1',.7).length === 0);
console.log("PASS: Weak or invalid evidence abstains");
}
