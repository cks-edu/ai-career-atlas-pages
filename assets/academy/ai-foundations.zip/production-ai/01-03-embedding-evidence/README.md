# Embeddings find candidates, not truth

An embedding represents an item as numbers so a search system can compare items. A high similarity score suggests a useful candidate; it does not prove the document is correct, current or visible to this user. Apply access filters before selecting evidence.

Filter synthetic search hits by authenticated tenant and a declared score threshold. Return no evidence when nothing qualifies. The toy score is provided by the fixture; it does not calculate an embedding or claim a universal similarity threshold.

Task: Implement the tenant and relevance filter. Add a no-evidence result and explain why it must remain explicit.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Question → candidate hits → access filter → evidence IDs.
State: Each hit has tenant, ID and an illustrative relevance score.
Boundary: Relevance cannot override document permissions.
Failure: The nearest hit belongs to a different customer.
Control: Filter by trusted tenant before selecting answer context.
Observability: Log permitted hit IDs, revision and no-evidence decisions.
Blast radius: One tenant’s documents; cross-tenant retrieval can expose private data.
Trade-off: A stricter threshold reduces weak evidence but may miss relevant sources.

Limit: A score threshold must be calibrated on your corpus and task. Authorization comes from trusted session data, not from the generated query.

Sources:
https://qdrant.tech/documentation/manage-data/vectors/
https://qdrant.tech/documentation/search/filtering/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
