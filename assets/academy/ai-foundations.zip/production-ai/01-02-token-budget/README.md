# Tokens, context windows and a budget you can explain

A token is a model-specific text unit, not a word. Input and generated output share a model’s finite context capacity. Leave room for the answer and reject an oversized request explicitly. The numbers in this lab are supplied token counts; they are not a tokenizer.

Add system instructions, user text and retrieved context to obtain input usage. Check that input plus reserved output fits the selected model limit. The boundary is inclusive: exactly at capacity fits; one token beyond does not.

Task: Implement fitsContext and test 999, 1,000 and 1,001 combined tokens. Explain where your counts came from.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Count supplied input tokens → reserve output → admit or reject.
State: Input, reserved output and model capacity are nonnegative integers.
Boundary: A character count is not a token count.
Failure: Retrieved text consumes the answer’s reserved capacity.
Control: Validate counts and enforce input + reserve ≤ capacity.
Observability: Track token estimates, actual provider usage and rejection reason separately.
Blast radius: This request; a shared unbounded budget can exhaust the service.
Trade-off: More context may help evidence but raises latency and resource use.

Limit: Real tokenization depends on the selected model, chat template and tools. Reasoning tokens, caches and billing rules may add separate constraints.

Sources:
https://huggingface.co/docs/transformers/llm_tutorial
