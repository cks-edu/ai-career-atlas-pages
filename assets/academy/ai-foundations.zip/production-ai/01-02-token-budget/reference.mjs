function fitsContext(input, reserve, capacity) {
  return [input,reserve,capacity].every(n => Number.isSafeInteger(n) && n >= 0) &&
    input + reserve <= capacity;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(fitsContext(600,200,1000));
console.log("PASS: Ordinary request fits");
}
{
assert(fitsContext(800,200,1000)); assert(!fitsContext(801,200,1000));
console.log("PASS: Exact boundary and overflow differ");
}
{
assert(!fitsContext(-1,200,1000)); assert(!fitsContext(NaN,200,1000)); assert(!fitsContext(1.5,2,100));
console.log("PASS: Invalid counts fail closed");
}
