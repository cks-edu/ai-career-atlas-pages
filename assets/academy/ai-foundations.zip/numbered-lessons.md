# AI Foundations & System Mental Models — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: No AI background is required. Basic file navigation is enough to read; the optional browser code exercise uses simple JavaScript functions.

Terms:

LLM: A language model that predicts tokens; it is not an authorization system.

deterministic: The same input and rules produce the same decision.

token: A model-specific unit of text processing.

context window: The model’s supported input/output context capacity.

embedding: A numeric representation used for comparisons.

abstain: Return no supported answer rather than inventing one.

schema: Rules for expected fields, types and values.

citation: A pointer to evidence that must be inspected.

### A model proposes; your application decides

An LLM predicts tokens from its input. A fluent answer is not permission to update an account, nor proof that a claim is true. Treat the model’s output as a proposal. Your application checks the request, permitted action and result before it changes anything.

Follow one request through input → model proposal → validator → action. The validator is ordinary code with an explicit allowlist. Reject an unknown operation before calling a tool. In the sandbox you implement that validator without contacting a model.

An allowlisted action still needs authenticated user and resource checks. This synthetic validator is not an identity provider.

Mental model: User input → proposed action → policy check → tool. Picture the boundary as a checked gate between stages.

Boundary: An allowlisted action still needs authenticated user and resource checks. This synthetic validator is not an identity provider.

Worked example: function allowProposal(proposal, allowed) {
  return !!proposal && typeof proposal.operation === 'string' &&
    Array.isArray(allowed) && allowed.includes(proposal.operation);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-foundations.zip, install Node.js LTS, then open production-ai/01-01-model-boundary.

Tools for this exercise: JavaScript · local isolated workbench; JavaScript, Hugging Face Transformers as documented optional extensions

Course tool and framework map: JavaScript (Open standard · local); Hugging Face Transformers (Open source · hardware dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement allowProposal. Trace a valid read and a forbidden delete; add an unknown operation test.

Terminal folder: production-ai/01-01-model-boundary

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Follow one request through input → model proposal → validator → action. The validator is ordinary code with an explicit allowlist. Reject an unknown operation before calling a tool. In the sandbox you implement that validator without contacting a model.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement allowProposal. Trace a valid read and a forbidden delete; add an unknown operation test.

Expected: A permitted read succeeds

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: A proposed delete is denied; Missing input is rejected

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A permitted read succeeds; A proposed delete is denied; Missing input is rejected. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Reject unknown or unauthorized actions before dispatch. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/01-01-model-boundary/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: User input → proposed action → policy check → tool. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A model asks a read-only service to delete an account. What should the application do? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Model text cannot expand the caller’s permissions. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A model asks a read-only service to delete an account. What should the application do?

Interview: A model asks a read-only service to delete an account. What should the application do? Explain the decision, a failing case and a production limitation.

Quiz: A model asks a read-only service to delete an account. What should the application do?

Trust the confident wording.

Reject the operation in application policy.

Ask the model to rename delete as read.

Reference: Reject the operation in application policy. — The caller’s permissions govern execution. Confidence and wording cannot create permission.

Sources:

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

Hugging Face: LLM inference concepts: https://huggingface.co/docs/transformers/llm_tutorial

### Tokens, context windows and a budget you can explain

A token is a model-specific text unit, not a word. Input and generated output share a model’s finite context capacity. Leave room for the answer and reject an oversized request explicitly. The numbers in this lab are supplied token counts; they are not a tokenizer.

Add system instructions, user text and retrieved context to obtain input usage. Check that input plus reserved output fits the selected model limit. The boundary is inclusive: exactly at capacity fits; one token beyond does not.

Real tokenization depends on the selected model, chat template and tools. Reasoning tokens, caches and billing rules may add separate constraints.

Mental model: Count supplied input tokens → reserve output → admit or reject. Picture the boundary as a checked gate between stages.

Boundary: Real tokenization depends on the selected model, chat template and tools. Reasoning tokens, caches and billing rules may add separate constraints.

Worked example: function fitsContext(input, reserve, capacity) {
  return [input,reserve,capacity].every(n => Number.isSafeInteger(n) && n >= 0) &&
    input + reserve <= capacity;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-foundations.zip, install Node.js LTS, then open production-ai/01-02-token-budget.

Tools for this exercise: JavaScript · local isolated workbench; JavaScript, Hugging Face Transformers as documented optional extensions

Course tool and framework map: JavaScript (Open standard · local); Hugging Face Transformers (Open source · hardware dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement fitsContext and test 999, 1,000 and 1,001 combined tokens. Explain where your counts came from.

Terminal folder: production-ai/01-02-token-budget

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Add system instructions, user text and retrieved context to obtain input usage. Check that input plus reserved output fits the selected model limit. The boundary is inclusive: exactly at capacity fits; one token beyond does not.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement fitsContext and test 999, 1,000 and 1,001 combined tokens. Explain where your counts came from.

Expected: Ordinary request fits

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Exact boundary and overflow differ; Invalid counts fail closed

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Ordinary request fits; Exact boundary and overflow differ; Invalid counts fail closed. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Validate counts and enforce input + reserve ≤ capacity. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/01-02-token-budget/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Count supplied input tokens → reserve output → admit or reject. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Input uses 900 tokens and the answer reserve is 200 in a 1,000-token window. What is safe? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A character count is not a token count. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Input uses 900 tokens and the answer reserve is 200 in a 1,000-token window. What is safe?

Interview: Input uses 900 tokens and the answer reserve is 200 in a 1,000-token window. What is safe? Explain the decision, a failing case and a production limitation.

Quiz: Input uses 900 tokens and the answer reserve is 200 in a 1,000-token window. What is safe?

Send it; the input alone fits.

Assume 200 words means 200 tokens.

Reduce input or change the permitted model; the combined budget does not fit.

Reference: Reduce input or change the permitted model; the combined budget does not fit. — Input and output capacity must be planned together. Count with the actual tokenizer before real inference.

Sources:

Hugging Face: LLM inference concepts: https://huggingface.co/docs/transformers/llm_tutorial

### Embeddings find candidates, not truth

An embedding represents an item as numbers so a search system can compare items. A high similarity score suggests a useful candidate; it does not prove the document is correct, current or visible to this user. Apply access filters before selecting evidence.

Filter synthetic search hits by authenticated tenant and a declared score threshold. Return no evidence when nothing qualifies. The toy score is provided by the fixture; it does not calculate an embedding or claim a universal similarity threshold.

A score threshold must be calibrated on your corpus and task. Authorization comes from trusted session data, not from the generated query.

Mental model: Question → candidate hits → access filter → evidence IDs. Picture the boundary as a checked gate between stages.

Boundary: A score threshold must be calibrated on your corpus and task. Authorization comes from trusted session data, not from the generated query.

Worked example: function evidenceIds(hits, tenant, threshold) {
  return hits.filter(h => h.tenant === tenant && Number.isFinite(h.score) &&
    h.score >= threshold).map(h => h.id);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-foundations.zip, install Node.js LTS, then open production-ai/01-03-embedding-evidence.

Tools for this exercise: JavaScript · local isolated workbench; JavaScript, Hugging Face Transformers as documented optional extensions

Course tool and framework map: JavaScript (Open standard · local); Hugging Face Transformers (Open source · hardware dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement the tenant and relevance filter. Add a no-evidence result and explain why it must remain explicit.

Terminal folder: production-ai/01-03-embedding-evidence

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Filter synthetic search hits by authenticated tenant and a declared score threshold. Return no evidence when nothing qualifies. The toy score is provided by the fixture; it does not calculate an embedding or claim a universal similarity threshold.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement the tenant and relevance filter. Add a no-evidence result and explain why it must remain explicit.

Expected: Permitted relevant evidence is retained

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Another tenant is excluded; Weak or invalid evidence abstains

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Permitted relevant evidence is retained; Another tenant is excluded; Weak or invalid evidence abstains. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Filter by trusted tenant before selecting answer context. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/01-03-embedding-evidence/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Question → candidate hits → access filter → evidence IDs. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A high-scoring document belongs to another customer. Should it enter the model context? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Relevance cannot override document permissions. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A high-scoring document belongs to another customer. Should it enter the model context?

Interview: A high-scoring document belongs to another customer. Should it enter the model context? Explain the decision, a failing case and a production limitation.

Quiz: A high-scoring document belongs to another customer. Should it enter the model context?

No; apply authorization before context assembly.

Yes; relevance is enough.

Yes, if the answer omits its title.

Reference: No; apply authorization before context assembly. — Similarity is a relevance signal, not a permission. Excluding an unauthorized title after generation is too late.

Sources:

Qdrant: vectors and similarity representations: https://qdrant.tech/documentation/manage-data/vectors/

Qdrant: filtering and payloads: https://qdrant.tech/documentation/search/filtering/

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Valid JSON is only the first check

A model may return valid JSON with the wrong fields or an unsupported claim. First parse the text, then validate its shape and permitted values. Only after those checks should you examine factual support. In this task the response must contain exactly answer and sourceId.

Use an exact field set, check types, and require the source ID to exist in the permitted evidence set. Unknown keys and unknown source IDs are rejected. This proves structural and membership checks, not the truth of the answer.

A citation can exist while failing to support the sentence. A human or task-specific evidence check still has to compare the claim with the source.

Mental model: Generated text → JSON parser → schema → permitted source check. Picture the boundary as a checked gate between stages.

Boundary: A citation can exist while failing to support the sentence. A human or task-specific evidence check still has to compare the claim with the source.

Worked example: function validAnswer(text, allowedSources) {
  try {
    const a = JSON.parse(text);
    return !!a && !Array.isArray(a) && Object.keys(a).sort().join(',') === 'answer,sourceId' &&
      typeof a.answer === 'string' && a.answer.trim().length > 0 &&
      typeof a.sourceId === 'string' && allowedSources.includes(a.sourceId);
  } catch { return false; }
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-foundations.zip, install Node.js LTS, then open production-ai/01-04-structured-output.

Tools for this exercise: JavaScript · local isolated workbench; JavaScript, Hugging Face Transformers as documented optional extensions

Course tool and framework map: JavaScript (Open standard · local); Hugging Face Transformers (Open source · hardware dependent)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement validAnswer. Save one valid case and three rejection cases, then write a claim that has a real source ID but lacks support.

Terminal folder: production-ai/01-04-structured-output

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Use an exact field set, check types, and require the source ID to exist in the permitted evidence set. Unknown keys and unknown source IDs are rejected. This proves structural and membership checks, not the truth of the answer.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement validAnswer. Save one valid case and three rejection cases, then write a claim that has a real source ID but lacks support.

Expected: A supported-shaped answer is admitted

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Unknown sources and extra fields are denied; Malformed and wrong-type responses fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A supported-shaped answer is admitted; Unknown sources and extra fields are denied; Malformed and wrong-type responses fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require exact keys, text types and a permitted source ID. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/01-04-structured-output/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Generated text → JSON parser → schema → permitted source check. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. An answer passes JSON schema validation and cites a known source. What is still unknown? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Syntax, schema and factual support are different boundaries. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: An answer passes JSON schema validation and cites a known source. What is still unknown?

Interview: An answer passes JSON schema validation and cites a known source. What is still unknown? Explain the decision, a failing case and a production limitation.

Quiz: An answer passes JSON schema validation and cites a known source. What is still unknown?

Whether parsing succeeded.

Whether the source actually supports its claim.

Whether the object has the required fields.

Reference: Whether the source actually supports its claim. — Shape and source membership are useful checks; neither proves that the statement follows from the source.

Sources:

JSON Schema: object validation: https://json-schema.org/understanding-json-schema/reference/object

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
